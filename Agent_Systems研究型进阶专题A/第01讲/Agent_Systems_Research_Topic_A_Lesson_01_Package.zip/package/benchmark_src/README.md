# 专题A第1讲：真实 Agent Benchmark 最小闭环

目标：先在本地跑通 `Task -> Agent -> Tool -> Trace -> Evaluator -> Metrics`，再接入真实模型 API。

## 1. 本地 Mock 模式（推荐第一步）

```bash
python run_benchmark.py --backend mock
python analyze_results.py
```

运行后生成：

- `outputs/results.jsonl`：每个任务的结果与完整 trace
- `outputs/traces.jsonl`：独立 trace 文件
- `outputs/summary.json`：聚合指标

## 2. OpenAI-compatible API 模式（可选）

先配置环境变量（下面只是变量名示例，不要把密钥写进代码）：

Linux/macOS:

```bash
export AGENT_API_BASE="https://YOUR_PROVIDER/v1"
export AGENT_API_KEY="YOUR_KEY"
export AGENT_MODEL="YOUR_MODEL"
python run_benchmark.py --backend openai-compatible
```

Windows PowerShell:

```powershell
$env:AGENT_API_BASE="https://YOUR_PROVIDER/v1"
$env:AGENT_API_KEY="YOUR_KEY"
$env:AGENT_MODEL="YOUR_MODEL"
python run_benchmark.py --backend openai-compatible
```

> 不同供应商对 OpenAI-compatible 接口的兼容程度并不完全相同。若接口路径或返回 JSON 不一致，只改 `OpenAICompatibleAgent._chat()`，不要改 Task / Evaluator / Trace 数据结构。

## 3. 这份代码故意保持最小化

它不是为了“做出一个厉害的 Agent”，而是为了验证实验基础设施。真正科研时再逐步增加：

- 多模型、多随机种子
- 更真实的任务集
- 超时/重试/预算限制
- token / cost / latency
- Judge evaluator + deterministic evaluator
- 扰动实验、消融实验
- 错误类型标注与 trace-level 分析
