#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""读取 outputs/results.jsonl，输出最基础的失败分析。"""
import json
from collections import Counter, defaultdict
from pathlib import Path

ROOT = Path(__file__).resolve().parent
path = ROOT / "outputs" / "results.jsonl"

if not path.exists():
    raise SystemExit("请先运行：python run_benchmark.py --backend mock")

rows = [json.loads(line) for line in path.read_text(encoding="utf-8").splitlines() if line.strip()]

print("=== Overall ===")
print(f"tasks={len(rows)}")
print(f"success={sum(r['success'] for r in rows)}")
print(f"accuracy={sum(r['success'] for r in rows)/len(rows):.3f}")

print("\n=== By category ===")
bucket = defaultdict(list)
for r in rows:
    bucket[r["category"]].append(r)
for cat, xs in sorted(bucket.items()):
    acc = sum(x["success"] for x in xs) / len(xs)
    print(f"{cat:16s} n={len(xs):2d} acc={acc:.3f}")

print("\n=== Error types ===")
errors = Counter(r["error_type"] or "success" for r in rows)
for k, v in errors.most_common():
    print(f"{k:24s} {v}")

print("\n=== Failed traces ===")
for r in rows:
    if not r["success"]:
        print(f"\n[{r['task_id']}] expected={r['expected']} prediction={r['prediction']}")
        for step in r["trace"]:
            print(step)
