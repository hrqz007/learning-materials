#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""专题A第1讲：最小 Agent Benchmark 闭环。

默认：python run_benchmark.py --backend mock
可选：python run_benchmark.py --backend openai-compatible

openai-compatible 模式通过环境变量读取：
  AGENT_API_BASE   例如 https://api.example.com/v1
  AGENT_API_KEY
  AGENT_MODEL
"""

from __future__ import annotations

import argparse
import ast
import json
import os
import re
import time
import urllib.request
from dataclasses import dataclass
from pathlib import Path
from typing import Any, Dict, List
from urllib.parse import urlparse

ROOT = Path(__file__).resolve().parent
TASKS_FILE = ROOT / "tasks.jsonl"
OUTPUT_DIR = ROOT / "outputs"


def load_tasks(path: Path) -> List[Dict[str, Any]]:
    tasks = []
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            line = line.strip()
            if line:
                tasks.append(json.loads(line))
    return tasks


def safe_arithmetic(expr: str) -> str:
    """只允许数字与 + - * / ()，避免直接 eval 任意代码。"""
    if not re.fullmatch(r"[0-9+\-*/().\s]+", expr):
        raise ValueError(f"Unsafe expression: {expr}")
    tree = ast.parse(expr, mode="eval")
    allowed = (
        ast.Expression,
        ast.BinOp,
        ast.UnaryOp,
        ast.Constant,
        ast.Add,
        ast.Sub,
        ast.Mult,
        ast.Div,
        ast.USub,
        ast.UAdd,
        ast.Load,
    )
    if not all(isinstance(node, allowed) for node in ast.walk(tree)):
        raise ValueError("Expression contains unsupported syntax")
    value = eval(compile(tree, "<expr>", "eval"), {"__builtins__": {}}, {})
    if isinstance(value, float) and value.is_integer():
        return str(int(value))
    return str(value)


def tool_calculator(expression: str) -> str:
    return safe_arithmetic(expression)


def tool_word_count(text: str) -> str:
    words = re.findall(r"\b[\w'-]+\b", text, flags=re.UNICODE)
    return str(len(words))


def tool_sort_numbers(numbers: List[float]) -> str:
    ordered = sorted(numbers)
    return ",".join(str(int(x)) if float(x).is_integer() else str(x) for x in ordered)


def tool_max_number(numbers: List[float]) -> str:
    value = max(numbers)
    return str(int(value)) if float(value).is_integer() else str(value)


def tool_extract_domain(url: str) -> str:
    return urlparse(url).netloc


TOOLS = {
    "calculator": tool_calculator,
    "word_count": tool_word_count,
    "sort_numbers": tool_sort_numbers,
    "max_number": tool_max_number,
    "extract_domain": tool_extract_domain,
}


@dataclass
class AgentAction:
    tool: str
    arguments: Dict[str, Any]


class MockAgent:
    """不调用大模型，只根据任务字段选择工具，用于先验证 Harness。"""

    def decide(self, task: Dict[str, Any]) -> AgentAction:
        category = task["category"]
        if category == "calculator":
            # 从中文 instruction 中抽出“计算 ...，”中间表达式。
            m = re.search(r"计算\s*(.+?)[，,]", task["instruction"])
            expression = m.group(1) if m else task["instruction"].replace("计算", "")
            return AgentAction("calculator", {"expression": expression.strip()})
        if category == "word_count":
            return AgentAction("word_count", {"text": task["text"]})
        if category == "sort_numbers":
            return AgentAction("sort_numbers", {"numbers": task["numbers"]})
        if category == "max_number":
            return AgentAction("max_number", {"numbers": task["numbers"]})
        if category == "extract_domain":
            return AgentAction("extract_domain", {"url": task["url"]})
        raise ValueError(f"Unknown category: {category}")

    def finalize(self, task: Dict[str, Any], tool_result: str) -> str:
        return str(tool_result).strip()


class OpenAICompatibleAgent:
    """最小 OpenAI-compatible Chat Completions 客户端；不依赖第三方 SDK。"""

    def __init__(self) -> None:
        self.base = os.environ.get("AGENT_API_BASE", "").rstrip("/")
        self.key = os.environ.get("AGENT_API_KEY", "")
        self.model = os.environ.get("AGENT_MODEL", "")
        if not (self.base and self.key and self.model):
            raise RuntimeError(
                "缺少环境变量：AGENT_API_BASE / AGENT_API_KEY / AGENT_MODEL"
            )

    def _chat(self, messages: List[Dict[str, str]]) -> str:
        payload = {
            "model": self.model,
            "messages": messages,
            "temperature": 0,
        }
        req = urllib.request.Request(
            self.base + "/chat/completions",
            data=json.dumps(payload).encode("utf-8"),
            headers={
                "Authorization": f"Bearer {self.key}",
                "Content-Type": "application/json",
            },
            method="POST",
        )
        with urllib.request.urlopen(req, timeout=90) as resp:
            data = json.loads(resp.read().decode("utf-8"))
        return data["choices"][0]["message"]["content"]

    def decide(self, task: Dict[str, Any]) -> AgentAction:
        tool_specs = {
            "calculator": {"expression": "string"},
            "word_count": {"text": "string"},
            "sort_numbers": {"numbers": "number[]"},
            "max_number": {"numbers": "number[]"},
            "extract_domain": {"url": "string"},
        }
        prompt = (
            "你是一个研究用 Agent。根据任务选择且只选择一个工具。\n"
            f"可用工具与参数：{json.dumps(tool_specs, ensure_ascii=False)}\n"
            f"任务：{json.dumps(task, ensure_ascii=False)}\n"
            "只输出 JSON，不要 Markdown："
            '{"tool":"工具名","arguments":{...}}'
        )
        raw = self._chat([{"role": "user", "content": prompt}]).strip()
        raw = raw.removeprefix("```json").removeprefix("```").removesuffix("```").strip()
        obj = json.loads(raw)
        return AgentAction(tool=obj["tool"], arguments=obj["arguments"])

    def finalize(self, task: Dict[str, Any], tool_result: str) -> str:
        prompt = (
            "根据任务与工具返回值给出最终答案。严格遵守任务要求的输出格式，不要解释。\n"
            f"任务：{task['instruction']}\n"
            f"工具返回：{tool_result}"
        )
        return self._chat([{"role": "user", "content": prompt}]).strip()


def exact_match(pred: str, expected: str) -> bool:
    normalize = lambda s: re.sub(r"\s+", "", str(s)).strip().lower()
    return normalize(pred) == normalize(expected)


def run_one(task: Dict[str, Any], agent: Any) -> Dict[str, Any]:
    trace: List[Dict[str, Any]] = []
    t0 = time.perf_counter()
    error_type = None
    try:
        action = agent.decide(task)
        trace.append({"step": 1, "event": "agent_action", "tool": action.tool, "arguments": action.arguments})
        if action.tool not in TOOLS:
            raise ValueError(f"Unknown tool: {action.tool}")
        tool_result = TOOLS[action.tool](**action.arguments)
        trace.append({"step": 2, "event": "tool_result", "tool": action.tool, "result": tool_result})
        final_answer = agent.finalize(task, tool_result)
        trace.append({"step": 3, "event": "final_answer", "answer": final_answer})
        success = exact_match(final_answer, task["expected"])
        if not success:
            error_type = "wrong_final_answer"
    except Exception as e:
        final_answer = ""
        success = False
        error_type = type(e).__name__
        trace.append({"step": len(trace) + 1, "event": "exception", "error": repr(e)})
    latency_ms = round((time.perf_counter() - t0) * 1000, 2)
    return {
        "task_id": task["task_id"],
        "category": task["category"],
        "instruction": task["instruction"],
        "expected": task["expected"],
        "prediction": final_answer,
        "success": success,
        "error_type": error_type,
        "latency_ms": latency_ms,
        "trace": trace,
    }


def write_jsonl(path: Path, rows: List[Dict[str, Any]]) -> None:
    with path.open("w", encoding="utf-8") as f:
        for row in rows:
            f.write(json.dumps(row, ensure_ascii=False) + "\n")


def aggregate(results: List[Dict[str, Any]]) -> Dict[str, Any]:
    total = len(results)
    success = sum(1 for x in results if x["success"])
    by_category: Dict[str, Dict[str, int]] = {}
    for x in results:
        bucket = by_category.setdefault(x["category"], {"n": 0, "success": 0})
        bucket["n"] += 1
        bucket["success"] += int(x["success"])
    for bucket in by_category.values():
        bucket["accuracy"] = round(bucket["success"] / bucket["n"], 4)
    return {
        "n_tasks": total,
        "n_success": success,
        "accuracy": round(success / total, 4) if total else 0.0,
        "avg_latency_ms": round(sum(x["latency_ms"] for x in results) / total, 2) if total else 0.0,
        "by_category": by_category,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--backend", choices=["mock", "openai-compatible"], default="mock")
    parser.add_argument("--tasks", type=Path, default=TASKS_FILE)
    args = parser.parse_args()

    OUTPUT_DIR.mkdir(parents=True, exist_ok=True)
    tasks = load_tasks(args.tasks)
    agent = MockAgent() if args.backend == "mock" else OpenAICompatibleAgent()

    results = [run_one(task, agent) for task in tasks]
    summary = aggregate(results)

    write_jsonl(OUTPUT_DIR / "results.jsonl", results)
    traces = [
        {"task_id": row["task_id"], "trace": row["trace"]}
        for row in results
    ]
    write_jsonl(OUTPUT_DIR / "traces.jsonl", traces)
    (OUTPUT_DIR / "summary.json").write_text(
        json.dumps(summary, ensure_ascii=False, indent=2), encoding="utf-8"
    )

    print(json.dumps(summary, ensure_ascii=False, indent=2))
    print(f"\n结果已写入：{OUTPUT_DIR}")


if __name__ == "__main__":
    main()
