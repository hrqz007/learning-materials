# Agent Systems 研究型进阶专题 A-1

## 主题
真实 Agent Benchmark 实战——用当前 τ-bench 跑通 Task、Harness、Evaluator、Trajectory 与版本审计。

## 两条轨道
- A轨（已在本包实际运行）：无 API Key 的 τ-bench 风格 Preflight，熟悉 results.json / pass^k / failure audit。
- B轨（需要你本机联网和 API Key）：当前 Sierra Research 官方 τ-bench 实际 smoke run。

## 推荐顺序
1. 读 `01_零基础讲义.pdf`。
2. 运行 `python src/mini_tau_preflight.py`。
3. 运行 `python src/analyze_tau_results.py results/preflight_results.json --out-dir results/analysis`。
4. 运行 `version_guard.py` 理解版本可比性。
5. 安装官方 benchmark 后，先 dry-run `run_real_tau_bench.py`，检查命令；确认后再 `--execute`。
6. 真正跑完3–5个 task 后，先读失败 trajectory，不要立刻扩量。

## 重要说明
本包不重新分发官方任务数据，也没有替你调用付费 API。所有 `preflight_results.json` 数字均为受控教学模拟，不代表任何真实模型性能。

当前官方资料快照日期：2026-09-29。真实实验当天必须重新检查官方 README / release notes / CLI。
