# data 说明

本专题不重新分发官方 τ-bench 任务数据。真实运行时请从官方仓库获取当前版本数据。
本包的 `results/preflight_results.json` 是脚本生成的 τ-bench 风格教学数据，仅用于无 API 预演。
