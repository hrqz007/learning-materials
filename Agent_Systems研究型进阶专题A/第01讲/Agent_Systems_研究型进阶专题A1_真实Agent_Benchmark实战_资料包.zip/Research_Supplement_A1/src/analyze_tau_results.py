#!/usr/bin/env python3
"""分析 τ-bench 风格 results.json。
兼容本专题 fixture；对官方当前结果结构采用保守字段读取。
不会假设字段一定存在；缺失时用 NA。
"""
import json, argparse, csv, math
from pathlib import Path
from collections import defaultdict, Counter

EPS=1e-6
def successful(r): return r is not None and (1-EPS)<=float(r)<=(1+EPS)

def comb(n,k):
    if k<0 or k>n: return 0
    return math.comb(n,k)

def pass_hat_k(task_rewards, k, trials):
    vals=[]
    for task, rs in task_rewards.items():
        c=sum(successful(x) for x in rs)
        vals.append(comb(c,k)/comb(trials,k) if trials>=k else float('nan'))
    vals=[v for v in vals if not math.isnan(v)]
    return sum(vals)/len(vals) if vals else None

def get_reward(sim):
    ri=sim.get('reward_info') or {}
    return ri.get('reward')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('results_json')
    ap.add_argument('--out-dir',default='results/analysis')
    args=ap.parse_args()
    data=json.loads(Path(args.results_json).read_text(encoding='utf-8'))
    sims=data.get('simulations',[])
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    by_task=defaultdict(list); term=Counter(); failures=[]
    read_cor=read_tot=write_cor=write_tot=0
    trials=0
    for s in sims:
        r=get_reward(s); by_task[str(s.get('task_id'))].append(r)
        trials=max(trials, int(s.get('trial',0))+1)
        term[str(s.get('termination_reason','NA'))]+=1
        ri=s.get('reward_info') or {}; pr=ri.get('partial_action_reward') or {}
        rd=pr.get('read') or {}; wr=pr.get('write') or {}
        read_cor += int(rd.get('correct',0) or 0); read_tot += int(rd.get('count',0) or 0)
        write_cor += int(wr.get('correct',0) or 0); write_tot += int(wr.get('count',0) or 0)
        if not successful(r):
            failures.append({
              'simulation_id':s.get('id'),'task_id':s.get('task_id'),'trial':s.get('trial'),
              'reward':r,'termination_reason':s.get('termination_reason'),
              'difficulty':(s.get('info') or {}).get('difficulty','NA')
            })
    rewards=[get_reward(s) for s in sims if get_reward(s) is not None]
    metrics={
      'n_simulations':len(sims),'n_tasks':len(by_task),'num_trials_detected':trials,
      'average_reward':sum(map(float,rewards))/len(rewards) if rewards else None,
      'success_rate':sum(successful(r) for r in rewards)/len(rewards) if rewards else None,
      'pass_hat_k':{str(k):pass_hat_k(by_task,k,trials) for k in range(1,trials+1)},
      'read_action_accuracy':read_cor/read_tot if read_tot else None,
      'write_action_accuracy':write_cor/write_tot if write_tot else None,
      'termination_counts':dict(term),
      'note':'pass^k 采用任务级组合估计；真实研究需使用官方 compute_metrics 复核。'
    }
    (out/'metrics.json').write_text(json.dumps(metrics,ensure_ascii=False,indent=2),encoding='utf-8')
    with open(out/'failure_candidates.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=['simulation_id','task_id','trial','reward','termination_reason','difficulty']);w.writeheader();w.writerows(failures)
    print(json.dumps(metrics,ensure_ascii=False,indent=2))
    print(f"failure candidates: {len(failures)} -> {out/'failure_candidates.csv'}")
if __name__=='__main__': main()
