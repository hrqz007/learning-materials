#!/usr/bin/env python3
"""离线 τ-bench 风格 Preflight。

重要：这是受控教学模拟，不是官方 τ-bench，也不代表任何真实模型性能。
目的：在没有 API Key 时，先熟悉 results.json / trajectory / reward / pass^k 的数据闭环。
"""
import json, random, argparse
from pathlib import Path
from datetime import datetime

DIFF_P = {"easy":0.90, "medium":0.72, "hard":0.52}

def make_tasks(n=18):
    ds=[]
    levels=["easy","medium","hard"]
    for i in range(n):
        ds.append({
            "task_id": f"task_{i:03d}",
            "difficulty": levels[i%3],
            "needs_write": (i%2==0),
            "policy_case": ["refund","address_change","order_status"][i%3],
        })
    return ds

def run_one(task, trial, rng):
    p=DIFF_P[task['difficulty']]
    # 为了生成可分析的 failure trace，引入少量工具参数错误与 premature stop。
    arg_ok = rng.random() < (0.96 if task['difficulty']!='hard' else 0.88)
    policy_ok = rng.random() < (0.97 if task['difficulty']=='easy' else 0.91)
    success = rng.random() < p and arg_ok and policy_ok
    read_count=2 + (task['difficulty']=='hard')
    write_count=1 if task['needs_write'] else 0
    read_correct=read_count if rng.random()<0.94 else max(0,read_count-1)
    write_correct=write_count if (write_count==0 or arg_ok) else 0
    if success:
        term='user_stop'
    else:
        term=rng.choice(['agent_stop','max_steps','too_many_errors'])
    reward=1.0 if success else 0.0
    messages=[
      {"role":"user","content":f"教学任务 {task['task_id']}，场景={task['policy_case']}"},
      {"role":"assistant","content":"分析需求并选择工具。"},
      {"role":"tool","name":"lookup_record","arguments":{"id":task['task_id']},"result":"record_found"},
    ]
    if task['needs_write']:
        messages.append({"role":"tool","name":"update_record","arguments":{"valid":arg_ok},"result":"ok" if arg_ok else "schema_error"})
    return {
      "id": f"{task['task_id']}_trial_{trial}",
      "task_id": task['task_id'],
      "trial": trial,
      "reward_info": {
        "reward": reward,
        "db_check": {"db_match": bool(success or not task['needs_write'])},
        "action_checks": True,
        "partial_action_reward": {
          "read":{"correct":read_correct,"count":read_count},
          "write":{"correct":write_correct,"count":write_count},
          "total":{"correct":read_correct+write_correct,"count":read_count+write_count}
        }
      },
      "termination_reason": term,
      "messages": messages,
      "info": {"difficulty":task['difficulty'],"policy_case":task['policy_case'],"teaching_simulation":True}
    }

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--out', default='results/preflight_results.json')
    ap.add_argument('--tasks', type=int, default=18)
    ap.add_argument('--trials', type=int, default=4)
    ap.add_argument('--seed', type=int, default=20260929)
    args=ap.parse_args()
    rng=random.Random(args.seed)
    tasks=make_tasks(args.tasks)
    sims=[]
    for task in tasks:
        for trial in range(args.trials): sims.append(run_one(task, trial, rng))
    out={
      "benchmark":"TAU_STYLE_OFFLINE_PREFLIGHT",
      "benchmark_version":"teaching-1.0",
      "created_at":datetime.now().isoformat(timespec='seconds'),
      "disclaimer":"受控教学模拟；不是官方 τ-bench；不代表真实模型性能。",
      "info":{"seed":args.seed,"num_tasks":args.tasks,"num_trials":args.trials},
      "simulations":sims
    }
    p=Path(args.out); p.parent.mkdir(parents=True, exist_ok=True)
    p.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(f"wrote {len(sims)} simulations -> {p}")
if __name__=='__main__': main()
