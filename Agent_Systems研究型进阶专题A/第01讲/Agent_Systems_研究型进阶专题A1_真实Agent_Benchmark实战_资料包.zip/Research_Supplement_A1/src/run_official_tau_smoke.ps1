$ErrorActionPreference = "Stop"
if (-not $env:AGENT_LLM) { throw "请先设置 `$env:AGENT_LLM" }
if (-not $env:USER_LLM) { throw "请先设置 `$env:USER_LLM" }
$domain = if ($env:DOMAIN) {$env:DOMAIN} else {"airline"}
$numTasks = if ($env:NUM_TASKS) {$env:NUM_TASKS} else {"5"}
$numTrials = if ($env:NUM_TRIALS) {$env:NUM_TRIALS} else {"1"}
$saveTo = if ($env:SAVE_TO) {$env:SAVE_TO} else {"research_smoke"}
python src/run_real_tau_bench.py --domain $domain --agent-llm $env:AGENT_LLM --user-llm $env:USER_LLM --num-tasks $numTasks --num-trials $numTrials --save-to $saveTo --max-concurrency 1 --execute
