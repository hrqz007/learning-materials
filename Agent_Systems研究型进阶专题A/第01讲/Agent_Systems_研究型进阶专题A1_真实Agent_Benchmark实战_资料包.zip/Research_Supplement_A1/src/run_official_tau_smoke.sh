#!/usr/bin/env bash
set -euo pipefail
: "${AGENT_LLM:?请先 export AGENT_LLM=你的模型标识}"
: "${USER_LLM:?请先 export USER_LLM=你的用户模拟器模型标识}"
python src/run_real_tau_bench.py --domain "${DOMAIN:-airline}" --agent-llm "$AGENT_LLM" --user-llm "$USER_LLM" --num-tasks "${NUM_TASKS:-5}" --num-trials "${NUM_TRIALS:-1}" --save-to "${SAVE_TO:-research_smoke}" --max-concurrency 1 --execute
