#!/usr/bin/env python3
"""官方 τ-bench/τ³-bench 真实运行包装器。
默认只 dry-run；只有显式 --execute 才会调用本机 `tau2 run`。
不会读取或记录任何 API Key。
"""
import argparse, json, shutil, subprocess, sys, platform
from pathlib import Path
from datetime import datetime

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--domain',default='airline',choices=['mock','airline','retail','telecom','banking_knowledge'])
    ap.add_argument('--agent-llm',required=True,help='按你安装的 LiteLLM/provider 命名填写，不在脚本中硬编码模型')
    ap.add_argument('--user-llm',required=True)
    ap.add_argument('--num-tasks',type=int,default=5)
    ap.add_argument('--num-trials',type=int,default=1)
    ap.add_argument('--save-to',default='research_smoke')
    ap.add_argument('--max-concurrency',type=int,default=1)
    ap.add_argument('--execute',action='store_true')
    ap.add_argument('--manifest',default='results/real_run_manifest.json')
    a=ap.parse_args()
    cmd=['tau2','run','--domain',a.domain,'--agent-llm',a.agent_llm,'--user-llm',a.user_llm,
         '--num-trials',str(a.num_trials),'--num-tasks',str(a.num_tasks),'--save-to',a.save_to,
         '--max-concurrency',str(a.max_concurrency)]
    manifest={
      'created_at':datetime.now().isoformat(timespec='seconds'),'command':cmd,'domain':a.domain,
      'agent_llm':a.agent_llm,'user_llm':a.user_llm,'num_tasks':a.num_tasks,'num_trials':a.num_trials,
      'python':sys.version,'platform':platform.platform(),'tau2_path':shutil.which('tau2'),
      'api_keys_recorded':False,
      'note':'正式论文还应记录 benchmark tag/commit、task split、seed、pricing snapshot、evaluator version。'
    }
    p=Path(a.manifest);p.parent.mkdir(parents=True,exist_ok=True);p.write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print('DRY-RUN command:' if not a.execute else 'EXECUTE command:', ' '.join(cmd))
    print('manifest ->',p)
    if not a.execute: return
    if not shutil.which('tau2'):
        raise SystemExit('未找到 tau2。请先按官方当前文档安装并执行 uv sync。')
    proc=subprocess.run(cmd,text=True)
    raise SystemExit(proc.returncode)
if __name__=='__main__':main()
