#!/usr/bin/env python3
"""Benchmark 版本可比性闸门。
规则基于 τ-bench 官方 2026-07 v1.0.1 release note：banking_knowledge 在该版本有 grading/task fixes，
pre-1.0.1 与 >=1.0.1 分数不可直接比较；其他域不受该次 grading change 影响。
"""
import argparse, json, re

def vt(v):
    nums=re.findall(r'\d+',str(v)); return tuple((list(map(int,nums))+[0,0,0])[:3])

def comparable(a,b,domain):
    if domain!='banking_knowledge': return True,'2026-07 v1.0.1 grading change documented as banking_knowledge-specific.'
    boundary=(1,0,1)
    side_a=vt(a)>=boundary; side_b=vt(b)>=boundary
    if side_a != side_b:
        return False,'banking_knowledge crosses v1.0.1 grading boundary; direct score comparison is invalid.'
    return True,'same side of documented v1.0.1 banking grading boundary.'

def main():
    ap=argparse.ArgumentParser();ap.add_argument('--a',required=True);ap.add_argument('--b',required=True);ap.add_argument('--domain',required=True)
    x,why=comparable(ap.parse_args().a,ap.parse_args().b,ap.parse_args().domain)
    print(json.dumps({'comparable':x,'reason':why},ensure_ascii=False,indent=2))
    raise SystemExit(0 if x else 2)
if __name__=='__main__':main()
