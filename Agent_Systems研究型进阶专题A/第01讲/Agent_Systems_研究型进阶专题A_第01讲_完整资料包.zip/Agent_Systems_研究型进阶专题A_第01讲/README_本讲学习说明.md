# 研究型进阶专题 A · 第1讲：真实 Agent Benchmark 实战

本讲选择：**τ³-bench v1.0.1，text half-duplex，先从 retail 域起步**。

> 截至 2026-09-29，官方 GitHub 最新 release 为 v1.0.1。为保证复现，本讲不跟随 `main` 浮动，而是建议固定 tag `v1.0.1`。

## 你真正要完成的闭环

1. 安装并固定 benchmark 版本；
2. `tau2 check-data` 检查环境；
3. 先跑 1 个 task（Smoke Test）；
4. 再跑 3 个 task；
5. 再扩到 5-20 个 task（也可用 `src/run_pilot_n_tasks.sh`，通过 `NUM_TASKS=3/5/20` 控制）；
6. 用 `tau2 view` 看 trajectory；
7. 使用本资料包 `src/analyze_tau3_results.py` 汇总 success、cost、token、latency、termination；
8. 使用 `src/inspect_trace.py` 导出可人工标注的 trace；
9. 填写 `templates/failure_annotation_template.csv`，定位 First Bad Span；
10. 只在现象重复出现后，才写 Observation / Research Question。

## 重要声明

- `data/teaching_mock_results.json` 和 `traces/teaching_mock_trace.txt` 是**受控教学模拟**，仅用于验证本资料包的分析脚本。
- 它们**不代表** GPT、Claude、Gemini、DeepSeek、Kimi 或任何真实模型的实际性能。
- 本资料包未调用你的真实 API Key，因此没有伪造任何真实模型 benchmark 分数。
- 真正的性能数据必须由你在本地运行官方 τ³-bench 后生成。

## 推荐阅读顺序

`01_零基础讲义.pdf` → `03_实验指导书.docx` → 按 `src/` 脚本跑实验 → `04_实验设计书.docx` → `05_练习题.docx`

## 官方来源

- GitHub: https://github.com/sierra-research/tau2-bench
- Release v1.0.1: https://github.com/sierra-research/tau2-bench/releases/tag/v1.0.1
- Getting Started: https://github.com/sierra-research/tau2-bench/blob/v1.0.1/docs/getting-started.md
- Evaluation: https://github.com/sierra-research/tau2-bench/blob/v1.0.1/docs/evaluation.md
- CLI Reference: https://github.com/sierra-research/tau2-bench/blob/v1.0.1/docs/cli-reference.md
- τ-bench paper: https://arxiv.org/abs/2406.12045
- τ²-bench paper: https://arxiv.org/abs/2506.07982
