#!/usr/bin/env bash
set -euo pipefail

echo "[1/5] 检查 git"
git --version

echo "[2/5] 检查 uv"
uv --version

echo "[3/5] 检查 Python（τ³-bench v1.0.1 要求 Python >=3.12,<3.14）"
python3 --version || true

echo "[4/5] 如果当前目录是 tau2-bench，检查 benchmark 数据"
if [ -f "pyproject.toml" ] && grep -q "tau2" pyproject.toml 2>/dev/null; then
  uv run tau2 check-data
else
  echo "当前不在 tau2-bench 仓库目录；跳过 tau2 check-data。"
fi

echo "[5/5] API Key 只检查是否存在，不打印真实值"
if [ -n "${OPENAI_API_KEY:-}" ]; then
  echo "OPENAI_API_KEY: 已设置"
else
  echo "OPENAI_API_KEY: 未设置（如果你使用别的 LiteLLM provider，可忽略）"
fi
