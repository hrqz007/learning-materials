#!/usr/bin/env bash
set -euo pipefail

# 作用：安装并固定 τ³-bench v1.0.1。
# 说明：不使用浮动 main，以免课程中的 evaluator / task 定义发生漂移。

git clone --branch v1.0.1 --depth 1 https://github.com/sierra-research/tau2-bench.git
cd tau2-bench
uv sync
uv run tau2 check-data

echo "安装完成。当前 Git 信息："
git rev-parse HEAD
git describe --tags --always
