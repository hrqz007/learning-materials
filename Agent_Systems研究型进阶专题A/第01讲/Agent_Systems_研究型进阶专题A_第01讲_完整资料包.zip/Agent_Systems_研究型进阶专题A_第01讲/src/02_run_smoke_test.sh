#!/usr/bin/env bash
set -euo pipefail

# ===== 真实 API Smoke Test：只跑 1 个 task =====
# 默认使用 2026-09-29 价格较低的 GPT-5.6 Luna。
# 核心 benchmark 不绑定 OpenAI：τ³-bench 通过 LiteLLM 支持多 provider。
# 如你的 LiteLLM 版本需要无 provider 前缀，可把 openai/gpt-5.6-luna 改为 gpt-5.6-luna。

AGENT_MODEL="${AGENT_MODEL:-openai/gpt-5.6-luna}"
USER_MODEL="${USER_MODEL:-openai/gpt-5.6-luna}"
RUN_NAME="${RUN_NAME:-a01_smoke_retail}"

uv run tau2 run \
  --domain retail \
  --agent-llm "$AGENT_MODEL" \
  --user-llm "$USER_MODEL" \
  --num-trials 1 \
  --num-tasks 1 \
  --max-concurrency 1 \
  --seed 300 \
  --timeout 300 \
  --verbose-logs \
  --llm-log-mode all \
  --save-to "$RUN_NAME"

echo "结果目录：data/simulations/$RUN_NAME"
echo "下一步：uv run tau2 view --file data/simulations/$RUN_NAME/results.json"
