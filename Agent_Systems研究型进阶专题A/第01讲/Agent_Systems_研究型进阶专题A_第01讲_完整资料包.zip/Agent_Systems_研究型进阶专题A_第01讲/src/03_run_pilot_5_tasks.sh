#!/usr/bin/env bash
set -euo pipefail

# ===== 真实 API Pilot：5 个 task =====
# Smoke Test 成功后再运行。不要一开始就跑全集。

AGENT_MODEL="${AGENT_MODEL:-openai/gpt-5.6-luna}"
USER_MODEL="${USER_MODEL:-openai/gpt-5.6-luna}"
RUN_NAME="${RUN_NAME:-a01_pilot5_retail}"

uv run tau2 run \
  --domain retail \
  --agent-llm "$AGENT_MODEL" \
  --user-llm "$USER_MODEL" \
  --num-trials 1 \
  --num-tasks 5 \
  --max-concurrency 1 \
  --seed 300 \
  --timeout 300 \
  --max-retries 2 \
  --retry-delay 2 \
  --verbose-logs \
  --llm-log-mode all \
  --save-to "$RUN_NAME"

echo "Pilot 完成后："
echo "1) uv run tau2 view --file data/simulations/$RUN_NAME/results.json"
echo "2) python ../Agent_Systems_研究型进阶专题A_第01讲/src/analyze_tau3_results.py data/simulations/$RUN_NAME/results.json --out-dir ../Agent_Systems_研究型进阶专题A_第01讲/results/real_pilot5"
