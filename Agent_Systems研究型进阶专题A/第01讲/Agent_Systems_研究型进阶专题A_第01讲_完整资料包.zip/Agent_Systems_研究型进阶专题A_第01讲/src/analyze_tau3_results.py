#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分析 τ³-bench text results.json。

功能：
1) 每个 simulation 的 reward / termination / duration / cost；
2) 从 messages[*].usage 汇总 prompt/completion token；
3) 统计成功率、总成本、p50/p95 duration；
4) 输出 simulation_summary.csv 和 aggregate_summary.json。

说明：脚本对官方 v1.0.1 的 monolithic JSON 结构编写，并尽量容忍字段缺失。
"""
import argparse, json, csv, statistics
from pathlib import Path


def percentile(xs, p):
    if not xs:
        return None
    xs=sorted(xs)
    if len(xs)==1:
        return xs[0]
    k=(len(xs)-1)*p
    f=int(k); c=min(f+1,len(xs)-1)
    if f==c: return xs[f]
    return xs[f] + (xs[c]-xs[f])*(k-f)


def load_sims(path):
    path=Path(path)
    if path.is_dir():
        meta=path/'results.json'
    else:
        meta=path
    data=json.loads(meta.read_text(encoding='utf-8'))
    sims=data.get('simulations', [])
    # 如果是 directory format，results.json 可能只有 simulation_index。
    if not sims and (meta.parent/'simulations').exists():
        sims=[]
        for f in sorted((meta.parent/'simulations').glob('*.json')):
            sims.append(json.loads(f.read_text(encoding='utf-8')))
    return data, sims


def msg_usage(messages):
    pin=pout=0
    missing=0
    for m in messages or []:
        u=m.get('usage') or m.get('token_usage')
        if not isinstance(u,dict):
            if m.get('role') != 'tool': missing += 1
            continue
        pin += int(u.get('prompt_tokens') or u.get('input_tokens') or 0)
        pout += int(u.get('completion_tokens') or u.get('output_tokens') or 0)
    return pin,pout,missing


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('results_json')
    ap.add_argument('--out-dir',default='tau3_analysis')
    args=ap.parse_args()
    data,sims=load_sims(args.results_json)
    out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    rows=[]
    for s in sims:
        reward_info=s.get('reward_info') or {}
        reward=reward_info.get('reward')
        pin,pout,missing=msg_usage(s.get('messages'))
        agent_cost=s.get('agent_cost')
        user_cost=s.get('user_cost')
        known_cost=sum(x for x in [agent_cost,user_cost] if isinstance(x,(int,float)))
        row={
            'simulation_id':s.get('id'),'task_id':s.get('task_id'),'trial':s.get('trial'),
            'reward':reward,'success':1 if isinstance(reward,(int,float)) and reward>=1.0 else 0,
            'termination_reason':s.get('termination_reason'),'duration_s':s.get('duration'),
            'agent_cost_usd':agent_cost,'user_cost_usd':user_cost,'known_total_cost_usd':known_cost,
            'prompt_tokens':pin,'completion_tokens':pout,'total_tokens':pin+pout,'messages_missing_usage':missing,
            'db_match':((reward_info.get('db_check') or {}).get('db_match')),
            'reward_basis':json.dumps(reward_info.get('reward_basis'),ensure_ascii=False),
        }
        rows.append(row)
    fields=list(rows[0].keys()) if rows else ['simulation_id']
    with (out/'simulation_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    durations=[r['duration_s'] for r in rows if isinstance(r['duration_s'],(int,float))]
    costs=[r['known_total_cost_usd'] for r in rows if isinstance(r['known_total_cost_usd'],(int,float))]
    summary={
        'n_simulations':len(rows),
        'success_count':sum(r['success'] for r in rows),
        'success_rate':(sum(r['success'] for r in rows)/len(rows)) if rows else None,
        'total_known_cost_usd':sum(costs),
        'total_prompt_tokens':sum(r['prompt_tokens'] for r in rows),
        'total_completion_tokens':sum(r['completion_tokens'] for r in rows),
        'duration_p50_s':percentile(durations,0.50),
        'duration_p95_s':percentile(durations,0.95),
        'termination_counts':{},
        'note':'known cost comes from official result fields when available; zero/missing does not prove the real API was free.'
    }
    for r in rows:
        key=str(r['termination_reason']); summary['termination_counts'][key]=summary['termination_counts'].get(key,0)+1
    (out/'aggregate_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
