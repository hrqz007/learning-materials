#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成科研 Run Manifest：记录版本、模型、prompt/harness、seed、运行命令和结果摘要。"""
import argparse, json, subprocess, platform, hashlib
from pathlib import Path
from datetime import datetime, timezone


def cmd(x):
    try: return subprocess.check_output(x,shell=True,text=True,stderr=subprocess.STDOUT).strip()
    except Exception as e: return f'UNAVAILABLE: {e}'

def sha256_file(path):
    p=Path(path)
    if not p.exists(): return None
    h=hashlib.sha256()
    with p.open('rb') as f:
        for b in iter(lambda:f.read(1024*1024),b''): h.update(b)
    return h.hexdigest()

ap=argparse.ArgumentParser(); ap.add_argument('--results',required=True); ap.add_argument('--command',required=True); ap.add_argument('--out',default='run_manifest.json'); ap.add_argument('--notes',default=''); args=ap.parse_args()
p=Path(args.results)
meta=json.loads(p.read_text(encoding='utf-8')) if p.is_file() else json.loads((p/'results.json').read_text(encoding='utf-8'))
info=meta.get('info') or {}
manifest={
  'created_at_utc':datetime.now(timezone.utc).isoformat(),
  'benchmark':'tau3-bench / tau2-bench repo',
  'benchmark_git_commit':info.get('git_commit') or cmd('git rev-parse HEAD'),
  'benchmark_git_tag':cmd('git describe --tags --always'),
  'python':platform.python_version(),
  'platform':platform.platform(),
  'run_command':args.command,
  'results_path':str(p.resolve()),
  'results_sha256':sha256_file(p if p.is_file() else p/'results.json'),
  'seed':info.get('seed'),
  'num_trials':info.get('num_trials'),
  'max_steps':info.get('max_steps'),
  'agent_info':info.get('agent_info'),
  'user_info':info.get('user_info'),
  'environment_info':info.get('environment_info'),
  'notes':args.notes,
  'reproducibility_note':'API model aliases can change server-side. For paper-grade runs, record provider model version/fingerprint when exposed and archive raw LLM logs.'
}
Path(args.out).write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(manifest,ensure_ascii=False,indent=2))
