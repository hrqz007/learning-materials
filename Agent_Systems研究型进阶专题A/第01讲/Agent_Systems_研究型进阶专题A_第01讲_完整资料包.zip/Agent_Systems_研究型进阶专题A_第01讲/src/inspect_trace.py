#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从 τ³-bench results.json 中导出某个 task 的人类可读 Trace。"""
import argparse, json
from pathlib import Path


def load(path):
    p=Path(path); meta=p/'results.json' if p.is_dir() else p
    d=json.loads(meta.read_text(encoding='utf-8'))
    sims=d.get('simulations',[])
    if not sims and (meta.parent/'simulations').exists():
        sims=[json.loads(f.read_text(encoding='utf-8')) for f in sorted((meta.parent/'simulations').glob('*.json'))]
    return sims


def main():
    ap=argparse.ArgumentParser(); ap.add_argument('results_json'); ap.add_argument('--task-id',required=True); ap.add_argument('--out',default='trace.txt'); args=ap.parse_args()
    sims=[s for s in load(args.results_json) if str(s.get('task_id'))==str(args.task_id)]
    if not sims: raise SystemExit(f'没有找到 task_id={args.task_id}')
    s=sims[0]; lines=[]
    lines.append(f"simulation_id={s.get('id')} task_id={s.get('task_id')} reward={(s.get('reward_info') or {}).get('reward')} termination={s.get('termination_reason')}")
    for i,m in enumerate(s.get('messages') or []):
        role=m.get('role','?'); content=m.get('content')
        lines.append(f"\n[{i:03d}] role={role} turn_idx={m.get('turn_idx')}")
        if content: lines.append(str(content))
        if m.get('tool_calls'):
            lines.append('TOOL_CALLS='+json.dumps(m['tool_calls'],ensure_ascii=False,indent=2))
        if role=='tool':
            for k in ['name','id','requestor']:
                if k in m: lines.append(f'{k}={m[k]}')
    Path(args.out).write_text('\n'.join(lines),encoding='utf-8')
    print(f'已写出 {args.out}')

if __name__=='__main__': main()
