#!/usr/bin/env bash
set -euo pipefail

# 通用真实 API 小样本脚本：严格按 3 -> 5 -> 20 逐步放大。
# 示例：
#   NUM_TASKS=3  RUN_NAME=a01_small3_retail  bash /path/to/run_pilot_n_tasks.sh
#   NUM_TASKS=5  RUN_NAME=a01_pilot5_retail  bash /path/to/run_pilot_n_tasks.sh
#   NUM_TASKS=20 RUN_NAME=a01_pilot20_retail bash /path/to/run_pilot_n_tasks.sh
# 注意：20-task 阶段只应在 1/3/5-task 均无基础设施错误后运行。

NUM_TASKS="${NUM_TASKS:-3}"
AGENT_MODEL="${AGENT_MODEL:-openai/gpt-5.6-luna}"
USER_MODEL="${USER_MODEL:-openai/gpt-5.6-luna}"
RUN_NAME="${RUN_NAME:-a01_pilot${NUM_TASKS}_retail}"
SEED="${SEED:-300}"

case "$NUM_TASKS" in
  3|5|20) ;;
  *) echo "本讲只建议 NUM_TASKS=3、5 或 20；收到: $NUM_TASKS" >&2; exit 2 ;;
esac

uv run tau2 run \
  --domain retail \
  --agent-llm "$AGENT_MODEL" \
  --user-llm "$USER_MODEL" \
  --num-trials 1 \
  --num-tasks "$NUM_TASKS" \
  --max-concurrency 1 \
  --seed "$SEED" \
  --timeout 300 \
  --max-retries 2 \
  --retry-delay 2 \
  --verbose-logs \
  --llm-log-mode all \
  --save-to "$RUN_NAME"

echo "完成：data/simulations/$RUN_NAME/results.json"
echo "下一步先用 tau2 view 逐条看 Trace，再运行 analyze_tau3_results.py。"
