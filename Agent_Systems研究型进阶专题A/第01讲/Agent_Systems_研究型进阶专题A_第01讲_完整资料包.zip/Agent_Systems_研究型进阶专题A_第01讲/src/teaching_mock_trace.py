#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成受控教学模拟 results.json，用于验证分析脚本。

警告：这不是任何真实模型的 benchmark 结果。
"""
import argparse, json, uuid
from pathlib import Path

sims=[]
examples=[
    ('0',1.0,'agent_stop',12.3,0.0012,0.0009,1200,160),
    ('1',0.0,'agent_stop',18.8,0.0018,0.0010,1800,220),
    ('2',0.0,'timeout',45.0,0.0021,0.0011,2400,260),
]
for i,(task,reward,term,dur,ac,uc,pin,pout) in enumerate(examples):
    msgs=[
      {'role':'user','content':'[教学模拟] 用户提出任务。','usage':{'prompt_tokens':200,'completion_tokens':30},'turn_idx':0},
      {'role':'assistant','content':None,'tool_calls':[{'id':'call1','name':'lookup_order','arguments':{'order_id':'DEMO'}}], 'usage':{'prompt_tokens':pin-400,'completion_tokens':pout-60},'turn_idx':1},
      {'role':'tool','content':'{\"status\":\"delivered\"}','turn_idx':2},
      {'role':'assistant','content':'[教学模拟] 完成或失败的最终回复。','usage':{'prompt_tokens':200,'completion_tokens':30},'turn_idx':3},
    ]
    sims.append({'id':str(uuid.uuid4()),'task_id':task,'trial':0,'start_time':'2026-09-29T00:00:00Z','end_time':'2026-09-29T00:00:20Z','duration':dur,'termination_reason':term,'agent_cost':ac,'user_cost':uc,'reward_info':{'reward':reward,'reward_basis':['DB','COMMUNICATE'],'db_check':{'db_match':reward==1.0,'db_reward':1.0 if reward==1 else 0.0}},'messages':msgs,'seed':300,'mode':'half_duplex'})
out={'timestamp':'2026-09-29T00:00:00Z','info':{'git_commit':'TEACHING_MOCK_NOT_REAL','num_trials':1,'max_steps':200,'max_errors':10,'seed':300,'agent_info':{'implementation':'mock','llm':'NOT_A_REAL_MODEL'},'user_info':{'implementation':'mock','llm':'NOT_A_REAL_MODEL'},'environment_info':{'domain':'teaching_mock'}},'tasks':[], 'simulations':sims,
'_DISCLAIMER':'受控教学模拟，不代表任何真实模型性能。'}
ap=argparse.ArgumentParser()
ap.add_argument('--out', default='data/teaching_mock_results.json')
args=ap.parse_args()
out_path=Path(args.out)
out_path.parent.mkdir(parents=True, exist_ok=True)
out_path.write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
print(f'已写出受控教学模拟（非真实模型结果）：{out_path}')
