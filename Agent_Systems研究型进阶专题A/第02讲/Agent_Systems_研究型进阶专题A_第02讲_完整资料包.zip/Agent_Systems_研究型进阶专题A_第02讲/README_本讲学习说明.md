# 研究型进阶专题 A · 第2讲：真实 Benchmark 重复实验

主题：**随机性、Failure Stability 与 pass^k**。

本讲继续使用上一讲固定的 **τ³-bench v1.0.1 / retail / text half-duplex**，不更换 Benchmark，避免把“学习新环境”误当成科研进展。

## 本讲最小真实实验

- 固定 5 个 retail task；
- 每个 task 运行 4 trials；
- 共 20 条 trajectory；
- 保持同一 benchmark tag、harness、prompt、model、user simulator、seed schedule；
- 汇总 reward、pass^1…pass^4、cost、duration、token、termination；
- 把 task 分成 Stable Pass / Stochastic / Stable Fail；
- 只对 Stochastic 与 Stable Fail 优先做 Trace / First Bad Span 标注。

## 重要声明

`data/teaching_mock_repeated_results.json` 是**受控教学模拟**，只用于验证分析脚本和理解 pass^k，不代表任何真实模型性能。
本资料包没有你的真实 API Key，因此**没有生成真实 GPT / Claude / Gemini / DeepSeek / Kimi 的 benchmark 成绩**。

## 官方依据（截至 2026-09-29）

- τ³-bench GitHub 最新 release: v1.0.1 (2026-07-22)
- CLI 支持 `--num-trials`、`--task-ids`、`--seed`、`--verbose-logs`
- 官方 metrics 代码定义：`pass_hat_k = C(success_count,k) / C(num_trials,k)`
- 官方 metrics 会把 `infrastructure_error` 从能力指标中排除并单独计数

官方页面：
- https://github.com/sierra-research/tau2-bench/releases/tag/v1.0.1
- https://github.com/sierra-research/tau2-bench/blob/v1.0.1/docs/cli-reference.md
- https://github.com/sierra-research/tau2-bench/blob/v1.0.1/src/tau2/metrics/agent_metrics.py
- https://arxiv.org/abs/2406.12045

## 推荐顺序

`01_零基础讲义.pdf` → `03_实验指导书.docx` → 先运行教学模拟分析 → 再运行真实 5×4 pilot → 填写 Trace Review Queue → `04_实验设计书.docx`。
