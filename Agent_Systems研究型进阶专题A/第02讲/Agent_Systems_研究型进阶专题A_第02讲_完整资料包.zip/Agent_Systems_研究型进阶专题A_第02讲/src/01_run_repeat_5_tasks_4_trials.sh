#!/usr/bin/env bash
set -euo pipefail

# 研究型进阶专题 A · 第2讲
# 真实重复实验：固定 5 个 retail task × 4 trials = 20 trajectories
# 前提：已经按第1讲安装并进入 tau2-bench v1.0.1 仓库，并配置好 API Key。

AGENT_MODEL="${AGENT_MODEL:-openai/gpt-5.6-luna}"
USER_MODEL="${USER_MODEL:-openai/gpt-5.6-luna}"
RUN_NAME="${RUN_NAME:-a02_retail_5tasks_4trials}"

uv run tau2 run \
  --domain retail \
  --agent-llm "$AGENT_MODEL" \
  --user-llm "$USER_MODEL" \
  --num-tasks 5 \
  --num-trials 4 \
  --seed 300 \
  --max-concurrency 1 \
  --timeout 300 \
  --max-retries 2 \
  --retry-delay 2 \
  --verbose-logs \
  --llm-log-mode all \
  --save-to "$RUN_NAME"

echo "真实结果：data/simulations/$RUN_NAME/results.json"
echo "下一步：python /path/to/A02/src/analyze_repeated_trials.py data/simulations/$RUN_NAME/results.json --out-dir /path/to/A02/results/real_5x4"
