#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""分析 τ³-bench 重复 trials。

输出：
- episode_summary.csv：每条 trajectory
- task_stability.csv：每个 task 的成功次数、pass^k、稳定性类别
- failure_matrix.csv：task × trial 的 PASS/FAIL/INFRA 矩阵
- aggregate_summary.json：整体统计

官方风格：infrastructure_error 不参与 pass^k 能力统计，但单独报告。
"""
import argparse, json, csv, math, statistics
from pathlib import Path
from collections import defaultdict


def is_success(r):
    try: return abs(float(r)-1.0) <= 1e-6
    except Exception: return False

def pct(xs,p):
    if not xs: return None
    s=sorted(xs)
    if len(s)==1: return s[0]
    k=(len(s)-1)*p; f=int(k); c=min(f+1,len(s)-1)
    if f==c: return s[f]
    return s[f]*(c-k)+s[c]*(k-f)

def pass_hat_k(n,c,k):
    if n<k: return None
    return math.comb(c,k)/math.comb(n,k)

def usage_from_messages(messages):
    prompt=completion=0
    for m in messages or []:
        u=m.get('usage') or {}
        prompt += int(u.get('prompt_tokens') or u.get('input_tokens') or 0)
        completion += int(u.get('completion_tokens') or u.get('output_tokens') or 0)
    return prompt,completion

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('results_json'); ap.add_argument('--out-dir',default='a02_analysis')
    args=ap.parse_args(); src=Path(args.results_json); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    data=json.loads(src.read_text(encoding='utf-8')); sims=data.get('simulations',[])
    rows=[]
    for s in sims:
        reward=((s.get('reward_info') or {}).get('reward'))
        term=str(s.get('termination_reason') or '')
        p,c=usage_from_messages(s.get('messages'))
        rows.append({'simulation_id':s.get('id'),'task_id':str(s.get('task_id')),'trial':s.get('trial'),'seed':s.get('seed'),'reward':reward,'success':int(is_success(reward)),'termination_reason':term,'is_infra':int(term=='infrastructure_error'),'agent_cost':s.get('agent_cost'),'user_cost':s.get('user_cost'),'duration':s.get('duration'),'prompt_tokens':p,'completion_tokens':c,'total_tokens':p+c})
    fields=list(rows[0].keys()) if rows else []
    with (out/'episode_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

    groups=defaultdict(list)
    for r in rows: groups[r['task_id']].append(r)
    task_rows=[]; matrix=[]
    max_trials=max([len(v) for v in groups.values()] or [0])
    for tid,rs in sorted(groups.items(), key=lambda kv: kv[0]):
        rs=sorted(rs,key=lambda x:(x['trial'] if x['trial'] is not None else 9999))
        eval_rs=[r for r in rs if not r['is_infra']]; n=len(eval_rs); c=sum(r['success'] for r in eval_rs); infra=sum(r['is_infra'] for r in rs)
        if n and c==n: status='stable_pass'
        elif n and c==0: status='stable_fail'
        elif n: status='stochastic'
        else: status='infra_only'
        tr={'task_id':tid,'total_recorded_trials':len(rs),'evaluable_trials':n,'success_count':c,'failure_count':n-c,'infra_count':infra,'success_rate':(c/n if n else None),'stability_class':status}
        for k in range(1,5): tr[f'pass^{k}']=pass_hat_k(n,c,k)
        task_rows.append(tr)
        m={'task_id':tid}
        for r in rs:
            m[f"trial_{r['trial']}"]='INFRA' if r['is_infra'] else ('PASS' if r['success'] else 'FAIL')
        matrix.append(m)
    tfields=['task_id','total_recorded_trials','evaluable_trials','success_count','failure_count','infra_count','success_rate','pass^1','pass^2','pass^3','pass^4','stability_class']
    with (out/'task_stability.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=tfields); w.writeheader(); w.writerows(task_rows)
    mfields=['task_id']+[f'trial_{i}' for i in range(max_trials)]
    with (out/'failure_matrix.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=mfields); w.writeheader(); w.writerows(matrix)

    eval_rows=[r for r in rows if not r['is_infra']]
    costs=[float(r['agent_cost']) for r in eval_rows if r['agent_cost'] is not None]
    durs=[float(r['duration']) for r in eval_rows if r['duration'] is not None]
    toks=[r['total_tokens'] for r in eval_rows if r['total_tokens']]
    common_k=[]
    for k in range(1,5):
        vals=[tr[f'pass^{k}'] for tr in task_rows if tr[f'pass^{k}'] is not None]
        common_k.append((k,sum(vals)/len(vals) if vals else None))
    summary={'source':str(src),'recorded_episodes':len(rows),'evaluable_episodes':len(eval_rows),'infra_errors':sum(r['is_infra'] for r in rows),'stable_pass_tasks':sum(t['stability_class']=='stable_pass' for t in task_rows),'stochastic_tasks':sum(t['stability_class']=='stochastic' for t in task_rows),'stable_fail_tasks':sum(t['stability_class']=='stable_fail' for t in task_rows),'mean_pass_k':{f'pass^{k}':v for k,v in common_k},'agent_cost_total':sum(costs) if costs else None,'agent_cost_mean':statistics.mean(costs) if costs else None,'duration_p50':pct(durs,.50),'duration_p95':pct(durs,.95),'tokens_mean':statistics.mean(toks) if toks else None}
    (out/'aggregate_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
