#!/usr/bin/env python3
# -*- coding: utf-8 -*-
import argparse, json, hashlib, subprocess, sys
from pathlib import Path

def sha256(p):
    h=hashlib.sha256();
    with open(p,'rb') as f:
        for b in iter(lambda:f.read(1<<20),b''): h.update(b)
    return h.hexdigest()
def cmd(x):
    try:return subprocess.check_output(x,shell=True,text=True,stderr=subprocess.STDOUT).strip()
    except Exception:return None

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--results',required=True); ap.add_argument('--command',required=True); ap.add_argument('--out',required=True); args=ap.parse_args(); p=Path(args.results)
    d=json.loads(p.read_text(encoding='utf-8'))
    info=d.get('info',{})
    out={'results_file':str(p.resolve()),'results_sha256':sha256(p),'benchmark_git_commit':info.get('git_commit'),'benchmark_release':'v1.0.1 (course pin)','base_seed':info.get('seed'),'num_trials':info.get('num_trials'),'run_command':args.command,'python':sys.version.split()[0],'git_head_now':cmd('git rev-parse HEAD'),'git_tag_now':cmd('git describe --tags --always'),'note':'Model/provider aliases and pricing can change. Record exact provider/model metadata separately when available.'}
    Path(args.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8'); print(args.out)
if __name__=='__main__': main()
