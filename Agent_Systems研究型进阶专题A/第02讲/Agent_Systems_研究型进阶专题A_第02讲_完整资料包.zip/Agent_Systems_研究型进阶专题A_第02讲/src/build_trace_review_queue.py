#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""从分析结果中生成 Trace 人工复核队列。优先 stochastic / stable_fail。"""
import argparse,csv
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('task_stability_csv'); ap.add_argument('--out',default='trace_review_queue.csv'); args=ap.parse_args()
    rows=list(csv.DictReader(open(args.task_stability_csv,encoding='utf-8-sig')))
    pri={'stable_fail':0,'stochastic':1,'stable_pass':2,'infra_only':3}
    rows.sort(key=lambda r:(pri.get(r.get('stability_class'),9),r.get('task_id','')))
    out=[]
    for r in rows:
        if r.get('stability_class') not in ('stable_fail','stochastic'): continue
        out.append({'task_id':r['task_id'],'stability_class':r['stability_class'],'success_count':r['success_count'],'evaluable_trials':r['evaluable_trials'],'review_priority':'HIGH' if r['stability_class']=='stable_fail' else 'MEDIUM','first_bad_span':'','primary_failure_class':'','evidence':'','repeats_across_trials':'','research_observation':''})
    fields=list(out[0].keys()) if out else ['task_id','stability_class','success_count','evaluable_trials','review_priority','first_bad_span','primary_failure_class','evidence','repeats_across_trials','research_observation']
    with open(args.out,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(out)
    print(f'Wrote {len(out)} rows -> {args.out}')
if __name__=='__main__': main()
