#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""生成受控教学模拟 repeated-results。
这不是任何真实模型性能数据。
"""
import json,argparse,random,time
from pathlib import Path

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',default='teaching_mock_repeated_results.json'); args=ap.parse_args()
    patterns={"0":[1,1,1,1],"1":[1,1,0,1],"2":[1,0,1,0],"3":[0,0,0,0],"4":[1,1,'I',1]}
    sims=[]; seeds=[641770,128752,527334,742036]
    for tid,pat in patterns.items():
        for trial,v in enumerate(pat):
            infra=v=='I'; success=v==1
            msgs=[{'role':'user','content':'教学模拟请求','usage':{'prompt_tokens':0,'completion_tokens':0}},{'role':'assistant','content':'教学模拟响应','usage':{'prompt_tokens':1100+100*trial,'completion_tokens':140+20*trial}}]
            sims.append({'id':f'mock-{tid}-{trial}','task_id':tid,'trial':trial,'seed':seeds[trial],'termination_reason':'infrastructure_error' if infra else 'user_stop','agent_cost':0.0025+0.0002*trial,'user_cost':0.001,'duration':8.0+trial*1.7,'reward_info':{'reward':1.0 if success else 0.0},'messages':msgs})
    data={'timestamp':'TEACHING_MOCK','info':{'git_commit':'TEACHING_MOCK_NOT_REAL','num_trials':4,'seed':300},'tasks':[{'id':k} for k in patterns],'simulations':sims,'notice':'受控教学模拟；不代表任何真实模型性能。'}
    Path(args.out).write_text(json.dumps(data,ensure_ascii=False,indent=2),encoding='utf-8')
    print(args.out)
if __name__=='__main__': main()
