# Repeated Benchmark Observation Log

## 1. 现象（只写可观察事实）
- Task IDs:
- 发生在多少个 trial:
- 成功/失败矩阵:
- First Bad Span 是否重复:

## 2. 可能解释（明确标注为 Hypothesis）

## 3. Falsifier
什么结果一出现，就说明这个解释可能是错的？

## 4. 下一步最小 Controlled Intervention
只改变一个变量。

## 5. 当前不能声称什么
避免把相关性写成因果。
