真实 trace 不随资料包生成。运行真实 API 后，用 `tau2 view` 与上一讲 inspect_trace 工具查看；本讲重点是跨 trial 对照。
