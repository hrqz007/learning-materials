# Agent Systems 研究型进阶专题 A · 第3讲

## 本讲目标
从“重复失败”推进到第一次机制验证实验：Failure Pattern → Falsifiable Hypothesis → Controlled Intervention → Evidence Update。

## 推荐顺序
1. 先读 `01_零基础讲义.pdf`。
2. 根据第2讲 `task_stability.csv` 选择 2–3 个失败候选任务。
3. 按 `03_实验指导书.docx` 跑 Baseline 与 Oracle-plan。
4. 用 `compare_conditions.py` 生成对照表。
5. 人工完成 First Bad Span 对照与 hypothesis card。
6. 最后做练习题。

## 重要边界
`llm_agent_gt` 得到 benchmark reference resolution steps，因此只能作为诊断性 oracle ablation。不要把它当作公平排行榜改进方法。

## 教学模拟数据
`data/` 下的数据全部带 `TEACHING_MOCK_ONLY` 标记，只用于测试分析脚本，不得作为科研结果。
