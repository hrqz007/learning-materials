#!/usr/bin/env python3
import argparse,csv,json,sys
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument('task_stability_csv'); ap.add_argument('--results-json'); ap.add_argument('--max-success-rate',type=float,default=.5); ap.add_argument('--limit',type=int,default=3)
a=ap.parse_args(); rows=[]; eligible=None
if a.results_json:
    d=json.loads(Path(a.results_json).read_text(encoding='utf-8')); eligible=set()
    for t in d.get('tasks',[]):
        acts=((t.get('evaluation_criteria') or {}).get('actions') or [])
        if acts: eligible.add(str(t.get('id')))
with open(a.task_stability_csv,encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        tid=str(r.get('task_id'))
        if eligible is not None and tid not in eligible: continue
        try: sr=float(r.get('success_rate') or 0)
        except: sr=0
        if r.get('stability_class')=='stable_fail' or (r.get('stability_class')=='stochastic' and sr<=a.max_success_rate): rows.append((0 if r.get('stability_class')=='stable_fail' else 1,sr,r))
rows.sort(key=lambda x:(x[0],x[1],x[2].get('task_id','')))
sel=[x[2] for x in rows[:a.limit]]
print(' '.join(r['task_id'] for r in sel))
for r in sel: print(f"# task={r['task_id']} class={r.get('stability_class')} success_rate={r.get('success_rate')}")
if not sel:
    print('# No eligible candidate. Try a higher --max-success-rate or more tasks.', file=sys.stderr)
