#!/usr/bin/env bash
set -euo pipefail
: "${TASK_IDS:?Please export TASK_IDS='17 23 41'}"
AGENT_LLM="${AGENT_LLM:-gpt-4.1}"
USER_LLM="${USER_LLM:-gpt-4.1}"
cd "${TAU2_DIR:-$HOME/tau2-bench}"
read -r -a TASK_ARRAY <<< "$TASK_IDS"

uv run tau2 run \
  --domain retail \
  --agent llm_agent \
  --agent-llm "$AGENT_LLM" \
  --user-llm "$USER_LLM" \
  --task-ids "${TASK_ARRAY[@]}" \
  --num-trials 4 \
  --seed 300 \
  --max-concurrency 1 \
  --save-to a03_baseline \
  --verbose-logs --llm-log-mode all
