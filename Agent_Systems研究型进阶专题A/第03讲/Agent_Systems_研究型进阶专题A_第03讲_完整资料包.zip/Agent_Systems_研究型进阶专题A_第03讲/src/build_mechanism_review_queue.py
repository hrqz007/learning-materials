#!/usr/bin/env python3
import argparse,csv
ap=argparse.ArgumentParser();ap.add_argument('task_condition_csv');ap.add_argument('--out',default='trace_review_queue.csv');a=ap.parse_args()
rows=[]
with open(a.task_condition_csv,encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        try:d=float(r.get('delta_success_rate') or 0);b=float(r.get('baseline_success_rate') or 0);o=float(r.get('oracle_plan_success_rate') or 0)
        except:continue
        pri=1 if d>=.5 and b<=.5 else (2 if d>0 else 3)
        rows.append({'priority':pri,'task_id':r['task_id'],'baseline_success_rate':b,'oracle_plan_success_rate':o,'delta':d,'interpretation':r.get('preliminary_interpretation'),'review_action':'compare baseline failure vs oracle-plan trajectory; label First Bad Span'})
rows.sort(key=lambda x:(x['priority'],-x['delta']))
with open(a.out,'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()) if rows else ['priority']);w.writeheader();w.writerows(rows)
print(f'wrote {len(rows)} tasks -> {a.out}')
