#!/usr/bin/env python3
import argparse,json,subprocess,platform,datetime
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--baseline');ap.add_argument('--intervention');ap.add_argument('--out',default='run_manifest.json');a=ap.parse_args()
def sha(p):
 import hashlib
 h=hashlib.sha256();h.update(Path(p).read_bytes());return h.hexdigest()
def info(p):
 d=json.loads(Path(p).read_text(encoding='utf-8')); return {'path':str(p),'sha256':sha(p),'git_commit':(d.get('info') or {}).get('git_commit'),'num_trials':(d.get('info') or {}).get('num_trials'),'seed':(d.get('info') or {}).get('seed'),'agent':((d.get('info') or {}).get('agent_info') or {}).get('implementation'),'agent_llm':((d.get('info') or {}).get('agent_info') or {}).get('llm'),'user_llm':((d.get('info') or {}).get('user_info') or {}).get('llm')}
out={'created_at':datetime.datetime.now(datetime.timezone.utc).isoformat(),'python':platform.python_version(),'baseline':info(a.baseline) if a.baseline else None,'intervention':info(a.intervention) if a.intervention else None}
Path(a.out).write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8');print(json.dumps(out,ensure_ascii=False,indent=2))
