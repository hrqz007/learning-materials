#!/usr/bin/env python3
import argparse,json,csv,math,statistics
from pathlib import Path
from collections import defaultdict

def success(x):
    try:return abs(float(x)-1.0)<=1e-6
    except:return False

def load(path,condition):
    d=json.loads(Path(path).read_text(encoding='utf-8')); out=[]
    for s in d.get('simulations',[]):
        term=str(s.get('termination_reason') or '')
        r=((s.get('reward_info') or {}).get('reward'))
        out.append({'condition':condition,'simulation_id':s.get('id'),'task_id':str(s.get('task_id')),'trial':s.get('trial'),'seed':s.get('seed'),'reward':r,'success':int(success(r)),'is_infra':int(term=='infrastructure_error'),'termination_reason':term,'agent_cost':s.get('agent_cost'),'duration':s.get('duration')})
    return out

def pk(n,c,k): return math.comb(c,k)/math.comb(n,k) if n>=k else None
ap=argparse.ArgumentParser(); ap.add_argument('baseline'); ap.add_argument('intervention'); ap.add_argument('--out-dir',default='a03_analysis'); a=ap.parse_args(); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
rows=load(a.baseline,'baseline')+load(a.intervention,'oracle_plan')
with (out/'episode_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
G=defaultdict(lambda:defaultdict(list))
for r in rows:G[r['task_id']][r['condition']].append(r)
task=[]
for tid,conds in sorted(G.items()):
    rec={'task_id':tid}
    for cond in ['baseline','oracle_plan']:
        rs=[r for r in conds.get(cond,[]) if not r['is_infra']]; n=len(rs); c=sum(r['success'] for r in rs)
        rec[f'{cond}_n']=n; rec[f'{cond}_successes']=c; rec[f'{cond}_success_rate']=c/n if n else None
        for k in range(1,5):rec[f'{cond}_pass^{k}']=pk(n,c,k)
        costs=[float(r['agent_cost']) for r in rs if r.get('agent_cost') is not None]; rec[f'{cond}_mean_cost']=statistics.mean(costs) if costs else None
    b=rec.get('baseline_success_rate'); o=rec.get('oracle_plan_success_rate'); rec['delta_success_rate']=(o-b) if b is not None and o is not None else None
    if b is None or o is None: interp='insufficient_data'
    elif b<=.5 and o>=.75 and o-b>=.5: interp='planning_bottleneck_supported'
    elif b<=.5 and o<=.5: interp='planning_only_not_supported_check_execution_comm_env'
    elif b>.5 and o>.5: interp='weak_candidate_task'
    elif o<b: interp='anomalous_oracle_worse_check_reference_or_noise'
    else: interp='mixed_evidence'
    rec['preliminary_interpretation']=interp; task.append(rec)
fields=[]
for r in task:
    for k in r:
        if k not in fields:fields.append(k)
with (out/'task_condition.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows(task)
with (out/'mechanism_matrix.csv').open('w',newline='',encoding='utf-8-sig') as f:
    fs=['task_id','baseline_success_rate','oracle_plan_success_rate','delta_success_rate','preliminary_interpretation']; w=csv.DictWriter(f,fieldnames=fs);w.writeheader();w.writerows([{k:r.get(k) for k in fs} for r in task])
summary=[]
for cond in ['baseline','oracle_plan']:
    rs=[r for r in rows if r['condition']==cond and not r['is_infra']]; summary.append({'condition':cond,'evaluable_episodes':len(rs),'success_rate':sum(r['success'] for r in rs)/len(rs) if rs else None,'infra_errors':sum(r['is_infra'] for r in rows if r['condition']==cond),'mean_agent_cost':statistics.mean([float(r['agent_cost']) for r in rs if r.get('agent_cost') is not None]) if any(r.get('agent_cost') is not None for r in rs) else None})
with (out/'condition_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(summary[0].keys()));w.writeheader();w.writerows(summary)
print(json.dumps({'tasks':len(task),'episodes':len(rows),'output':str(out)},ensure_ascii=False,indent=2))
