#!/usr/bin/env python3
import json,random,argparse
from pathlib import Path
ap=argparse.ArgumentParser();ap.add_argument('--out-dir',default='data');a=ap.parse_args();out=Path(a.out_dir);out.mkdir(parents=True,exist_ok=True)
patterns={'baseline':{'17':[0,0,1,0],'23':[0,0,0,0],'41':[1,0,1,0]},'oracle_plan':{'17':[1,1,1,1],'23':[0,0,1,0],'41':[1,1,1,1]}}
for cond,pat in patterns.items():
 sims=[]
 for ti,(tid,ys) in enumerate(pat.items()):
  for trial,y in enumerate(ys):
   sims.append({'id':f'mock-{cond}-{tid}-{trial}','task_id':tid,'trial':trial,'seed':300+trial,'termination_reason':'user_stop','agent_cost':round((.003 if cond=='baseline' else .0035)+.0002*trial,4),'duration':9+trial,'reward_info':{'reward':float(y)},'messages':[{'role':'user','content':'TEACHING_MOCK_ONLY'},{'role':'assistant','content':'TEACHING_MOCK_ONLY'}]})
 d={'notice':'TEACHING_MOCK_ONLY - DO NOT USE AS RESEARCH EVIDENCE','timestamp':'2026-09-29T00:00:00Z','info':{'git_commit':'TEACHING_MOCK','num_trials':4,'seed':300,'agent_info':{'implementation':'llm_agent' if cond=='baseline' else 'llm_agent_gt','llm':'mock-model'},'user_info':{'implementation':'user_simulator','llm':'mock-user'},'environment_info':{'domain_name':'retail'}},'tasks':[{'id':x,'evaluation_criteria':{'actions':[{'name':'mock_action','arguments':{}}]}} for x in pat],'simulations':sims}
 (out/f'teaching_mock_{cond}.json').write_text(json.dumps(d,ensure_ascii=False,indent=2),encoding='utf-8')
 print(out/f'teaching_mock_{cond}.json')
