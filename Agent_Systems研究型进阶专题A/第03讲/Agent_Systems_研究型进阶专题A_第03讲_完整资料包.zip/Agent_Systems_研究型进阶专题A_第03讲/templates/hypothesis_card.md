# Hypothesis Card

- Date:
- Benchmark/version:
- Domain / task IDs:

## 1. Observed failure pattern

## 2. Hypothesis (H1)

## 3. Falsification condition
如果出现什么结果，我就认为 H1 不被支持？

## 4. Intervention

## 5. Predicted observable changes
- success_rate:
- pass^k:
- First Bad Span:
- cost/steps:

## 6. Alternative explanations

## 7. Result

## 8. Conclusion strength
- [ ] supports
- [ ] does_not_support
- [ ] insufficient_evidence

## 9. Next minimal experiment
