# Mechanism Interpretation

## Observation

## Baseline evidence

## Intervention evidence

## What changed?

## What did NOT change?

## Supported mechanism

## Alternative explanations still alive

## Strongest wording allowed
“Results are consistent with / support ...”

## Follow-up experiment
