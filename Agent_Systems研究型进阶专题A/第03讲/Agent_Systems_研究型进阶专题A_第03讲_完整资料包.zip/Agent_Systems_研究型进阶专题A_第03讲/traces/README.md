# Traces
真实运行后，可把需要人工比较的 baseline/oracle-plan trajectory 导出到这里。
优先看 `results/.../trace_review_queue.csv` 中 priority=1 的 task。
