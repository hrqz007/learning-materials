# Agent Systems 研究型进阶专题 A · 第4讲

主题：从 Oracle 诊断到最小机制干预 - Pre-Write Verification。

建议顺序：
1. 先读 `01_零基础讲义.pdf`。
2. 按 `03_实验指导书.docx` 做 24 条 trajectory 的 pilot。
3. 用 `04_实验设计书.docx` 检查控制变量。
4. 运行 `src/00_tau2_compat_check.py`（不调用付费 API）。
5. 再运行 `src/run_prewrite_ablation.py`。
6. 用 `src/compare_prewrite_conditions.py` 生成结果表。
7. 人工审查 review_queue，填写 First Bad Span 模板。

注意：`data/teaching_mock_*.json` 全部是教学模拟数据，只用于验证分析流程，不代表任何真实模型表现。
