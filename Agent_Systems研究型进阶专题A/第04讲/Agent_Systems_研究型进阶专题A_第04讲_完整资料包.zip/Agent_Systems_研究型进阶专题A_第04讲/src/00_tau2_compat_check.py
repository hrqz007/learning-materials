#!/usr/bin/env python3
"""No paid API calls. Checks the tau2 interfaces used by Lecture 4."""
from tau2.environment.toolkit import ToolKitBase, ToolType, is_tool
from tau2.registry import registry
from tau2.environment.tool import as_tool
from prewrite_verify_agent import create_prewrite_verify_agent, _tool_type

class DummyKit(ToolKitBase):
    @is_tool(ToolType.READ)
    def read_x(self, key: str) -> str:
        """Read x. Args: key: key. Returns: value."""
        return key

    @is_tool(ToolType.WRITE)
    def write_x(self, key: str) -> str:
        """Write x. Args: key: key. Returns: result."""
        return key

kit=DummyKit()
tools=list(kit.get_tools().values())
observed={t.name: str(_tool_type(t)) for t in tools}
print('tool types:', observed)
assert any(t.name=='write_x' and (_tool_type(t)==ToolType.WRITE or str(_tool_type(t))=='write') for t in tools)
name='prewrite_verify_agent_a04_check'
if name not in registry.get_agents():
    registry.register_agent_factory(create_prewrite_verify_agent,name)
assert name in registry.get_agents()
print('PASS: ToolType.WRITE detection and runtime registry registration work.')
