#!/usr/bin/env python3
import argparse,csv
p=argparse.ArgumentParser()
p.add_argument('mechanism_matrix')
p.add_argument('--limit-positive',type=int,default=2)
p.add_argument('--limit-negative',type=int,default=1)
a=p.parse_args()
with open(a.mechanism_matrix,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))
pos=[r for r in rows if 'planning_bottleneck_supported' in (r.get('preliminary_interpretation') or '')]
neg=[r for r in rows if r not in pos]
pos=sorted(pos,key=lambda r:float(r.get('delta_success_rate',0)),reverse=True)[:a.limit_positive]
neg=sorted(neg,key=lambda r:float(r.get('delta_success_rate',0)))[:a.limit_negative]
print('positive_targets:', ' '.join(r['task_id'] for r in pos))
print('negative_controls:', ' '.join(r['task_id'] for r in neg))
print('TASK_IDS=' + ' '.join([r['task_id'] for r in pos+neg]))
