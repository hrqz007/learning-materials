#!/usr/bin/env python3
import json,platform,sys,argparse
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--out',required=True);p.add_argument('--note',default='');a=p.parse_args()
obj={'lecture':'A04','python':sys.version,'platform':platform.platform(),'note':a.note,'reproducibility_fields':['tau2 git commit/tag','agent model','user model','task ids','num trials','seed','agent implementation','verifier prompt hash']}
Path(a.out).write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8')
