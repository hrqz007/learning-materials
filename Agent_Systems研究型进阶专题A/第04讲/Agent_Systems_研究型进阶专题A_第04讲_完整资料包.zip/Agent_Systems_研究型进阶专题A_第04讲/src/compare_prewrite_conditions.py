#!/usr/bin/env python3
import argparse,json,csv,math
from pathlib import Path
from collections import defaultdict

def load(p):
    return json.loads(Path(p).read_text(encoding='utf-8'))

def reward(s):
    ri=s.get('reward_info') or {}
    v=ri.get('reward',s.get('reward'))
    return None if v is None else float(v)

def is_infra(s): return s.get('termination_reason')=='infrastructure_error'
def success(s):
    r=reward(s); return None if r is None else abs(r-1.0)<=1e-6

def passk(n,c,k):
    if n<k:return None
    return math.comb(c,k)/math.comb(n,k)

def raw_records(s):
    out=[]
    for m in s.get('messages') or []:
        rd=m.get('raw_data') or {}
        recs=rd.get('prewrite_verification') or []
        if isinstance(recs,dict): recs=[recs]
        for r in recs:
            x=dict(r); x['simulation_id']=s.get('id'); x['task_id']=s.get('task_id'); x['trial']=s.get('trial'); out.append(x)
    return out

def summarize(label,data):
    sims=data.get('simulations',[]); evals=[s for s in sims if not is_infra(s) and success(s) is not None]
    ss=sum(bool(success(s)) for s in evals); costs=[s.get('agent_cost') for s in evals if s.get('agent_cost') is not None]; durations=[s.get('duration') for s in evals if s.get('duration') is not None]
    return {'condition':label,'evaluable_episodes':len(evals),'success_rate':ss/len(evals) if evals else None,'infra_errors':sum(is_infra(s) for s in sims),'mean_agent_cost':sum(costs)/len(costs) if costs else None,'mean_duration':sum(durations)/len(durations) if durations else None}

p=argparse.ArgumentParser(); p.add_argument('baseline'); p.add_argument('prewrite'); p.add_argument('--out',required=True); a=p.parse_args(); out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
B=load(a.baseline); P=load(a.prewrite)

def write_csv(name,rows):
    if not rows:return
    keys=[]
    for r in rows:
        for k in r:
            if k not in keys:keys.append(k)
    with open(out/name,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rows)

write_csv('condition_summary.csv',[summarize('baseline',B),summarize('prewrite',P)])
by={}
for label,data in [('baseline',B),('prewrite',P)]:
    g=defaultdict(list)
    for s in data.get('simulations',[]):
        if not is_infra(s) and success(s) is not None:g[str(s.get('task_id'))].append(s)
    by[label]=g
rows=[]
for tid in sorted(set(by['baseline'])|set(by['prewrite'])):
    row={'task_id':tid}
    for label in ['baseline','prewrite']:
        sims=by[label].get(tid,[]); n=len(sims); c=sum(bool(success(s)) for s in sims)
        row[f'{label}_n']=n; row[f'{label}_successes']=c; row[f'{label}_success_rate']=c/n if n else None
        for k in range(1,5): row[f'{label}_pass^{k}']=passk(n,c,k)
        costs=[s.get('agent_cost') for s in sims if s.get('agent_cost') is not None]; durs=[s.get('duration') for s in sims if s.get('duration') is not None]
        row[f'{label}_mean_cost']=sum(costs)/len(costs) if costs else None; row[f'{label}_mean_duration']=sum(durs)/len(durs) if durs else None
    b=row.get('baseline_success_rate'); q=row.get('prewrite_success_rate'); row['delta_success_rate']=(q-b) if b is not None and q is not None else None
    rows.append(row)
write_csv('task_comparison.csv',rows)

events=[]
for s in P.get('simulations',[]): events.extend(raw_records(s))
write_csv('verification_events.csv',events)
counts=defaultdict(lambda:defaultdict(int))
for e in events: counts[str(e.get('task_id'))][str(e.get('decision'))]+=1
mech=[]
for r in rows:
    tid=str(r['task_id']); delta=r.get('delta_success_rate')
    mech.append({'task_id':tid,'delta_success_rate':delta,'verify_events':sum(counts[tid].values()),'allow':counts[tid].get('ALLOW',0),'reconsider':counts[tid].get('RECONSIDER',0),'force_nonwrite':counts[tid].get('FORCE_NONWRITE',0),'interpretation':'inspect_trace_for_selective_write_boundary_effect' if (delta or 0)>0 else 'no_positive_signal_or_negative_control'})
write_csv('mechanism_signal.csv',mech)
# simple review queue: biggest positive delta first, then regressions
queue=[]
for r in sorted(rows,key=lambda x:abs(x.get('delta_success_rate') or 0),reverse=True):
    queue.append({'priority':1 if (r.get('delta_success_rate') or 0)!=0 else 2,'task_id':r['task_id'],'delta_success_rate':r.get('delta_success_rate'),'review':'pair baseline/prewrite trajectories; inspect candidate WRITE, verifier decision, First Bad Span, false positive/negative'})
write_csv('review_queue.csv',queue)
print('Wrote analysis to',out)
