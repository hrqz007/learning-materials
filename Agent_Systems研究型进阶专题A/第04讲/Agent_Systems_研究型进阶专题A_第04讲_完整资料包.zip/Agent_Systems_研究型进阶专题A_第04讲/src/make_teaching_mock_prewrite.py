#!/usr/bin/env python3
import json,argparse,random
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--baseline',required=True);p.add_argument('--prewrite',required=True);a=p.parse_args()
patterns={'17':([0,0,1,0],[1,1,1,0]),'41':([1,0,1,0],[1,1,1,1]),'23':([0,0,0,0],[0,0,1,0])}
def build(kind):
    sims=[]
    for tid,(b,q) in patterns.items():
        arr=b if kind=='baseline' else q
        for tr,succ in enumerate(arr):
            messages=[]
            if kind=='prewrite':
                # Educational process logs: target tasks have meaningful reconsider events; negative control mostly unchanged.
                if tid in ('17','41') and tr in (0,1):
                    rec=[{'cycle':1,'decision':'RECONSIDER','reason':'Required eligibility evidence is not yet established.','candidate_write_calls':[{'name':'modify_order','arguments':{'example':'mock'}}]}]
                else:
                    rec=[{'cycle':1,'decision':'ALLOW','reason':'Policy and required evidence are satisfied.','candidate_write_calls':[{'name':'modify_order','arguments':{'example':'mock'}}]}] if tr==2 else []
                if rec: messages=[{'role':'assistant','content':None,'tool_calls':None,'raw_data':{'prewrite_verification':rec}}]
            sims.append({'id':f'mock-{kind}-{tid}-{tr}','task_id':tid,'trial':tr,'seed':300+tr,'reward_info':{'reward':float(succ)},'termination_reason':'user_stop','agent_cost':round((0.0032+tr*0.0002)*(1.0 if kind=='baseline' else 1.35),6),'duration':10+tr+(3 if kind=='prewrite' else 0),'messages':messages})
    return {'info':{'note':'TEACHING MOCK ONLY - NOT REAL MODEL PERFORMANCE'},'tasks':[],'simulations':sims}
Path(a.baseline).write_text(json.dumps(build('baseline'),ensure_ascii=False,indent=2),encoding='utf-8')
Path(a.prewrite).write_text(json.dumps(build('prewrite'),ensure_ascii=False,indent=2),encoding='utf-8')
