#!/usr/bin/env python3
"""Pre-Write Verification agent for tau2-bench v1.0.1.

This is a research/teaching intervention. It does NOT use benchmark gold actions.
It only adds an LLM verification gate before ToolType.WRITE calls.
"""
import re
from typing import Optional

from tau2.agent.llm_agent import LLMAgent
from tau2.data_model.message import AssistantMessage, MultiToolMessage, SystemMessage, UserMessage
from tau2.environment.toolkit import ToolType
from tau2.utils.llm_utils import generate

VERIFIER_PROMPT = """You are an internal action verifier. The candidate action below is about to mutate external state.
Do NOT use benchmark gold answers. Judge only from the domain policy and conversation evidence already visible above.

Check:
1) Is this WRITE action permitted by policy?
2) Are required preconditions satisfied?
3) Are critical arguments grounded in observed/user-provided information rather than guessed?

Candidate WRITE call(s):
{candidate}

Output exactly two lines:
DECISION: ALLOW
REASON: <one concise sentence>

or
DECISION: RECONSIDER
REASON: <one concise sentence>
"""

RECONSIDER_PROMPT = """An internal verifier rejected your proposed WRITE action for this reason:
{reason}

Reconsider the next step. Do not mention the verifier to the user. You may use a READ tool, ask the user for missing information, choose another action, or perform a WRITE only if the missing evidence/problem is actually resolved."""

FORCE_NONWRITE_PROMPT = """Your proposed WRITE action still lacks sufficient verification. In this turn, do NOT perform a WRITE action. Use a READ tool if useful, or ask the user for the missing information. Do not mention the internal verifier."""


def _tool_type(tool):
    func = getattr(tool, "_func", None)
    candidates = [func, getattr(func, "__func__", None)]
    for obj in candidates:
        if obj is None:
            continue
        value = getattr(obj, "__tool_type__", None)
        if value is not None:
            return value
    return None


class PreWriteVerifyAgent(LLMAgent):
    def __init__(self, tools, domain_policy, llm, llm_args=None, max_verify_cycles=2):
        super().__init__(tools=tools, domain_policy=domain_policy, llm=llm, llm_args=llm_args)
        self.max_verify_cycles = max_verify_cycles
        self.write_tool_names = {
            t.name for t in tools if _tool_type(t) == ToolType.WRITE or str(_tool_type(t)) == "write"
        }
        self.nonwrite_tools = [t for t in tools if t.name not in self.write_tool_names]

    def _write_calls(self, message: AssistantMessage):
        if not message.tool_calls:
            return []
        return [tc for tc in message.tool_calls if tc.name in self.write_tool_names]

    @staticmethod
    def _fmt_calls(calls):
        return "\n".join(f"- {tc.name}({tc.arguments})" for tc in calls)

    @staticmethod
    def _parse_verdict(text: str):
        text = text or ""
        m = re.search(r"DECISION\s*:\s*(ALLOW|RECONSIDER)", text, re.I)
        decision = m.group(1).upper() if m else "RECONSIDER"
        r = re.search(r"REASON\s*:\s*(.+)", text, re.I)
        reason = r.group(1).strip() if r else "Verifier output could not be parsed; fail-closed."
        return decision, reason

    def _verify(self, state, calls):
        prompt = VERIFIER_PROMPT.format(candidate=self._fmt_calls(calls))
        response = generate(
            model=self.llm,
            tools=[],
            messages=state.system_messages + state.messages + [UserMessage(role="user", content=prompt)],
            call_name="prewrite_verify",
            **self.llm_args,
        )
        return self._parse_verdict(response.content or "")

    @staticmethod
    def _attach(message, records):
        raw = dict(message.raw_data or {})
        raw["prewrite_verification"] = records
        message.raw_data = raw
        return message

    def _generate_next_message(self, message, state):
        if isinstance(message, MultiToolMessage):
            state.messages.extend(message.tool_messages)
        else:
            state.messages.append(message)

        base_messages = state.system_messages + state.messages
        candidate = generate(
            model=self.llm,
            tools=self.tools,
            messages=base_messages,
            call_name="agent_response",
            **self.llm_args,
        )
        records = []

        for cycle in range(self.max_verify_cycles):
            writes = self._write_calls(candidate)
            if not writes:
                return self._attach(candidate, records)

            decision, reason = self._verify(state, writes)
            records.append({
                "cycle": cycle + 1,
                "decision": decision,
                "reason": reason,
                "candidate_write_calls": [
                    {"name": tc.name, "arguments": tc.arguments} for tc in writes
                ],
            })
            if decision == "ALLOW":
                return self._attach(candidate, records)

            candidate = generate(
                model=self.llm,
                tools=self.tools,
                messages=base_messages + [UserMessage(role="user", content=RECONSIDER_PROMPT.format(reason=reason))],
                call_name="prewrite_reconsider",
                **self.llm_args,
            )

        # Fail-closed fallback: after repeated rejected writes, do not expose WRITE tools this turn.
        fallback = generate(
            model=self.llm,
            tools=self.nonwrite_tools,
            messages=base_messages + [UserMessage(role="user", content=FORCE_NONWRITE_PROMPT)],
            call_name="prewrite_fallback_nonwrite",
            **self.llm_args,
        )
        records.append({"cycle": self.max_verify_cycles + 1, "decision": "FORCE_NONWRITE"})
        return self._attach(fallback, records)


def create_prewrite_verify_agent(tools, domain_policy, **kwargs):
    return PreWriteVerifyAgent(
        tools=tools,
        domain_policy=domain_policy,
        llm=kwargs.get("llm"),
        llm_args=kwargs.get("llm_args"),
    )
