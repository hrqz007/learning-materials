#!/usr/bin/env python3
import argparse
from tau2.data_model.simulation import TextRunConfig
from tau2.registry import registry
from tau2.runner import run_domain
from prewrite_verify_agent import create_prewrite_verify_agent

p=argparse.ArgumentParser()
p.add_argument('--task-ids',nargs='+',required=True)
p.add_argument('--agent-llm',required=True)
p.add_argument('--user-llm',required=True)
p.add_argument('--num-trials',type=int,default=4)
p.add_argument('--seed',type=int,default=300)
p.add_argument('--max-concurrency',type=int,default=1)
p.add_argument('--prefix',default='a04_prewrite')
a=p.parse_args()

name='prewrite_verify_agent'
if name not in registry.get_agents():
    registry.register_agent_factory(create_prewrite_verify_agent,name)

common=dict(
    domain='retail', task_ids=a.task_ids, llm_agent=a.agent_llm, llm_user=a.user_llm,
    num_trials=a.num_trials, seed=a.seed, max_concurrency=a.max_concurrency,
)
print('=== BASELINE ===')
run_domain(TextRunConfig(agent='llm_agent',save_to=a.prefix+'_baseline',**common))
print('=== PREWRITE ===')
run_domain(TextRunConfig(agent=name,save_to=a.prefix+'_prewrite',**common))
print('Done. Compare:')
print(f'data/simulations/{a.prefix}_baseline/results.json')
print(f'data/simulations/{a.prefix}_prewrite/results.json')
