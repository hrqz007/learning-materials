# Method Card - Pre-Write Verification

## Target failure

## Mechanism hypothesis

## Trigger condition
Only before ToolType.WRITE.

## Verifier inputs
- domain policy
- conversation/history
- proposed write tool + arguments

## Allowed decisions
- ALLOW
- RECONSIDER

## Expected selective effect

## Negative control

## Cost/latency budget

## Main threats / alternative explanations
