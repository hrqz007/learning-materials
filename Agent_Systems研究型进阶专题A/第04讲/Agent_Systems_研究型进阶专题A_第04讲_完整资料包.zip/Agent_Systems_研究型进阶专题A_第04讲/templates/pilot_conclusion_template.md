# A04 Pilot Conclusion

## 1. Observed outcome change

## 2. Process evidence (verification events)

## 3. First Bad Span changes

## 4. False positives / false negatives

## 5. Cost and latency overhead

## 6. Negative-control behavior

## 7. Supported / unsupported parts of H2

## 8. Decision: expand, revise, or reject the mechanism
