把需要人工对照的 baseline/prewrite Trace 记录或导出放在这里。优先检查 Baseline FAIL→PreWrite PASS 与 Baseline PASS→PreWrite FAIL。
