# 研究型进阶专题 A · 第5讲

主题：**Component Error Correlation / 组件错误相关性**。

本讲不是继续堆一个更复杂的 verifier，而是学习如何测量：Agent 与 Verifier 是否在同一批困难样本上共同失败。

推荐顺序：
1. 阅读 `01_零基础讲义.pdf`。
2. 看 `03_实验指导书.docx`，先运行教学 Mock。
3. 在 **tau2-bench v1.0.1 项目根目录、完成 `uv sync` 后**，用 `src/00_tau2_compat_check.py` 做接口自检。
4. 用 `src/run_shadow_audit.py` 跑真实 Shadow Verifier。
5. 用 `prepare_write_annotation.py` 生成标注表，人工标 VALID/INVALID/UNCERTAIN。
6. 用 `analyze_error_correlation.py` 计算四象限、κ 和 φ。

**教学 Mock 不是真实模型成绩，只用于验证分析流水线。**


> 说明：本资料包自身不包含 tau2-bench 依赖；兼容性自检必须在已安装 tau2 的实验环境中运行。
