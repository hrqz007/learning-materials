#!/usr/bin/env python3
"""No paid API calls. Check the tau2 interfaces used in Lecture 5."""
from tau2.environment.toolkit import ToolKitBase, ToolType, is_tool
from tau2.registry import registry
from shadow_verify_agent import create_shadow_verify_agent, _tool_type

class DummyKit(ToolKitBase):
    @is_tool(ToolType.READ)
    def read_x(self, key: str) -> str:
        """Read x. Args: key: key. Returns: value."""
        return key
    @is_tool(ToolType.WRITE)
    def write_x(self, key: str) -> str:
        """Write x. Args: key: key. Returns: result."""
        return key

kit = DummyKit()
tools = list(kit.get_tools().values())
assert any(t.name == "write_x" and (_tool_type(t) == ToolType.WRITE or str(_tool_type(t)) == "write") for t in tools)
name = "a05_shadow_agent_compat_check"
if name not in registry.get_agents():
    registry.register_agent_factory(create_shadow_verify_agent, name)
assert name in registry.get_agents()
print("PASS: WRITE detection and runtime agent registration are compatible.")
