#!/usr/bin/env python3
import argparse,csv,json,math
from pathlib import Path
from collections import defaultdict

p=argparse.ArgumentParser(); p.add_argument('annotation_csv'); p.add_argument('--out',required=True); a=p.parse_args()
out=Path(a.out); out.mkdir(parents=True,exist_ok=True)
with open(a.annotation_csv,encoding='utf-8-sig',newline='') as f: rows=list(csv.DictReader(f))

usable=[]
for r in rows:
    label=(r.get('human_label_VALID_INVALID_UNCERTAIN') or '').strip().upper()
    dec=(r.get('verifier_decision') or '').strip().upper()
    if label not in {'VALID','INVALID'} or dec not in {'ALLOW','RECONSIDER'}: continue
    x=dict(r)
    x['agent_error']=1 if label=='INVALID' else 0
    x['verifier_error']=1 if ((label=='INVALID' and dec=='ALLOW') or (label=='VALID' and dec=='RECONSIDER')) else 0
    x['dangerous_cofailure']=1 if (label=='INVALID' and dec=='ALLOW') else 0
    x['safe_catch']=1 if (label=='INVALID' and dec=='RECONSIDER') else 0
    x['false_block']=1 if (label=='VALID' and dec=='RECONSIDER') else 0
    usable.append(x)

def safe_div(a,b): return a/b if b else None

def phi(n11,n10,n01,n00):
    den=(n11+n10)*(n01+n00)*(n11+n01)*(n10+n00)
    return (n11*n00-n10*n01)/math.sqrt(den) if den>0 else None

N=len(usable); invalid=sum(x['agent_error'] for x in usable); verr=sum(x['verifier_error'] for x in usable); joint=sum(x['dangerous_cofailure'] for x in usable)
valid=N-invalid
safe=sum(x['safe_catch'] for x in usable); falseb=sum(x['false_block'] for x in usable)
n11=joint; n10=invalid-joint; n01=falseb; n00=valid-falseb
pA=safe_div(invalid,N); pV=safe_div(verr,N); obs=safe_div(joint,N); indep=(pA*pV) if pA is not None and pV is not None else None
kappa=safe_div(obs,indep) if indep not in (None,0) else None
summary={
 'usable_proposals':N,'invalid_proposals':invalid,'valid_proposals':valid,
 'agent_proposal_error_rate':pA,'verifier_error_rate':pV,
 'invalid_catch_rate':safe_div(safe,invalid),'valid_false_block_rate':safe_div(falseb,valid),
 'dangerous_cofailure_rate':obs,'independence_expected_joint_error':indep,
 'cofailure_ratio_kappa':kappa,'phi_error_correlation':phi(n11,n10,n01,n00),
 'n11_agent_error_verifier_error':n11,'n10_agent_error_verifier_correct':n10,
 'n01_agent_correct_verifier_error':n01,'n00_both_correct':n00,
}
(out/'summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')

def write_csv(name, rs):
    if not rs: return
    keys=[]
    for r in rs:
        for k in r:
            if k not in keys: keys.append(k)
    with open(out/name,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=keys); w.writeheader(); w.writerows(rs)

write_csv('quadrant_counts.csv',[
 {'quadrant':'VALID + ALLOW','count':n00,'meaning':'correct allow'},
 {'quadrant':'VALID + RECONSIDER','count':n01,'meaning':'false block'},
 {'quadrant':'INVALID + RECONSIDER','count':n10,'meaning':'safe catch'},
 {'quadrant':'INVALID + ALLOW','count':n11,'meaning':'dangerous co-failure'},
])
by=defaultdict(list)
for x in usable: by[str(x.get('task_id'))].append(x)
task_rows=[]
for tid,xs in sorted(by.items()):
    n=len(xs); ia=sum(x['agent_error'] for x in xs); ve=sum(x['verifier_error'] for x in xs); jj=sum(x['dangerous_cofailure'] for x in xs)
    task_rows.append({'task_id':tid,'n':n,'agent_error_rate':safe_div(ia,n),'verifier_error_rate':safe_div(ve,n),'dangerous_cofailure_rate':safe_div(jj,n),'dangerous_count':jj})
write_csv('task_level.csv',task_rows)
write_csv('dangerous_cases.csv',[x for x in usable if x['dangerous_cofailure']])
print(json.dumps(summary,ensure_ascii=False,indent=2))
