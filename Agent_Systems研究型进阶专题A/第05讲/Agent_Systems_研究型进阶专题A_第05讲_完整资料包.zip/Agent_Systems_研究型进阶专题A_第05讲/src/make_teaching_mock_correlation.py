#!/usr/bin/env python3
import csv, json
from pathlib import Path
root=Path(__file__).resolve().parents[1]
# 40 hand-constructed teaching proposals: same schema as the annotation sheet.
# 12 INVALID proposals; 28 VALID proposals. Verifier makes 10 errors total:
# 6 dangerous misses on INVALID proposals + 4 false blocks on VALID proposals.
rows=[]
idx=0
for task, invalid, dangerous, false_blocks, total in [
 ('17',4,2,1,10),('41',4,2,1,10),('23',2,1,1,10),('58',2,1,1,10)]:
    for j in range(total):
        idx+=1
        is_invalid=j<invalid
        if is_invalid:
            dec='ALLOW' if j<dangerous else 'RECONSIDER'
            label='INVALID'
        else:
            k=j-invalid
            dec='RECONSIDER' if k<false_blocks else 'ALLOW'
            label='VALID'
        rows.append({
            'simulation_id':f'mock_{task}_{j}','task_id':task,'trial':j%4,'turn_idx':3+j,
            'candidate_tool':'mock_write_action','candidate_arguments':json.dumps({'case':idx},ensure_ascii=False),
            'verifier_decision':dec,'verifier_reason':'TEACHING MOCK ONLY','verifier_llm':'mock-verifier',
            'reference_exact_match_DIAGNOSTIC_ONLY':'NO','context_excerpt':'Synthetic context for pipeline QA.',
            'human_label_VALID_INVALID_UNCERTAIN':label,'human_reason':'Synthetic ground truth for teaching.',
            'evidence_pointer':'mock','notes':'TEACHING MOCK - NOT A REAL MODEL RESULT'
        })
out=root/'data'/'teaching_mock_annotations.csv'
with open(out,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print(out)
