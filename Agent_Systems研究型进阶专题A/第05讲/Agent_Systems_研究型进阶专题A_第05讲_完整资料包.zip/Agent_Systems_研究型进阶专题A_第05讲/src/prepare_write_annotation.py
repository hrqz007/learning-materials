#!/usr/bin/env python3
import argparse, json, csv
from pathlib import Path

p=argparse.ArgumentParser(); p.add_argument('results_json'); p.add_argument('--out',required=True); a=p.parse_args()
data=json.loads(Path(a.results_json).read_text(encoding='utf-8'))
tasks={str(t.get('id')):t for t in data.get('tasks',[])}

def compact_context(messages, upto, keep=6):
    parts=[]
    for m in messages[max(0,upto-keep):upto+1]:
        role=m.get('role','?')
        if m.get('content'):
            c=' '.join(str(m.get('content')).split())[:350]
            parts.append(f'{role}: {c}')
        elif m.get('tool_calls'):
            calls='; '.join(f"{x.get('name')}({x.get('arguments')})" for x in m.get('tool_calls') or [])
            parts.append(f'{role}: TOOL_CALL {calls[:350]}')
    return ' || '.join(parts)

def ref_exact_match(task, name, args):
    ec=(task or {}).get('evaluation_criteria') or {}
    for act in ec.get('actions') or []:
        if act.get('requestor','assistant')!='assistant':
            continue
        if act.get('name')==name and (act.get('arguments') or {})==args:
            return 'YES'
    return 'NO'

rows=[]
for s in data.get('simulations',[]):
    msgs=s.get('messages') or []
    for i,m in enumerate(msgs):
        recs=(m.get('raw_data') or {}).get('shadow_verification') or []
        if isinstance(recs,dict): recs=[recs]
        for rec in recs:
            for call in rec.get('candidate_write_calls') or []:
                tid=str(s.get('task_id'))
                rows.append({
                    'simulation_id':s.get('id'),'task_id':tid,'trial':s.get('trial'),'turn_idx':m.get('turn_idx',i),
                    'candidate_tool':call.get('name'),'candidate_arguments':json.dumps(call.get('arguments') or {},ensure_ascii=False,sort_keys=True),
                    'verifier_decision':rec.get('decision'),'verifier_reason':rec.get('reason'),'verifier_llm':rec.get('verifier_llm'),
                    'reference_exact_match_DIAGNOSTIC_ONLY':ref_exact_match(tasks.get(tid),call.get('name'),call.get('arguments') or {}),
                    'context_excerpt':compact_context(msgs,i),
                    'human_label_VALID_INVALID_UNCERTAIN':'',
                    'human_reason':'',
                    'evidence_pointer':'',
                    'notes':'NO reference match does NOT mean invalid; judge against policy + observable state.'
                })

out=Path(a.out); out.parent.mkdir(parents=True,exist_ok=True)
fields=list(rows[0].keys()) if rows else [
    'simulation_id','task_id','trial','turn_idx','candidate_tool','candidate_arguments',
    'verifier_decision','verifier_reason','verifier_llm',
    'reference_exact_match_DIAGNOSTIC_ONLY','context_excerpt',
    'human_label_VALID_INVALID_UNCERTAIN','human_reason','evidence_pointer','notes'
]
with open(out,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
print(f'Wrote {len(rows)} WRITE proposals to {out}')
