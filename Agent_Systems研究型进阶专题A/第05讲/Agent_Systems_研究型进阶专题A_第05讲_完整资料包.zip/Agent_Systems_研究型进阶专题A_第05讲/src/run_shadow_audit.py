#!/usr/bin/env python3
import argparse, os
from tau2.data_model.simulation import TextRunConfig
from tau2.registry import registry
from tau2.runner import run_domain
from shadow_verify_agent import create_shadow_verify_agent

p = argparse.ArgumentParser()
p.add_argument('--task-ids', nargs='+', required=True)
p.add_argument('--agent-llm', required=True)
p.add_argument('--verifier-llm', required=True)
p.add_argument('--user-llm', required=True)
p.add_argument('--num-trials', type=int, default=4)
p.add_argument('--seed', type=int, default=300)
p.add_argument('--max-concurrency', type=int, default=1)
p.add_argument('--save-to', default='a05_shadow_audit')
a = p.parse_args()

os.environ['A05_VERIFIER_LLM'] = a.verifier_llm
os.environ['A05_VERIFIER_TEMPERATURE'] = '0'
name = 'a05_shadow_verify_agent'
if name not in registry.get_agents():
    registry.register_agent_factory(create_shadow_verify_agent, name)

config = TextRunConfig(
    domain='retail', agent=name,
    task_ids=a.task_ids,
    llm_agent=a.agent_llm,
    llm_user=a.user_llm,
    num_trials=a.num_trials,
    seed=a.seed,
    max_concurrency=a.max_concurrency,
    save_to=a.save_to,
)
run_domain(config)
print(f'Done: data/simulations/{a.save_to}/results.json')
print('Next: python src/prepare_write_annotation.py <results.json> --out write_annotation.csv')
