#!/usr/bin/env python3
"""Shadow verifier agent for tau2-bench v1.0.1.

The verifier observes candidate WRITE actions but NEVER changes the agent's action.
This makes it suitable for measuring component-error correlation without the
intervention changing the action distribution.
"""
import os, re, json
from tau2.agent.llm_agent import LLMAgent
from tau2.data_model.message import AssistantMessage, MultiToolMessage, UserMessage
from tau2.environment.toolkit import ToolType
from tau2.utils.llm_utils import generate

VERIFIER_PROMPT = """You are a shadow verifier for a customer-service agent.
The candidate action below may mutate external state. You are OBSERVING ONLY:
your decision will not change the action.

Use only the domain policy and conversation evidence already visible above.
Do NOT use benchmark gold actions or hidden answers.

Check:
1) Is this WRITE action permitted by policy?
2) Are all required preconditions satisfied?
3) Are critical arguments grounded in user-provided or tool-observed evidence?

Candidate WRITE call(s):
{candidate}

Output exactly two lines:
DECISION: ALLOW
REASON: <one concise sentence>

or
DECISION: RECONSIDER
REASON: <one concise sentence>
"""

def _tool_type(tool):
    func = getattr(tool, "_func", None)
    for obj in [func, getattr(func, "__func__", None)]:
        if obj is not None:
            value = getattr(obj, "__tool_type__", None)
            if value is not None:
                return value
    return None

class ShadowVerifyAgent(LLMAgent):
    def __init__(self, tools, domain_policy, llm, llm_args=None):
        super().__init__(tools=tools, domain_policy=domain_policy, llm=llm, llm_args=llm_args)
        self.write_tool_names = {
            t.name for t in tools
            if _tool_type(t) == ToolType.WRITE or str(_tool_type(t)) == "write"
        }
        self.verifier_llm = os.environ.get("A05_VERIFIER_LLM", llm)
        self.verifier_temperature = float(os.environ.get("A05_VERIFIER_TEMPERATURE", "0"))

    def _write_calls(self, message: AssistantMessage):
        return [tc for tc in (message.tool_calls or []) if tc.name in self.write_tool_names]

    @staticmethod
    def _parse(text):
        text = text or ""
        m = re.search(r"DECISION\s*:\s*(ALLOW|RECONSIDER)", text, re.I)
        decision = m.group(1).upper() if m else "UNKNOWN"
        m2 = re.search(r"REASON\s*:\s*(.+)", text, re.I)
        reason = m2.group(1).strip() if m2 else "Could not parse verifier reason."
        return decision, reason

    def _shadow_verify(self, state, calls):
        candidate = "\n".join(f"- {tc.name}({json.dumps(tc.arguments, ensure_ascii=False)})" for tc in calls)
        response = generate(
            model=self.verifier_llm,
            tools=[],
            messages=state.system_messages + state.messages + [
                UserMessage(role="user", content=VERIFIER_PROMPT.format(candidate=candidate))
            ],
            call_name="a05_shadow_verify",
            temperature=self.verifier_temperature,
        )
        decision, reason = self._parse(response.content or "")
        return {
            "decision": decision,
            "reason": reason,
            "verifier_llm": self.verifier_llm,
            "verifier_cost": getattr(response, "cost", None),
            "verifier_usage": getattr(response, "usage", None),
            "candidate_write_calls": [
                {"name": tc.name, "arguments": tc.arguments} for tc in calls
            ],
        }

    def _generate_next_message(self, message, state):
        # Reproduce the standard LLMAgent generation path.
        if isinstance(message, MultiToolMessage):
            state.messages.extend(message.tool_messages)
        else:
            state.messages.append(message)
        candidate = generate(
            model=self.llm,
            tools=self.tools,
            messages=state.system_messages + state.messages,
            call_name="agent_response",
            **self.llm_args,
        )
        writes = self._write_calls(candidate)
        if writes:
            record = self._shadow_verify(state, writes)
            raw = dict(candidate.raw_data or {})
            raw.setdefault("shadow_verification", []).append(record)
            candidate.raw_data = raw
        # IMPORTANT: return candidate unchanged. Shadow verifier never blocks or rewrites it.
        return candidate

def create_shadow_verify_agent(tools, domain_policy, **kwargs):
    return ShadowVerifyAgent(
        tools=tools,
        domain_policy=domain_policy,
        llm=kwargs.get("llm"),
        llm_args=kwargs.get("llm_args"),
    )
