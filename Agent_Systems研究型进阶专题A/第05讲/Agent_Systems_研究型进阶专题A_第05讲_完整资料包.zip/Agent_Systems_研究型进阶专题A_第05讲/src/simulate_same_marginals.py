#!/usr/bin/env python3
import csv, math
from pathlib import Path
rows=[]
for name,(n11,n10,n01,n00) in {
 'negative_complementary':(0,20,10,70),
 'independent':(2,18,8,72),
 'positive_shared_blind_spot':(6,14,4,76),
}.items():
    N=n11+n10+n01+n00; pA=(n11+n10)/N; pV=(n11+n01)/N; joint=n11/N; exp=pA*pV
    den=(n11+n10)*(n01+n00)*(n11+n01)*(n10+n00)
    phi=(n11*n00-n10*n01)/math.sqrt(den) if den else None
    rows.append({'scenario':name,'agent_error_rate':pA,'verifier_error_rate':pV,'joint_error_rate':joint,'independence_expected':exp,'kappa':joint/exp if exp else None,'phi':phi})
out=Path(__file__).resolve().parents[1]/'results'/'correlation_scenarios.csv'; out.parent.mkdir(exist_ok=True)
with open(out,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print(out)
