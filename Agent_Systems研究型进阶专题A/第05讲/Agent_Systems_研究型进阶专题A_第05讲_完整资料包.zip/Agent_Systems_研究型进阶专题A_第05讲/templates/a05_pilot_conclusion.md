# 第5讲 Pilot Conclusion

## 1. 数据规模
## 2. Agent proposal error rate
## 3. Verifier error rate
## 4. Dangerous co-failure rate
## 5. Independence baseline 与 κ
## 6. φ correlation
## 7. 最常见共盲点
## 8. 负向结果/反例
## 9. 下一轮实验

> 注意：小样本 κ/φ 只作为诊断信号，不作为论文级统计结论。
