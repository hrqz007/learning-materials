# Component Error Correlation Hypothesis Card

- 观察到的危险双错模式：
- Agent 首个错误位置：
- Verifier 为什么也没有识别：
- 共同依赖的证据/能力：
- 候选共盲点机制：
- 可证伪预测：
- 下一轮最小干预：
- 哪个结果会否定该假设：
