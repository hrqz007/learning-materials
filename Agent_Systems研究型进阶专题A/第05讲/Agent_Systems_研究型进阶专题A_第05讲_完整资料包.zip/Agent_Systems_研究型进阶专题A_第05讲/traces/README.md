# Trace audit

把 `dangerous_cases.csv` 中的 INVALID + ALLOW 样本优先放到这里精读。
重点记录：Agent 为什么提出错误 WRITE，Verifier 为什么也认为可以放行，两者是否共享同一错误证据或同一推理盲点。
