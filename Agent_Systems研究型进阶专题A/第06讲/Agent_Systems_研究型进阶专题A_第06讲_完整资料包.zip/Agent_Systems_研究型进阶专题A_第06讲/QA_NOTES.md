# 第6讲 QA Notes

- 文档渲染：PASS。DOCX 共 17 页；讲义 PDF 共 8 页。
- Python syntax compile：PASS。
- Teaching mock + analyzer：PASS。
- Fixed-proposal builder synthetic functional test：PASS（2 retained, 1 UNCERTAIN excluded）。
- tau2 import compatibility in packaging container：NOT RUN/PASS；当前容器没有安装 tau2，实际报 `ModuleNotFoundError: No module named 'tau2'`。必须在 tau2-bench v1.0.1 的 `uv sync` 环境中执行。
- Real verifier API calls：NOT RUN，避免产生费用并避免把模拟数据伪装成真实结果。
