# Agent Systems 研究型进阶专题 A · 第6讲

主题：**Shared Blind Spot Mechanism Ablation / 共盲点机制消融**。

本讲承接第5讲的 Component Error Correlation。第5讲只告诉我们“Agent 和 Verifier 是否共同失败”；第6讲开始问“为什么共同失败”。

推荐顺序：
1. 读 `01_零基础讲义.pdf`。
2. 跑教学 Mock：`python src/generate_teaching_mock.py`。
3. 用 `analyze_mechanism_ablation.py` 验证所有分析产物。
4. 真实验时，从第5讲的 `results.json + human annotations` 构造 fixed proposal set。
5. 先只跑 8~12 个 proposals × 4 variants，确认 API、输出解析和成本。
6. 再扩展到 30~50 个 proposals，并人工做机制标签。

**教学 Mock 是受控教学模拟，不代表任何 GPT / Claude / Gemini / DeepSeek / Kimi 或其他真实模型性能。**

真实 API 未在本资料包生成阶段调用，因此没有真实模型性能数据。

## 生成阶段 QA 说明

- 6 份 DOCX 已全部实际渲染并逐页检查，共 17 页；讲义 PDF 8 页另行渲染复核。
- `src/*.py` 已全部通过 Python 语法编译检查。
- 教学 Mock 生成器与机制消融分析器已实际执行，`results/teaching_mock_analysis/` 为其真实程序输出。
- `build_fixed_proposals.py` 已用最小 A05 风格合成输入做功能测试：正确保留 VALID/INVALID，正确排除 UNCERTAIN。
- 生成环境本身未安装 `tau2`，因此 `00_tau2_compat_check.py` 在这里无法完成 import 级运行；请在已执行 `uv sync` 的 tau2-bench v1.0.1 项目环境中运行该自检。
- `run_verifier_variants.py` 会产生真实 API 费用，本资料包生成阶段未调用它，也没有伪造任何真实模型实验结果。
