#!/usr/bin/env python3
"""No paid API. Verify the minimal tau2/LiteLLM dependencies used by Lecture 6."""
import tau2
import litellm
from tau2.runner import build_environment

env=build_environment('retail')
assert env.get_policy()
assert hasattr(litellm,'completion')
print('PASS: tau2 retail environment and LiteLLM are importable.')
