#!/usr/bin/env python3
"""Analyze fixed-proposal verifier variants. No API call."""
import argparse, csv, json, math
from pathlib import Path
from collections import defaultdict

p=argparse.ArgumentParser()
p.add_argument('--proposals',required=True)
p.add_argument('--verifier-outputs',required=True)
p.add_argument('--mechanism-labels',required=True)
p.add_argument('--out-dir',required=True)
a=p.parse_args()
props={x['proposal_id']:x for x in [json.loads(s) for s in Path(a.proposals).read_text(encoding='utf-8').splitlines() if s.strip()]}
outs=[json.loads(s) for s in Path(a.verifier_outputs).read_text(encoding='utf-8').splitlines() if s.strip()]
with open(a.mechanism_labels,encoding='utf-8-sig') as f: mech={r['proposal_id']:r for r in csv.DictReader(f)}
outdir=Path(a.out_dir); outdir.mkdir(parents=True,exist_ok=True)

def metrics(rows):
    rows=[r for r in rows if r.get('decision') in {'ALLOW','RECONSIDER'} and r.get('human_label') in {'VALID','INVALID'}]
    n=len(rows); inv=sum(r['human_label']=='INVALID' for r in rows); val=n-inv
    miss=sum(r['human_label']=='INVALID' and r['decision']=='ALLOW' for r in rows)
    catch=sum(r['human_label']=='INVALID' and r['decision']=='RECONSIDER' for r in rows)
    fb=sum(r['human_label']=='VALID' and r['decision']=='RECONSIDER' for r in rows)
    ta=sum(r['human_label']=='VALID' and r['decision']=='ALLOW' for r in rows)
    verr=miss+fb; pa=inv/n if n else 0; pv=verr/n if n else 0; joint=miss/n if n else 0; expected=pa*pv
    n11,n10,n01,n00=miss,catch,fb,ta
    den=(n11+n10)*(n01+n00)*(n11+n01)*(n10+n00)
    phi=(n11*n00-n10*n01)/math.sqrt(den) if den else None
    return {'n':n,'invalid_n':inv,'valid_n':val,'dangerous_miss_n':miss,'safe_catch_n':catch,'false_block_n':fb,'true_allow_n':ta,'invalid_miss_rate':miss/inv if inv else None,'valid_false_block_rate':fb/val if val else None,'verifier_error_rate':verr/n if n else None,'agent_proposal_error_rate':pa,'dangerous_cofailure_rate':joint,'independence_expected_joint_error':expected,'cofailure_ratio_kappa':joint/expected if expected else None,'phi_error_correlation':phi,'mean_cost_usd':sum(r.get('total_cost_usd') or 0 for r in rows)/n if n else None,'mean_latency_s':sum(r.get('total_latency_s') or 0 for r in rows)/n if n else None}

by=defaultdict(list)
for r in outs: by[r['variant']].append(r)
summary=[]
for v,rs in sorted(by.items()): summary.append({'variant':v,**metrics(rs)})
with open(outdir/'variant_summary.csv','w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(summary[0].keys())); w.writeheader(); w.writerows(summary)

# Paired invalid flips against baseline same_direct.
lookup={(r['proposal_id'],r['variant']):r for r in outs}
variants=sorted({r['variant'] for r in outs if r['variant']!='same_direct'})
flips=[]
for v in variants:
    mm=mc=cm=cc=0
    for pid,p0 in props.items():
        if p0.get('human_label')!='INVALID': continue
        b=lookup.get((pid,'same_direct')); x=lookup.get((pid,v))
        if not b or not x or b.get('decision') not in {'ALLOW','RECONSIDER'} or x.get('decision') not in {'ALLOW','RECONSIDER'}: continue
        bmiss=b['decision']=='ALLOW'; xmiss=x['decision']=='ALLOW'
        if bmiss and xmiss: mm+=1
        elif bmiss and not xmiss: mc+=1
        elif not bmiss and xmiss: cm+=1
        else: cc+=1
    flips.append({'variant_vs_same_direct':v,'miss_to_miss':mm,'miss_to_catch':mc,'catch_to_miss':cm,'catch_to_catch':cc,'net_miss_reduction':mc-cm})
with open(outdir/'paired_invalid_flips.csv','w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(flips[0].keys())); w.writeheader(); w.writerows(flips)

# Merge mechanism labels and calculate strata on INVALID proposals.
merged=[]
for r in outs:
    m=mech.get(r['proposal_id'],{})
    row={**r,'needed_evidence_present':m.get('needed_evidence_present_YES_NO_UNCERTAIN',''),'error_family':m.get('error_family_if_INVALID',''),'anchoring_plausible':m.get('candidate_anchoring_plausible_YES_NO_UNCERTAIN','')}
    merged.append(row)

for field,name in [('needed_evidence_present','by_evidence_presence.csv'),('error_family','by_error_family.csv'),('anchoring_plausible','by_anchoring_plausibility.csv')]:
    groups=defaultdict(list)
    for r in merged:
        if r.get('human_label')!='INVALID': continue
        value=(r.get(field) or '').strip()
        if not value: continue
        groups[(r['variant'],value)].append(r)
    rows=[]
    for (v,val),rs in sorted(groups.items()):
        miss=sum(x.get('decision')=='ALLOW' for x in rs); rows.append({'variant':v,field:val,'n_invalid':len(rs),'dangerous_miss_n':miss,'dangerous_miss_rate':miss/len(rs)})
    if rows:
        with open(outdir/name,'w',encoding='utf-8-sig',newline='') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

# Dangerous cases per variant for trace review.
danger=[r for r in merged if r.get('human_label')=='INVALID' and r.get('decision')=='ALLOW']
with open(outdir/'dangerous_cases_by_variant.csv','w',encoding='utf-8-sig',newline='') as f:
    fields=['proposal_id','task_id','variant','model','decision','reason','needed_evidence_present','error_family','anchoring_plausible','total_cost_usd','total_latency_s']
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows([{k:r.get(k) for k in fields} for r in danger])

print(json.dumps({'variants':summary,'paired_flips':flips},ensure_ascii=False,indent=2))
