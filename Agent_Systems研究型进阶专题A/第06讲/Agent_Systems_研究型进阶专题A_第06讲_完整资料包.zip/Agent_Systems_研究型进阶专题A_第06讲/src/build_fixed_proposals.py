#!/usr/bin/env python3
"""Build a fixed offline proposal set from Lecture 5 outputs.

Input 1: tau2 results.json produced by A05 shadow audit.
Input 2: A05 human annotation CSV with VALID/INVALID/UNCERTAIN labels.
Output: JSONL used by all A06 verifier variants + a mechanism annotation CSV.

No API call is made here.
"""
import argparse, csv, json
from pathlib import Path

p=argparse.ArgumentParser()
p.add_argument('--results', required=True)
p.add_argument('--annotations', required=True)
p.add_argument('--out-jsonl', required=True)
p.add_argument('--out-mechanism-csv', required=True)
a=p.parse_args()

data=json.loads(Path(a.results).read_text(encoding='utf-8'))
with open(a.annotations,encoding='utf-8-sig') as f:
    anns=list(csv.DictReader(f))

def norm_args(x):
    if isinstance(x,str):
        try: return json.dumps(json.loads(x),sort_keys=True,ensure_ascii=False)
        except Exception: return x
    return json.dumps(x or {},sort_keys=True,ensure_ascii=False)

ann_map={}
for r in anns:
    key=(str(r.get('simulation_id')),str(r.get('turn_idx')),str(r.get('candidate_tool')),norm_args(r.get('candidate_arguments')))
    ann_map[key]=r

def serialize_history(msgs, upto):
    out=[]
    for m in msgs[:upto+1]:
        item={'role':m.get('role'),'content':m.get('content'),'tool_calls':m.get('tool_calls')}
        # Keep tool outputs/text but discard large/debug raw_data from context.
        out.append(item)
    return out

proposals=[]; mechanism=[]; pid=0
for sim in data.get('simulations',[]):
    msgs=sim.get('messages') or []
    for i,m in enumerate(msgs):
        recs=(m.get('raw_data') or {}).get('shadow_verification') or []
        if isinstance(recs,dict): recs=[recs]
        if not recs: continue
        for rec in recs:
            for call in rec.get('candidate_write_calls') or []:
                key=(str(sim.get('id')),str(m.get('turn_idx',i)),str(call.get('name')),norm_args(call.get('arguments')))
                ar=ann_map.get(key)
                if ar is None:
                    continue
                label=(ar.get('human_label_VALID_INVALID_UNCERTAIN') or '').strip().upper()
                if label not in {'VALID','INVALID'}:
                    continue
                pid += 1
                prop={
                    'proposal_id':f'P{pid:04d}',
                    'simulation_id':str(sim.get('id')),
                    'task_id':str(sim.get('task_id')),
                    'trial':sim.get('trial'),
                    'turn_idx':m.get('turn_idx',i),
                    'candidate_tool':call.get('name'),
                    'candidate_arguments':call.get('arguments') or {},
                    'history':serialize_history(msgs,i-1),
                    'human_label':label,
                    'human_reason':ar.get('human_reason',''),
                    'evidence_pointer':ar.get('evidence_pointer',''),
                    'source_shadow_decision':rec.get('decision'),
                }
                proposals.append(prop)
                mechanism.append({
                    'proposal_id':prop['proposal_id'],'task_id':prop['task_id'],'human_label':label,
                    'needed_evidence_present_YES_NO_UNCERTAIN':'',
                    'error_family_if_INVALID':'',
                    'candidate_anchoring_plausible_YES_NO_UNCERTAIN':'',
                    'policy_ambiguity_YES_NO_UNCERTAIN':'',
                    'mechanism_notes':''
                })

out=Path(a.out_jsonl); out.parent.mkdir(parents=True,exist_ok=True)
with open(out,'w',encoding='utf-8') as f:
    for r in proposals: f.write(json.dumps(r,ensure_ascii=False)+'\n')
out2=Path(a.out_mechanism_csv); out2.parent.mkdir(parents=True,exist_ok=True)
fields=list(mechanism[0].keys()) if mechanism else ['proposal_id']
with open(out2,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(mechanism)
print(f'Wrote {len(proposals)} fixed proposals -> {out}')
print(f'Wrote mechanism annotation template -> {out2}')
