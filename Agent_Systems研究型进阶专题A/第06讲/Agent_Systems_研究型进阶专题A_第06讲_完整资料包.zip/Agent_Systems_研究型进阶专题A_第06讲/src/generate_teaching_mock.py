#!/usr/bin/env python3
"""Generate controlled teaching mock. NOT real model performance."""
import csv, json, random
from pathlib import Path
random.seed(6)
out=Path(__file__).resolve().parents[1]/'data'
out.mkdir(exist_ok=True)
# 48 fixed proposals: 20 INVALID, 28 VALID.
rows=[]
invalid_specs=[]
for fam,n,evid,anchor in [('missing_evidence',8,'NO','YES'),('policy_misread',6,'YES','NO'),('argument_grounding',6,'YES','YES')]:
    for i in range(n): invalid_specs.append((fam,evid,anchor))
valid_n=28
# Miss counts per invalid family, designed only to test analysis pipeline.
miss_sets={
 'same_direct': {'missing_evidence':6,'policy_misread':3,'argument_grounding':4},
 'same_recheck': {'missing_evidence':5,'policy_misread':3,'argument_grounding':3},
 'same_independent_first': {'missing_evidence':5,'policy_misread':2,'argument_grounding':1},
 'cross_direct': {'missing_evidence':5,'policy_misread':1,'argument_grounding':2},
}
false_blocks={'same_direct':4,'same_recheck':4,'same_independent_first':5,'cross_direct':5}
# Proposals JSONL + mechanism CSV
props=[]; mech=[]
for idx,(fam,evid,anchor) in enumerate(invalid_specs,1):
    pid=f'P{idx:04d}'; props.append({'proposal_id':pid,'task_id':str(10+(idx%4)),'human_label':'INVALID','candidate_tool':'mock_write','candidate_arguments':{'case':idx},'history':[{'role':'user','content':'TEACHING MOCK ONLY'}]}); mech.append({'proposal_id':pid,'task_id':str(10+(idx%4)),'human_label':'INVALID','needed_evidence_present_YES_NO_UNCERTAIN':evid,'error_family_if_INVALID':fam,'candidate_anchoring_plausible_YES_NO_UNCERTAIN':anchor,'policy_ambiguity_YES_NO_UNCERTAIN':'NO','mechanism_notes':'TEACHING MOCK ONLY'})
for j in range(valid_n):
    idx=len(props)+1; pid=f'P{idx:04d}'; props.append({'proposal_id':pid,'task_id':str(10+(idx%4)),'human_label':'VALID','candidate_tool':'mock_write','candidate_arguments':{'case':idx},'history':[{'role':'user','content':'TEACHING MOCK ONLY'}]}); mech.append({'proposal_id':pid,'task_id':str(10+(idx%4)),'human_label':'VALID','needed_evidence_present_YES_NO_UNCERTAIN':'YES','error_family_if_INVALID':'','candidate_anchoring_plausible_YES_NO_UNCERTAIN':'','policy_ambiguity_YES_NO_UNCERTAIN':'NO','mechanism_notes':'TEACHING MOCK ONLY'})
with open(out/'teaching_mock_fixed_proposals.jsonl','w',encoding='utf-8') as f:
    for r in props: f.write(json.dumps(r,ensure_ascii=False)+'\n')
with open(out/'teaching_mock_mechanism_labels.csv','w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(mech[0].keys())); w.writeheader(); w.writerows(mech)
# Build deterministic verifier outputs.
outs=[]
invalid_by_family={}
for fam in {'missing_evidence','policy_misread','argument_grounding'}: invalid_by_family[fam]=[r for r,m in zip(props,mech) if m['error_family_if_INVALID']==fam]
for v in miss_sets:
    miss_ids=set()
    for fam,k in miss_sets[v].items(): miss_ids.update(r['proposal_id'] for r in invalid_by_family[fam][:k])
    valid_ids=[r['proposal_id'] for r in props if r['human_label']=='VALID']
    fb=set(valid_ids[:false_blocks[v]])
    for r in props:
        dec='ALLOW'
        if r['human_label']=='INVALID' and r['proposal_id'] not in miss_ids: dec='RECONSIDER'
        if r['human_label']=='VALID' and r['proposal_id'] in fb: dec='RECONSIDER'
        calls=2 if v in {'same_recheck','same_independent_first'} else 1
        outs.append({'proposal_id':r['proposal_id'],'task_id':r['task_id'],'human_label':r['human_label'],'variant':v,'decision':dec,'reason':'TEACHING MOCK ONLY','model':'mock-same' if not v.startswith('cross') else 'mock-cross','calls':[],'total_cost_usd':0.001*calls,'total_latency_s':0.4*calls})
with open(out/'teaching_mock_verifier_outputs.jsonl','w',encoding='utf-8') as f:
    for r in outs: f.write(json.dumps(r,ensure_ascii=False)+'\n')
print('Generated controlled teaching mock. NOT real model performance.')
