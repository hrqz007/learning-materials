# A06 Shared-Blind-Spot Hypothesis Card

- 观察到的共错现象：
- 候选机制（只选一个作为本轮主假设）：model homogeneity / candidate anchoring / shared evidence bottleneck / other
- 可证伪预测：
- 主比较：
- compute-matched control：
- 人工机制标签：
- 哪个结果支持：
- 哪个结果否定：
- 仍然存在的替代解释：
- 下一轮最小实验：
