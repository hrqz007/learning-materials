# A06 Pilot Conclusion

## 1. 固定 proposal 数量与标签分布
## 2. Same-Direct 基线共错率
## 3. Same-Recheck：额外计算效应
## 4. Same-Independent-First：去锚定效应（与 Recheck 比）
## 5. Cross-Direct：模型异质性效应
## 6. Evidence strata：证据缺失是否跨 variant 持续失败
## 7. Paired flips：哪些 proposal 被真正救回 / 新增误判
## 8. 成本与延迟
## 9. 机制边界与替代解释
## 10. 是否值得扩展为正式研究问题
