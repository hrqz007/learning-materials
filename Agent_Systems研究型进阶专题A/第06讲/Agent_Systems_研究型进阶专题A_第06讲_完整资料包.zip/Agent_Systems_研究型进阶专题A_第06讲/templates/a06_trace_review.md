# A06 Paired Trace Review

Proposal ID: 
Human label: INVALID / VALID
Error family: 
Needed evidence present: YES / NO / UNCERTAIN

## Same-Direct
Decision / reason:

## Same-Recheck
Decision / reason:

## Same-Independent-First
Decision / reason:

## Cross-Direct
Decision / reason:

## 机制解释
- 哪个最小改变发生了 verdict flip？
- 该 flip 与候选机制一致吗？
- 有什么替代解释？
