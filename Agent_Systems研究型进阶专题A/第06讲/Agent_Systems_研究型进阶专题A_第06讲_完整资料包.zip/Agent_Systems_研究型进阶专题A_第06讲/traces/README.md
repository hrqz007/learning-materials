# A06 paired trace review

优先审查 `dangerous_cases_by_variant.csv`：
1. Same-Direct miss，但 Independent-First catch 的样本；
2. Same-Direct miss，但 Cross-Direct catch 的样本；
3. 所有 variant 都 miss 的样本。

第三类尤其重要：它可能指向共同证据瓶颈，而不是 Reviewer 结构问题。
