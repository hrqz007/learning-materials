# 第07讲 QA 记录

## 文档渲染
- 01_零基础讲义.docx：最终 7 页，全部实际渲染并逐页检查。
- 03_实验指导书.docx：2 页，全部实际渲染并逐页检查。
- 04_实验设计书.docx：2 页，全部实际渲染并逐页检查。
- 05_练习题.docx：1 页，已检查。
- 06_练习题答案.docx：1 页，已检查。
- 07_术语速查表.docx：1 页，已检查。
- 02_零基础讲义.pdf：7 页，使用独立 PDF 渲染流程逐页检查。

检查重点：中文字体、图表边界、表格换行、代码框、页脚、分页、裁切与重叠。最终版本未发现影响阅读的排版问题。

## 代码 QA
- src/*.py 均通过 Python 语法编译检查。
- generate_teaching_mock.py 已实际运行，生成 60 个 proposals × 4 conditions × 3 members = 720 条受控教学 judgment。
- analyze_error_diversity.py 已实际运行并生成 member_summary.csv、pairwise_error_structure.csv、system_summary.csv、disagreement_cases.csv。
- prepare_panel_inputs.py 已用最小合成输入做功能测试；测试文件已从正式资料包删除。
- run_diversity_panel.py 未在本制作用容器进行真实商业 API 调用；原因是当前容器未安装 litellm，也没有用户 API 凭据。请在用户已完成依赖安装的 tau2-bench 环境中运行 00_dependency_check.py 后再做 smoke test。

## 数据边界
资料包中的 teaching_mock_* 全部为人为构造的受控教学数据，只用于验证分析代码和训练实验解释能力，不代表任何真实模型或厂商的实际性能。
