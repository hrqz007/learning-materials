# 第7讲学习说明

本讲承接第6讲 fixed proposal 机制实验。核心问题：怎样主动设计有用的 Error Diversity，并验证它是否经过 error decorrelation 转化为 system reliability。

建议顺序：
1. 先读 `02_零基础讲义.pdf`。
2. 做练习题，再对答案。
3. 先运行 teaching mock，理解四类指标。
4. 再用自己的 A06 fixed proposals 做 4~6 条 API smoke test。
5. Pilot 不建议超过 36~48 proposals，除非结果已经显示稳定机制信号。

注意：`data/teaching_mock_*` 全部是人为构造教学数据，不代表任何真实模型。
