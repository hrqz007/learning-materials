#!/usr/bin/env python3
"""No paid API call. Checks the local environment needed for Lecture 7."""
import importlib.util, sys
mods=['litellm']
missing=[m for m in mods if importlib.util.find_spec(m) is None]
if missing:
    print('MISSING:', ', '.join(missing))
    print('Run this inside your tau2-bench uv environment, e.g. uv run python ...')
    sys.exit(2)
print('OK: litellm importable')
try:
    import tau2
    print('OK: tau2 importable (optional for this offline lecture)')
except Exception:
    print('INFO: tau2 not importable; offline panel can still run if inputs are already prepared.')
