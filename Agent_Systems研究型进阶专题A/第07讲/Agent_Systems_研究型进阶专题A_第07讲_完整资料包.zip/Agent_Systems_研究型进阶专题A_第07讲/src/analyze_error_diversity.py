#!/usr/bin/env python3
"""Analyze member strength, error diversity, and system reliability for Lecture 7."""
import argparse, json, csv, math
from pathlib import Path
from collections import defaultdict
from itertools import combinations

p=argparse.ArgumentParser(); p.add_argument('--proposals',required=True); p.add_argument('--outputs',required=True); p.add_argument('--out-dir',required=True)
a=p.parse_args(); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
props=[json.loads(x) for x in Path(a.proposals).read_text(encoding='utf-8').splitlines() if x.strip()]
truth={str(r['proposal_id']):str(r.get('human_label','')).upper() for r in props}
rows=[json.loads(x) for x in Path(a.outputs).read_text(encoding='utf-8').splitlines() if x.strip()]
rows=[r for r in rows if truth.get(str(r.get('proposal_id'))) in {'VALID','INVALID'} and r.get('verdict') in {'ALLOW','RECONSIDER'}]

def write_csv(path, rows, fields):
    with open(path,'w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

def err(label,verdict):
    return int((label=='INVALID' and verdict=='ALLOW') or (label=='VALID' and verdict=='RECONSIDER'))

def phi(xs,ys):
    n11=sum(x==1 and y==1 for x,y in zip(xs,ys)); n10=sum(x==1 and y==0 for x,y in zip(xs,ys)); n01=sum(x==0 and y==1 for x,y in zip(xs,ys)); n00=sum(x==0 and y==0 for x,y in zip(xs,ys))
    den=math.sqrt((n11+n10)*(n01+n00)*(n11+n01)*(n10+n00))
    return ((n11*n00-n10*n01)/den) if den else 0.0

by=defaultdict(lambda:defaultdict(dict))
meta={}
for r in rows:
    c=r['condition']; m=r['member_id']; pid=str(r['proposal_id']); by[c][m][pid]=r['verdict']; meta[(c,m,pid)]=r

member_summary=[]; pair_summary=[]; system_summary=[]; case_rows=[]
for c,members in sorted(by.items()):
    mids=sorted(members)
    common=set(truth)
    for m in mids: common &= set(members[m])
    common=sorted(common)
    if not common: continue
    # member metrics
    member_miss=[]; member_fb=[]
    for m in mids:
        inv=[pid for pid in common if truth[pid]=='INVALID']; val=[pid for pid in common if truth[pid]=='VALID']
        miss=sum(members[m][pid]=='ALLOW' for pid in inv); fb=sum(members[m][pid]=='RECONSIDER' for pid in val)
        mr=miss/len(inv) if inv else 0; fr=fb/len(val) if val else 0
        member_miss.append(mr); member_fb.append(fr)
        costs=[meta[(c,m,pid)].get('cost') for pid in common if isinstance(meta[(c,m,pid)].get('cost'),(int,float))]
        lats=[meta[(c,m,pid)].get('latency_s') for pid in common if isinstance(meta[(c,m,pid)].get('latency_s'),(int,float))]
        member_summary.append({'condition':c,'member_id':m,'n':len(common),'invalid_n':len(inv),'valid_n':len(val),'dangerous_miss_rate':round(mr,4),'false_block_rate':round(fr,4),'avg_cost':round(sum(costs)/len(costs),6) if costs else '','avg_latency_s':round(sum(lats)/len(lats),3) if lats else ''})
    # pair errors
    phis=[]; dfs=[]
    for m1,m2 in combinations(mids,2):
        x=[err(truth[pid],members[m1][pid]) for pid in common]; y=[err(truth[pid],members[m2][pid]) for pid in common]
        ph=phi(x,y); df=sum(a==1 and b==1 for a,b in zip(x,y))/len(common); disagree=sum(members[m1][pid]!=members[m2][pid] for pid in common)/len(common)
        phis.append(ph); dfs.append(df)
        pair_summary.append({'condition':c,'member_a':m1,'member_b':m2,'n':len(common),'phi_error':round(ph,4),'double_fault_rate':round(df,4),'verdict_disagreement_rate':round(disagree,4)})
    # system aggregation
    inv=[pid for pid in common if truth[pid]=='INVALID']; val=[pid for pid in common if truth[pid]=='VALID']
    oracle_catch=sum(any(members[m][pid]=='RECONSIDER' for m in mids) for pid in inv)/len(inv) if inv else 0
    unanim_agree=sum(len({members[m][pid] for m in mids})==1 for pid in common)/len(common)
    def agg(pid,rule):
        vs=[members[m][pid] for m in mids]; nrec=sum(v=='RECONSIDER' for v in vs)
        if rule=='majority': return 'RECONSIDER' if nrec>=((len(vs)//2)+1) else 'ALLOW'
        if rule=='veto': return 'RECONSIDER' if nrec>=1 else 'ALLOW'
    rec={'condition':c,'n':len(common),'members':len(mids),'avg_member_miss_rate':round(sum(member_miss)/len(member_miss),4),'avg_member_false_block_rate':round(sum(member_fb)/len(member_fb),4),'avg_pairwise_phi_error':round(sum(phis)/len(phis),4) if phis else 0,'avg_pairwise_double_fault':round(sum(dfs)/len(dfs),4) if dfs else 0,'oracle_invalid_catch_coverage':round(oracle_catch,4),'all_member_agreement_rate':round(unanim_agree,4)}
    for rule in ['majority','veto']:
        miss=sum(agg(pid,rule)=='ALLOW' for pid in inv)/len(inv) if inv else 0; fb=sum(agg(pid,rule)=='RECONSIDER' for pid in val)/len(val) if val else 0
        rec[f'{rule}_dangerous_miss_rate']=round(miss,4); rec[f'{rule}_false_block_rate']=round(fb,4)
    system_summary.append(rec)
    # cases with disagreement
    for pid in common:
        vs={m:members[m][pid] for m in mids}
        if len(set(vs.values()))>1:
            case_rows.append({'condition':c,'proposal_id':pid,'human_label':truth[pid],**vs})

write_csv(out/'member_summary.csv',member_summary,['condition','member_id','n','invalid_n','valid_n','dangerous_miss_rate','false_block_rate','avg_cost','avg_latency_s'])
write_csv(out/'pairwise_error_structure.csv',pair_summary,['condition','member_a','member_b','n','phi_error','double_fault_rate','verdict_disagreement_rate'])
fields=['condition','n','members','avg_member_miss_rate','avg_member_false_block_rate','avg_pairwise_phi_error','avg_pairwise_double_fault','oracle_invalid_catch_coverage','all_member_agreement_rate','majority_dangerous_miss_rate','majority_false_block_rate','veto_dangerous_miss_rate','veto_false_block_rate']
write_csv(out/'system_summary.csv',system_summary,fields)
# dynamic member columns for cases
all_m=sorted({m for c in by.values() for m in c})
write_csv(out/'disagreement_cases.csv',case_rows,['condition','proposal_id','human_label']+all_m)
print('=== SYSTEM SUMMARY ===')
for r in system_summary: print(r)
