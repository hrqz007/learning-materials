#!/usr/bin/env python3
"""Generate controlled mock data for Lecture 7. NOT real model results."""
import json, random, argparse
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--out-dir',required=True); p.add_argument('--seed',type=int,default=707); a=p.parse_args(); rng=random.Random(a.seed); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
# 60 proposals: 24 INVALID / 36 VALID
props=[]
for i in range(60):
    label='INVALID' if i<24 else 'VALID'
    fam=['policy','evidence','parameter'][i%3] if label=='INVALID' else 'valid'
    props.append({'proposal_id':f'p{i:03d}','human_label':label,'error_family':fam,'candidate_tool':'mock_write','candidate_arguments':{'x':i},'policy':'mock policy','history':[{'role':'user','content':'mock'}]})
with open(out/'teaching_mock_panel_inputs.jsonl','w',encoding='utf-8') as f:
    for r in props: f.write(json.dumps(r,ensure_ascii=False)+'\n')

conditions={
 'H0_homogeneous':['h1','h2','h3'],
 'H1_model_diverse':['mA','mB','mC'],
 'H2_evidence_diverse':['e_policy','e_history','e_full'],
 'H3_role_diverse':['r_policy','r_evidence','r_parameter']
}
records=[]
for r in props:
    i=int(r['proposal_id'][1:]); invalid=r['human_label']=='INVALID'; fam=r['error_family']
    for c,mids in conditions.items():
        for j,m in enumerate(mids):
            # default correct verdict
            verdict='RECONSIDER' if invalid else 'ALLOW'
            wrong=False
            if c=='H0_homogeneous':
                # Similar marginal strength to H1, but errors are highly shared.
                shared_invalid={0,3,6,9,12}
                unique_invalid={0:15,1:18,2:21}
                shared_valid={30,42}
                unique_valid={0:33,1:45,2:57}
                if invalid and (i in shared_invalid or i==unique_invalid[j]): wrong=True
                if (not invalid) and (i in shared_valid or i==unique_valid[j]): wrong=True
            elif c=='H1_model_diverse':
                # Similar marginal error rate, but error locations are deliberately decorrelated.
                miss_sets=[{0,1,2,3,4,5},{6,7,8,9,10,11},{12,13,14,15,16,17}]
                fb_sets=[{25,31,37},{28,40,52},{34,46,58}]
                if invalid and i in miss_sets[j]: wrong=True
                if (not invalid) and i in fb_sets[j]: wrong=True
            elif c=='H2_evidence_diverse':
                # Lower correlation but some views are weaker because they emphasize different evidence.
                if invalid:
                    if m=='e_policy' and fam in {'evidence','parameter'}: wrong=True
                    if m=='e_history' and fam=='policy': wrong=True
                    if m=='e_full' and i in {2,11,20,23}: wrong=True
                else:
                    if m=='e_policy' and i in {26,38,50,59}: wrong=True
                    if m=='e_history' and i in {29,41,53}: wrong=True
                    if m=='e_full' and i in {35,47}: wrong=True
            else:
                # Role specialists: each catches own family well, may miss others; veto is useful, majority less so.
                target={'r_policy':'policy','r_evidence':'evidence','r_parameter':'parameter'}[m]
                if invalid:
                    if fam==target:
                        wrong = (i+j)%13==0
                    else:
                        wrong = (i+j)%3!=0
                else:
                    # specialists can be overcautious
                    wrong = ((i + j*3) % 12 == 0)
            if wrong: verdict='ALLOW' if invalid else 'RECONSIDER'
            records.append({'proposal_id':r['proposal_id'],'human_label':r['human_label'],'condition':c,'member_id':m,'model':'TEACHING_MOCK','role':'mock','evidence_view':'mock','verdict':verdict,'reason':'CONTROLLED TEACHING MOCK - NOT A REAL MODEL RESULT','confidence':0.8,'latency_s':0.1+j*0.01,'cost':0.001})
with open(out/'teaching_mock_panel_outputs.jsonl','w',encoding='utf-8') as f:
    for x in records: f.write(json.dumps(x,ensure_ascii=False)+'\n')
print('Generated controlled teaching mock:',len(props),'proposals,',len(records),'member judgments')
