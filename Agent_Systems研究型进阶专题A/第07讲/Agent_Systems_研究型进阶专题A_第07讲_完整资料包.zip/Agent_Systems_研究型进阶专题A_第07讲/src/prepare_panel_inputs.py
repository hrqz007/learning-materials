#!/usr/bin/env python3
"""Prepare Lecture 7 fixed proposal inputs from Lecture 6 fixed_proposals.jsonl.
Keeps only human-labeled VALID/INVALID examples and can stratified-sample a pilot.
"""
import argparse, json, random
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--out',required=True); p.add_argument('--limit',type=int,default=48); p.add_argument('--seed',type=int,default=707)
a=p.parse_args(); rows=[]
for line in Path(a.input).read_text(encoding='utf-8').splitlines():
    if not line.strip(): continue
    r=json.loads(line); lab=str(r.get('human_label','')).upper()
    if lab in {'VALID','INVALID'}: rows.append(r)
if not rows: raise SystemExit('No VALID/INVALID proposals found.')
rng=random.Random(a.seed)
valid=[r for r in rows if str(r.get('human_label')).upper()=='VALID']; invalid=[r for r in rows if str(r.get('human_label')).upper()=='INVALID']
rng.shuffle(valid); rng.shuffle(invalid)
if a.limit and len(rows)>a.limit:
    # Prefer roughly balanced safety analysis, without fabricating labels.
    ni=min(len(invalid), max(1,a.limit//2)); nv=min(len(valid), a.limit-ni)
    selected=invalid[:ni]+valid[:nv]
    if len(selected)<a.limit:
        rest=[r for r in rows if r not in selected]; rng.shuffle(rest); selected+=rest[:a.limit-len(selected)]
else: selected=rows
rng.shuffle(selected)
Path(a.out).parent.mkdir(parents=True,exist_ok=True)
with open(a.out,'w',encoding='utf-8') as f:
    for r in selected: f.write(json.dumps(r,ensure_ascii=False)+'\n')
print(f'Wrote {len(selected)} proposals: VALID={sum(str(r.get("human_label")).upper()=="VALID" for r in selected)}, INVALID={sum(str(r.get("human_label")).upper()=="INVALID" for r in selected)}')
