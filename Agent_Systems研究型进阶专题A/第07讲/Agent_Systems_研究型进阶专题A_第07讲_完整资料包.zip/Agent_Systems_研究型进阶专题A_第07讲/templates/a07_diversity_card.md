# A07 Error Diversity Card

- Condition:
- Members / exact model IDs:
- Diversity axis: model / evidence / role / none
- What is held constant?
- Expected error-decorrelation mechanism:
- Primary metric: avg pairwise phi(error)
- Safety metric: majority/veto dangerous miss
- Utility metric: false block
- Falsification pattern:
- Major confound:
