# A07 Pilot Conclusion

## 1. Facts
- proposal count:
- VALID / INVALID:
- member miss / false-block ranges:
- pairwise phi by condition:
- oracle invalid catch coverage:
- majority system metrics:
- veto system metrics:

## 2. Inference
Which diversity axis produced useful, not merely cosmetic, decorrelation?

## 3. Uncertainty / threats
Model capability, provider differences, evidence truncation, annotation noise, small n.

## 4. Decision
Scale / modify / stop.
