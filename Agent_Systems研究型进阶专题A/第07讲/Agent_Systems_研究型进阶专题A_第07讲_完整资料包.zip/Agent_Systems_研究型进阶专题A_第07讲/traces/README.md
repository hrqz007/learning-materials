Use disagreement_cases.csv to choose traces where members disagree, especially INVALID proposals where only one member catches the error.
