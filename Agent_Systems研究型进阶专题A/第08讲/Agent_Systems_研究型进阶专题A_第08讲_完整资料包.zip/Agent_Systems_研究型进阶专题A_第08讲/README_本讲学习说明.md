# Agent Systems 研究型进阶专题 A · 第8讲

## 主题
Diversity Collapse：通信如何把“互补错误”重新变成“共同错误”

## 本讲与前一讲关系
- 第7讲：设计初始 Error Diversity。
- 第8讲：冻结这份初始多样性，只改变通信结构，观察 correlation dynamics 与 collective outcome。

## 推荐学习顺序
1. `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 先运行 Teaching Mock 分析：
   `python src/analyze_diversity_collapse.py --input data/teaching_mock_round1.jsonl --outdir outputs/recheck`
4. 再用第7讲真实 outputs 构造 frozen Round-0。
5. 先 `--limit 4` 做 API smoke test，再扩到 36~48 proposals。

## 重要边界
`data/teaching_mock_*` 是受控教学模拟，绝不是任何真实模型成绩。它只验证分析闭环。

## 当前外部研究连接（截至 2026-09-29）
- Chen et al., Findings of ACL 2026, Diversity Collapse in Multi-Agent LLM Systems.
- Shen et al., EMNLP 2025, Understanding the Information Propagation Effects of Communication Topologies in LLM-based Multi-Agent Systems.
- Cui et al., Findings of ACL 2026, Free-MAD: Consensus-Free Multi-Agent Debate.
- Zhu et al., Findings of ACL 2026, Demystifying Multi-Agent Debate: The Role of Confidence and Diversity.
- Okawa, arXiv 2608.02827, Emergence of Biased Consensus in Multi-Agent LLM Debates.
