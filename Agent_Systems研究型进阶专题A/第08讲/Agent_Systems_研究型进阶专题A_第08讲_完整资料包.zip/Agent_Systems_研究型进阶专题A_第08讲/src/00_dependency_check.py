#!/usr/bin/env python3
import importlib.util
mods=['litellm']
missing=[m for m in mods if importlib.util.find_spec(m) is None]
if missing:
    raise SystemExit('Missing dependencies: '+', '.join(missing)+'\nInstall in your experiment environment before real API runs.')
print('Dependency check passed:', ', '.join(mods))
