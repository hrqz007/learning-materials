#!/usr/bin/env python3
import argparse, json, math, csv
from collections import defaultdict
from itertools import combinations

def load(path):
    with open(path,encoding='utf-8') as f: return [json.loads(x) for x in f if x.strip()]
def correct(label): return 'RECONSIDER' if label=='INVALID' else 'ALLOW'
def mean(xs): return sum(xs)/len(xs) if xs else float('nan')
def phi(xs,ys):
    n=len(xs); n11=sum(a and b for a,b in zip(xs,ys)); n10=sum(a and not b for a,b in zip(xs,ys)); n01=sum((not a) and b for a,b in zip(xs,ys)); n00=n-n11-n10-n01
    den=math.sqrt((n11+n10)*(n01+n00)*(n11+n01)*(n10+n00))
    return ((n11*n00-n10*n01)/den) if den else 0.0
def majority(ds): return 'ALLOW' if ds.count('ALLOW')>=2 else 'RECONSIDER'
def pair_disagree(panel, field):
    vals=[x[field] for x in panel]; pairs=list(combinations(range(len(vals)),2))
    return mean([vals[i]!=vals[j] for i,j in pairs]) if pairs else 0.0

def analyze(rows,outdir):
    import os; os.makedirs(outdir,exist_ok=True)
    byp=defaultdict(list)
    for r in rows: byp[(r['protocol'],r['proposal_id'])].append(r)
    # protocol summary
    protocols=sorted({r['protocol'] for r in rows})
    ps=[]; pair_rows=[]; flip_rows=[]
    for p in protocols:
        groups=[g for (pp,_),g in byp.items() if pp==p]
        d0=[];d1=[];wrongcons=[];majerr=[];dm=[];fb=[]; helpful=harmful=changed=0; total_j=0
        member_ids=sorted({x['member_id'] for g in groups for x in g})
        err0={m:[] for m in member_ids}; err1={m:[] for m in member_ids}
        for g in groups:
            g=sorted(g,key=lambda x:str(x['member_id'])); label=g[0]['human_label']; c=correct(label)
            d0.append(pair_disagree(g,'round0_verdict')); d1.append(pair_disagree(g,'round1_verdict'))
            finals=[x['round1_verdict'] for x in g]
            wc=(len(set(finals))==1 and finals[0]!=c); wrongcons.append(wc)
            maj=majority(finals); majerr.append(maj!=c)
            if label=='INVALID': dm.append(maj=='ALLOW')
            else: fb.append(maj=='RECONSIDER')
            for x in g:
                e0=x['round0_verdict']!=c; e1=x['round1_verdict']!=c
                err0[x['member_id']].append(e0); err1[x['member_id']].append(e1)
                total_j+=1
                if x['round0_verdict']!=x['round1_verdict']:
                    changed+=1
                    if e0 and not e1: helpful+=1
                    elif not e0 and e1: harmful+=1
        ph0=[];ph1=[]
        for a,b in combinations(member_ids,2):
            ph0.append(phi(err0[a],err0[b])); ph1.append(phi(err1[a],err1[b]))
            pair_rows.append({'protocol':p,'member_a':a,'member_b':b,'phi_error_round0':phi(err0[a],err0[b]),'phi_error_round1':phi(err1[a],err1[b])})
        div0=mean(d0); div1=mean(d1); retention=(div1/div0 if div0 else float('nan'))
        ps.append({'protocol':p,'pairwise_disagreement_r0':div0,'pairwise_disagreement_r1':div1,
                   'diversity_retention':retention,'collapse_index_custom':1-retention if not math.isnan(retention) else float('nan'),
                   'mean_phi_error_r0':mean(ph0),'mean_phi_error_r1':mean(ph1),'phi_growth':mean(ph1)-mean(ph0),
                   'wrong_consensus_rate':mean(wrongcons),'majority_error_rate':mean(majerr),'majority_dangerous_miss_invalid':mean(dm),
                   'majority_false_block_valid':mean(fb),'flip_rate':changed/total_j,'helpful_flip_rate':helpful/total_j,'harmful_flip_rate':harmful/total_j,
                   'helpful_minus_harmful':(helpful-harmful)/total_j})
    def write_csv(name, rows):
        if not rows: return
        with open(os.path.join(outdir,name),'w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    write_csv('protocol_summary.csv',ps); write_csv('pairwise_correlation.csv',pair_rows)
    # case-level transitions
    cases=[]
    for (p,pid),g in sorted(byp.items()):
        g=sorted(g,key=lambda x:str(x['member_id'])); label=g[0]['human_label']; c=correct(label)
        init=[x['round0_verdict'] for x in g]; fin=[x['round1_verdict'] for x in g]
        cases.append({'protocol':p,'proposal_id':pid,'human_label':label,'initial_majority':majority(init),'final_majority':majority(fin),
                      'initial_pairwise_disagreement':pair_disagree(g,'round0_verdict'),'final_pairwise_disagreement':pair_disagree(g,'round1_verdict'),
                      'wrong_consensus_final':len(set(fin))==1 and fin[0]!=c,
                      'num_changed':sum(a!=b for a,b in zip(init,fin))})
    write_csv('case_transitions.csv',cases)
    print('Protocol summary:')
    for x in ps:
        print(x['protocol'], 'D0=',round(x['pairwise_disagreement_r0'],3),'D1=',round(x['pairwise_disagreement_r1'],3),
              'phi1=',round(x['mean_phi_error_r1'],3),'wrong_cons=',round(x['wrong_consensus_rate'],3),'maj_err=',round(x['majority_error_rate'],3),
              'help-harm=',round(x['helpful_minus_harmful'],3))

ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--outdir',required=True); args=ap.parse_args()
analyze(load(args.input),args.outdir)
