#!/usr/bin/env python3
"""Generate deterministic controlled teaching mock for A08.
This is synthetic data, NOT a real model result.
"""
import argparse, json, random
from pathlib import Path

ap=argparse.ArgumentParser(); ap.add_argument('--outdir',default='data'); args=ap.parse_args()
out=Path(args.outdir); out.mkdir(parents=True,exist_ok=True)
rng=random.Random(8); N=60
labels=['INVALID']*24+['VALID']*36; rng.shuffle(labels)
members=['A','B','C']; ids=list(range(N))
errs={}; errs['A']=set(rng.sample(ids,15)); cand=[i for i in ids if i not in errs['A']]
errs['B']=set(rng.sample(cand,12)+rng.sample(list(errs['A']),3)); union=errs['A']|errs['B']; cand=[i for i in ids if i not in union]
errs['C']=set(rng.sample(cand,10)+rng.sample(list(union),5))
def correct(label): return 'RECONSIDER' if label=='INVALID' else 'ALLOW'
def flip(d): return 'ALLOW' if d=='RECONSIDER' else 'RECONSIDER'
r0={m:[flip(correct(labels[i])) if i in errs[m] else correct(labels[i]) for i in range(N)] for m in members}
rconf=random.Random(88); conf={m:[] for m in members}
for m in members:
    for i in range(N): conf[m].append(round(rconf.uniform(.58,.92) if i in errs[m] else rconf.uniform(.68,.96),3))
with open(out/'teaching_mock_inputs.jsonl','w',encoding='utf-8') as f:
    for i,l in enumerate(labels):
        f.write(json.dumps({'proposal_id':f'p{i:03d}','human_label':l,'error_family':['policy','evidence','parameter'][i%3],
            'candidate_tool':'mock_write','candidate_arguments':{'x':i},'policy':'CONTROLLED TEACHING MOCK POLICY','history':[{'role':'user','content':f'mock request {i}'}]},ensure_ascii=False)+'\n')
with open(out/'teaching_mock_round0.jsonl','w',encoding='utf-8') as f:
    for i,l in enumerate(labels):
        for m in members:
            f.write(json.dumps({'proposal_id':f'p{i:03d}','human_label':l,'member_id':m,'model':'TEACHING_MOCK','round0_verdict':r0[m][i],
                'round0_confidence':conf[m][i],'round0_brief':'CONTROLLED TEACHING MOCK - NOT A REAL MODEL RESULT'},ensure_ascii=False)+'\n')
protocols=['C0_solo_recheck','C1_full_mesh','C2_ring','C3_dissent_guard']; result={p:{m:[] for m in members} for p in protocols}
rr=random.Random(801)
for i,l in enumerate(labels):
    c=correct(l)
    for m in members:
        d=r0[m][i]
        if d!=c and rr.random()<.22: d=c
        elif d==c and rr.random()<.04: d=flip(c)
        result['C0_solo_recheck'][m].append(d)
rr=random.Random(802)
for i,l in enumerate(labels):
    weights={d:sum(conf[m][i] for m in members if r0[m][i]==d) for d in ['ALLOW','RECONSIDER']}; target=max(weights,key=weights.get)
    for m in members:
        d=r0[m][i]
        if d!=target and rr.random()<.88: d=target
        elif d==target and rr.random()<.03: d=flip(d)
        result['C1_full_mesh'][m].append(d)
rr=random.Random(803); pred={'A':'C','B':'A','C':'B'}
for i,l in enumerate(labels):
    c=correct(l)
    for m in members:
        d=r0[m][i]; pd=r0[pred[m]][i]
        if pd!=d:
            if d!=c and pd==c and rr.random()<.40: d=pd
            elif d==c and pd!=c and rr.random()<.08: d=pd
        if d!=c and rr.random()<.10: d=c
        result['C2_ring'][m].append(d)
rr=random.Random(804)
for i,l in enumerate(labels):
    c=correct(l)
    for m in members:
        d=r0[m][i]
        if d!=c and rr.random()<.48: d=c
        elif d==c and rr.random()<.015: d=flip(c)
        result['C3_dissent_guard'][m].append(d)
with open(out/'teaching_mock_round1.jsonl','w',encoding='utf-8') as f:
    for p in protocols:
        for i,l in enumerate(labels):
            peers={m:r0[m][i] for m in members}
            for m in members:
                d0=r0[m][i]; d1=result[p][m][i]
                f.write(json.dumps({'proposal_id':f'p{i:03d}','human_label':l,'protocol':p,'member_id':m,'model':'TEACHING_MOCK',
                    'round0_verdict':d0,'round1_verdict':d1,'changed':d0!=d1,'peer_round0':peers,
                    'round1_brief':'CONTROLLED TEACHING MOCK - NOT A REAL MODEL RESULT','latency_s':0.1,'cost':0.001},ensure_ascii=False)+'\n')
print('Generated controlled teaching mock:', out)
