#!/usr/bin/env python3
"""Prepare a frozen Round-0 panel from A07 inputs + panel outputs.
Supports real or mock A07 JSONL. UNCERTAIN labels are excluded by default.
"""
import argparse, json
from collections import defaultdict

def load_jsonl(path):
    with open(path, encoding='utf-8') as f:
        return [json.loads(x) for x in f if x.strip()]

ap=argparse.ArgumentParser()
ap.add_argument('--inputs', required=True)
ap.add_argument('--panel-outputs', required=True)
ap.add_argument('--condition', required=True, help='A07 condition to freeze, e.g. H1_model_diverse')
ap.add_argument('--out', required=True)
args=ap.parse_args()
inputs={x['proposal_id']:x for x in load_jsonl(args.inputs) if x.get('human_label') in {'VALID','INVALID'}}
rows=[x for x in load_jsonl(args.panel_outputs) if x.get('condition')==args.condition and x.get('proposal_id') in inputs]
by=defaultdict(list)
for r in rows: by[r['proposal_id']].append(r)
with open(args.out,'w',encoding='utf-8') as f:
    for pid,base in inputs.items():
        panel=sorted(by.get(pid,[]), key=lambda x:str(x.get('member_id')))
        if len(panel)<2: continue
        obj=dict(base)
        obj['round0_panel']=[{
            'member_id':x['member_id'],'model':x.get('model'),'role':x.get('role'),'evidence_view':x.get('evidence_view'),
            'verdict':x.get('verdict'),'confidence':x.get('confidence'),'brief_justification':x.get('reason','')
        } for x in panel]
        f.write(json.dumps(obj,ensure_ascii=False)+'\n')
print(f'Frozen proposals: {sum(1 for _ in open(args.out,encoding="utf-8"))}')
