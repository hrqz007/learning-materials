# A08 Pilot Conclusion

## 1. Main observation

## 2. Does communication reduce diversity beyond Solo-Recheck?

## 3. Does error correlation grow?

## 4. Helpful vs harmful flips

## 5. Wrong-consensus cases

## 6. Topology/protocol comparison

## 7. Cost and latency

## 8. Alternative explanations

## 9. Decision: stop / replicate / expand
