# A08 Communication Protocol Card

- Protocol name:
- Topology:
- What peer information is visible?
- Is verdict visible?
- Is rationale/evidence visible?
- Change rule:
- Number of Round-1 calls per member:
- Expected benefit:
- Expected failure mode:
- Cost notes:
