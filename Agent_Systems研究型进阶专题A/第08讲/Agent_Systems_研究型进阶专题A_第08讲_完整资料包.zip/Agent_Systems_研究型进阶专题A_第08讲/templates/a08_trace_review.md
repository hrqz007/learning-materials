# A08 Trace Review

Proposal ID:
Human label: VALID / INVALID
Protocol:

## Round-0
A:
B:
C:

## Communication received
A saw:
B saw:
C saw:

## Round-1
A:
B:
C:

## Transition classification
- Helpful flips:
- Harmful flips:
- Wrong consensus formed?
- New evidence actually appeared?
- Possible mechanism: anchoring / conformity / evidence propagation / authority / other
