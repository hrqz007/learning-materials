把人工精读的 wrong-consensus、helpful-flip、harmful-flip 案例放在这里。不要只挑支持假设的案例。
