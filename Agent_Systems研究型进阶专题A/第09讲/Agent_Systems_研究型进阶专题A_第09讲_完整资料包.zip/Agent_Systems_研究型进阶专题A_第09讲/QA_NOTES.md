# 第9讲质量检查记录

本记录用于区分“已真实检查”与“因当前制作用环境限制而未执行”的部分。

## 已完成

- 6 份 DOCX 已全部实际渲染并逐页检查：讲义 5 页、实验指导书 2 页、实验设计书 2 页、练习题 1 页、答案 1 页、术语表 1 页，共 12 页。
- 讲义已独立转换为 PDF，并用 PDF 渲染器重新渲染 5 页逐页检查；未发现文字裁切、图形重叠、中文缺字或代码框越界。
- 已修复讲义中遗留的“第8讲”页脚，最终版全部为“第9讲”。
- 已将 EASS 流程图改为纵向布局，避免文字挤压。
- `python -m compileall` 对 src/ 全部通过。
- `prepare_multiround_inputs.py` 已用最小合成 Round-0 数据实际功能测试：3 条输入中保留 2 条 VALID/INVALID，正确排除 1 条 UNCERTAIN；并为每个成员补齐 `evidence_keys`。
- `analyze_round_dynamics.py` 已对 900 条 Teaching Mock judgment 实际执行并重新复现 round summary、Fixed-1~4 与 EASS 结果。
- Teaching Mock 仅用于教学和验证分析流水线，不代表任何真实模型性能。

## 当前环境未执行

- `00_dependency_check.py` 在本制作用容器中实际返回：`Missing dependencies: litellm`。
- 因此 `run_multiround_deliberation.py` 没有在本容器调用商业模型 API；也没有伪造任何真实实验结果。
- 真实实验应在用户自己的实验环境安装 `litellm`、配置 API 凭据后，先运行 dependency check，再从小规模 smoke test 开始。
