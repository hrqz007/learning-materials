# Agent Systems 研究型进阶专题 A · 第9讲

## 主题
通信应该进行几轮？从边际收益到 Evidence-Aware Early Stopping

## 与第8讲的关系
- 第8讲：固定 Round-0，改变 communication topology / protocol。
- 第9讲：固定 protocol，改变 communication depth，并研究 adaptive stopping。

## 推荐顺序
1. `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 先重跑 Teaching Mock 分析：`python src/analyze_round_dynamics.py --input data/teaching_mock_multiround.jsonl --outdir outputs/recheck`
4. 再用你第8讲真实 frozen Round-0 运行真实 R1-R4。

## 外部研究连接（截至 2026-09-29）
- Hu et al., Multi-Agent Debate for LLM Judges with Adaptive Stability Detection, NeurIPS 2025.
- Morandi, Sequential Consensus for Multi-Agent LLM Debates: A Wald-SPRT compute governor..., arXiv 2605.19193, 2026.
- Cui et al., Free-MAD: Consensus-Free Multi-Agent Debate, arXiv 2509.11035.
- Becker et al., Stay Focused: Problem Drift in Multi-Agent Debate, Findings of EACL 2026.

## 重要边界
Teaching Mock 是受控合成数据，不代表任何真实模型结果。EASS 是本课程自定义教学规则，不是现有标准算法。
