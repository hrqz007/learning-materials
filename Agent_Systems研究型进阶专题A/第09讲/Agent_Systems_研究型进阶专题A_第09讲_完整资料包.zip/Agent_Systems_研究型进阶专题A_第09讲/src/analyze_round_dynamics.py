#!/usr/bin/env python3
import argparse,json,math,csv,os
from collections import defaultdict,Counter
from itertools import combinations

def load(path):
    with open(path,encoding='utf-8') as f: return [json.loads(x) for x in f if x.strip()]
def correct(label): return 'RECONSIDER' if label=='INVALID' else 'ALLOW'
def majority(ds): return 'ALLOW' if ds.count('ALLOW')>=2 else 'RECONSIDER'
def mean(xs): return sum(xs)/len(xs) if xs else float('nan')
def phi(xs,ys):
    n11=sum(a and b for a,b in zip(xs,ys)); n10=sum(a and not b for a,b in zip(xs,ys)); n01=sum((not a) and b for a,b in zip(xs,ys)); n00=len(xs)-n11-n10-n01
    den=math.sqrt((n11+n10)*(n01+n00)*(n11+n01)*(n10+n00))
    return (n11*n00-n10*n01)/den if den else 0.0
def disagree(ds):
    ps=list(combinations(range(len(ds)),2)); return mean([ds[i]!=ds[j] for i,j in ps]) if ps else 0.0

def norm_key(s): return ' '.join(str(s).lower().split())

def analyze(rows,outdir):
    os.makedirs(outdir,exist_ok=True)
    by=defaultdict(list)
    for x in rows: by[(x['round'],x['proposal_id'])].append(x)
    rounds=sorted({x['round'] for x in rows}); pids=sorted({x['proposal_id'] for x in rows})
    members=sorted({x['member_id'] for x in rows})
    round_summary=[]
    prev_member={}  # (pid,m)->row
    seen_evidence=defaultdict(set)
    # round-level metrics
    for r in rounds:
        member_err=[]; maj_err=[]; dm=[]; fb=[]; wc=[]; dis=[]; helpful=harmful=changed=0; total=0
        err_by={m:[] for m in members}; cost=[]; lat=[]; new_ev_count=0
        for pid in pids:
            g=sorted(by.get((r,pid),[]),key=lambda x:str(x['member_id']))
            if not g: continue
            c=correct(g[0]['human_label']); ds=[x['verdict'] for x in g]; maj=majority(ds)
            maj_err.append(maj!=c); wc.append(len(set(ds))==1 and ds[0]!=c); dis.append(disagree(ds))
            if g[0]['human_label']=='INVALID': dm.append(maj=='ALLOW')
            else: fb.append(maj=='RECONSIDER')
            for x in g:
                e=(x['verdict']!=c); member_err.append(e); err_by[x['member_id']].append(e); total+=1
                cost.append(x.get('cost') or 0); lat.append(x.get('latency_s') or 0)
                keys={norm_key(k) for k in x.get('evidence_keys',[]) if str(k).strip()}
                new_ev=keys-seen_evidence[(pid,x['member_id'])]
                if r>0: new_ev_count+=len(new_ev)
                seen_evidence[(pid,x['member_id'])].update(keys)
                if r>0:
                    prev=prev_member.get((pid,x['member_id']))
                    if prev is not None and prev['verdict']!=x['verdict']:
                        changed+=1
                        if prev['verdict']!=c and x['verdict']==c: helpful+=1
                        elif prev['verdict']==c and x['verdict']!=c: harmful+=1
                prev_member[(pid,x['member_id'])]=x
        ph=[phi(err_by[a],err_by[b]) for a,b in combinations(members,2)]
        round_summary.append({'round':r,'member_error_rate':mean(member_err),'majority_error_rate':mean(maj_err),
          'dangerous_miss_invalid':mean(dm),'false_block_valid':mean(fb),'wrong_consensus_rate':mean(wc),
          'pairwise_disagreement':mean(dis),'mean_pairwise_phi_error':mean(ph),
          'changed_count':changed,'helpful_flip_count':helpful,'harmful_flip_count':harmful,
          'net_helpful_minus_harmful':helpful-harmful,'new_evidence_key_count':new_ev_count,
          'round_cost_total':sum(cost),'round_latency_total':sum(lat)})
    # proposal-round stats needed for runtime-observable stopping
    panel_stats={}
    seen_panel=defaultdict(set)
    for pid in pids:
        prev_maj=None
        for r in rounds:
            g=sorted(by.get((r,pid),[]),key=lambda x:str(x['member_id']))
            if not g: continue
            ds=[x['verdict'] for x in g]; maj=majority(ds)
            changes=sum(bool(x.get('changed')) for x in g) if r>0 else 0
            keys=set()
            for x in g: keys|={norm_key(k) for k in x.get('evidence_keys',[]) if str(k).strip()}
            novelty=len(keys-seen_panel[pid]); seen_panel[pid]|=keys
            panel_stats[(pid,r)]={'majority':maj,'changes':changes,'novelty':novelty,'human_label':g[0]['human_label'],
                                  'wrong_consensus':len(set(ds))==1 and ds[0]!=correct(g[0]['human_label'])}
            prev_maj=maj
    # fixed policies
    policy_rows=[]
    maxr=max(rounds)
    for target in [1,2,3,maxr]:
        errs=[]; dms=[]; fbs=[]
        for pid in pids:
            st=panel_stats[(pid,target)]; c=correct(st['human_label']); e=st['majority']!=c; errs.append(e)
            if st['human_label']=='INVALID': dms.append(st['majority']=='ALLOW')
            else: fbs.append(st['majority']=='RECONSIDER')
        policy_rows.append({'policy':f'Fixed-{target}','avg_rounds':target,'avg_reviewer_calls':3*target,'majority_error_rate':mean(errs),
                            'dangerous_miss_invalid':mean(dms),'false_block_valid':mean(fbs)})
    # EASS: from round 2 onward stop if majority stable, <=1 member changed, and no new evidence this round
    stop_round={}
    for pid in pids:
        stop=maxr
        for r in range(2,maxr+1):
            cur=panel_stats[(pid,r)]; prev=panel_stats[(pid,r-1)]
            if cur['majority']==prev['majority'] and cur['changes']<=1 and cur['novelty']==0:
                stop=r; break
        stop_round[pid]=stop
    errs=[];dms=[];fbs=[];wcs=[]
    for pid,stp in stop_round.items():
        st=panel_stats[(pid,stp)]; c=correct(st['human_label']); errs.append(st['majority']!=c); wcs.append(st['wrong_consensus'])
        if st['human_label']=='INVALID': dms.append(st['majority']=='ALLOW')
        else: fbs.append(st['majority']=='RECONSIDER')
    policy_rows.append({'policy':'EASS','avg_rounds':mean(list(stop_round.values())),'avg_reviewer_calls':3*mean(list(stop_round.values())),
                        'majority_error_rate':mean(errs),'dangerous_miss_invalid':mean(dms),'false_block_valid':mean(fbs)})
    stop_hist=Counter(stop_round.values())
    stop_rows=[{'round':r,'count':stop_hist.get(r,0)} for r in range(2,maxr+1)]
    def write(name,rs):
        if not rs: return
        with open(os.path.join(outdir,name),'w',newline='',encoding='utf-8-sig') as f:
            w=csv.DictWriter(f,fieldnames=list(rs[0].keys())); w.writeheader(); w.writerows(rs)
    write('round_summary.csv',round_summary); write('stopping_policy_summary.csv',policy_rows); write('eass_stop_histogram.csv',stop_rows)
    print('Round summary:')
    for x in round_summary:
        print(x['round'],'maj_err=',round(x['majority_error_rate'],3),'dis=',round(x['pairwise_disagreement'],3),'phi=',round(x['mean_pairwise_phi_error'],3),'help=',x['helpful_flip_count'],'harm=',x['harmful_flip_count'])
    print('Stopping policies:')
    for x in policy_rows: print(x['policy'],'rounds=',round(x['avg_rounds'],2),'err=',round(x['majority_error_rate'],3))

ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--outdir',required=True); args=ap.parse_args()
analyze(load(args.input),args.outdir)
