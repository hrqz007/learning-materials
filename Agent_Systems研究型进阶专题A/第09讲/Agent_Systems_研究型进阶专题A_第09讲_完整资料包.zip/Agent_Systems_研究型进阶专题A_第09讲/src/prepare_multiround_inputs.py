#!/usr/bin/env python3
import argparse,json
ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
count=0
with open(args.input,encoding='utf-8') as fi, open(args.out,'w',encoding='utf-8') as fo:
    for line in fi:
        if not line.strip(): continue
        x=json.loads(line)
        if x.get('human_label') not in {'VALID','INVALID'}: continue
        if not x.get('round0_panel') or len(x['round0_panel'])<2: continue
        for m in x['round0_panel']:
            if not m.get('member_id') or not m.get('model') or not m.get('verdict'): raise ValueError('round0_panel member missing member_id/model/verdict')
            m.setdefault('evidence_keys',[])
        fo.write(json.dumps(x,ensure_ascii=False)+'\n'); count+=1
print('Prepared proposals:',count)
