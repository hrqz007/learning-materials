# A09 Pilot Conclusion

## 1. Best fixed depth on this pilot
## 2. Accuracy / risk curve across rounds
## 3. Helpful vs harmful marginal flips
## 4. Correlation growth
## 5. Evidence novelty decay
## 6. EASS cost-reliability trade-off
## 7. Wrong-consensus early-stop failures
## 8. Alternative explanations
## 9. Decision: stop / replicate / expand / redesign rule
