# A09 Stopping Rule Card

- Rule name:
- Runtime observables used:
- Ground truth used at runtime? MUST be NO
- Earliest stop round:
- Rmax:
- Thresholds (pre-registered):
- Expected benefit:
- Known failure mode (especially wrong consensus):
- Cost metric:
