# A09 Multi-round Trace Review

Proposal ID:
Human label:

## R0
A/B/C verdicts:

## R1
New evidence:
Helpful/Harmful flips:

## R2
New evidence:
Helpful/Harmful flips:

## R3
New evidence:
Helpful/Harmful flips:

## R4
New evidence:
Helpful/Harmful flips:

## Stop analysis
- Fixed best round (analysis only):
- EASS stop round:
- Did EASS stop correctly?
- If failure: stability trap / wrong consensus / evidence-key mismatch / other
