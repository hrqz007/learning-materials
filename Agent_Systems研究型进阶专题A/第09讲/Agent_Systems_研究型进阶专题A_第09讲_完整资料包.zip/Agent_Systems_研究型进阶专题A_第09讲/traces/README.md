优先保存：后期 harmful flip、wrong consensus、EASS 正确早停、EASS 错误早停、R4 仍有新证据的 hard cases。
