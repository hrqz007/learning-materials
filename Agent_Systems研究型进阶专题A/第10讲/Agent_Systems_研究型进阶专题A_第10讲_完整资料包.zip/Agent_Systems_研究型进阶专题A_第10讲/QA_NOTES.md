A10 artifacts generated programmatically. Teaching Mock is synthetic. Core analysis is offline and does not call paid APIs. DOCX/PDF render QA performed before packaging.
