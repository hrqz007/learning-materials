# Agent Systems 研究型进阶专题 A · 第10讲

## 主题
什么时候值得通信？Selective Deliberation / Adaptive Communication

## 与第9讲的关系
- 第9讲：已经进入 deliberation 后，讨论几轮、什么时候停。
- 第10讲：在进入 deliberation 之前，先决定这个 proposal 值不值得升级。

## 推荐顺序
1. `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 先重跑 Teaching Mock：
   `python src/04_generate_teaching_mock.py --out data/recheck_mock.csv`
   `python src/03_analyze_selective_routing.py --input data/recheck_mock.csv --outdir outputs/recheck`
4. 再把第9讲真实 multiround 日志压成 `selective_dataset.csv`，进行离线路由分析。

## 外部研究连接（截至 2026-09-30）
- CascadeDebate, ACL Industry 2026：confidence-based selective multi-agent deliberation。
- DALA, AAAI 2026：把通信带宽作为稀缺资源，出现 strategic silence。
- G-Designer, ICML 2025：task-aware communication topology。
- Adaptive Graph Pruning, ECAI 2025 / online 2026：动态 Agent 数量与拓扑。

## 重要边界
RAUR 是本课程定义的教学 baseline，不是现有标准算法。Teaching Mock 是合成数据，不代表任何真实模型。
