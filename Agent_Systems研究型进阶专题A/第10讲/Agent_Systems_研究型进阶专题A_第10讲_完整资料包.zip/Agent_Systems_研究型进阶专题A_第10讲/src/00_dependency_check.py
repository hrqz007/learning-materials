#!/usr/bin/env python3
"""A10 is intentionally offline: only Python stdlib is required for the core analysis."""
import sys
print("Python:", sys.version.split()[0])
assert sys.version_info >= (3,10), "Python 3.10+ recommended"
print("OK: A10 core routing analysis needs only Python stdlib.")
