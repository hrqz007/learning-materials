#!/usr/bin/env python3
"""Collapse A09 multi-round logs into one row per proposal for offline routing.
Solo branch = designated Round-0 primary member.
Deliberated branch = EASS stopping result from A09.
"""
import argparse,json,csv
from collections import defaultdict

def load_jsonl(p):
    with open(p,encoding='utf-8') as f: return [json.loads(x) for x in f if x.strip()]
def maj(ds): return 'ALLOW' if ds.count('ALLOW') >= (len(ds)//2+1) else 'RECONSIDER'
def norm(s): return ' '.join(str(s).lower().split())

def risk_map(p):
    out={}
    with open(p,encoding='utf-8-sig') as f:
        for r in csv.DictReader(f):
            lv=(r.get('risk_level') or '').strip().upper()
            if lv not in {'LOW','MEDIUM','HIGH'}: raise ValueError(f"Bad/missing risk_level for {r.get('proposal_id')}: {lv}")
            out[r['proposal_id']]=(lv,r.get('risk_reason',''))
    return out

ap=argparse.ArgumentParser(); ap.add_argument('--multiround',required=True); ap.add_argument('--risk-csv',required=True); ap.add_argument('--out',required=True); ap.add_argument('--primary-member',default='A'); ap.add_argument('--max-rounds',type=int,default=4); args=ap.parse_args()
rows=load_jsonl(args.multiround); risks=risk_map(args.risk_csv)
by=defaultdict(list)
for x in rows: by[(x['proposal_id'],int(x['round']))].append(x)
pids=sorted({x['proposal_id'] for x in rows}); out=[]
for pid in pids:
    r0=by[(pid,0)]; prim=next((x for x in r0 if str(x['member_id'])==str(args.primary_member)),None)
    if prim is None: raise ValueError(f'{pid}: primary member {args.primary_member} absent')
    # reproduce A09 EASS: from round 2, stop when majority stable, <=1 changed, no new evidence keys.
    seen=set(); stats={}
    for r in range(0,args.max_rounds+1):
        g=by.get((pid,r),[])
        if not g: continue
        keys=set()
        for x in g: keys |= {norm(k) for k in x.get('evidence_keys',[]) if str(k).strip()}
        novelty=len(keys-seen); seen |= keys
        stats[r]={'majority':maj([x['verdict'] for x in g]), 'changes':sum(bool(x.get('changed')) for x in g) if r>0 else 0,
                  'novelty':novelty,'cost':sum((x.get('cost') or 0) for x in g),'latency':sum((x.get('latency_s') or 0) for x in g)}
    stop=max(stats)
    for r in range(2,max(stats)+1):
        if r in stats and (r-1) in stats:
            if stats[r]['majority']==stats[r-1]['majority'] and stats[r]['changes']<=1 and stats[r]['novelty']==0:
                stop=r; break
    panel_cost=sum(stats[r]['cost'] for r in stats if 1<=r<=stop)
    panel_lat=sum(stats[r]['latency'] for r in stats if 1<=r<=stop)
    lv,reason=risks[pid]
    out.append({'proposal_id':pid,'human_label':prim.get('human_label'),'risk_level':lv,'risk_reason':reason,
                'primary_member':args.primary_member,'solo_verdict':prim['verdict'],'solo_confidence':prim.get('confidence',0.5),
                'deliberated_verdict':stats[stop]['majority'],'eass_stop_round':stop,
                'extra_reviewer_calls':3*stop,'extra_cost':panel_cost,'extra_latency_s':panel_lat})
with open(args.out,'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(out[0].keys())); w.writeheader(); w.writerows(out)
print('Prepared',len(out),'proposal-level rows')
