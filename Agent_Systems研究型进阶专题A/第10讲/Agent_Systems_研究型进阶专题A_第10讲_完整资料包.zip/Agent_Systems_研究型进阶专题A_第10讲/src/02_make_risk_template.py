#!/usr/bin/env python3
import argparse,json,csv
ap=argparse.ArgumentParser(); ap.add_argument('--round0-input',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
rows=[]
with open(args.round0_input,encoding='utf-8') as f:
    for line in f:
        if not line.strip(): continue
        x=json.loads(line)
        rows.append({'proposal_id':x['proposal_id'],'candidate_tool':x.get('candidate_tool',''),
                     'risk_level':'', 'risk_reason':'',
                     'instruction':'Fill LOW/MEDIUM/HIGH using reversibility + potential impact; do NOT use human_label.'})
with open(args.out,'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys()) if rows else ['proposal_id','candidate_tool','risk_level','risk_reason','instruction']); w.writeheader(); w.writerows(rows)
print('Wrote',len(rows),'risk rows to',args.out)
