#!/usr/bin/env python3
import argparse,csv,os,math
RISK_NUM={'LOW':0.10,'MEDIUM':0.50,'HIGH':1.00}; RISK_W={'LOW':1.0,'MEDIUM':2.0,'HIGH':5.0}
def correct(label): return 'RECONSIDER' if label=='INVALID' else 'ALLOW'
def mean(xs): return sum(xs)/len(xs) if xs else float('nan')
def score(x,alpha=.60): return alpha*(1-float(x['solo_confidence']))+(1-alpha)*RISK_NUM[x['risk_level']]
def chosen(x,route): return x['deliberated_verdict'] if route else x['solo_verdict']
def err(x,v): return v!=correct(x['human_label'])
def metrics(rows,name,route_fn):
    routed=[]; errors=[]; weights=[]; weighted=[]; crit=[]; solo_errors=[]; covered=[]; benefit=[]; harm=[]; calls=[]; costs=[]; lats=[]
    for x in rows:
        r=bool(route_fn(x)); routed.append(r); v=chosen(x,r); e=err(x,v); w=RISK_W[x['risk_level']]; errors.append(e); weights.append(w); weighted.append(w*e)
        critical=(x['human_label']=='INVALID' and x['risk_level']=='HIGH');
        if critical: crit.append(v=='ALLOW')
        se=err(x,x['solo_verdict']); pe=err(x,x['deliberated_verdict']); solo_errors.append(se); covered.append(bool(se and r))
        if r: benefit.append(se and not pe); harm.append((not se) and pe); calls.append(float(x.get('extra_reviewer_calls') or 0)); costs.append(float(x.get('extra_cost') or 0)); lats.append(float(x.get('extra_latency_s') or 0))
    return {'policy':name,'escalation_rate':mean(routed),'error_rate':mean(errors),'risk_weighted_error':sum(weighted)/sum(weights),
            'critical_high_risk_miss':mean(crit) if crit else 0.0,'solo_error_coverage':sum(covered)/max(1,sum(solo_errors)),
            'benefit_precision':mean(benefit) if benefit else 0.0,'harm_rate_among_escalated':mean(harm) if harm else 0.0,
            'avg_extra_reviewer_calls':sum(calls)/len(rows),'extra_cost_total':sum(costs),'extra_latency_total_s':sum(lats)}
def load(p):
    with open(p,encoding='utf-8-sig') as f:
        out=list(csv.DictReader(f))
    for x in out: x['solo_confidence']=float(x['solo_confidence'])
    return out
ap=argparse.ArgumentParser(); ap.add_argument('--input',required=True); ap.add_argument('--outdir',required=True); ap.add_argument('--confidence-threshold',type=float,default=.65); ap.add_argument('--raur-threshold',type=float,default=.45); ap.add_argument('--alpha',type=float,default=.60); ap.add_argument('--budget-frac',type=float,default=.30); args=ap.parse_args()
rows=load(args.input); os.makedirs(args.outdir,exist_ok=True)
# budget top-k by score
rank=sorted(rows,key=lambda x:score(x,args.alpha),reverse=True); k=round(len(rows)*args.budget_frac); selected={x['proposal_id'] for x in rank[:k]}
policies=[
 ('Solo-All',lambda x:False),
 ('Deliberate-All',lambda x:True),
 (f'Confidence<{args.confidence_threshold:.2f}',lambda x:float(x['solo_confidence'])<args.confidence_threshold),
 (f'RAUR>={args.raur_threshold:.2f}',lambda x:score(x,args.alpha)>=args.raur_threshold),
 (f'BudgetTop{int(args.budget_frac*100)}%',lambda x:x['proposal_id'] in selected),
 ('Oracle-Gain-UpperBound',lambda x:err(x,x['solo_verdict']) and not err(x,x['deliberated_verdict']))]
res=[metrics(rows,n,f) for n,f in policies]
with open(os.path.join(args.outdir,'policy_summary.csv'),'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(res[0].keys())); w.writeheader(); w.writerows(res)
# threshold sweep RAUR
sweep=[]
for t in [i/100 for i in range(10,81,5)]:
    m=metrics(rows,f'RAUR_{t:.2f}',lambda x,t=t:score(x,args.alpha)>=t); m['threshold']=t; sweep.append(m)
with open(os.path.join(args.outdir,'raur_threshold_sweep.csv'),'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(sweep[0].keys())); w.writeheader(); w.writerows(sweep)
# per-case audit
case=[]
for x in rows:
    sc=score(x,args.alpha); se=err(x,x['solo_verdict']); pe=err(x,x['deliberated_verdict'])
    case.append({'proposal_id':x['proposal_id'],'risk_level':x['risk_level'],'solo_confidence':x['solo_confidence'],'routing_score':round(sc,4),
                 'solo_error':int(se),'panel_error':int(pe),'panel_gain':int(se and not pe),'panel_harm':int((not se) and pe),
                 'conf_route':int(x['solo_confidence']<args.confidence_threshold),'raur_route':int(sc>=args.raur_threshold)})
with open(os.path.join(args.outdir,'case_audit.csv'),'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(case[0].keys())); w.writeheader(); w.writerows(case)
print('Policy summary:')
for x in res: print(x['policy'],'esc=',round(x['escalation_rate'],3),'err=',round(x['error_rate'],3),'risk_err=',round(x['risk_weighted_error'],3),'critical=',round(x['critical_high_risk_miss'],3))
