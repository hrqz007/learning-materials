#!/usr/bin/env python3
import csv,random,argparse
random.seed(10)
ap=argparse.ArgumentParser(); ap.add_argument('--out',required=True); args=ap.parse_args()
rows=[]; pid=0
def add(category,n,risk,conf_range,solo_wrong,panel_fix,panel_harm=0):
    global pid
    wrong=set(range(solo_wrong)); fixes=set(list(wrong)[:panel_fix]); correct=set(range(solo_wrong,n)); harms=set(list(correct)[:panel_harm])
    for i in range(n):
        label='INVALID' if (pid+i)%2 else 'VALID'; c='RECONSIDER' if label=='INVALID' else 'ALLOW'; bad='ALLOW' if c=='RECONSIDER' else 'RECONSIDER'
        solo=bad if i in wrong else c; panel=c if i in fixes else (bad if i in wrong else (bad if i in harms else c))
        lo,hi=conf_range; conf=round(lo+(hi-lo)*((i*37)%101)/100,3)
        stop=2 if i%3 else 3
        rows.append({'proposal_id':f'p{pid+i:03d}','human_label':label,'risk_level':risk,'risk_reason':f'TEACHING_MOCK:{category}',
                     'primary_member':'A','solo_verdict':solo,'solo_confidence':conf,'deliberated_verdict':panel,'eass_stop_round':stop,
                     'extra_reviewer_calls':3*stop,'extra_cost':0.0,'extra_latency_s':0.0,'category':category,
                     'note':'CONTROLLED TEACHING MOCK - NOT A REAL MODEL RESULT'})
    pid += n
add('easy_low_risk',45,'LOW',(0.82,0.98),2,1,1)
add('uncertain_medium',20,'MEDIUM',(0.42,0.64),8,6,1)
add('confident_wrong_high_risk',15,'HIGH',(0.78,0.94),7,5,0)
add('shared_blind_spot',20,'MEDIUM',(0.62,0.86),7,1,1)
with open(args.out,'w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print('Wrote',len(rows),'controlled teaching cases')
