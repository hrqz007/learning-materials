#!/usr/bin/env python3
"""Course-defined Risk-Aware Uncertainty Router (RAUR).
This is a pedagogical baseline, not a published standard algorithm.
"""
RISK = {"LOW":0.10, "MEDIUM":0.50, "HIGH":1.00}

def routing_score(confidence: float, risk_level: str, alpha: float = 0.60) -> float:
    """score = alpha * uncertainty + (1-alpha) * risk."""
    c = min(1.0, max(0.0, float(confidence)))
    r = RISK[str(risk_level).upper()]
    return alpha * (1.0-c) + (1.0-alpha) * r

def should_escalate(confidence: float, risk_level: str, threshold: float = 0.45, alpha: float = 0.60) -> bool:
    return routing_score(confidence, risk_level, alpha) >= threshold

if __name__ == '__main__':
    examples=[(0.92,'LOW'),(0.55,'MEDIUM'),(0.86,'HIGH')]
    for c,r in examples:
        s=routing_score(c,r)
        print(c,r,round(s,3),should_escalate(c,r))
