# A10 Pilot Conclusion

1. Does selective deliberation dominate Solo-All on reliability?
2. How much of Deliberate-All reliability can be retained at lower escalation rate?
3. Which solo errors are systematically missed by confidence-only routing?
4. Does risk-aware routing reduce high-risk misses?
5. Where does the panel itself fail or harm?
6. What is the Pareto frontier between risk-weighted error and communication cost?
7. What result would falsify the current routing hypothesis?
8. What should be tested online next?
