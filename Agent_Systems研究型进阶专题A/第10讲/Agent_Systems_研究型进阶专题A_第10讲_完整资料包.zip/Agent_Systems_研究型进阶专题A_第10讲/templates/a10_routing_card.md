# A10 Routing Card

- Primary model/member:
- Routing signals used:
- Confidence threshold:
- Risk taxonomy:
- RAUR alpha / threshold:
- Budget cap:
- Development split used for tuning:
- Frozen test split:
- Escalation rate:
- Primary-error coverage:
- Panel benefit precision:
- Panel harm rate:
- Risk-weighted error:
- Critical high-risk miss:
- Cost / latency delta:
- Notes on data leakage risk:
