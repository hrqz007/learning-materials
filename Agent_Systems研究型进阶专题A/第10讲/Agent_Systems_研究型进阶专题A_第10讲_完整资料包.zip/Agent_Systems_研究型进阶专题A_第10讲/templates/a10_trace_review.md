# A10 Selective Routing Trace Review

## Proposal
- proposal_id:
- risk level / reason:
- solo verdict / confidence:
- RAUR score:
- router decision: SOLO / ESCALATE
- deliberated verdict (counterfactual or executed):
- human label:

## Diagnosis
- Did routing cover a solo error?
- Did deliberation repair it?
- Did deliberation harm a correct solo decision?
- Was the error confidently wrong?
- What runtime-observable signal was available before routing?
- Would this signal generalize without using ground truth?
