Place manually reviewed selective-routing traces here. Do not include secrets/API keys.
