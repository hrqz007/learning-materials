# QA Notes - 第11讲

- Teaching Mock: 240 cases, 1920 candidate judgments; end-to-end analysis executed successfully.
- Teaching Mock EC-Team-Router test error: 3.33%; avg team cost: 1.55 synthetic cost units. These are controlled mock results, not real-model scores.
- A07 -> A11 bridge test: 60 proposals -> 30 calibration + 30 test, 720 judgments, 12 candidates; conversion and downstream analysis executed successfully.
- All Python files passed `py_compile`.
- DOCX render QA passed: lecture 6 pages, experiment guide 2, design 2, exercises 1, answers 1, terms 1 (13 pages total).
- Lecture PDF render QA passed independently: 6 pages.
- Fixed during QA: pipeline figure overlap, complementarity schematic scaling, section-11 numbering, A07 ALLOW/RECONSIDER semantic mapping, calibration/test split generation, cost field alignment.
