# 第11讲：谁应该进入团队？

本讲目标：在**固定 team size=3、固定 majority aggregation**的条件下，只研究 team composition。

推荐顺序：
1. 先读 `02_零基础讲义.pdf`；
2. 按 `03_实验指导书.docx` 跑 Teaching Mock；
3. 用 `01_prepare_from_a07.py` 直接承接第7讲 panel 日志；
4. 只在 calibration split 计算成员画像与团队评分；
5. 最后一次性在 test split 比较 Fixed-Top3 / Fixed-Complementary3 / Task-Expert3 / EC-Team-Router。

**重要：Teaching Mock 不是任何真实模型成绩。**
