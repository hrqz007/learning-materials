#!/usr/bin/env python3
"""第11讲依赖检查：本讲完全离线，不需要真实 API。"""
import importlib.util, sys
mods = ["pandas"]
missing = [m for m in mods if importlib.util.find_spec(m) is None]
print("Python:", sys.version.split()[0])
for m in mods:
    print(f"{m}:", "OK" if m not in missing else "MISSING")
if missing:
    raise SystemExit("请先安装缺失依赖：" + ", ".join(missing))
print("A11 dependency check passed.")
