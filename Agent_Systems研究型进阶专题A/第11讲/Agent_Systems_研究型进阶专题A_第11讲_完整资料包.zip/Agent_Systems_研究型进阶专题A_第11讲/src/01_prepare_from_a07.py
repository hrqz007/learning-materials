#!/usr/bin/env python3
"""把第7讲 panel 输入/输出转换成第11讲数据集，并按 task_family 分层切 calibration/test。"""
import argparse,json,random
from pathlib import Path
import pandas as pd

def read_jsonl(path): return [json.loads(x) for x in Path(path).read_text(encoding='utf-8').splitlines() if x.strip()]
def split_cases(cases,test_frac,seed):
 r=random.Random(seed); out=[]; by={}
 for x in cases: by.setdefault(x['task_family'],[]).append(x)
 for fam,items in sorted(by.items()):
  items=items[:]; r.shuffle(items); n=max(1,round(len(items)*test_frac)) if len(items)>1 else 0; tids={x['case_id'] for x in items[:n]}
  for x in items:
   y=dict(x); y['split']='test' if y['case_id'] in tids else 'calibration'; out.append(y)
 return out

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--inputs',required=True); ap.add_argument('--outputs',required=True); ap.add_argument('--out-dir',required=True); ap.add_argument('--test-frac',type=float,default=.5); ap.add_argument('--seed',type=int,default=300); a=ap.parse_args()
 od=Path(a.out_dir); od.mkdir(parents=True,exist_ok=True); ins=read_jsonl(a.inputs); outs=read_jsonl(a.outputs)
 cases=[]
 for x in ins:
  if x.get('human_label') not in ('VALID','INVALID'): continue
  cases.append({'case_id':str(x['proposal_id']),'task_family':x.get('error_family','unknown'),'human_label':x['human_label'],'risk_level':x.get('risk_level','UNKNOWN')})
 cases=split_cases(cases,a.test_frac,a.seed); ids={x['case_id'] for x in cases}; jud=[]
 for x in outs:
  pid=str(x.get('proposal_id'))
  if pid not in ids: continue
  raw=x.get('verdict',''); verdict='VALID' if raw=='ALLOW' else ('INVALID' if raw=='RECONSIDER' else raw)
  cond=x.get('condition','unknown'); member=x.get('member_id','unknown')
  jud.append({'case_id':pid,'candidate_id':f'{cond}::{member}','condition':cond,'member_id':member,'model':x.get('model',''),'role':x.get('role',''),'evidence_view':x.get('evidence_view',''),'verdict':verdict,'cost_unit':float(x.get('cost') or 0),'latency_s':float(x.get('latency_s') or 0)})
 cdf=pd.DataFrame(cases).drop_duplicates('case_id'); jdf=pd.DataFrame(jud); cdf.to_csv(od/'cases.csv',index=False); jdf.to_csv(od/'judgments.csv',index=False)
 if not jdf.empty:
  pool=jdf.groupby('candidate_id',as_index=False).agg(model=('model','first'),role=('role','first'),evidence_view=('evidence_view','first'),cost_unit=('cost_unit','mean'),avg_latency_s=('latency_s','mean')); pool.to_csv(od/'candidate_pool.csv',index=False)
 print(f'cases={len(cdf)}, calibration={(cdf.split=="calibration").sum()}, test={(cdf.split=="test").sum()}, judgments={len(jdf)}, candidates={jdf.candidate_id.nunique() if not jdf.empty else 0}')
if __name__=='__main__': main()
