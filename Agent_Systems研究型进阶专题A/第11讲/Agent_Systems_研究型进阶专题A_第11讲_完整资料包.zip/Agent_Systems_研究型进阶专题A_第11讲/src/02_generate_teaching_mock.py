#!/usr/bin/env python3
"""生成第11讲受控 Teaching Mock。不是任何真实模型结果。"""
import argparse, random
from pathlib import Path
import pandas as pd

FAMILIES=['policy','evidence','parameter','mixed']
CANDIDATES={
 'A': {'name':'Generalist-A','cost':1.00,'p':{'policy':.10,'evidence':.11,'parameter':.11,'mixed':.12},'group':'AB'},
 'B': {'name':'Generalist-B','cost':.90,'p':{'policy':.11,'evidence':.12,'parameter':.12,'mixed':.13},'group':'AB'},
 'C': {'name':'Policy-Specialist','cost':.55,'p':{'policy':.04,'evidence':.24,'parameter':.24,'mixed':.22},'group':'ind'},
 'D': {'name':'Evidence-Specialist','cost':.55,'p':{'policy':.24,'evidence':.04,'parameter':.24,'mixed':.22},'group':'ind'},
 'E': {'name':'Parameter-Specialist','cost':.55,'p':{'policy':.24,'evidence':.24,'parameter':.04,'mixed':.22},'group':'ind'},
 'F': {'name':'Mixed-Specialist','cost':.65,'p':{'policy':.18,'evidence':.18,'parameter':.18,'mixed':.06},'group':'ind'},
 'G': {'name':'Diverse-General','cost':.40,'p':{k:.17 for k in FAMILIES},'group':'ind'},
 'H': {'name':'Cheap-General','cost':.25,'p':{k:.23 for k in FAMILIES},'group':'ind'},
}

def flip(label): return 'VALID' if label=='INVALID' else 'INVALID'

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out-dir',required=True); ap.add_argument('--seed',type=int,default=17)
    ap.add_argument('--per-family-per-split',type=int,default=30); args=ap.parse_args()
    random.seed(args.seed); od=Path(args.out_dir); od.mkdir(parents=True,exist_ok=True)
    cases=[]; judgments=[]; cid=0
    for split in ['calibration','test']:
      for fam in FAMILIES:
        for _ in range(args.per_family_per_split):
          invalid=random.random()<.40
          label='INVALID' if invalid else 'VALID'
          shared_ab=random.random() < (.18 if fam!='mixed' else .22)
          case_id=f"{split[:3]}_{cid:04d}"; cid+=1
          cases.append({'case_id':case_id,'split':split,'task_family':fam,'human_label':label,'teaching_mock':True})
          for m,cfg in CANDIDATES.items():
            p=cfg['p'][fam]
            if m in ('A','B'):
              err=random.random() < (.75 if shared_ab else max(.01,p-.04))
            else:
              err=random.random() < p
            judgments.append({'case_id':case_id,'candidate_id':m,'verdict':flip(label) if err else label,
                              'error':int(err),'cost_unit':cfg['cost'],'teaching_mock':True})
    pd.DataFrame(cases).to_csv(od/'cases.csv',index=False)
    pd.DataFrame(judgments).to_csv(od/'judgments.csv',index=False)
    pd.DataFrame([{'candidate_id':m,'display_name':cfg['name'],'cost_unit':cfg['cost'],
                   'teaching_note':'CONTROLLED TEACHING MOCK - NOT A REAL MODEL RESULT'} for m,cfg in CANDIDATES.items()]).to_csv(od/'candidate_pool.csv',index=False)
    print(f"Generated {len(cases)} cases and {len(judgments)} judgments. TEACHING MOCK ONLY.")

if __name__=='__main__': main()
