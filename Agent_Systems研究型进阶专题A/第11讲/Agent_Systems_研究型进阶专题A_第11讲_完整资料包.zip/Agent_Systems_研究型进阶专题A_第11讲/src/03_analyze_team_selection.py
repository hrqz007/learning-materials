#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import pandas as pd
from team_router import build_profiles, choose_policies, team_metrics, summarize_policy

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--data-dir',required=True); ap.add_argument('--out-dir',required=True)
    ap.add_argument('--weights',default='0.50,0.40,0.10'); args=ap.parse_args()
    dd=Path(args.data_dir); od=Path(args.out_dir); od.mkdir(parents=True,exist_ok=True)
    cases=pd.read_csv(dd/'cases.csv'); jud=pd.read_csv(dd/'judgments.csv'); pool=pd.read_csv(dd/'candidate_pool.csv')
    if 'cost_unit' not in jud.columns:
        jud=jud.merge(pool[['candidate_id','cost_unit']],on='candidate_id',how='left')
    df,mp,pp=build_profiles(cases,jud,pool)
    weights=tuple(map(float,args.weights.split(',')))
    policies,scores=choose_policies(df,mp,pp,pool,weights=weights)
    summaries=[]; audits=[]
    for name,sel in policies.items():
        aud=team_metrics(df,sel,split='test'); aud.insert(0,'policy',name); audits.append(aud)
        summaries.append(summarize_policy(name,aud))
    summary=pd.DataFrame(summaries).sort_values(['error_rate','avg_team_cost'])
    audit=pd.concat(audits,ignore_index=True)
    freq=(audit.groupby(['policy','task_family','team'],as_index=False).size().rename(columns={'size':'case_count'}))
    mp.to_csv(od/'calibration_member_profiles.csv',index=False)
    pp.to_csv(od/'calibration_pairwise_complementarity.csv',index=False)
    scores.to_csv(od/'ec_team_scores.csv',index=False)
    summary.to_csv(od/'policy_summary.csv',index=False)
    freq.to_csv(od/'team_selection_frequency.csv',index=False)
    audit.to_csv(od/'case_audit.csv',index=False)
    print(summary.to_string(index=False))

if __name__=='__main__': main()
