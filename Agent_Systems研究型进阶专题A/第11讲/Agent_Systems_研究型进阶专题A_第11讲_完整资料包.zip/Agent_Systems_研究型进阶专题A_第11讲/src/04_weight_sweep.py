#!/usr/bin/env python3
"""在 calibration/test 严格分离的前提下，对 EC Router 权重做一个教学型网格扫描。"""
import argparse
from pathlib import Path
import pandas as pd
from team_router import build_profiles, choose_policies, team_metrics, summarize_policy

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--data-dir',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
 dd=Path(args.data_dir); cases=pd.read_csv(dd/'cases.csv'); jud=pd.read_csv(dd/'judgments.csv'); pool=pd.read_csv(dd/'candidate_pool.csv')
 if 'cost_unit' not in jud.columns: jud=jud.merge(pool[['candidate_id','cost_unit']],on='candidate_id',how='left')
 df,mp,pp=build_profiles(cases,jud,pool); rows=[]
 for w1 in [0.4,0.5,0.6]:
  for w2 in [0.2,0.3,0.4,0.5]:
   w3=1-w1-w2
   if w3<0 or w3>0.3: continue
   pol,_=choose_policies(df,mp,pp,pool,weights=(w1,w2,w3)); aud=team_metrics(df,pol['EC-Team-Router'],'test')
   s=summarize_policy('EC-Team-Router',aud); s.update({'w_expertise':w1,'w_complementarity':w2,'w_cost':w3}); rows.append(s)
 out=pd.DataFrame(rows).sort_values(['error_rate','avg_team_cost']); out.to_csv(args.out,index=False); print(out.head(10).to_string(index=False))
if __name__=='__main__': main()
