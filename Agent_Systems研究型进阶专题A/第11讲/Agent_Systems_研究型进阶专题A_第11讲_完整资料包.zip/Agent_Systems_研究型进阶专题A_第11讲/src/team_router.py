"""第11讲：团队选择核心函数。"""
from __future__ import annotations
import itertools, math
import pandas as pd


def error_jaccard(a: pd.Series, b: pd.Series) -> float:
    aa=set(a[a.astype(bool)].index); bb=set(b[b.astype(bool)].index); u=aa|bb
    return len(aa&bb)/len(u) if u else 0.0


def build_profiles(cases, judgments, pool):
    df=judgments.merge(cases[['case_id','split','task_family','human_label']],on='case_id',how='inner')
    df['error']=(df['verdict']!=df['human_label']).astype(int)
    cal=df[df['split']=='calibration'].copy()
    members=[]
    for (m,fam),g in cal.groupby(['candidate_id','task_family']):
        members.append({'candidate_id':m,'task_family':fam,'n':len(g),'accuracy':1-g.error.mean(),
                        'dangerous_miss_rate':((g.human_label=='INVALID')&(g.verdict=='VALID')).sum()/max(1,(g.human_label=='INVALID').sum()),
                        'false_block_rate':((g.human_label=='VALID')&(g.verdict=='INVALID')).sum()/max(1,(g.human_label=='VALID').sum())})
    member_profiles=pd.DataFrame(members)
    pairs=[]
    mids=sorted(cal.candidate_id.unique())
    for fam, gf in cal.groupby('task_family'):
        pivot=gf.pivot_table(index='case_id',columns='candidate_id',values='error',aggfunc='first')
        for a,b in itertools.combinations(mids,2):
            if a not in pivot or b not in pivot: continue
            sub=pivot[[a,b]].dropna()
            j=error_jaccard(sub[a],sub[b])
            pairs.append({'task_family':fam,'member_a':a,'member_b':b,'error_jaccard':j,'complementarity':1-j,
                          'double_fault_rate':((sub[a]==1)&(sub[b]==1)).mean() if len(sub) else 0})
    pair_profiles=pd.DataFrame(pairs)
    return df, member_profiles, pair_profiles


def majority_prediction(g, team):
    sub=g[g.candidate_id.isin(team)]
    inv=(sub.verdict=='INVALID').sum()
    return 'INVALID' if inv >= math.ceil(len(team)/2) else 'VALID'


def team_metrics(df, team_by_family, split='test'):
    d=df[df.split==split]
    rows=[]
    for cid,g in d.groupby('case_id'):
        fam=g.task_family.iloc[0]; team=tuple(team_by_family[fam]) if isinstance(team_by_family,dict) else tuple(team_by_family)
        pred=majority_prediction(g,team); lab=g.human_label.iloc[0]
        cost=g[g.candidate_id.isin(team)].cost_unit.sum() if 'cost_unit' in g else 0.0
        rows.append({'case_id':cid,'task_family':fam,'human_label':lab,'prediction':pred,'error':int(pred!=lab),
                     'dangerous_miss':int(lab=='INVALID' and pred=='VALID'),'false_block':int(lab=='VALID' and pred=='INVALID'),
                     'team':'+'.join(team),'team_cost':cost})
    x=pd.DataFrame(rows)
    return x


def summarize_policy(name, audit):
    inv=audit[audit.human_label=='INVALID']; val=audit[audit.human_label=='VALID']
    return {'policy':name,'n':len(audit),'error_rate':audit.error.mean(),
            'dangerous_miss_rate':inv.dangerous_miss.mean() if len(inv) else 0.0,
            'false_block_rate':val.false_block.mean() if len(val) else 0.0,
            'avg_team_cost':audit.team_cost.mean(),'unique_teams':audit.team.nunique()}


def choose_policies(df, member_profiles, pair_profiles, pool, weights=(.50,.40,.10), team_size=3):
    mids=sorted(pool.candidate_id.unique()); teams=list(itertools.combinations(mids,team_size))
    cost_map=pool.set_index('candidate_id')['cost_unit'].to_dict()
    max_cost=max(sum(cost_map[m] for m in t) for t in teams)
    # P-1 best single + P0 global top3 by individual calibration accuracy
    cal=df[df.split=='calibration']
    global_acc=(cal.groupby('candidate_id').error.mean().rsub(1)).to_dict()
    p_single=(sorted(mids,key=lambda m:(-global_acc[m],cost_map[m]))[0],)
    p0=tuple(sorted(mids,key=lambda m:(-global_acc[m],cost_map[m]))[:team_size])
    # P1 fixed complementarity-aware global team
    global_pair={}
    piv=cal.pivot_table(index='case_id',columns='candidate_id',values='error',aggfunc='first')
    for a,b in itertools.combinations(mids,2):
        sub=piv[[a,b]].dropna(); global_pair[(a,b)]=1-error_jaccard(sub[a],sub[b])
    def gcomp(t): return sum(global_pair.get(tuple(sorted((a,b))),0) for a,b in itertools.combinations(t,2))/math.comb(team_size,2)
    w1,w2,w3=weights
    best=(-1,None)
    for t in teams:
        exp=sum(global_acc[m] for m in t)/team_size; comp=gcomp(t); cost=sum(cost_map[m] for m in t)/max_cost
        sc=w1*exp+w2*comp-w3*cost
        if sc>best[0]: best=(sc,t)
    p1=best[1]
    # P2 per-family top experts ignoring complementarity
    p2={}
    for fam in sorted(df.task_family.unique()):
        mp=member_profiles[member_profiles.task_family==fam].set_index('candidate_id')['accuracy'].to_dict()
        p2[fam]=tuple(sorted(mids,key=lambda m:(-mp.get(m,0),cost_map[m]))[:team_size])
    # P3 EC Router: expertise + complementarity - cost, per family
    p3={}; score_rows=[]
    pp={(r.task_family,)+tuple(sorted((r.member_a,r.member_b))):r.complementarity for _,r in pair_profiles.iterrows()}
    for fam in sorted(df.task_family.unique()):
        mp=member_profiles[member_profiles.task_family==fam].set_index('candidate_id')['accuracy'].to_dict()
        best=(-1,None,None)
        for t in teams:
            exp=sum(mp.get(m,0) for m in t)/team_size
            comp=sum(pp.get((fam,)+tuple(sorted((a,b))),0) for a,b in itertools.combinations(t,2))/math.comb(team_size,2)
            cost=sum(cost_map[m] for m in t)/max_cost
            sc=w1*exp+w2*comp-w3*cost
            score_rows.append({'task_family':fam,'team':'+'.join(t),'score':sc,'expertise':exp,'complementarity':comp,'cost_norm':cost})
            if sc>best[0]: best=(sc,t,(exp,comp,cost))
        p3[fam]=best[1]
    return {'Best-Single':p_single,'Fixed-Top3':p0,'Fixed-Complementary3':p1,'Task-Expert3':p2,'EC-Team-Router':p3}, pd.DataFrame(score_rows)
