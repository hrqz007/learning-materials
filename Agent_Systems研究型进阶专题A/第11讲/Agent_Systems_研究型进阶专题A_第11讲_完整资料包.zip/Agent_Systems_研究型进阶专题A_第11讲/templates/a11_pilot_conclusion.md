# A11 Pilot Conclusion

## Fact
Report test-split error, dangerous miss, false block, average team cost, and selected-team frequency.

## Inference
State whether dynamic composition appears to improve the reliability-cost frontier relative to fixed teams.

## Uncertainty
List small-sample, task-family, calibration drift, model-version, and aggregation-rule limitations.

## Next experiment
Specify one controlled follow-up. Do not claim a general team-formation law from a single pilot.
