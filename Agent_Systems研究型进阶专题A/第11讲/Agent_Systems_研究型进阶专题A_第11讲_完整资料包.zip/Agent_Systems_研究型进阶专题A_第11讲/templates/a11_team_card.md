# A11 Team Card

- Case / task family:
- Candidate pool version:
- Selected team:
- Member expertise estimates:
- Pairwise error-complementarity estimates:
- Team cost:
- Aggregation rule: majority (fixed)
- Why this team was selected:
- Could a cheaper team have produced the same outcome?
- Any sign of calibration leakage?
