# A11 Case Review

- case_id:
- task_family:
- human_label:
- Fixed-Top3 team / outcome:
- Task-Expert3 team / outcome:
- EC-Team-Router team / outcome:
- Which member corrected the others?
- Did the router select redundant members?
- Was the gain from expertise, complementarity, or both?
- What evidence supports this interpretation?
