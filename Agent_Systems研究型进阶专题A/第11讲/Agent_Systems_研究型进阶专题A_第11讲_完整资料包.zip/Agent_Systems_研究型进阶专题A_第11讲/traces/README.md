把 `case_audit.csv` 中以下样本优先放到这里做 Trace 对照：
1. Fixed-Top3 失败但 EC Router 成功；
2. EC Router 失败但某未选成员本可纠错；
3. 动态团队成本更低但结果相同；
4. 动态团队因历史统计偏差选错成员。
