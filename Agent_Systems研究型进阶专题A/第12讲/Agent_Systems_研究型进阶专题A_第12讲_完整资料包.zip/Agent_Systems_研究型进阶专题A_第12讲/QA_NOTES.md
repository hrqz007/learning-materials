# QA Notes

- Python source: all `src/*.py` passed `python -m py_compile` in the production container.
- Cross-lesson converter: re-tested against the actual Lesson 11 teaching package; produced 120 frozen A12 test cases (30 each: evidence / mixed / parameter / policy) without rerunning members.
- Teaching Mock: regenerated from the frozen Lesson 11 teams and re-analyzed; 360 member-evidence rows and 960 coordinator judgments were produced. These are controlled synthetic teaching data, not real-model results.
- DOCX visual QA: 6 documents, 16 pages total, all rendered with the official DOCX workflow and visually inspected after layout fixes.
  - Lecture: 7 pages
  - Experiment guide: 3 pages
  - Experiment design: 2 pages
  - Exercises: 1 page
  - Answers: 1 page
  - Glossary: 2 pages
- PDF visual QA: lecture PDF has 7 pages; all 7 pages were independently rendered with the PDF renderer and visually inspected.
- Layout fixes completed before delivery: prevented table-row splitting, prevented code-block splitting, and removed the near-blank final page in the experiment-design document.
- Real API runner: not executed in the production container because `litellm` is absent; this limitation is explicit. No real-model scores are fabricated.
- Final package excludes internal QA page images and Python `__pycache__` artifacts.
