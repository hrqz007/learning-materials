# 第12讲学习说明

主题：Leadership / Coordinator Selection / Information Bottleneck。

## 推荐学习顺序
1. 先读 `02_零基础讲义.pdf`。
2. 跑 `src/00_dependency_check.py`。
3. 用 `src/01_prepare_from_a11.py` 冻结第11讲团队输出。
4. 先跑 Teaching Mock，确认你理解 override / expert suppression / bottleneck。
5. 再按 `03_实验指导书.docx` 做 8-case smoke test。
6. 最后扩大真实 pilot，并人工复核 harmful override trace。

## 本讲最重要的边界
- Teaching Mock 不是任何真实模型成绩。
- Leader 规则只能用 calibration 数据定义。
- human_label 绝不能进入 Coordinator prompt。
- 当前资料制作用环境缺少 litellm，因此真实商业 API runner 没有在这里执行。

## 与第11讲的接口
`01_prepare_from_a11.py` 已经在第11讲 Teaching Mock 完整资料包上实际跑通：读取 120 条 test case，并生成四种 Leader 候选。
