#!/usr/bin/env python3
import importlib.util, sys
mods = ['pandas','numpy','litellm']
print('A12 dependency check')
for m in mods:
    ok = importlib.util.find_spec(m) is not None
    print(f'{m}: {"OK" if ok else "MISSING"}')
print('python:', sys.version.split()[0])
