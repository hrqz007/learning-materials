#!/usr/bin/env python3
"""Prepare frozen team outputs from A11 for A12 coordinator experiments.

This script DOES NOT call any model. It freezes the team selected by A11's
EC-Team-Router on the test split and derives four possible leaders from
calibration-only statistics:
- global_strong_leader: highest mean calibration accuracy
- task_expert_leader: highest calibration accuracy for this task family
- bridge_leader: highest mean pairwise complementarity inside this team
- cheapest_leader: lowest candidate cost

If A11 judgments contain optional reason/confidence columns, they are preserved.
"""
import argparse, json
from pathlib import Path
import pandas as pd


def jd(obj):
    return json.dumps(obj, ensure_ascii=False, separators=(',',':'))


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--a11-root', required=True, help='Path to extracted A11 package root')
    ap.add_argument('--out', required=True)
    args=ap.parse_args()
    root=Path(args.a11_root); out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    pool=pd.read_csv(root/'data/teaching_mock/candidate_pool.csv')
    cases=pd.read_csv(root/'data/teaching_mock/cases.csv')
    jud=pd.read_csv(root/'data/teaching_mock/judgments.csv')
    prof=pd.read_csv(root/'outputs/teaching_mock/calibration_member_profiles.csv')
    pair=pd.read_csv(root/'outputs/teaching_mock/calibration_pairwise_complementarity.csv')
    audit=pd.read_csv(root/'outputs/teaching_mock/case_audit.csv')
    audit=audit[audit['policy'].eq('EC-Team-Router')].copy()
    audit=audit.merge(cases[['case_id','split','task_family','human_label']], on=['case_id','task_family','human_label'], how='left')
    audit=audit[audit['split'].eq('test')].copy()
    cost=dict(zip(pool.candidate_id, pool.cost_unit))
    global_acc=prof.groupby('candidate_id').accuracy.mean().to_dict()
    fam_acc={(r.candidate_id,r.task_family):float(r.accuracy) for r in prof.itertuples()}
    comp={}
    for r in pair.itertuples():
        comp[(r.task_family, r.member_a, r.member_b)]=float(r.complementarity)
        comp[(r.task_family, r.member_b, r.member_a)]=float(r.complementarity)
    reason_col='reason' if 'reason' in jud.columns else None
    conf_col='confidence' if 'confidence' in jud.columns else None
    rows=[]
    for a in audit.itertuples():
        team=str(a.team).split('+')
        j=jud[(jud.case_id==a.case_id) & jud.candidate_id.isin(team)].copy()
        verdicts={r.candidate_id:r.verdict for r in j.itertuples()}
        reasons={r.candidate_id:(getattr(r,reason_col) if reason_col else '') for r in j.itertuples()}
        confs={r.candidate_id:(getattr(r,conf_col) if conf_col else None) for r in j.itertuples()}
        costs={m:float(cost.get(m,1.0)) for m in team}
        # Majority for 3-member team. If malformed, mark UNKNOWN rather than guessing.
        vals=list(verdicts.values())
        majority='UNKNOWN'
        if vals.count('VALID')>=2: majority='VALID'
        if vals.count('INVALID')>=2: majority='INVALID'
        gs=max(team,key=lambda m:(global_acc.get(m,0.0), -costs[m], m))
        te=max(team,key=lambda m:(fam_acc.get((m,a.task_family),0.0), global_acc.get(m,0.0), -costs[m], m))
        def bridge_score(m):
            others=[x for x in team if x!=m]
            vals=[comp.get((a.task_family,m,x),0.0) for x in others]
            return sum(vals)/len(vals) if vals else 0.0
        br=max(team,key=lambda m:(bridge_score(m), fam_acc.get((m,a.task_family),0.0), -costs[m], m))
        ch=min(team,key=lambda m:(costs[m], -fam_acc.get((m,a.task_family),0.0), m))
        rows.append({
            'case_id':a.case_id,'task_family':a.task_family,'human_label':a.human_label,
            'team':'+'.join(team),'member_verdicts_json':jd(verdicts),'member_reasons_json':jd(reasons),
            'member_confidences_json':jd(confs),'member_costs_json':jd(costs),
            'majority_verdict':majority,'majority_error':int(majority!=a.human_label),
            'global_strong_leader':gs,'task_expert_leader':te,'bridge_leader':br,'cheapest_leader':ch,
            'global_strong_acc':global_acc.get(gs,0.0),'task_expert_acc':fam_acc.get((te,a.task_family),0.0),
            'bridge_score':bridge_score(br), 'teaching_source':'A11 frozen team outputs'
        })
    df=pd.DataFrame(rows).sort_values('case_id')
    df.to_csv(out,index=False)
    print(f'wrote {len(df)} frozen A12 cases -> {out}')
    print(df[['task_family','majority_error']].groupby('task_family').agg(['count','mean']))

if __name__=='__main__': main()
