#!/usr/bin/env python3
"""Generate controlled A12 coordinator outcomes from frozen A11 teams.
All outputs are TEACHING MOCK and must not be interpreted as real model results.
"""
import argparse, json, hashlib
from pathlib import Path
import pandas as pd


def u01(*parts):
    s='|'.join(map(str,parts)).encode()
    return int(hashlib.sha256(s).hexdigest()[:12],16)/float(16**12-1)

def clip(x,a,b): return max(a,min(b,x))
def parse(s): return json.loads(s)

def decide_authority(majority, leader_v, leader_s, peer_strength, bias, key):
    if leader_v==majority: return majority
    noise=(u01(key,'auth')-.5)*.12
    return leader_v if leader_s + bias + noise > peer_strength else majority

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inputs',required=True); ap.add_argument('--out-dir',required=True); a=ap.parse_args()
    inp=pd.read_csv(a.inputs); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    evidence_rows=[]; result_rows=[]
    # family-specific specialist hints in A11 teaching pool
    specialist={'policy':'C','evidence':'D','parameter':'E','mixed':'F'}
    for r in inp.itertuples():
        verdicts=parse(r.member_verdicts_json); members=list(verdicts)
        # Synthetic evidence strength: correct evidence tends to be stronger, but confident wrong evidence remains possible.
        strengths={}; confs={}; reasons={}
        for m in members:
            correct=verdicts[m]==r.human_label
            spec=(specialist.get(r.task_family)==m)
            z=u01(r.case_id,m,'evidence')
            s=(0.69 if correct else 0.43) + (0.10 if spec else 0.0) + (z-.5)*0.22
            # inject several confident-but-wrong leaders so authority can become harmful
            if (not correct) and u01(r.case_id,m,'confident_wrong')<0.30: s+=0.18
            s=clip(s,.18,.97); c=clip(s+(u01(r.case_id,m,'confidence')-.5)*.12,.15,.99)
            strengths[m]=s; confs[m]=c
            reasons[m]=f"TEACHING MOCK evidence from member {m}; family={r.task_family}; strength={s:.2f}."
            evidence_rows.append({'case_id':r.case_id,'task_family':r.task_family,'human_label':r.human_label,
                                  'member_id':m,'verdict':verdicts[m],'evidence_strength':s,'confidence':c,
                                  'reason':reasons[m],'is_correct':int(correct),'teaching_mock':True})
        majority=r.majority_verdict
        # peer strength supporting majority
        ms=[strengths[m] for m in members if verdicts[m]==majority]
        peer_strength=sum(ms)/len(ms) if ms else .5
        conditions=[]
        conditions.append(('C0_Majority_NoLeader', majority, None, 'majority'))
        for cname,leader_field,bias in [
            ('C1_GlobalStrong_NamedFull','global_strong_leader',.20),
            ('C2_TaskExpert_NamedFull','task_expert_leader',.14),
            ('C3_BridgeLeader_NamedFull','bridge_leader',.10),
        ]:
            leader=getattr(r,leader_field); final=decide_authority(majority,verdicts[leader],strengths[leader],peer_strength,bias,(r.case_id,cname))
            conditions.append((cname,final,leader,'named_full'))
        # Same TaskExpert leader, progressively richer information.
        te=r.task_expert_leader
        # Verdict-only: mostly majority; leader can override only when calibration expertise was strong.
        final_vo=verdicts[te] if (verdicts[te]!=majority and r.task_expert_acc>=.90 and u01(r.case_id,'vo')<.55) else majority
        conditions.append(('C4_TaskExpert_VerdictOnly',final_vo,te,'verdict_only'))
        # Compressed summary: use counts + the strongest single evidence item; compression can discard minority details.
        top=max(members,key=lambda m:strengths[m]); final_cs=majority
        # Compression keeps only a salient summary; it can miss a useful dissent unless it is extremely strong.
        if verdicts[top]!=majority and strengths[top]>.80 and strengths[top]>peer_strength+.18: final_cs=verdicts[top]
        elif verdicts[te]!=majority and strengths[te]>.82 and strengths[te]>peer_strength+.14 and u01(r.case_id,'cs')<.50: final_cs=verdicts[te]
        conditions.append(('C5_TaskExpert_CompressedSummary',final_cs,te,'compressed_summary'))
        # Evidence ledger: aggregate all evidence, preserve dissent, modest expert bonus.
        score={'VALID':0.0,'INVALID':0.0}
        for m in members: score[verdicts[m]]+=strengths[m]
        score[verdicts[te]]+=0.08
        final_el='VALID' if score['VALID']>=score['INVALID'] else 'INVALID'
        # Dissent-preserving rule: a task-expert minority with substantially stronger evidence may override 2-v-1 count.
        minority=[m for m in members if verdicts[m]!=majority]
        if len(minority)==1:
            mm=minority[0]; maj_avg=sum(strengths[m] for m in members if verdicts[m]==majority)/2
            if mm==te and strengths[mm]>maj_avg+.08 and strengths[mm]>.70: final_el=verdicts[mm]
        conditions.append(('C6_TaskExpert_EvidenceLedger',final_el,te,'evidence_ledger'))
        # External anonymous coordinator: no identity bonus; minority can win only on evidence.
        score2={'VALID':0.0,'INVALID':0.0}
        for m in members: score2[verdicts[m]]+=strengths[m]
        final_an='VALID' if score2['VALID']>=score2['INVALID'] else 'INVALID'
        minority=[m for m in members if verdicts[m]!=majority]
        if len(minority)==1:
            mm=minority[0]; maj_avg=sum(strengths[m] for m in members if verdicts[m]==majority)/2
            if strengths[mm]>maj_avg+.08 and strengths[mm]>.62: final_an=verdicts[mm]
        conditions.append(('C7_External_AnonymousLedger',final_an,'EXTERNAL','anonymous_ledger'))
        for cname,final,leader,mode in conditions:
            majority_correct=majority==r.human_label; final_correct=final==r.human_label
            lv=verdicts.get(leader) if leader in verdicts else None
            leader_disagrees=(lv is not None and lv!=majority)
            result_rows.append({
                'case_id':r.case_id,'task_family':r.task_family,'human_label':r.human_label,'team':r.team,
                'condition':cname,'leader_id':leader,'info_mode':mode,'majority_verdict':majority,
                'final_verdict':final,'error':int(not final_correct),'dangerous_miss':int(r.human_label=='INVALID' and final=='VALID'),
                'false_block':int(r.human_label=='VALID' and final=='INVALID'),'override':int(final!=majority),
                'helpful_override':int((not majority_correct) and final_correct),'harmful_override':int(majority_correct and (not final_correct)),
                'leader_disagrees_majority':int(leader_disagrees),'final_follows_leader':int(leader_disagrees and final==lv),
                'leader_wrong_follow':int(leader_disagrees and lv!=r.human_label and final==lv),
                'task_expert_correct':int(verdicts[te]==r.human_label),
                'expert_suppressed':int(verdicts[te]==r.human_label and final!=r.human_label),
                'estimated_extra_cost':0.0 if cname=='C0_Majority_NoLeader' else (0.25 if 'VerdictOnly' in cname else 0.55 if 'Compressed' in cname else 0.85),
                'teaching_mock':True
            })
    pd.DataFrame(evidence_rows).to_csv(out/'member_evidence.csv',index=False)
    pd.DataFrame(result_rows).to_csv(out/'coordinator_judgments.csv',index=False)
    print(f'wrote {len(evidence_rows)} member evidence rows and {len(result_rows)} coordinator rows')

if __name__=='__main__': main()
