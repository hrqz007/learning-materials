#!/usr/bin/env python3
"""Analyze leadership/coordinator outcomes against frozen A12 cases."""
import argparse
from pathlib import Path
import pandas as pd

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inputs',required=True); ap.add_argument('--judgments',required=True); ap.add_argument('--out-dir',required=True); a=ap.parse_args()
    inp=pd.read_csv(a.inputs); j=pd.read_csv(a.judgments); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
    base=inp[['case_id','task_family','human_label','majority_verdict','task_expert_leader']].copy()
    df=j.merge(base,on='case_id',how='left',suffixes=('','_input'))
    # Teaching mock already contains some fields; recompute robustly for real outputs.
    if 'final_verdict' not in df: raise SystemExit('judgments missing final_verdict')
    df['error_calc']=(df.final_verdict!=df.human_label).astype(int)
    df['dangerous_miss_calc']=((df.human_label=='INVALID')&(df.final_verdict=='VALID')).astype(int)
    df['false_block_calc']=((df.human_label=='VALID')&(df.final_verdict=='INVALID')).astype(int)
    df['override_calc']=(df.final_verdict!=df.majority_verdict).astype(int)
    df['majority_correct']=(df.majority_verdict==df.human_label)
    df['helpful_override_calc']=((~df.majority_correct)&(df.final_verdict==df.human_label)).astype(int)
    df['harmful_override_calc']=((df.majority_correct)&(df.final_verdict!=df.human_label)).astype(int)
    summaries=[]
    for cond,g in df.groupby('condition'):
        valid=g[~g.final_verdict.isin(['API_ERROR','PARSE_ERROR','CONFIG_ERROR'])]
        n=len(valid)
        inv=(valid.human_label=='INVALID').sum(); val=(valid.human_label=='VALID').sum()
        summaries.append({
            'condition':cond,'n':n,'error_rate':valid.error_calc.mean() if n else None,
            'dangerous_miss_rate':valid.dangerous_miss_calc.sum()/inv if inv else None,
            'false_block_rate':valid.false_block_calc.sum()/val if val else None,
            'override_rate':valid.override_calc.mean() if n else None,
            'helpful_override_count':int(valid.helpful_override_calc.sum()),'harmful_override_count':int(valid.harmful_override_calc.sum()),
            'avg_cost':valid['cost'].mean() if 'cost' in valid.columns else valid.get('estimated_extra_cost',pd.Series(dtype=float)).mean(),
            'avg_latency_s':valid['latency_s'].mean() if 'latency_s' in valid.columns else None,
        })
    s=pd.DataFrame(summaries).sort_values(['error_rate','dangerous_miss_rate'],na_position='last')
    s.to_csv(out/'condition_summary.csv',index=False)
    fam=(df.groupby(['condition','task_family']).agg(n=('case_id','count'),error_rate=('error_calc','mean'),override_rate=('override_calc','mean')).reset_index())
    fam.to_csv(out/'family_summary.csv',index=False)
    harm=df[df.harmful_override_calc.eq(1)].copy(); harm.to_csv(out/'harmful_overrides.csv',index=False)
    helpful=df[df.helpful_override_calc.eq(1)].copy(); helpful.to_csv(out/'helpful_overrides.csv',index=False)
    # Authority diagnostics if teaching mock columns are present.
    if {'leader_disagrees_majority','final_follows_leader','leader_wrong_follow'}.issubset(df.columns):
        auth=[]
        for cond,g in df.groupby('condition'):
            d=g[g.leader_disagrees_majority.eq(1)]
            auth.append({'condition':cond,'leader_disagreement_n':len(d),'follow_leader_rate':d.final_follows_leader.mean() if len(d) else None,'follow_wrong_leader_rate':d.leader_wrong_follow.mean() if len(d) else None})
        pd.DataFrame(auth).to_csv(out/'authority_diagnostics.csv',index=False)
    print(s.to_string(index=False))

if __name__=='__main__': main()
