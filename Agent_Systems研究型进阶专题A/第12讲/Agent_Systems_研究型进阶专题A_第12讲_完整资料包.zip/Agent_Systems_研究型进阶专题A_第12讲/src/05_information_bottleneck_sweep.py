#!/usr/bin/env python3
"""Teaching analysis: how many member evidence items must the coordinator retain?
Uses A12 member_evidence.csv. k=0 is majority-only; k=1..3 keep top-k evidence items.
"""
import argparse
from pathlib import Path
import pandas as pd

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--evidence',required=True); ap.add_argument('--out',required=True); a=ap.parse_args()
    ev=pd.read_csv(a.evidence); rows=[]
    for cid,g in ev.groupby('case_id'):
        truth=g.human_label.iloc[0]; counts=g.verdict.value_counts(); majority=counts.idxmax()
        for k in range(4):
            if k==0: pred=majority
            else:
                top=g.sort_values('evidence_strength',ascending=False).head(k)
                scores=top.groupby('verdict').evidence_strength.sum().to_dict()
                if len(scores)==1: pred=next(iter(scores))
                else: pred=max(scores,key=scores.get)
            rows.append({'case_id':cid,'k_evidence_items':k,'human_label':truth,'prediction':pred,'error':int(pred!=truth),'dangerous_miss':int(truth=='INVALID' and pred=='VALID')})
    df=pd.DataFrame(rows); out_rows=[]
    for k,g in df.groupby('k_evidence_items'):
        inv=g[g.human_label.eq('INVALID')]
        out_rows.append({'k_evidence_items':k,'n':len(g),'error_rate':g.error.mean(),'dangerous_miss_rate':inv.dangerous_miss.mean() if len(inv) else None})
    summ=pd.DataFrame(out_rows); Path(a.out).parent.mkdir(parents=True,exist_ok=True); summ.to_csv(a.out,index=False); print(summ.to_string(index=False))
if __name__=='__main__': main()
