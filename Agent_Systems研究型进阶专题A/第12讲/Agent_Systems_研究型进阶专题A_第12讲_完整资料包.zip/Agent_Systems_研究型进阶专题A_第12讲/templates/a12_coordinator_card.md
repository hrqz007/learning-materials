# A12 Coordinator Card

- Team composition (frozen):
- Coordinator selection rule:
- Information channel: verdict-only / compressed summary / evidence ledger
- Are member identities visible?: yes / no
- Does coordinator have final authority?: yes / no
- Can coordinator abstain?: yes / no
- Aggregation fallback:
- Extra model calls per case:
- Expected failure mode:
- What evidence would falsify the hypothesis?:
