# A12 Pilot Conclusion

1. Did coordinator identity materially change outcomes when information was held fixed?
2. Which leader-selection rule had the lowest harmful-override rate?
3. Did verdict-only compression suppress useful minority/expert information?
4. Did evidence-ledger input improve minority rescue without creating excessive false blocks?
5. Did anonymization change the coordinator's tendency to follow a named leader?
6. Were gains consistent across task families, or driven by one family?
7. What is the next falsifiable mechanism hypothesis?

Do not write “leadership causes X” unless the intervention isolated leadership and the result is stable across repeated real runs.
