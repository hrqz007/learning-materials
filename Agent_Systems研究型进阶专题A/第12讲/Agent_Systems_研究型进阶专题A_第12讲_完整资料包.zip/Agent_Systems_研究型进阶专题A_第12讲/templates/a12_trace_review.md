# A12 Trace Review

## Case metadata
- case_id:
- task_family:
- human_label:
- selected team:
- coordinator condition:

## Frozen member state
- member 1 verdict + evidence:
- member 2 verdict + evidence:
- member 3 verdict + evidence:
- majority verdict:
- task-expert member:

## Coordinator behavior
- final verdict:
- did it override majority?:
- did it follow leader identity over stronger evidence?:
- strongest dissent preserved?:
- evidence lost by compression?:

## Failure attribution
- leadership dominance / identity bias / information bottleneck / reasonable override / other:
- first place the coordinator went wrong:
- counterfactual safer behavior:
