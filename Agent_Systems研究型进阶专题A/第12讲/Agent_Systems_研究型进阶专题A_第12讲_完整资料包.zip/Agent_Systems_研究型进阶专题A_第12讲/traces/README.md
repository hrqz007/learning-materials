Place hand-reviewed coordinator traces here. Recommended naming:
`<case_id>__<condition>.md`.
Prioritize harmful overrides, expert-suppression cases, and majority-wrong cases that were successfully rescued.
