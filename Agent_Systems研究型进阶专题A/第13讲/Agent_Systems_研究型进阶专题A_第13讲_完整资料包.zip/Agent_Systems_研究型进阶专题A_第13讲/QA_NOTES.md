# 第13讲 QA Notes

## 文档渲染
- `01_零基础讲义.docx`：7 页，逐页检查通过。
- `03_实验指导书.docx`：3 页，逐页检查通过。
- `04_实验设计书.docx`：3 页，逐页检查通过。
- `05_练习题.docx`：1 页，通过。
- `06_练习题答案.docx`：1 页，通过。
- `07_术语速查表.docx`：2 页，通过。
- `02_零基础讲义.pdf`：7 页，由独立 PDF renderer 再次逐页检查通过。

检查项：中文 glyph、图片、表格、代码框、页脚、跨页裁切、重叠、空白异常页。

## 代码 QA
- 所有 `src/*.py` 通过 `python -m py_compile`。
- `00_dependency_check.py`：pandas/numpy OK；当前制作用容器 `litellm` 缺失，因此没有伪造真实商业 API 运行。
- Teaching Mock：实际生成 1440 条 judgment 并完成全套分析。
- `01_prepare_from_a07.py`：使用第7讲完整资料包真实功能测试，成功得到 30 条 experience + 30 条 held-out evaluation（每个 family 10/10）。
- A07 Teaching Mock 的 VALID case 原始 `error_family=valid`，跨讲脚本会 round-robin 分配到 policy/evidence/parameter 并打印 WARNING；正式研究必须独立标注这些 VALID case 的 task family。
- `02_build_experience_streams.py`：成功生成三个 10 条专业经历 bank + 一个 10 条 shared bank。
- `06_merge_real_conditions.py`：用 Teaching Mock 三条件完成合并功能测试。

## Teaching Mock 边界
Teaching Mock 是受控合成数据，目的是验证：
1. specialization matrix；
2. pairwise error correlation / double-fault；
3. fixed-majority collective gain；
4. Memory-On / Memory-Off paired effect。

不得把其中任何数字当作真实模型性能。
