# Agent Systems 研究型进阶专题 A · 第13讲

主题：**Persistent Agents / Experience-Induced Heterogeneity**。

## 本讲最低闭环

同一基础 Agent → 不同长期 Experience Stream → 持久化 Experience Bank → Held-out 测试 → Specialization Matrix → Error Correlation → Fixed Aggregation → Memory-Off 因果回退。

## 推荐学习顺序

1. `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 先运行 `src/00_dependency_check.py`
4. 跑 Teaching Mock：`src/03_generate_teaching_mock.py` + `src/04_analyze_experience_heterogeneity.py`
5. 用第7讲包测试跨讲桥：`src/01_prepare_from_a07.py` + `src/02_build_experience_streams.py`
6. 有 API 环境后再运行 `src/05_run_persistent_agents.py`
7. 填 `templates/a13_trace_review.md`

## 重要边界

- Teaching Mock 是受控合成数据，不代表任何真实模型成绩。
- 第13讲禁止通过 Persona / Role / Model / Tool 差异制造“异质性”。
- 对 VALID case 的 task_family 如果第7讲原始数据没有标注，跨讲脚本会为教学桥做 round-robin fallback，并打印 WARNING；正式论文必须人工或独立规则标注，不能依赖这个教学 fallback。
- 真实结论必须来自 held-out 数据、重复实验与 Memory-Off / counterfactual memory 因果对照。

## 本讲外部研究线索（截至 2026-10-01）

- ACL 2026: How Memory Management Impacts LLM Agents: An Empirical Study of Experience-Following Behavior
  - https://aclanthology.org/2026.acl-long.27/
- ICML 2026: Large Language Model Agents Are Not Always Faithful Self-Evolvers
  - https://proceedings.mlr.press/v306/zhao26aw.html
- 2026 preprint: When Continual Learning Moves to Memory
  - https://arxiv.org/abs/2604.27003
- Sep 2026 preprint: LifeMem
  - https://arxiv.org/abs/2609.12655
- 2025 preprint: Intrinsic Memory Agents
  - https://arxiv.org/abs/2508.08997
