#!/usr/bin/env python3
import importlib.util, sys
mods=['pandas','numpy']
optional=['litellm']
print('Python:',sys.version.split()[0])
ok=True
for m in mods:
    found=importlib.util.find_spec(m) is not None
    print(f'{m}:', 'OK' if found else 'MISSING')
    ok &= found
for m in optional:
    found=importlib.util.find_spec(m) is not None
    print(f'{m}:', 'OK (real API runner available)' if found else 'MISSING (Teaching Mock still works)')
if not ok:
    raise SystemExit(1)
