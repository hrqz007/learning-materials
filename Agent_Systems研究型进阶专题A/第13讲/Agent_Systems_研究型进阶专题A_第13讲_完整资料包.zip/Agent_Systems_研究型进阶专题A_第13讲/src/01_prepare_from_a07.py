#!/usr/bin/env python3
"""Build an exposure/evaluation split from A07 fixed-proposal inputs.
No LLM call is made. Human labels are used only for completed-experience cards and later evaluation, never inserted into test prompts.
"""
import argparse, json
from pathlib import Path
import pandas as pd

p=argparse.ArgumentParser()
p.add_argument('--a07-root', required=True)
p.add_argument('--out-dir', required=True)
p.add_argument('--experience-per-family', type=int, default=10)
p.add_argument('--eval-per-family', type=int, default=10)
a=p.parse_args()
root=Path(a.a07_root)
src=root/'data'/'teaching_mock_panel_inputs.jsonl'
if not src.exists():
    # fallback for a real A07-like run
    cand=list(root.rglob('*panel_inputs*.jsonl'))
    if not cand: raise FileNotFoundError('Cannot find A07 panel inputs JSONL')
    src=cand[0]
rows=[]
with open(src,encoding='utf-8') as f:
    for line in f:
        if line.strip(): rows.append(json.loads(line))
df=pd.DataFrame(rows)
family_col='error_family' if 'error_family' in df.columns else 'task_family'
need=['proposal_id','human_label',family_col]
for c in need:
    if c not in df.columns: raise ValueError(f'Missing column: {c}')
df=df.sort_values('proposal_id').reset_index(drop=True)
# A07 Teaching Mock labels INVALID cases by failure family but often stores VALID cases as family='valid'.
# For a balanced teaching bridge, distribute such VALID/unknown rows round-robin across the known failure families.
# In a real paper, replace this fallback with an independently annotated task_family field.
main_fams=[x for x in sorted(df[family_col].dropna().astype(str).unique()) if x not in {'valid','unknown','none','nan'}]
mask=df[family_col].astype(str).str.lower().isin(['valid','unknown','none','nan'])
if mask.any() and main_fams:
    ids=df.index[mask].tolist()
    for k,idx in enumerate(ids): df.loc[idx,family_col]=main_fams[k % len(main_fams)]
    df['family_inferred']=False; df.loc[mask,'family_inferred']=True
    print(f'WARNING: inferred task_family for {mask.sum()} VALID/unknown rows by round-robin across {main_fams}. For formal research, manually annotate these rows.')
else:
    df['family_inferred']=False
out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
exp=[]; eva=[]
for fam,g in df.groupby(family_col,sort=True):
    g=g.sort_values(['human_label','proposal_id']).reset_index(drop=True)
    exp_parts=[]; eval_parts=[]
    leftovers=[]
    for label,gl in g.groupby('human_label',sort=True):
        gl=gl.reset_index(drop=True)
        exp_parts.append(gl.iloc[::2])
        eval_parts.append(gl.iloc[1::2])
    exp_g=pd.concat(exp_parts,ignore_index=True) if exp_parts else g.iloc[:0]
    eval_g=pd.concat(eval_parts,ignore_index=True) if eval_parts else g.iloc[:0]
    # Fill exact requested sizes from the opposite pool if alternating produced an imbalance.
    target_exp=min(a.experience_per_family,len(g))
    target_eval=min(a.eval_per_family,max(0,len(g)-target_exp))
    exp_g=exp_g.head(target_exp)
    used=set(exp_g.proposal_id.astype(str))
    remaining=g[~g.proposal_id.astype(str).isin(used)]
    eval_g=remaining.head(target_eval)
    if len(exp_g)<target_exp:
        extra=remaining[~remaining.proposal_id.astype(str).isin(set(eval_g.proposal_id.astype(str)))].head(target_exp-len(exp_g))
        exp_g=pd.concat([exp_g,extra],ignore_index=True)
    exp.append(exp_g.assign(task_family=fam,split='experience'))
    eva.append(eval_g.assign(task_family=fam,split='evaluation'))
exp=pd.concat(exp,ignore_index=True); eva=pd.concat(eva,ignore_index=True)
exp.to_json(out/'experience_pool.jsonl',orient='records',lines=True,force_ascii=False)
eva.to_json(out/'eval_cases.jsonl',orient='records',lines=True,force_ascii=False)
print(f'Prepared {len(exp)} experiences + {len(eva)} held-out cases from {src}')
print(exp.groupby('task_family').size().to_dict())
print(eva.groupby('task_family').size().to_dict())
