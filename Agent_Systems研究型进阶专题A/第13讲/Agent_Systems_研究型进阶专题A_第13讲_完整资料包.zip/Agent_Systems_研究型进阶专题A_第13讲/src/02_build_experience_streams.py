#!/usr/bin/env python3
import argparse, json
from pathlib import Path
import pandas as pd

p=argparse.ArgumentParser()
p.add_argument('--experience-pool',required=True)
p.add_argument('--out-dir',required=True)
p.add_argument('--per-agent',type=int,default=10)
a=p.parse_args()
df=pd.read_json(a.experience_pool,lines=True)
out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
agent_family={'agent_P':'policy','agent_E':'evidence','agent_R':'parameter'}

def card(row, idx):
    fam=row['task_family']; label=row['human_label']
    lesson = {
      'policy': 'Before a write, verify the domain policy permits this operation under the stated conditions.',
      'evidence': 'Before a write, verify the required fact is actually supported by observable conversation/tool evidence.',
      'parameter': 'Before a write, ground every consequential argument in observed evidence; do not infer missing values.'
    }.get(fam,'Check policy, evidence, and parameters before consequential actions.')
    if str(label).upper()=='VALID':
        lesson='Successful prior episode: '+lesson+' This case satisfied the requirement.'
    else:
        lesson='Failed/blocked prior episode: '+lesson+' This case violated the requirement.'
    return {
      'experience_id':f'exp_{idx:03d}', 'source_proposal_id':row['proposal_id'],
      'task_family':fam, 'candidate_tool':row.get('candidate_tool',''),
      'candidate_arguments':row.get('candidate_arguments',{}), 'policy':row.get('policy',''),
      'history':row.get('history',[]), 'outcome_label':str(label).upper(), 'lesson':lesson
    }

banks={}
for aid,fam in agent_family.items():
    g=df[df.task_family==fam].head(a.per_agent)
    banks[aid]=[card(r,i) for i,(_,r) in enumerate(g.iterrows())]
# Shared bank: same quantity, balanced when possible.
parts=[]
fams=sorted(df.task_family.unique())
base=a.per_agent//len(fams); rem=a.per_agent%len(fams)
for i,fam in enumerate(fams): parts.append(df[df.task_family==fam].head(base+(1 if i<rem else 0)))
shared=pd.concat(parts,ignore_index=True).head(a.per_agent)
banks['shared']=[card(r,i) for i,(_,r) in enumerate(shared.iterrows())]
for name,items in banks.items():
    with open(out/f'{name}.jsonl','w',encoding='utf-8') as f:
        for x in items: f.write(json.dumps(x,ensure_ascii=False)+'\n')
manifest=[]
for name,items in banks.items():
    manifest.append({'bank':name,'n':len(items),'family_counts':dict(pd.Series([x['task_family'] for x in items]).value_counts())})
pd.DataFrame(manifest).to_json(out/'bank_manifest.json',orient='records',force_ascii=False,indent=2)
print(pd.DataFrame(manifest).to_string(index=False))
