#!/usr/bin/env python3
"""Controlled synthetic example. NOT real model results."""
import argparse
from pathlib import Path
import numpy as np, pandas as pd

p=argparse.ArgumentParser(); p.add_argument('--out-dir',required=True); p.add_argument('--seed',type=int,default=1313); a=p.parse_args()
rng=np.random.default_rng(a.seed)
out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)
families=['policy','evidence','parameter']; agents=['agent_P','agent_E','agent_R']
# 120 held-out cases, 40 per family, balanced labels.
rows=[]
for fam in families:
    for i in range(40):
        label='INVALID' if (i%2==0) else 'VALID'
        prefix={'policy':'pol','evidence':'evi','parameter':'par'}[fam]
        rows.append({'case_id':f'{prefix}_{i:03d}','task_family':fam,'human_label':label,'teaching_mock':True})
cases=pd.DataFrame(rows); cases.to_csv(out/'cases.csv',index=False)

# shared latent difficulty creates correlated failures in homogeneous settings.
latent={cid:rng.random() for cid in cases.case_id}
records=[]
baseline_cache={}
# conditions: no memory; same shared bank; different persistent histories; divergent bank disabled.
for cond in ['C0_NoMemory','C1_SharedMemory','C2_DivergentExperience','C3_Divergent_MemoryOff']:
    for _,r in cases.iterrows():
        fam=r.task_family; truth=r.human_label; z=latent[r.case_id]
        for j,aid in enumerate(agents):
            specialty={'agent_P':'policy','agent_E':'evidence','agent_R':'parameter'}[aid]
            u=rng.random()
            if cond=='C0_NoMemory':
                # same base, shared latent difficulty -> correlated errors around 20%
                p_err=0.05 + 0.25*(z>0.55) + 0.08*(z>0.85) + 0.02*j
            elif cond=='C3_Divergent_MemoryOff':
                p_err=None
            elif cond=='C1_SharedMemory':
                # same useful experience helps, but errors remain correlated
                p_err=0.035 + 0.24*(z>0.60) + 0.08*(z>0.84) + 0.015*j
            else:
                # same model/prompt/role; only memory history differs. specialty helps and shared-latent weight is lower.
                p_err=(0.02 if fam==specialty else 0.22) + 0.04*(z>0.80)
                # small agent-specific deterministic modulation -> complementary profiles
                if (sum(ord(ch) for ch in (r.case_id+aid)) % 11)==0: p_err += 0.04
            if cond=='C3_Divergent_MemoryOff':
                err=baseline_cache[(r.case_id,aid)]
            else:
                err = u < min(max(p_err,0),0.9)
                if cond=='C0_NoMemory': baseline_cache[(r.case_id,aid)]=err
            verdict = truth if not err else ('VALID' if truth=='INVALID' else 'INVALID')
            used_memory = cond in ['C1_SharedMemory','C2_DivergentExperience']
            records.append({'condition':cond,'case_id':r.case_id,'task_family':fam,'human_label':truth,'agent_id':aid,
                            'verdict':verdict,'error':int(err),'used_memory':used_memory,'retrieved_family': specialty if cond=='C2_DivergentExperience' else ('mixed' if cond=='C1_SharedMemory' else 'none'),
                            'cost_unit':1.00+(0.10 if used_memory else 0.0),'teaching_mock':True})
pd.DataFrame(records).to_csv(out/'judgments.csv',index=False)
print('Wrote',len(records),'synthetic judgments. CONTROLLED TEACHING MOCK ONLY.')
