#!/usr/bin/env python3
import argparse, math
from pathlib import Path
import numpy as np, pandas as pd

p=argparse.ArgumentParser(); p.add_argument('--cases',required=True); p.add_argument('--judgments',required=True); p.add_argument('--out-dir',required=True); a=p.parse_args()
cases=pd.read_csv(a.cases); j=pd.read_csv(a.judgments); out=Path(a.out_dir); out.mkdir(parents=True,exist_ok=True)

def phi(x,y):
    x=np.asarray(x,dtype=int); y=np.asarray(y,dtype=int)
    a=((x==1)&(y==1)).sum(); b=((x==1)&(y==0)).sum(); c=((x==0)&(y==1)).sum(); d=((x==0)&(y==0)).sum()
    den=math.sqrt((a+b)*(c+d)*(a+c)*(b+d))
    return (a*d-b*c)/den if den else np.nan

member=[]
for (cond,aid),g in j.groupby(['condition','agent_id']):
    member.append({'condition':cond,'agent_id':aid,'n':len(g),'error_rate':g.error.mean(),'accuracy':1-g.error.mean(),'avg_cost':g.cost_unit.mean()})
pd.DataFrame(member).to_csv(out/'member_summary.csv',index=False)

fam=[]
for (cond,aid,f),g in j.groupby(['condition','agent_id','task_family']):
    fam.append({'condition':cond,'agent_id':aid,'task_family':f,'n':len(g),'error_rate':g.error.mean(),'accuracy':1-g.error.mean()})
famdf=pd.DataFrame(fam); famdf.to_csv(out/'member_family_matrix.csv',index=False)

pairs=[]
for cond,gc in j.groupby('condition'):
    agents=sorted(gc.agent_id.unique())
    for i in range(len(agents)):
      for k in range(i+1,len(agents)):
        a1,a2=agents[i],agents[k]
        x=gc[gc.agent_id==a1][['case_id','error','verdict']].rename(columns={'error':'e1','verdict':'v1'})
        y=gc[gc.agent_id==a2][['case_id','error','verdict']].rename(columns={'error':'e2','verdict':'v2'})
        m=x.merge(y,on='case_id')
        pairs.append({'condition':cond,'agent_a':a1,'agent_b':a2,'n':len(m),'phi_error':phi(m.e1,m.e2),
                      'double_fault_rate':((m.e1==1)&(m.e2==1)).mean(),'verdict_disagreement_rate':(m.v1!=m.v2).mean()})
pairdf=pd.DataFrame(pairs); pairdf.to_csv(out/'pairwise_error_structure.csv',index=False)

system=[]; audits=[]
for cond,gc in j.groupby('condition'):
    piv=gc.pivot(index='case_id',columns='agent_id',values='verdict')
    truth=cases.set_index('case_id').human_label
    pred=[]
    for cid,row in piv.iterrows():
        vals=row.dropna().tolist(); final=pd.Series(vals).value_counts().index[0]; pred.append((cid,final,truth[cid]))
    d=pd.DataFrame(pred,columns=['case_id','majority_verdict','human_label']); d['error']=(d.majority_verdict!=d.human_label).astype(int)
    inv=d[d.human_label=='INVALID']; val=d[d.human_label=='VALID']
    mean_member_error=gc.groupby('agent_id').error.mean().mean()
    majority_error=d.error.mean()
    system.append({'condition':cond,'n_cases':len(d),'avg_member_error_rate':mean_member_error,'majority_error_rate':majority_error,
                   'collective_gain_vs_mean_member':mean_member_error-majority_error,
                   'majority_dangerous_miss_rate':(inv.majority_verdict=='VALID').mean() if len(inv) else np.nan,
                   'majority_false_block_rate':(val.majority_verdict=='INVALID').mean() if len(val) else np.nan,
                   'avg_pairwise_phi_error':pairdf[pairdf.condition==cond].phi_error.mean(),
                   'avg_pairwise_disagreement':pairdf[pairdf.condition==cond].verdict_disagreement_rate.mean(),
                   'avg_cost_per_member_case':gc.cost_unit.mean()})
    d['condition']=cond; audits.append(d)
pd.DataFrame(system).to_csv(out/'condition_summary.csv',index=False)
pd.concat(audits,ignore_index=True).to_csv(out/'case_audit.csv',index=False)

# Paired causal effect: divergent experience ON vs the same persistent identities with memory OFF.
on=j[j.condition=='C2_DivergentExperience'][['case_id','agent_id','verdict','error']].rename(columns={'verdict':'on_verdict','error':'on_error'})
off=j[j.condition=='C3_Divergent_MemoryOff'][['case_id','agent_id','verdict','error']].rename(columns={'verdict':'off_verdict','error':'off_error'})
m=on.merge(off,on=['case_id','agent_id']); m['changed']=(m.on_verdict!=m.off_verdict).astype(int); m['helpful_flip']=((m.off_error==1)&(m.on_error==0)).astype(int); m['harmful_flip']=((m.off_error==0)&(m.on_error==1)).astype(int)
m.to_csv(out/'memory_on_off_paired.csv',index=False)
summary=m.groupby('agent_id').agg(n=('case_id','size'),memory_dependence_rate=('changed','mean'),helpful_flip_rate=('helpful_flip','mean'),harmful_flip_rate=('harmful_flip','mean'),error_on=('on_error','mean'),error_off=('off_error','mean')).reset_index()
summary.to_csv(out/'memory_causal_effect.csv',index=False)
print(pd.read_csv(out/'condition_summary.csv').to_string(index=False))
