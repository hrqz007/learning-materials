#!/usr/bin/env python3
import argparse
from pathlib import Path
import pandas as pd
p=argparse.ArgumentParser(); p.add_argument('files',nargs='+'); p.add_argument('--out',required=True); a=p.parse_args()
d=pd.concat([pd.read_csv(x) for x in a.files],ignore_index=True)
if 'human_label' in d.columns:
    d['error']=(d.verdict.astype(str).str.upper()!=d.human_label.astype(str).str.upper()).astype(int)
Path(a.out).parent.mkdir(parents=True,exist_ok=True); d.to_csv(a.out,index=False); print(d.groupby('condition').size())
