# A13 Experience Card

- experience_id:
- source_episode / proposal_id:
- task_family: policy / evidence / parameter
- situation summary:
- observable evidence:
- proposed or executed action:
- outcome: VALID / INVALID / success / failure
- reusable lesson:
- quality flag: verified / uncertain / noisy
- provenance:

> Rule: an experience is a fallible historical record, not a new policy. Current policy and current observable evidence always dominate.
