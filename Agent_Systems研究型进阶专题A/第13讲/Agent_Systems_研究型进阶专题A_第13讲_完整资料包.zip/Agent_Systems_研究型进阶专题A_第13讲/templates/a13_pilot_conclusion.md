# A13 Pilot Conclusion Template

## 1. What is observed?
Report only what the data directly shows.

## 2. Did functional specialization emerge?
Include agent × task-family matrix and uncertainty / repeated-run stability.

## 3. Did error correlation change?
Compare Shared Memory vs Divergent Experience using pairwise phi, double-fault, and disagreement.

## 4. Did the group gain anything?
Compare fixed aggregation under matched member strength.

## 5. Did Memory-Off erase the effect?
Summarize paired Memory-On/Off helpful and harmful flips.

## 6. What is still uncertain?
Separate experience content, retrieval, ordering, and memory quality as possible mechanisms.

## 7. Go / No-Go
- GO: replicate on a second model / task split if the full chain is stable.
- NO-GO: if specialization is unstable, correlation does not fall, or Memory-Off does not remove the effect.
