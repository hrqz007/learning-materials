# A13 Trace Review

## Case
- case_id:
- task_family:
- human label:

## Agent / condition
- agent_id:
- condition: NoMemory / SharedMemory / DivergentExperience / MemoryOff
- retrieved experience ids:

## What changed?
- Memory-On verdict:
- Memory-Off verdict:
- same or changed?
- helpful flip / harmful flip / neutral change?

## Experience relevance
- Which retrieved experience was most influential?
- Was it truly analogous to the current case?
- What key policy/evidence/parameter matched?
- What key constraint differed?

## Mechanism hypothesis
- specialization / positive transfer / negative transfer / experience-following / retrieval miss / other:
- first bad span:
- alternative explanation:
