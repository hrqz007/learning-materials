# Trace 目录

这里用于保存第13讲真实实验的关键 case。

优先保存：
1. Divergent Experience 中多数票被错误去相关救回的 case；
2. Memory-On 正确、Memory-Off 错的 helpful flip；
3. Memory-On 把正确判断改错的 harmful flip（negative transfer）；
4. 三个 Agent 检索到高度相似 experience、但仍做出不同判断的反例。

不要把 Teaching Mock 的 trace 当真实科研证据。
