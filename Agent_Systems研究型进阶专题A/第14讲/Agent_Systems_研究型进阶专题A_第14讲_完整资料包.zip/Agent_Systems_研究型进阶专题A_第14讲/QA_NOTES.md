# QA Notes - 第14讲

## 已完成的功能 QA

- `src/00_dependency_check.py`：实际运行。
  - numpy / pandas / scipy：OK
  - litellm：当前资料制作环境未安装，因此真实 API runner **没有伪造执行**。
- `src/03_generate_teaching_mock.py`：实际运行，生成 180 cases / 5,940 judgments。
- `src/04_analyze_heterogeneity_dynamics.py`：实际运行，成功生成 checkpoint / specialization / pairwise / forgetting / Memory-Off 等分析表。
- 所有 `src/*.py`：`py_compile` 通过。
- A13 → A14 bridge：实际使用第13讲 `experience_pool.jsonl` 与 `eval_cases.jsonl` 测试。
  - policy/evidence/parameter 各 10 条 experience。
  - 0/5/10 checkpoint 成功建立。
  - 20/40 checkpoint 正确返回 `SKIP_NOT_ENOUGH_EXPERIENCE`，未重复旧记录凑数。

## 已完成的文档 QA

最终 DOCX 渲染页数：

- 01_零基础讲义.docx：6 页
- 03_实验指导书.docx：2 页
- 04_实验设计书.docx：2 页
- 05_练习题.docx：1 页
- 06_练习题答案.docx：1 页
- 07_术语速查表.docx：1 页

共 13 页，全部实际渲染检查。

中间发现并修复：

1. 实验设计书原第3页只剩单个 callout 的尾页；压缩排版后为 2 页。
2. 术语表原第2页只剩最后一个术语；缩小表格 padding/font 后为 1 页。

讲义 PDF：6 页，使用独立 PDF renderer 再次逐页检查。

最终检查未发现：

- 文字裁切
- 表格越界
- 图形重叠
- 中文缺字
- 页脚错号
- 空白异常页

## Teaching Mock 边界

Teaching Mock 的所有数值均为合成数据，只验证教学逻辑和分析代码，不代表任何商业或开源模型的真实能力。
