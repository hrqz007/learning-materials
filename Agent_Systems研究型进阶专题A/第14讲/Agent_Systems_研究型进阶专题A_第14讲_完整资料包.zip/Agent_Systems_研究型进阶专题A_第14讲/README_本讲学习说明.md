# Agent Systems 研究型进阶专题 A · 第14讲

## 主题

**异质性是怎样长出来的？—— Longitudinal Formation of Functional Heterogeneity**

本讲直接承接第13讲的 Experience-Induced Heterogeneity，但把“最终状态比较”升级为纵向 checkpoint 实验：

`0 → 5 → 10 → 20 → 40 episodes`

重点同时跟踪：

- individual / family accuracy
- specialization index
- pairwise error correlation
- fixed-majority collective gain
- retention / forgetting
- negative transfer
- Memory-On / Memory-Off causal dependence

## 建议学习顺序

1. `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 先运行 `src/00_dependency_check.py`
4. 用第13讲数据运行 `src/01_prepare_from_a13.py`
5. 运行 `src/02_build_checkpoint_banks.py`
6. 先完整跑 Teaching Mock：`03_generate_teaching_mock.py` + `04_analyze_heterogeneity_dynamics.py`
7. 填写 `templates/a14_growth_card.md`
8. 再做真实 API 的 0/5/10 smoke test
9. 只有出现稳定纵向信号后，再投入成本收集 20/40 episode

## 最重要的实验纪律

- checkpoint 必须 cumulative，不能换一批完全不同的经验冒充“成长”。
- 所有 checkpoint 必须用同一 held-out evaluation。
- 模型版本、prompt、role、tools、temperature、retrieval top-k 必须冻结。
- 第13讲桥接数据每个 family 只有 10 条经验，因此本包会诚实地只建立 0/5/10 checkpoint；不会重复旧 experience 凑 20/40。
- `operational_onset.csv` 中的阈值只是课程教学诊断标准，不是论文可直接照搬的科学规律。
- Teaching Mock 是合成数据，绝不能当作真实模型性能。

## Teaching Mock 的用途

Teaching Mock 共 180 个固定 held-out cases，生成 5,940 条判断，故意构造了一个非单调过程：Divergent Experience 在 checkpoint 20 附近出现最明显的 error decorrelation 与 fixed-majority gain，但 checkpoint 40 出现部分 retention drop / negative transfer，提醒你“更多经验”不一定单调更好。

## 近期研究背景

- Xiong et al., *How Memory Management Impacts LLM Agents: An Empirical Study of Experience-Following Behavior*, ACL 2026.
- Zhao et al., *Large Language Model Agents Are Not Always Faithful Self-Evolvers*, ICML 2026.
- Qiu et al., *LifeMem: Enabling Lifelong Experience Reuse for LLM Agents*, arXiv:2609.12655, 2026.
- Luo et al., *From Storage to Experience: A Survey on the Evolution of LLM Agent Memory Mechanisms*, Findings of ACL 2026.
- Su et al., *Mistake Notebook Learning: Batch-Clustered Failures for Training-Free Agent Adaptation*, Findings of ACL 2026.

这些工作支持“长期经验的复用、顺序、管理、遗忘与因果依赖值得研究”，但并不直接证明本讲的完整链条：

`Experience Dose → Functional Heterogeneity → Error Decorrelation → Collective Gain`

这条链必须由你自己的受控实验验证。
