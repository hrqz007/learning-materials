Lesson-14 Teaching Mock metrics. operational_onset is a course-defined diagnostic threshold, not a scientific law.
First checkpoint meeting all teaching criteria: 20
