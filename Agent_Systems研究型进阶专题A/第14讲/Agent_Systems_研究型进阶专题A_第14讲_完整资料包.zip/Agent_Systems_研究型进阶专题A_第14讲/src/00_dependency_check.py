#!/usr/bin/env python3
"""Dependency check for Lesson 14.
Teaching Mock: numpy, pandas, scipy. Real API runner: litellm."""
mods = ["numpy", "pandas", "scipy"]
for m in mods:
    try:
        mod = __import__(m)
        print(f"[OK] {m} {getattr(mod, '__version__', '')}")
    except Exception as e:
        print(f"[MISSING] {m}: {e}")
try:
    import litellm
    print(f"[OK] litellm {getattr(litellm, '__version__', '')}")
except Exception as e:
    print(f"[OPTIONAL-MISSING] litellm: {e}")
