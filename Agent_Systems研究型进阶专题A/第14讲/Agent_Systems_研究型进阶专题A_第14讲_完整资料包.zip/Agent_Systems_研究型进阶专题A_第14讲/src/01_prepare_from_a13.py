#!/usr/bin/env python3
"""Convert Lesson-13 experience_pool/eval_cases into longitudinal streams.
The bridge NEVER fabricates additional experiences. If a requested checkpoint exceeds
available family-specific experience, it is reported as unavailable rather than repeated.
"""
import argparse, json
from pathlib import Path
from collections import defaultdict

FAMILY_TO_AGENT = {"policy":"agent_P", "evidence":"agent_E", "parameter":"agent_R"}

def read_jsonl(p):
    return [json.loads(x) for x in Path(p).read_text(encoding="utf-8").splitlines() if x.strip()]

def write_jsonl(p, rows):
    Path(p).parent.mkdir(parents=True, exist_ok=True)
    Path(p).write_text("\n".join(json.dumps(r, ensure_ascii=False) for r in rows)+("\n" if rows else ""), encoding="utf-8")

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--experience-pool', required=True)
    ap.add_argument('--eval-cases', required=True)
    ap.add_argument('--out-dir', required=True)
    ap.add_argument('--checkpoints', default='0,5,10,20,40')
    args=ap.parse_args()
    out=Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    exp=read_jsonl(args.experience_pool); ev=read_jsonl(args.eval_cases)
    by=defaultdict(list)
    for r in exp:
        fam=r.get('task_family') or r.get('error_family')
        if fam in FAMILY_TO_AGENT:
            by[fam].append(r)
    for fam, agent in FAMILY_TO_AGENT.items():
        rows=[]
        for i,r in enumerate(by[fam],1):
            x=dict(r); x['experience_index']=i; x['assigned_agent']=agent
            rows.append(x)
        write_jsonl(out/f'{agent}_stream.jsonl', rows)
    write_jsonl(out/'heldout_eval_cases.jsonl', ev)
    requested=[int(x) for x in args.checkpoints.split(',') if x.strip()]
    avail={fam:len(by[fam]) for fam in FAMILY_TO_AGENT}
    max_bal=min(avail.values()) if avail else 0
    available=[k for k in requested if k==0 or k<=max_bal]
    unavailable=[k for k in requested if k>max_bal]
    manifest={"requested_checkpoints":requested,"available_checkpoints":available,
              "unavailable_checkpoints":unavailable,"family_counts":avail,
              "note":"Bridge does not repeat experience records. Collect more real episodes before 20/40 if unavailable."}
    (out/'bridge_manifest.json').write_text(json.dumps(manifest,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
