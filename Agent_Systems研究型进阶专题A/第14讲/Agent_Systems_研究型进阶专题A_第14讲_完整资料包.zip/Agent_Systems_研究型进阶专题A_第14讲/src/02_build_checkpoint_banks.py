#!/usr/bin/env python3
"""Build cumulative experience-bank snapshots at requested checkpoints."""
import argparse, json
from pathlib import Path

def read_jsonl(p):
    p=Path(p)
    if not p.exists(): return []
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def write_jsonl(p, rows):
    Path(p).parent.mkdir(parents=True,exist_ok=True)
    Path(p).write_text('\n'.join(json.dumps(r,ensure_ascii=False) for r in rows)+('\n' if rows else ''),encoding='utf-8')

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--streams-dir',required=True)
    ap.add_argument('--out-dir',required=True)
    ap.add_argument('--checkpoints',default='0,5,10,20,40')
    args=ap.parse_args()
    sdir=Path(args.streams_dir); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    cps=[int(x) for x in args.checkpoints.split(',') if x.strip()]
    agents=['agent_P','agent_E','agent_R']
    report=[]
    streams={a:read_jsonl(sdir/f'{a}_stream.jsonl') for a in agents}
    for cp in cps:
        for a in agents:
            if cp>len(streams[a]):
                report.append({"agent":a,"checkpoint":cp,"status":"SKIP_NOT_ENOUGH_EXPERIENCE","available":len(streams[a])})
                continue
            write_jsonl(out/f'cp_{cp}'/f'{a}_bank.jsonl',streams[a][:cp])
            report.append({"agent":a,"checkpoint":cp,"status":"OK","available":len(streams[a])})
    (out/'checkpoint_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    ok=sum(r['status']=='OK' for r in report)
    print(f'Built {ok} agent-checkpoint banks. See checkpoint_report.json')
if __name__=='__main__': main()
