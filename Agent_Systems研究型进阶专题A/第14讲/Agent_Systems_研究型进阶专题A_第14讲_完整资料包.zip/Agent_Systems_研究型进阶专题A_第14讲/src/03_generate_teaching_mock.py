#!/usr/bin/env python3
"""Generate a deterministic longitudinal Teaching Mock.
This is synthetic data only; it must never be reported as real model performance.
"""
import argparse
from pathlib import Path
import numpy as np, pandas as pd
from scipy.stats import norm

AGENTS=['agent_P','agent_E','agent_R']
FAMILIES=['policy','evidence','parameter']
OWN={'agent_P':'policy','agent_E':'evidence','agent_R':'parameter'}
CHECKPOINTS=[0,5,10,20,40]

SHARED_P={0:.225,5:.190,10:.170,20:.150,40:.145}
SHARED_RHO={0:.08,5:.12,10:.18,20:.23,40:.28}
DIV_OWN={0:.225,5:.160,10:.105,20:.055,40:.080}
DIV_OFF={0:.225,5:.205,10:.190,20:.180,40:.235}
DIV_RHO={0:.08,5:.03,10:-.05,20:-.10,40:.02}

def corrmat(rho):
    m=np.full((3,3),rho,float); np.fill_diagonal(m,1.0); return m

def make_errors(rng, n, ps, rho):
    z=rng.multivariate_normal(np.zeros(3),corrmat(rho),size=n)
    thr=np.array([norm.ppf(max(1e-6,min(.999999,p))) for p in ps])
    return z < thr

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out-dir',required=True); ap.add_argument('--seed',type=int,default=14014)
    args=ap.parse_args(); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    rng=np.random.default_rng(args.seed)
    cases=[]
    for fam in FAMILIES:
        prefix={'policy':'pol','evidence':'evi','parameter':'par'}[fam]
        for i in range(60):
            cid=f'{prefix}_{i:03d}'
            truth='INVALID' if (i%2==0) else 'VALID'
            cases.append({"case_id":cid,"task_family":fam,"truth":truth,"retention_probe": i<20,"risk":"high" if i%4==0 else "normal"})
    cdf=pd.DataFrame(cases); cdf.to_csv(out/'cases.csv',index=False)
    rows=[]
    # shared/divergent; checkpoint 0 uses identical latent draw so baseline is exactly matched.
    base_err_by_fam={}
    for fam in FAMILIES:
        idx=cdf.index[cdf.task_family.eq(fam)].tolist(); n=len(idx)
        base_err_by_fam[fam]=make_errors(rng,n,[.225]*3,.08)
    for regime in ['shared','divergent']:
        for cp in CHECKPOINTS:
            for fam in FAMILIES:
                subset=cdf[cdf.task_family.eq(fam)].reset_index(drop=True); n=len(subset)
                if cp==0:
                    errs=base_err_by_fam[fam]
                else:
                    if regime=='shared':
                        ps=[SHARED_P[cp]]*3; rho=SHARED_RHO[cp]
                    else:
                        ps=[DIV_OWN[cp] if OWN[a]==fam else DIV_OFF[cp] for a in AGENTS]; rho=DIV_RHO[cp]
                    errs=make_errors(rng,n,ps,rho)
                for j,row in subset.iterrows():
                    for ai,a in enumerate(AGENTS):
                        err=bool(errs[j,ai]); truth=row.truth
                        pred=('VALID' if truth=='INVALID' else 'INVALID') if err else truth
                        rows.append({"condition":regime,"checkpoint":cp,"experience_count":cp,"agent_id":a,
                                     "case_id":row.case_id,"task_family":fam,"truth":truth,"prediction":pred,
                                     "error":int(err),"retention_probe":bool(row.retention_probe),"risk":row.risk})
    # Memory-Off at checkpoint 40 = exact baseline behavior, paired case by case.
    base=pd.DataFrame(rows); base=base[(base.condition=='divergent')&(base.checkpoint==0)].copy()
    base['condition']='memory_off'; base['checkpoint']=40; base['experience_count']=40
    rows.extend(base.to_dict('records'))
    jdf=pd.DataFrame(rows); jdf.to_csv(out/'judgments.csv',index=False)
    print(f'Wrote {len(cdf)} cases and {len(jdf)} judgments to {out}')
if __name__=='__main__': main()
