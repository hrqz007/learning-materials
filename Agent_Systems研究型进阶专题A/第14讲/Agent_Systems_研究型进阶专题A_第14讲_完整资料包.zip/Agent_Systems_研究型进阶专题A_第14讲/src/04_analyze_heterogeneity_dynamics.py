#!/usr/bin/env python3
"""Analyze longitudinal specialization, error correlation, collective gain, forgetting and transfer."""
import argparse, math
from pathlib import Path
import numpy as np, pandas as pd
AGENTS=['agent_P','agent_E','agent_R']
OWN={'agent_P':'policy','agent_E':'evidence','agent_R':'parameter'}

def phi(x,y):
    x=np.asarray(x,dtype=int); y=np.asarray(y,dtype=int)
    if x.std()==0 or y.std()==0: return np.nan
    return float(np.corrcoef(x,y)[0,1])

def majority_error(g):
    # all rows for one case, 3 agents
    votes=(g['prediction']=='INVALID').sum()
    pred='INVALID' if votes>=2 else 'VALID'
    return int(pred!=g['truth'].iloc[0])

def disagreement(g):
    vals=g['prediction'].tolist(); n=len(vals)
    pairs=0; diff=0
    for i in range(n):
        for j in range(i+1,n):
            pairs+=1; diff+=vals[i]!=vals[j]
    return diff/pairs if pairs else 0.0

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--judgments',required=True); ap.add_argument('--out-dir',required=True)
    args=ap.parse_args(); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
    df=pd.read_csv(args.judgments)
    # Member-family matrix
    m=(df.groupby(['condition','checkpoint','agent_id','task_family'])['error'].mean().reset_index())
    m['accuracy']=1-m['error']; m.to_csv(out/'member_family_matrix.csv',index=False)
    # Pairwise error structure
    prs=[]
    for (cond,cp),g in df.groupby(['condition','checkpoint']):
        wide=g.pivot_table(index='case_id',columns='agent_id',values='error',aggfunc='first')
        for i,a in enumerate(AGENTS):
            for b in AGENTS[i+1:]:
                if a in wide and b in wide:
                    ea=wide[a].astype(int); eb=wide[b].astype(int)
                    prs.append({"condition":cond,"checkpoint":cp,"agent_a":a,"agent_b":b,"phi":phi(ea,eb),
                                "double_fault":float(((ea==1)&(eb==1)).mean())})
    p=pd.DataFrame(prs); p.to_csv(out/'pairwise_error_structure.csv',index=False)
    # Specialization dynamics
    specs=[]
    for (cond,cp,a),g in m.groupby(['condition','checkpoint','agent_id']):
        own=OWN[a]
        own_acc=float(g.loc[g.task_family.eq(own),'accuracy'].iloc[0]) if (g.task_family==own).any() else np.nan
        other=float(g.loc[~g.task_family.eq(own),'accuracy'].mean())
        specs.append({"condition":cond,"checkpoint":cp,"agent_id":a,"own_family_accuracy":own_acc,
                      "other_family_accuracy":other,"specialization_index":own_acc-other})
    s=pd.DataFrame(specs); s.to_csv(out/'specialization_dynamics.csv',index=False)
    # Condition/checkpoint summary + collective metrics
    sums=[]; audits=[]
    for (cond,cp),g in df.groupby(['condition','checkpoint']):
        case=[]
        for cid,cg in g.groupby('case_id'):
            me=majority_error(cg); dis=disagreement(cg)
            case.append((cid,me,dis))
            audits.append({"condition":cond,"checkpoint":cp,"case_id":cid,"task_family":cg.task_family.iloc[0],
                           "majority_error":me,"disagreement":dis,"member_errors":int(cg.error.sum())})
        mean_member=float(g.error.mean()); maj=float(np.mean([x[1] for x in case])); dis=float(np.mean([x[2] for x in case]))
        pg=p[(p.condition==cond)&(p.checkpoint==cp)]
        avg_phi=float(pg.phi.mean()) if len(pg) else np.nan
        si=s[(s.condition==cond)&(s.checkpoint==cp)].specialization_index.mean()
        sums.append({"condition":cond,"checkpoint":cp,"mean_member_error":mean_member,"majority_error":maj,
                     "collective_gain":mean_member-maj,"mean_disagreement":dis,"mean_pairwise_phi":avg_phi,
                     "mean_specialization_index":float(si)})
    summary=pd.DataFrame(sums).sort_values(['condition','checkpoint']); summary.to_csv(out/'checkpoint_summary.csv',index=False)
    pd.DataFrame(audits).to_csv(out/'case_audit.csv',index=False)
    # Forgetting / negative transfer (divergent only): compare checkpoint 40 to peak and baseline.
    d=s[s.condition=='divergent'].copy(); ft=[]
    for a,g in d.groupby('agent_id'):
        g=g.sort_values('checkpoint'); base=g[g.checkpoint==0].iloc[0]; last=g[g.checkpoint==40].iloc[0]
        peak_own=float(g.own_family_accuracy.max()); peak_cp=int(g.loc[g.own_family_accuracy.idxmax(),'checkpoint'])
        ft.append({"agent_id":a,"peak_own_accuracy":peak_own,"peak_checkpoint":peak_cp,
                   "own_accuracy_cp40":float(last.own_family_accuracy),"retention_drop":peak_own-float(last.own_family_accuracy),
                   "off_family_accuracy_cp0":float(base.other_family_accuracy),"off_family_accuracy_cp40":float(last.other_family_accuracy),
                   "negative_transfer_delta":float(last.other_family_accuracy-base.other_family_accuracy)})
    pd.DataFrame(ft).to_csv(out/'forgetting_transfer.csv',index=False)
    # Memory-off paired causal check at cp40
    on=df[(df.condition=='divergent')&(df.checkpoint==40)][['case_id','agent_id','error','prediction']].rename(columns={'error':'error_on','prediction':'pred_on'})
    off=df[(df.condition=='memory_off')&(df.checkpoint==40)][['case_id','agent_id','error','prediction']].rename(columns={'error':'error_off','prediction':'pred_off'})
    pair=on.merge(off,on=['case_id','agent_id'])
    pair['changed']=(pair.pred_on!=pair.pred_off).astype(int)
    pair['helpful_flip']=((pair.error_off==1)&(pair.error_on==0)).astype(int)
    pair['harmful_flip']=((pair.error_off==0)&(pair.error_on==1)).astype(int)
    pair.to_csv(out/'memory_on_off_paired.csv',index=False)
    causal=pd.DataFrame([{"changed_rate":pair.changed.mean(),"helpful_flip_rate":pair.helpful_flip.mean(),"harmful_flip_rate":pair.harmful_flip.mean()}])
    causal.to_csv(out/'memory_causal_effect.csv',index=False)
    # Teaching operational onset: first cp where divergence SI>=.08, phi at least .05 lower than shared same cp, and majority error lower.
    onset=[]
    sh=summary[summary.condition=='shared'].set_index('checkpoint'); dv=summary[summary.condition=='divergent'].set_index('checkpoint')
    for cp in sorted(set(sh.index)&set(dv.index)):
        criteria={"si_ge_008":dv.loc[cp,'mean_specialization_index']>=.08,
                  "phi_reduced_005":dv.loc[cp,'mean_pairwise_phi']<=sh.loc[cp,'mean_pairwise_phi']-.05,
                  "majority_better":dv.loc[cp,'majority_error']<sh.loc[cp,'majority_error']}
        onset.append({"checkpoint":cp,**criteria,"all_met":all(criteria.values())})
    onset_df=pd.DataFrame(onset); onset_df.to_csv(out/'operational_onset.csv',index=False)
    met=onset_df[onset_df.all_met]
    first=int(met.checkpoint.iloc[0]) if len(met) else None
    (out/'README_METRICS.txt').write_text(
        'Lesson-14 Teaching Mock metrics. operational_onset is a course-defined diagnostic threshold, not a scientific law.\n'
        f'First checkpoint meeting all teaching criteria: {first}\n',encoding='utf-8')
    print(summary.to_string(index=False))
    print('\nOperational onset:',first)
if __name__=='__main__': main()
