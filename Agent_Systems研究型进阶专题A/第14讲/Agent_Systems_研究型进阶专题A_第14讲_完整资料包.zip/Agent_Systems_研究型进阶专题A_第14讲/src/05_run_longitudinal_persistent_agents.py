#!/usr/bin/env python3
"""Real-API longitudinal runner for Lesson 14.
Requires litellm and user API credentials. Uses the SAME model/prompt/tools for all agents.
Only experience-bank contents differ. This script deliberately avoids fine-tuning.
"""
import argparse, json, os, time
from pathlib import Path
import pandas as pd

def read_jsonl(p):
    p=Path(p)
    if not p.exists(): return []
    return [json.loads(x) for x in p.read_text(encoding='utf-8').splitlines() if x.strip()]

def compact_exp(bank, max_items=40):
    bank=bank[-max_items:]
    out=[]
    for r in bank:
        out.append({k:r.get(k) for k in ['proposal_id','task_family','human_label','candidate_tool','candidate_arguments','policy','history'] if k in r})
    return out

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--eval-cases',required=True); ap.add_argument('--banks-root',required=True)
    ap.add_argument('--model',required=True); ap.add_argument('--out',required=True)
    ap.add_argument('--checkpoints',default='0,5,10,20,40'); ap.add_argument('--limit',type=int,default=None)
    ap.add_argument('--temperature',type=float,default=0.0)
    args=ap.parse_args()
    try:
        from litellm import completion
    except Exception as e:
        raise SystemExit(f'litellm is required for real API run: {e}')
    cases=read_jsonl(args.eval_cases)
    if args.limit: cases=cases[:args.limit]
    cps=[int(x) for x in args.checkpoints.split(',') if x.strip()]
    agents=['agent_P','agent_E','agent_R']; rows=[]
    system=("You are a reviewer of a proposed WRITE action. Judge only from the supplied policy, history, action, and past experience. "
            "Return JSON only: {\"verdict\":\"VALID|INVALID\",\"confidence\":0..1,\"reason\":\"...\",\"used_experience_ids\":[...]}.")
    for cp in cps:
        for a in agents:
            bank=read_jsonl(Path(args.banks_root)/f'cp_{cp}'/f'{a}_bank.jsonl') if cp>0 else []
            if cp>0 and len(bank)<cp:
                print(f'[SKIP] {a} cp={cp}: bank not available'); continue
            mem=compact_exp(bank)
            for case in cases:
                user={"policy":case.get('policy'),"history":case.get('history'),"candidate_tool":case.get('candidate_tool'),
                      "candidate_arguments":case.get('candidate_arguments'),"past_experience":mem}
                t=time.time()
                resp=completion(model=args.model,temperature=args.temperature,
                                messages=[{"role":"system","content":system},{"role":"user","content":json.dumps(user,ensure_ascii=False)}],
                                response_format={"type":"json_object"})
                txt=resp.choices[0].message.content; data=json.loads(txt)
                rows.append({"condition":"divergent","checkpoint":cp,"agent_id":a,"case_id":case.get('proposal_id') or case.get('case_id'),
                             "task_family":case.get('task_family'),"truth":case.get('human_label'),"prediction":data.get('verdict'),
                             "confidence":data.get('confidence'),"reason":data.get('reason'),"used_experience_ids":json.dumps(data.get('used_experience_ids',[])),
                             "latency_s":time.time()-t,"model":args.model})
    pd.DataFrame(rows).to_csv(args.out,index=False)
    print(f'Wrote {len(rows)} real judgments to {args.out}')
if __name__=='__main__': main()
