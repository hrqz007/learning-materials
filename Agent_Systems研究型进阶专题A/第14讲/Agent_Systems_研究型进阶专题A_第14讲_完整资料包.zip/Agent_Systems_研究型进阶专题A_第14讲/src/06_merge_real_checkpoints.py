#!/usr/bin/env python3
"""Normalize one or more real runner CSVs into the analyzer schema."""
import argparse
from pathlib import Path
import pandas as pd

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('csvs',nargs='+'); ap.add_argument('--out',required=True)
    args=ap.parse_args(); dfs=[]
    for p in args.csvs:
        d=pd.read_csv(p)
        if 'error' not in d:
            d['error']=(d['prediction']!=d['truth']).astype(int)
        if 'experience_count' not in d: d['experience_count']=d['checkpoint']
        if 'retention_probe' not in d: d['retention_probe']=False
        if 'risk' not in d: d['risk']='unknown'
        dfs.append(d)
    out=pd.concat(dfs,ignore_index=True); Path(args.out).parent.mkdir(parents=True,exist_ok=True); out.to_csv(args.out,index=False)
    print(f'Wrote {len(out)} rows to {args.out}')
if __name__=='__main__': main()
