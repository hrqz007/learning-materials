# A14 Experience-Growth Card

- Agent ID:
- Base model / version:
- System prompt hash:
- Tool schema hash:
- Retrieval config:
- Stream family:
- Checkpoint: 0 / 5 / 10 / 20 / 40
- Number of unique experience records:
- Experience IDs added since previous checkpoint:
- Own-family accuracy:
- Off-family accuracy:
- Specialization index:
- Pairwise error correlation vs peers:
- Majority outcome:
- Retention probe accuracy:
- Negative-transfer signal:
- Notes / anomalies:
