# A14 Pilot Conclusion

## 1. Dose-response
At which checkpoint did individual accuracy improve most? Did later experience still help?

## 2. Heterogeneity formation
When did specialization index become non-trivial? Was the pattern stable across families/seeds?

## 3. Error structure
Did pairwise error correlation decrease before, after, or at the same time as specialization?

## 4. Collective gain
Did lower correlation translate into lower fixed-majority error?

## 5. Long-term costs
Was there negative transfer, retention loss, memory saturation, or retrieval interference at larger checkpoints?

## 6. Causal evidence
Did Memory-Off at the final checkpoint reverse part of the effect? Were changes linked to actually retrieved experiences?

## 7. Decision
Continue / redesign / stop. State exactly which observation justifies the decision.
