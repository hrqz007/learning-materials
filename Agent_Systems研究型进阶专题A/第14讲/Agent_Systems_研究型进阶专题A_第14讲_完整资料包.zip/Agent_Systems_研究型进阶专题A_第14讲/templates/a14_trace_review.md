# A14 Longitudinal Trace Review

Case ID:
Task family:
Agent:
Checkpoint:
Retrieved experience IDs:
Prediction:
Ground truth:

## Compare against previous checkpoint
- What new experiences entered the bank?
- Did the prediction change?
- If changed, is the new behavior plausibly linked to retrieved experience?
- Helpful flip / harmful flip / unchanged?
- Was an old useful experience crowded out?
- Is there evidence of retrieval interference or error propagation?

## Causal caution
State only what the trace supports. A temporal association between more experience and a behavior change is not by itself causal proof.
