# Trace review folder

Put selected real traces here, especially:
1. first checkpoint where an agent changes behavior;
2. cases where specialization appears;
3. cases where pairwise errors decorrelate;
4. checkpoint-40 failures that were correct at checkpoint 20 (forgetting/interference candidates);
5. Memory-On vs Memory-Off paired reversals.
