# QA Notes

- Teaching Mock generated and analyzed by executable scripts.
- A14 cp10 bridge tested successfully.
- A14 bundled bridge example does not contain cp20; the bridge script correctly refuses to fabricate it.
- Real API runner is a reference skeleton and was not executed against commercial APIs in the artifact-building environment.
- DOCX/PDF render QA is performed after generation.
- Final script compileall: PASS.
- Round-0 paired-baseline assertion across all protocols: PASS.
- A14 cp20 missing-checkpoint refusal: PASS.
- Equal memory-budget manifest assertion across sharing forks: PASS.
- All six DOCX files rendered and visually inspected page by page: PASS (12 pages total).
- Lecture PDF independently converted, rendered, and visually inspected page by page: PASS (5 pages).
