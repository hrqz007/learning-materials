# Agent Systems 研究型进阶专题 A · 第15讲

## 主题
Experience Sharing → Heterogeneity Stability / Collapse

## 本讲承接
- 第13讲：不同长期经历能否形成 Agent 功能性异质性。
- 第14讲：异质性如何随 experience dose 形成、达到峰值或发生 negative transfer。
- 第15讲：形成以后，一旦 Agents 开始分享 memory / experience，这些差异会保持、扩散还是塌缩？

## 推荐学习顺序
1. 先读 `02_零基础讲义.pdf`。
2. 运行 Teaching Mock，理解 transfer vs erosion vs error re-coupling。
3. 阅读实验设计书，确认控制变量。
4. 若你已有真实 A14 checkpoint，使用 `01_prepare_from_a14.py` 冻结起点。
5. 先做 6–10 case smoke test，再跑真实 protocol ablation。

## 关键边界
Teaching Mock 是人为合成数据，不代表任何真实模型。真实实验必须使用真正独立的 experience records；不得复制旧 experience 凑分享轮次或 checkpoint。
