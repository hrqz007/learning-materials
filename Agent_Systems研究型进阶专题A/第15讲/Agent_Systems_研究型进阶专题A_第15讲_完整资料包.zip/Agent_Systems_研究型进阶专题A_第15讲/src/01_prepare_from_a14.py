#!/usr/bin/env python3
"""Freeze one A14 checkpoint and prepare identical starting state for A15 sharing forks.
This script NEVER fabricates missing checkpoints or duplicates experience records.
"""
from pathlib import Path
import argparse, json, shutil

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--a14-root', required=True)
    ap.add_argument('--checkpoint', type=int, required=True)
    ap.add_argument('--out', required=True)
    args=ap.parse_args()
    root=Path(args.a14_root); cp=root/'data'/'a13_bridge_example'/'checkpoints'/f'cp_{args.checkpoint}'
    held=root/'data'/'a13_bridge_example'/'heldout_eval_cases.jsonl'
    if not cp.exists():
        raise SystemExit(f'CHECKPOINT_NOT_AVAILABLE: {cp}. Collect genuinely new experience; do not duplicate old records.')
    required=[cp/f'agent_{a}_bank.jsonl' for a in ['P','E','R']]
    miss=[str(p) for p in required if not p.exists()]
    if miss: raise SystemExit('Missing bank(s): '+', '.join(miss))
    out=Path(args.out); out.mkdir(parents=True, exist_ok=True)
    for p in required: shutil.copy2(p, out/p.name)
    if held.exists(): shutil.copy2(held, out/held.name)
    manifest={'source':str(root),'checkpoint':args.checkpoint,'banks':[p.name for p in required],
              'heldout':held.name if held.exists() else None,'note':'Frozen identical start state for all A15 protocols.'}
    (out/'frozen_start_manifest.json').write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8')
    print(json.dumps(manifest,ensure_ascii=False))
if __name__=='__main__': main()
