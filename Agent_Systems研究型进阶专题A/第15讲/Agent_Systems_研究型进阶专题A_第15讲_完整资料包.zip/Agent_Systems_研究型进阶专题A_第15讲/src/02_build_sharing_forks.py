#!/usr/bin/env python3
"""Create protocol manifests from one frozen starting state. No model calls."""
from pathlib import Path
import argparse, json, shutil
PROTOCOLS={
 'private_only': {'sharing':'none','local_quota':1.0,'incoming_policy':'none'},
 'full_pool': {'sharing':'all-to-all','local_quota':0.34,'incoming_policy':'all accepted'},
 'periodic_exchange': {'sharing':'pairwise periodic','local_quota':0.67,'incoming_policy':'round-robin peer samples'},
 'diversity_guard': {'sharing':'selective','local_quota':0.67,'incoming_policy':'high-quality, cross-specialty, provenance-preserving, novelty-gated'},
}
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--frozen-start',required=True); ap.add_argument('--out',required=True); ap.add_argument('--memory-budget',type=int,default=20); args=ap.parse_args()
 start=Path(args.frozen_start); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
 if not (start/'frozen_start_manifest.json').exists(): raise SystemExit('frozen_start_manifest.json missing')
 for name,cfg in PROTOCOLS.items():
   d=out/name; d.mkdir(exist_ok=True)
   for f in start.glob('agent_*_bank.jsonl'): shutil.copy2(f,d/f.name)
   m={'protocol':name,'memory_budget_per_agent':args.memory_budget,**cfg,
      'control':'same agents, same start memory, same held-out evaluation, same budget; only sharing policy changes'}
   (d/'protocol_manifest.json').write_text(json.dumps(m,indent=2,ensure_ascii=False),encoding='utf-8')
 print('created',len(PROTOCOLS),'protocol forks in',out)
if __name__=='__main__': main()
