#!/usr/bin/env python3
from pathlib import Path
import argparse, random, csv
FAMS=['policy','evidence','parameter']; AGENTS=['P','E','R']; SPECIAL={'P':'policy','E':'evidence','R':'parameter'}
ROUNDS=[0,1,2,4]
PROT=['private_only','full_pool','periodic_exchange','diversity_guard']
# (specialty error, off-specialty error, shared wrong latent)
PARAM={
 'private_only': {0:(.08,.20,.035),1:(.08,.20,.035),2:(.08,.20,.035),4:(.08,.20,.035)},
 'full_pool': {0:(.08,.20,.035),1:(.095,.17,.07),2:(.12,.15,.12),4:(.155,.135,.19)},
 'periodic_exchange': {0:(.08,.20,.035),1:(.09,.18,.05),2:(.10,.165,.07),4:(.115,.15,.095)},
 'diversity_guard': {0:(.08,.20,.035),1:(.075,.175,.04),2:(.078,.155,.045),4:(.08,.14,.05)},
}
OVERLAP={
 'private_only':{0:.12,1:.12,2:.12,4:.12},
 'full_pool':{0:.12,1:.42,2:.69,4:.91},
 'periodic_exchange':{0:.12,1:.28,2:.43,4:.61},
 'diversity_guard':{0:.12,1:.22,2:.29,4:.36},
}
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--out',required=True); ap.add_argument('--seed',type=int,default=1515); ap.add_argument('--cases-per-family',type=int,default=40); args=ap.parse_args()
 rng=random.Random(args.seed); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
 cases=[]
 for fam in FAMS:
  for i in range(args.cases_per_family): cases.append({'case_id':f'{fam[:3]}_{i:03d}','family':fam,'truth': 'VALID' if i%2==0 else 'INVALID'})
 with (out/'cases.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=cases[0].keys()); w.writeheader(); w.writerows(cases)
 rows=[]
 # Round 0 is generated ONCE and copied to every protocol: a true frozen paired baseline.
 base_rows=[]
 sp,off,shared=PARAM['private_only'][0]
 for c in cases:
  shock = rng.random() < shared
  shock_wrong = rng.choice([True, False]) if shock else False
  for a in AGENTS:
   p = sp if SPECIAL[a]==c['family'] else off
   err = shock_wrong or (rng.random() < p)
   pred = ('INVALID' if c['truth']=='VALID' else 'VALID') if err else c['truth']
   base_rows.append({'case_id':c['case_id'],'family':c['family'],'agent':a,'specialty':SPECIAL[a],
                     'truth':c['truth'],'prediction':pred,'error':int(pred!=c['truth'])})
 for prot in PROT:
  for b in base_rows:
   rows.append({'protocol':prot,'round':0,**b,'memory_overlap':OVERLAP[prot][0]})
  for rd in [1,2,4]:
   sp,off,shared=PARAM[prot][rd]
   for c in cases:
    shock = rng.random() < shared
    shock_wrong = rng.choice([True, False]) if shock else False
    for a in AGENTS:
      p = sp if SPECIAL[a]==c['family'] else off
      err = shock_wrong or (rng.random() < p)
      pred = ('INVALID' if c['truth']=='VALID' else 'VALID') if err else c['truth']
      rows.append({'protocol':prot,'round':rd,'case_id':c['case_id'],'family':c['family'],'agent':a,'specialty':SPECIAL[a],
                   'truth':c['truth'],'prediction':pred,'error':int(pred!=c['truth']),'memory_overlap':OVERLAP[prot][rd]})
 with (out/'judgments.csv').open('w',newline='',encoding='utf-8-sig') as f:
  w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
 print('cases',len(cases),'judgments',len(rows))
if __name__=='__main__': main()
