#!/usr/bin/env python3
from pathlib import Path
import argparse, math
import pandas as pd
import numpy as np

def phi(a,b):
 a=np.asarray(a,dtype=int); b=np.asarray(b,dtype=int)
 n11=int(((a==1)&(b==1)).sum()); n10=int(((a==1)&(b==0)).sum()); n01=int(((a==0)&(b==1)).sum()); n00=int(((a==0)&(b==0)).sum())
 den=math.sqrt((n11+n10)*(n01+n00)*(n11+n01)*(n10+n00))
 return (n11*n00-n10*n01)/den if den else float('nan')

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--judgments',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
 df=pd.read_csv(args.judgments); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
 summary=[]; pairs=[]; fam_rows=[]
 for (prot,rd),g in df.groupby(['protocol','round']):
  piv=g.pivot(index='case_id',columns='agent',values='error')
  ph=[]
  for x,y in [('P','E'),('P','R'),('E','R')]:
   v=phi(piv[x],piv[y]); ph.append(v); pairs.append({'protocol':prot,'round':rd,'pair':f'{x}-{y}','phi':v})
  pred=g.pivot(index='case_id',columns='agent',values='prediction'); truth=g.groupby('case_id').first()['truth']
  maj=pred.apply(lambda r: 'VALID' if (r=='VALID').sum()>=2 else 'INVALID',axis=1)
  majerr=(maj!=truth).mean(); wrong_cons=((pred.nunique(axis=1)==1)&(pred.iloc[:,0]!=truth)).mean()
  sp=g[g.family==g.specialty].error.mean(); off=g[g.family!=g.specialty].error.mean(); spec=off-sp
  avgerr=g.error.mean(); overlap=g.memory_overlap.mean(); gain=avgerr-majerr
  summary.append({'protocol':prot,'round':rd,'avg_member_error':avgerr,'specialty_error':sp,'off_specialty_error':off,'specialization_index':spec,
                  'avg_pairwise_phi':float(np.nanmean(ph)),'memory_overlap':overlap,'majority_error':majerr,'wrong_consensus':wrong_cons,'collective_gain':gain})
  for (agent,fam),h in g.groupby(['agent','family']): fam_rows.append({'protocol':prot,'round':rd,'agent':agent,'family':fam,'error_rate':h.error.mean()})
 s=pd.DataFrame(summary).sort_values(['protocol','round']); s.to_csv(out/'sharing_dynamics.csv',index=False)
 pd.DataFrame(pairs).to_csv(out/'pairwise_error_structure.csv',index=False)
 pd.DataFrame(fam_rows).to_csv(out/'agent_family_error.csv',index=False)
 # deltas from round0 within protocol
 base=s[s['round']==0].set_index('protocol')
 ds=[]
 for _,r in s.iterrows():
  b=base.loc[r.protocol]
  ds.append({'protocol':r.protocol,'round':r['round'],'delta_specialization':r.specialization_index-b.specialization_index,
             'delta_phi':r.avg_pairwise_phi-b.avg_pairwise_phi,'delta_majority_error':r.majority_error-b.majority_error,
             'delta_off_specialty_error':r.off_specialty_error-b.off_specialty_error,'delta_specialty_error':r.specialty_error-b.specialty_error})
 pd.DataFrame(ds).to_csv(out/'collapse_deltas.csv',index=False)
 print(s.to_string(index=False,float_format=lambda x:f'{x:.3f}'))
if __name__=='__main__': main()
