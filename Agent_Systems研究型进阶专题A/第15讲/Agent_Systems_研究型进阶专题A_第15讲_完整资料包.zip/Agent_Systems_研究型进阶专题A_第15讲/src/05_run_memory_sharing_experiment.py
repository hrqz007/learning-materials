#!/usr/bin/env python3
"""Reference runner skeleton for real API evaluation.
Deliberately provider-agnostic via LiteLLM. It retrieves memory entries and asks a model to judge held-out cases.
You must adapt the task rendering/evaluator to your real benchmark before treating results as publishable.
"""
from pathlib import Path
import argparse, json, math
try:
 from litellm import completion
except Exception as e:
 raise SystemExit('litellm is required in the real experiment environment: '+str(e))

def load_jsonl(p):
 return [json.loads(x) for x in Path(p).read_text(encoding='utf-8').splitlines() if x.strip()]
def tok(s): return set(str(s).lower().replace('_',' ').split())
def retrieve(bank, case, k=4):
 q=tok(json.dumps(case,ensure_ascii=False)); scored=[]
 for x in bank:
  t=tok(json.dumps(x,ensure_ascii=False)); score=len(q&t)/max(1,len(q|t)); scored.append((score,x))
 return [x for _,x in sorted(scored,key=lambda z:z[0],reverse=True)[:k]]
def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--fork-root',required=True); ap.add_argument('--protocol',required=True); ap.add_argument('--cases',required=True); ap.add_argument('--model',required=True); ap.add_argument('--out',required=True); ap.add_argument('--top-k',type=int,default=4); args=ap.parse_args()
 root=Path(args.fork_root)/args.protocol; cases=load_jsonl(args.cases); out=[]
 for aid in ['P','E','R']:
  bank=load_jsonl(root/f'agent_{aid}_bank.jsonl')
  for c in cases:
   mem=retrieve(bank,c,args.top_k)
   prompt='You are a persistent agent. Use retrieved experiences as fallible evidence, not authority. Return concise JSON with prediction VALID/INVALID and rationale.\nCASE='+json.dumps(c,ensure_ascii=False)+'\nMEMORY='+json.dumps(mem,ensure_ascii=False)
   r=completion(model=args.model,messages=[{'role':'user','content':prompt}],temperature=0)
   text=r.choices[0].message.content
   out.append({'agent':aid,'case_id':c.get('case_id',c.get('id')),'protocol':args.protocol,'response':text})
 Path(args.out).write_text('\n'.join(json.dumps(x,ensure_ascii=False) for x in out),encoding='utf-8')
 print('wrote',len(out),'rows')
if __name__=='__main__': main()
