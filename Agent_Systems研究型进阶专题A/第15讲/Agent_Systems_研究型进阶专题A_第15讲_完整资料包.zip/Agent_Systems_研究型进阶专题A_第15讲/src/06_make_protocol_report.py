#!/usr/bin/env python3
from pathlib import Path
import argparse, pandas as pd

def main():
 ap=argparse.ArgumentParser(); ap.add_argument('--summary',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
 df=pd.read_csv(args.summary); final=df[df['round']==df['round'].max()].copy()
 cols=['protocol','avg_member_error','specialization_index','avg_pairwise_phi','memory_overlap','majority_error','wrong_consensus','collective_gain']
 Path(args.out).write_text(final[cols].to_markdown(index=False,floatfmt='.3f'),encoding='utf-8')
 print(final[cols].to_string(index=False))
if __name__=='__main__': main()
