# A15 Pilot Conclusion

## 1. What changed after experience sharing?

## 2. Did off-specialty transfer improve?

## 3. Did specialty competence erode?

## 4. Did pairwise error correlation increase?

## 5. Did collective gain improve or collapse?

## 6. Is the effect attributable to sharing rather than memory budget?

## 7. What should be falsified next?
