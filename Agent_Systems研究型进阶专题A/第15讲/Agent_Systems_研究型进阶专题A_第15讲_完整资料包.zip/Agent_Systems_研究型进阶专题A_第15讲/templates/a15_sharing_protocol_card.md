# A15 Sharing Protocol Card

- Protocol name:
- Frozen start checkpoint:
- Local memory quota:
- What may be shared:
- What must remain private:
- Provenance retained?
- Memory budget equalized?
- Sharing frequency:
- Expected benefit:
- Main collapse risk:
- Falsification criterion:
