# A15 Trace Review

| case_id | protocol | round | agent | retrieved_memory_ids | prediction | correct? | copied peer pattern? | new evidence? | specialty preserved? | notes |
|---|---|---:|---|---|---|---|---|---|---|---|
