# QA Notes

- Teaching Mock candidate stream, four governance regimes, downstream paired-randomness simulation, and governance analysis were executed end-to-end from scratch.
- Teaching Mock size: 240 candidate experiences, 150 held-out cases, 4 governance regimes, 3 agents, 1,800 downstream judgments.
- Final Teaching Mock reproduces the intended controlled contrast: Unfiltered-Ingest and Success-Only retain unsafe/stale/local-only records; Quality+Provenance and Diversity-Aware remove those synthetic governance failures. These are teaching-only synthetic results, not real model scores.
- Paired-randomness correction verified: for the same case and agent, all regimes share the same underlying random noise; only the governed memory state differs.
- A15 -> A16 bridge was executed against the bundled Lesson 15 frozen experience banks; 30 candidate records were recovered. `share_scope` and `human_governance_action` remain intentionally blank (0 nonblank entries), so no governance labels were fabricated.
- Dependency check in the artifact-building environment: numpy OK, pandas OK, litellm MISSING. The real LLM curator is therefore provided as a reference runner and was not executed against commercial APIs.
- All Python files passed `compileall` after final edits.
- DOCX visual QA completed after final regeneration: lecture 5 pages; lab guide 2; experiment design 2; exercises 1; answers 1; terminology 1. Every rendered page was inspected for clipping, overlap, broken tables, missing glyphs, and footer/header problems.
- The lecture PDF contains 5 pages and was rendered independently with the PDF renderer; every page was inspected. No clipping, overlap, broken glyphs, or figure/table defects were found.
- A table-header orphan found during an earlier lecture render was fixed by adding a controlled page break before Section 8; the final DOCX/PDF renders are clean.
