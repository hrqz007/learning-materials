# Agent Systems 研究型进阶专题 A · 第16讲

## 主题
Shared Memory Governance / Selective Consolidation / Memory Lifecycle

## 承接关系
- 第13讲：不同经历形成 Agent 异质性。
- 第14讲：异质性随经验剂量动态形成。
- 第15讲：经验共享可能带来 transfer，也可能造成 heterogeneity collapse。
- 第16讲：进一步问——哪些 experience 有资格成为整个群体的共同记忆？

## 推荐顺序
1. 阅读 `02_零基础讲义.pdf`。
2. 跑 Teaching Mock，理解 governance metric 与 downstream reliability 的区别。
3. 使用 `01_prepare_candidates_from_a15.py` 从 A15 冻结经验生成候选清单。
4. 对真实候选补齐 scope / quality / stale / contradiction / version / novelty 标签。
5. 同预算比较 G0-G3；最后才运行真实下游 Agent。

## 硬边界
Teaching Mock 是完全合成数据。A15 bridge 只搬运已有 provenance，不会伪造治理标签。真实论文必须保存 retrieved memory IDs，并对关键治理失败做 trace-level 因果核验。
