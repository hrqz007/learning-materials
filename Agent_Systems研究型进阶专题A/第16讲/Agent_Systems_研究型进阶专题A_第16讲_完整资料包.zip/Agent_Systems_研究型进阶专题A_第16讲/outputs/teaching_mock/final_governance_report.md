# A16 Memory Governance Report

| Regime | Admission precision | Local leak | Stale | Provenance | Family entropy | Redundancy | Error φ | Majority error | Wrong consensus |
|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|
| unfiltered_ingest | 27.1% | 14.6% | 43.8% | 91.7% | 0.888 | 37.5% | 0.276 | 30.0% | 16.7% |
| success_only | 43.8% | 10.4% | 33.3% | 91.7% | 0.910 | 37.5% | 0.284 | 26.7% | 15.3% |
| quality_provenance | 100.0% | 0.0% | 0.0% | 100.0% | 0.945 | 29.2% | 0.062 | 4.0% | 1.3% |
| diversity_aware | 100.0% | 0.0% | 0.0% | 100.0% | 0.989 | 12.5% | 0.068 | 4.0% | 1.3% |

> Teaching Mock only: these values are synthetic and must not be reported as real model performance.