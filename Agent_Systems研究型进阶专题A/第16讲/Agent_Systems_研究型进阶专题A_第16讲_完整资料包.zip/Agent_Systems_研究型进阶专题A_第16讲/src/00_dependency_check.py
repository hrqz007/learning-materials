#!/usr/bin/env python3
import importlib.util, sys
mods=['numpy','pandas','litellm']
for m in mods:
    ok=importlib.util.find_spec(m) is not None
    print(f'{m}: {"OK" if ok else "MISSING"}')
print('Python:', sys.version.split()[0])
