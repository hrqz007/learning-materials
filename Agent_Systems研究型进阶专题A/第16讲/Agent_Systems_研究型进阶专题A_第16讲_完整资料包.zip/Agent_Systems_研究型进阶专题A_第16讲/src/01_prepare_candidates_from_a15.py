#!/usr/bin/env python3
"""Convert A15 frozen local experience banks into an A16 governance-candidate inventory.
No governance label is fabricated. Fields that require human/curator judgment are left blank.
"""
from pathlib import Path
import argparse, json, csv

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--a15-root',required=True)
    ap.add_argument('--out',required=True)
    args=ap.parse_args()
    root=Path(args.a15_root)
    frozen=root/'data'/'a14_bridge_test'/'frozen_start'
    if not frozen.exists():
        raise SystemExit(f'A15_FROZEN_START_NOT_FOUND: {frozen}')
    rows=[]; seen=set()
    for bank in sorted(frozen.glob('agent_*_bank.jsonl')):
        agent=bank.stem.replace('_bank','')
        for line_no,line in enumerate(bank.read_text(encoding='utf-8').splitlines(),1):
            if not line.strip(): continue
            rec=json.loads(line)
            rid=f'{agent}:{rec.get("proposal_id",line_no)}'
            if rid in seen: continue
            seen.add(rid)
            rows.append({
                'candidate_id':rid,
                'source_agent':agent,
                'task_family':rec.get('task_family') or rec.get('error_family') or '',
                'source_label':rec.get('human_label',''),
                'source_proposal_id':rec.get('proposal_id',''),
                'provenance_complete':1,
                'share_scope':'',
                'outcome_status':'',
                'quality_score':'',
                'transferability_score':'',
                'stale_flag':'',
                'contradiction_key':'',
                'version':'',
                'novelty_cluster':'',
                'human_governance_action':'',
                'notes':'',
                'source_record_json':json.dumps(rec,ensure_ascii=False),
            })
    if not rows: raise SystemExit('No experience records found in A15 frozen_start.')
    out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    with out.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f'prepared {len(rows)} candidates -> {out}')
    print('IMPORTANT: governance fields are intentionally blank; annotate them before real policy comparison.')
if __name__=='__main__': main()
