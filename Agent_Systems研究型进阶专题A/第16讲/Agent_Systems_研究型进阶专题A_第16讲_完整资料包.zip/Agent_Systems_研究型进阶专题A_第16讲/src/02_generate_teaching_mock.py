#!/usr/bin/env python3
from pathlib import Path
import argparse, csv, random, math
FAMS=['policy','evidence','parameter']
SOURCES=['agent_P','agent_E','agent_R']

def clipped(x,a=0,b=1): return max(a,min(b,x))

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--out',required=True); ap.add_argument('--seed',type=int,default=1616); ap.add_argument('--n-candidates',type=int,default=240); ap.add_argument('--cases-per-family',type=int,default=50); args=ap.parse_args()
    rng=random.Random(args.seed); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    candidates=[]
    # Candidate stream is intentionally imbalanced and contains stale, contradictory, local-only and low-quality records.
    fam_weights=['policy']*11+['evidence']*7+['parameter']*6
    for i in range(args.n_candidates):
        fam=rng.choice(fam_weights); src=rng.choice(SOURCES)
        outcome=rng.choices(['success','failure','uncertain'],weights=[72,18,10])[0]
        scope=rng.choices(['shareable','local_only'],weights=[86,14])[0]
        base={'success':0.78,'failure':0.34,'uncertain':0.50}[outcome]
        q=clipped(rng.gauss(base,0.15))
        tr=clipped(rng.gauss(0.68 if outcome=='success' else 0.42,0.18))
        prov=1 if rng.random()<0.90 else 0
        stale=1 if rng.random()<0.14 else 0
        # 35% participate in contradiction/version chains; old versions are more likely stale.
        if rng.random()<0.35:
            ckey=f'{fam}_rule_{rng.randrange(0,14)}'; version=rng.choice([1,1,1,2,2,3])
            if version==1 and rng.random()<0.55: stale=1
        else:
            ckey=''; version=1
        cluster=f'{fam}_cluster_{rng.randrange(0,18)}'
        safe=int(scope=='shareable' and outcome=='success' and q>=0.62 and prov==1 and stale==0)
        if scope=='local_only': truth='KEEP_LOCAL'
        elif outcome=='uncertain': truth='QUARANTINE'
        elif outcome=='failure' and q<0.60: truth='REJECT'
        elif safe: truth='PROMOTE_SHARED'
        else: truth='QUARANTINE'
        candidates.append({'candidate_id':f'm{i:03d}','source_agent':src,'task_family':fam,'outcome_status':outcome,'share_scope':scope,'quality_score':round(q,4),'transferability_score':round(tr,4),'provenance_complete':prov,'stale_flag':stale,'contradiction_key':ckey,'version':version,'novelty_cluster':cluster,'safe_share_truth':safe,'governance_truth_action':truth,'recency_rank':i})
    with (out/'candidates.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=candidates[0].keys()); w.writeheader(); w.writerows(candidates)
    cases=[]
    for fam in FAMS:
        for i in range(args.cases_per_family):
            cases.append({'case_id':f'{fam[:3]}_{i:03d}','task_family':fam,'required_cluster':f'{fam}_cluster_{i%18}','truth':'VALID' if i%2==0 else 'INVALID'})
    with (out/'eval_cases.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=cases[0].keys()); w.writeheader(); w.writerows(cases)
    print('candidates',len(candidates),'eval_cases',len(cases))
if __name__=='__main__': main()
