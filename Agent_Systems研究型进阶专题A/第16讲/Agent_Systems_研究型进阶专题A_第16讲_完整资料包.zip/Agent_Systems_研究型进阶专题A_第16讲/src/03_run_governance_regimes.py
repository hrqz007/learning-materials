#!/usr/bin/env python3
"""Apply four deterministic teaching governance regimes under the SAME shared-memory budget.
For real data, candidate metadata must be annotated first. This script does not call an LLM.
"""
from pathlib import Path
import argparse, pandas as pd, numpy as np, math
REGIMES=['unfiltered_ingest','success_only','quality_provenance','diversity_aware']

def norm_entropy(s):
    p=s.value_counts(normalize=True)
    if len(p)<=1: return 0.0
    h=-(p*np.log(p)).sum(); return float(h/np.log(len(p)))

def dedup_supersede(df):
    # Keep newest/highest version within contradiction chains; untouched records stay independent.
    no=df[df.contradiction_key.fillna('').eq('')]
    yes=df[~df.contradiction_key.fillna('').eq('')].copy()
    if len(yes): yes=yes.sort_values(['contradiction_key','version','quality_score','recency_rank']).groupby('contradiction_key',as_index=False).tail(1)
    return pd.concat([no,yes],ignore_index=True)

def select(df,regime,budget):
    x=df.copy()
    if regime=='unfiltered_ingest':
        return x.sort_values('recency_rank',ascending=False).head(budget)
    if regime=='success_only':
        x=x[x.outcome_status.eq('success')]
        return x.sort_values('recency_rank',ascending=False).head(budget)
    # Quality + provenance + scope + staleness + supersession
    x=x[(x.outcome_status.eq('success')) & (x.share_scope.eq('shareable')) & (x.quality_score>=0.62) & (x.provenance_complete==1) & (x.stale_flag==0)]
    x=dedup_supersede(x)
    x=x.assign(base_score=.55*x.quality_score+.45*x.transferability_score)
    if regime=='quality_provenance':
        return x.sort_values(['base_score','recency_rank'],ascending=[False,False]).head(budget)
    # Diversity-aware greedy: novelty + family/source coverage, while retaining quality floor.
    chosen=[]; fam_count={}; src_count={}; clusters=set()
    remaining=x.copy()
    fam_cap=max(1,math.ceil(budget*0.45)); src_cap=max(1,math.ceil(budget*0.50))
    while len(chosen)<budget and len(remaining):
        scored=[]
        for idx,r in remaining.iterrows():
            fam_bonus=0.12/(1+fam_count.get(r.task_family,0))
            src_bonus=0.08/(1+src_count.get(r.source_agent,0))
            nov_bonus=0.10 if r.novelty_cluster not in clusters else -0.08
            score=float(r.base_score+fam_bonus+src_bonus+nov_bonus)
            if fam_count.get(r.task_family,0)>=fam_cap: score-=0.25
            if src_count.get(r.source_agent,0)>=src_cap: score-=0.20
            scored.append((score,idx))
        scored.sort(reverse=True); _,idx=scored[0]; r=remaining.loc[idx]
        chosen.append(r)
        fam_count[r.task_family]=fam_count.get(r.task_family,0)+1
        src_count[r.source_agent]=src_count.get(r.source_agent,0)+1
        clusters.add(r.novelty_cluster)
        remaining=remaining.drop(index=idx)
    return pd.DataFrame(chosen) if chosen else x.head(0)

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--candidates',required=True); ap.add_argument('--out',required=True); ap.add_argument('--budget',type=int,default=48); args=ap.parse_args()
    df=pd.read_csv(args.candidates); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    req=['candidate_id','source_agent','task_family','outcome_status','share_scope','quality_score','transferability_score','provenance_complete','stale_flag','contradiction_key','version','novelty_cluster','safe_share_truth','recency_rank']
    miss=[c for c in req if c not in df.columns]
    if miss: raise SystemExit('Missing annotated columns: '+', '.join(miss))
    rows=[]
    for reg in REGIMES:
        m=select(df,reg,args.budget).copy(); m['regime']=reg
        m.to_csv(out/f'shared_memory_{reg}.csv',index=False)
        # contradiction persistence = admitted contradiction groups containing >1 version (should be zero for supersession regimes)
        con=m[m.contradiction_key.fillna('').ne('')]
        contrad=0.0
        if len(con):
            g=con.groupby('contradiction_key').version.nunique(); contrad=float((g>1).mean()) if len(g) else 0.0
        redundancy=1-(m.novelty_cluster.nunique()/len(m)) if len(m) else 0.0
        rows.append({'regime':reg,'admitted_count':len(m),'admission_precision':m.safe_share_truth.mean() if len(m) else np.nan,'local_scope_leak_rate':m.share_scope.eq('local_only').mean() if len(m) else np.nan,'stale_persistence_rate':m.stale_flag.mean() if len(m) else np.nan,'provenance_completeness':m.provenance_complete.mean() if len(m) else np.nan,'contradiction_persistence':contrad,'family_entropy':norm_entropy(m.task_family) if len(m) else np.nan,'source_entropy':norm_entropy(m.source_agent) if len(m) else np.nan,'redundancy_rate':redundancy})
    pd.DataFrame(rows).to_csv(out/'governance_inventory_summary.csv',index=False)
    print(pd.DataFrame(rows).to_string(index=False))
if __name__=='__main__': main()
