#!/usr/bin/env python3
"""Teaching-only downstream simulation. It is NOT a real model evaluation."""
from pathlib import Path
import argparse, pandas as pd, numpy as np, random, csv
AGENTS=['agent_P','agent_E','agent_R']; SPECIAL={'agent_P':'policy','agent_E':'evidence','agent_R':'parameter'}
REGIMES=['unfiltered_ingest','success_only','quality_provenance','diversity_aware']

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--memory-dir',required=True); ap.add_argument('--cases',required=True); ap.add_argument('--out',required=True); ap.add_argument('--seed',type=int,default=1617); args=ap.parse_args()
    rng=random.Random(args.seed); memdir=Path(args.memory_dir); cases=pd.read_csv(args.cases); out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True)
    # Paired randomness: every regime sees the same case-level and agent-level random draws.
    noise={}
    for _,c in cases.iterrows():
        noise[c.case_id]={'shock_u':rng.random(),'shock_wrong_u':rng.random(),'agent_u':{a:rng.random() for a in AGENTS}}
    rows=[]
    for reg in REGIMES:
        mem=pd.read_csv(memdir/f'shared_memory_{reg}.csv')
        fam_counts=mem.task_family.value_counts().to_dict()
        for _,c in cases.iterrows():
            fam=c.task_family; cl=c.required_cluster
            fam_mem=mem[mem.task_family.eq(fam)]
            good=fam_mem[(fam_mem.safe_share_truth==1)]
            bad=fam_mem[(fam_mem.safe_share_truth==0)]
            cluster_good=good[good.novelty_cluster.eq(cl)]
            cluster_bad=bad[bad.novelty_cluster.eq(cl)]
            coverage=min(1.0,0.30*len(cluster_good)+0.03*len(good))
            harm=min(1.0,0.40*len(cluster_bad)+0.06*len(bad))
            low_coverage=1 if fam_counts.get(fam,0)<max(4,len(mem)*0.20) else 0
            n=noise[c.case_id]
            shock=n['shock_u'] < (0.015+0.24*harm)
            shock_wrong=shock and (n['shock_wrong_u']<0.85)
            for a in AGENTS:
                base=.115 if SPECIAL[a]==fam else .185
                p=max(.02,min(.60,base-0.065*coverage+0.12*harm+0.035*low_coverage))
                err=bool(shock_wrong or (n['agent_u'][a]<p))
                pred=('INVALID' if c.truth=='VALID' else 'VALID') if err else c.truth
                rows.append({'regime':reg,'case_id':c.case_id,'task_family':fam,'agent':a,'truth':c.truth,'prediction':pred,'error':int(err),'coverage_signal':round(coverage,4),'harm_signal':round(harm,4),'shared_error_shock':int(shock_wrong)})
    pd.DataFrame(rows).to_csv(out,index=False)
    print('judgments',len(rows),'->',out)
if __name__=='__main__': main()
