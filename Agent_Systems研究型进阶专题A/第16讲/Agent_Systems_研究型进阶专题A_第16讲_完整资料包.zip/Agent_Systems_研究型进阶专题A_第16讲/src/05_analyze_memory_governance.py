#!/usr/bin/env python3
from pathlib import Path
import argparse, math, pandas as pd, numpy as np

def phi(a,b):
    a=np.asarray(a,dtype=int); b=np.asarray(b,dtype=int)
    n11=int(((a==1)&(b==1)).sum()); n10=int(((a==1)&(b==0)).sum()); n01=int(((a==0)&(b==1)).sum()); n00=int(((a==0)&(b==0)).sum())
    den=math.sqrt((n11+n10)*(n01+n00)*(n11+n01)*(n10+n00))
    return (n11*n00-n10*n01)/den if den else float('nan')

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--inventory-summary',required=True); ap.add_argument('--judgments',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    inv=pd.read_csv(args.inventory_summary); j=pd.read_csv(args.judgments); out=Path(args.out); out.mkdir(parents=True,exist_ok=True)
    rows=[]; pairrows=[]
    for reg,g in j.groupby('regime'):
        piv=g.pivot(index='case_id',columns='agent',values='error')
        ph=[]
        for x,y in [('agent_P','agent_E'),('agent_P','agent_R'),('agent_E','agent_R')]:
            v=phi(piv[x],piv[y]); ph.append(v); pairrows.append({'regime':reg,'pair':f'{x}-{y}','phi':v})
        pred=g.pivot(index='case_id',columns='agent',values='prediction'); truth=g.groupby('case_id').first()['truth']
        maj=pred.apply(lambda r:'VALID' if (r=='VALID').sum()>=2 else 'INVALID',axis=1)
        majerr=float((maj!=truth).mean()); wrong=float(((pred.nunique(axis=1)==1)&(pred.iloc[:,0]!=truth)).mean())
        rows.append({'regime':reg,'avg_member_error':g.error.mean(),'avg_pairwise_phi':float(np.nanmean(ph)),'majority_error':majerr,'wrong_consensus':wrong,'avg_coverage_signal':g.coverage_signal.mean(),'avg_harm_signal':g.harm_signal.mean()})
    perf=pd.DataFrame(rows); pair=pd.DataFrame(pairrows)
    final=inv.merge(perf,on='regime',how='left')
    final.to_csv(out/'governance_system_summary.csv',index=False); pair.to_csv(out/'pairwise_error_phi.csv',index=False)
    # Governance failure cases: common shocks or wrong consensus
    pred=j.pivot_table(index=['regime','case_id'],columns='agent',values='prediction',aggfunc='first').reset_index()
    truth=j.groupby(['regime','case_id']).first()['truth'].reset_index()
    z=pred.merge(truth,on=['regime','case_id']); z['wrong_consensus']=((z[['agent_P','agent_E','agent_R']].nunique(axis=1)==1)&(z.agent_P!=z.truth)).astype(int)
    shocks=j.groupby(['regime','case_id']).shared_error_shock.max().reset_index(); z=z.merge(shocks,on=['regime','case_id'])
    z[(z.wrong_consensus==1)|(z.shared_error_shock==1)].to_csv(out/'governance_failure_cases.csv',index=False)
    print(final.to_string(index=False))
if __name__=='__main__': main()
