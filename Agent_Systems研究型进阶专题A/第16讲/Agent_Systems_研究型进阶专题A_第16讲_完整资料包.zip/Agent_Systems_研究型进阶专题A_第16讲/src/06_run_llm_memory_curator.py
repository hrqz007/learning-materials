#!/usr/bin/env python3
"""Reference skeleton for a real LLM memory curator.
Requires a manually annotated candidate inventory and LiteLLM. It does NOT mutate any live shared memory by default.
"""
import argparse, json, pandas as pd
from litellm import completion
PROMPT="""You are a memory governance curator for a multi-agent system.
Given ONE candidate experience, choose exactly one admission action:
PROMOTE_SHARED, KEEP_LOCAL, QUARANTINE, or REJECT.
Consider provenance, scope, outcome quality, transferability, staleness, contradictions, and whether sharing could erase useful specialization.
Return strict JSON: {\"action\":\"...\",\"reason\":\"...\",\"risk\":\"low|medium|high\"}.
Candidate:\n{candidate}\n"""

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--candidates',required=True); ap.add_argument('--model',required=True); ap.add_argument('--out',required=True); ap.add_argument('--limit',type=int,default=6); args=ap.parse_args()
    df=pd.read_csv(args.candidates).head(args.limit); rows=[]
    for _,r in df.iterrows():
        msg=PROMPT.format(candidate=json.dumps(r.to_dict(),ensure_ascii=False))
        res=completion(model=args.model,messages=[{'role':'user','content':msg}],temperature=0)
        txt=res.choices[0].message.content
        try: obj=json.loads(txt)
        except Exception: obj={'action':'PARSE_ERROR','reason':txt,'risk':'unknown'}
        rows.append({'candidate_id':r.candidate_id,**obj})
    pd.DataFrame(rows).to_csv(args.out,index=False)
    print('wrote',len(rows),args.out)
if __name__=='__main__': main()
