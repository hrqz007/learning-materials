#!/usr/bin/env python3
from pathlib import Path
import argparse, pandas as pd

def pct(x): return 'NA' if pd.isna(x) else f'{100*x:.1f}%'
def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--summary',required=True); ap.add_argument('--out',required=True); args=ap.parse_args()
    df=pd.read_csv(args.summary)
    cols=['regime','admission_precision','local_scope_leak_rate','stale_persistence_rate','provenance_completeness','family_entropy','redundancy_rate','avg_pairwise_phi','majority_error','wrong_consensus']
    lines=['# A16 Memory Governance Report','', '| Regime | Admission precision | Local leak | Stale | Provenance | Family entropy | Redundancy | Error φ | Majority error | Wrong consensus |','|---|---:|---:|---:|---:|---:|---:|---:|---:|---:|']
    for _,r in df.iterrows():
        lines.append(f"| {r.regime} | {pct(r.admission_precision)} | {pct(r.local_scope_leak_rate)} | {pct(r.stale_persistence_rate)} | {pct(r.provenance_completeness)} | {r.family_entropy:.3f} | {pct(r.redundancy_rate)} | {r.avg_pairwise_phi:.3f} | {pct(r.majority_error)} | {pct(r.wrong_consensus)} |")
    lines += ['', '> Teaching Mock only: these values are synthetic and must not be reported as real model performance.']
    Path(args.out).write_text('\n'.join(lines),encoding='utf-8')
if __name__=='__main__': main()
