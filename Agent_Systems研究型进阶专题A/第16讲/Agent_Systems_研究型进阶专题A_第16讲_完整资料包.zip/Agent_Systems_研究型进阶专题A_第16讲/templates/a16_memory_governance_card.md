# Memory Governance Card

- Candidate ID:
- Source Agent:
- Task Family:
- Provenance complete?
- Scope: shareable / local-only
- Outcome: success / failure / uncertain
- Quality score:
- Transferability:
- Stale?
- Contradiction key / version:
- Novelty cluster:
- Admission action: PROMOTE_SHARED / KEEP_LOCAL / QUARANTINE / REJECT
- Supersedes existing memory?
- Rationale:
