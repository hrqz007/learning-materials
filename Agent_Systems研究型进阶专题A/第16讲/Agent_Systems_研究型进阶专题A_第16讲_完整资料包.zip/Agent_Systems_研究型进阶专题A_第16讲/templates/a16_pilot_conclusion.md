# A16 Pilot Conclusion

## 1. Candidate pool and shared-memory budget

## 2. Which governance regime had the best admission quality?

## 3. Which failure mode dominated?
- bad-memory admission
- stale persistence
- contradiction persistence
- provenance collapse
- source/family dominance

## 4. Did better governance reduce downstream error correlation?

## 5. What evidence would falsify the current hypothesis?

## 6. Next controlled experiment
