# A16 Governance Trace Review

- Case ID:
- Regime:
- Retrieved shared memories:
- Which admitted memory most affected the decision?
- Was it current / stale / contradictory / duplicated?
- Did all agents retrieve the same bad memory?
- First bad span / first wrong evidence use:
- Governance failure type: bad admission / stale persistence / contradiction persistence / provenance loss / coverage collapse / none
- Counterfactual: which governance action would have prevented it?
