# QA Notes

- Teaching Mock 使用安全合成 POISON_MARKER；没有真实攻击 payload。
- 所有 repair regime 使用相同 cases 与 paired deterministic noise。
- A16 bridge 只接受 safe_share_truth=1、stale_flag=0、provenance_complete=1 的记录作为 clean snapshot。
- 真实 LLM detector skeleton 仅做 existing-record classification；不包含 injection generator。
- DOCX/PDF 需要在最终交付前完成逐页渲染检查。
- Final compileall passed for all Python sources.
- Teaching Mock was regenerated from seed=1701; repair_system_summary.csv matched byte-for-byte.
- A16→A17 bridge was rerun: 48/48 safe, non-stale, provenance-complete memories became v0 clean snapshot.
- Independent PDF renderer verified all 4 lecture pages.
