# 第17讲学习说明

## 最低闭环
Clean Snapshot → Synthetic Contamination → Propagation → Quarantine → Rollback → Lineage Repair → Post-repair Validation。

## 推荐顺序
1. 先读 PDF 讲义。
2. 运行 Teaching Mock，确认四种 repair regime 的输出。
3. 手工查看 propagation_edges.csv 与 post_repair_failure_cases.csv。
4. 再读实验设计书，写自己的 Incident Card。
5. 真实 API 实验只从极小规模开始。

## 安全说明
本资料不提供真实 memory-poisoning payload 或攻击生成器。Teaching Mock 只使用 POISON_MARKER 和 contamination_truth，目标是学习检测、隔离、回滚和修复。
