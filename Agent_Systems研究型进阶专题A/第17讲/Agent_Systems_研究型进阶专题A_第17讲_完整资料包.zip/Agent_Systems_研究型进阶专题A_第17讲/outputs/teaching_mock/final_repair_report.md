# A17 Repair Pilot Report

> Teaching Mock / synthetic evidence only. Do not cite as real model performance.

## System summary

| regime          |   residual_contaminated_memories |   residual_rate |   majority_error |   dangerous_miss |   avg_pairwise_error_phi |   clean_utility |
|:----------------|---------------------------------:|----------------:|-----------------:|-----------------:|-------------------------:|----------------:|
| no_repair       |                               36 |        1        |         0.438889 |        0.155556  |               0.119115   |        0.533951 |
| quarantine_only |                                7 |        0.194444 |         0.205556 |        0.0777778 |               0.00141516 |        0.728395 |
| root_rollback   |                               24 |        0.666667 |         0.438889 |        0.155556  |               0.119115   |        0.533951 |
| lineage_repair  |                                0 |        0        |         0        |        0         |              -0.0735212  |        0.935185 |

## Interpretation checklist

- Did residual contamination fall after repair?
- Did dangerous miss fall without unacceptable clean-utility loss?
- Did error correlation fall after lineage repair?
- Was rollback sufficient, or were contaminated descendants still active?