#!/usr/bin/env python3
import argparse, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--input',required=True); p.add_argument('--out',required=True); args=p.parse_args()
df=pd.read_csv(args.input)
need=['candidate_id','source_agent','task_family','provenance_complete','stale_flag','safe_share_truth']
missing=[c for c in need if c not in df.columns]
if missing: raise SystemExit(f'Missing columns: {missing}')
# A17 clean snapshot only accepts A16 memories that were safe to share and are not stale.
clean=df[(df.safe_share_truth==1)&(df.stale_flag==0)&(df.provenance_complete==1)].copy()
clean['memory_id']='clean_'+clean['candidate_id'].astype(str)
clean['parent_memory_id']=''
clean['contamination_truth']=0
clean['status']='ACTIVE'
clean['version_id']='v0'
cols=['memory_id','parent_memory_id','source_agent','task_family','contamination_truth','status','version_id']
out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True); clean[cols].to_csv(out,index=False)
print(f'Prepared {len(clean)} clean memories from {len(df)} A16 records -> {out}')
