#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--out-dir',required=True); p.add_argument('--seed',type=int,default=1701); args=p.parse_args()
rng=np.random.default_rng(args.seed); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
families=['policy','evidence','parameter']; agents=['agent_P','agent_E','agent_R']
# 72 clean records + 12 synthetic contamination roots. No real malicious payload is stored.
rows=[]
for i in range(72):
    fam=families[i%3]; rows.append(dict(memory_id=f'c{i:03d}',parent_memory_id='',source_agent=agents[i%3],task_family=fam,record_type='BENIGN',contamination_truth=0,version_id='v0',status='ACTIVE',content_class='BENIGN_EXPERIENCE'))
for i in range(12):
    fam=families[i%3]; rows.append(dict(memory_id=f'p{i:03d}',parent_memory_id='',source_agent=agents[i%3],task_family=fam,record_type='SYNTHETIC_CONTAMINATION',contamination_truth=1,version_id='v1',status='ACTIVE',content_class='POISON_MARKER'))
mem=pd.DataFrame(rows); mem.to_csv(out/'memory_t1_injected.csv',index=False)
# Propagate: each root creates 1-3 descendants in later pseudo-rounds.
allrows=rows.copy(); edges=[]; did=0
for root in [r for r in rows if r['contamination_truth']==1]:
    n=int(rng.integers(1,4)); parent=root['memory_id']
    for depth in range(1,n+1):
        child=f'd{did:03d}'; did+=1
        rec=dict(memory_id=child,parent_memory_id=parent,source_agent=agents[(agents.index(root['source_agent'])+depth)%3],task_family=root['task_family'],record_type='DERIVED',contamination_truth=1,version_id=f'v{depth+1}',status='ACTIVE',content_class='DERIVED_SUMMARY')
        allrows.append(rec); edges.append(dict(parent=parent,child=child,root=root['memory_id'],depth=depth)); parent=child
pd.DataFrame(allrows).to_csv(out/'memory_t2_propagated.csv',index=False); pd.DataFrame(edges).to_csv(out/'propagation_edges.csv',index=False)
# 180 eval cases, paired random base difficulty.
cases=[]
for i in range(180):
    fam=families[i%3]; truth='INVALID' if (i%5 in [0,1]) else 'VALID'; risk='high' if (i%7 in [0,1]) else 'normal'
    cases.append(dict(case_id=f'{fam[:3]}_{i:03d}',task_family=fam,truth=truth,risk=risk,base_u=float(rng.random()),shock_u=float(rng.random())))
pd.DataFrame(cases).to_csv(out/'eval_cases.csv',index=False)
print('Generated teaching mock memory and eval cases')
