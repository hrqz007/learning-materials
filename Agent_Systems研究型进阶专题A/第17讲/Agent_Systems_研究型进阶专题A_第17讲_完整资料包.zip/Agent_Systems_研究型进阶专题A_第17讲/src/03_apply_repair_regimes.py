#!/usr/bin/env python3
import argparse, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--memory',required=True); p.add_argument('--edges',required=True); p.add_argument('--out-dir',required=True); args=p.parse_args()
mem=pd.read_csv(args.memory).fillna(''); edges=pd.read_csv(args.edges).fillna(''); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
# Four safe pedagogical regimes. Detection is simulated from contamination_truth; no attack generation here.
regimes=['no_repair','quarantine_only','root_rollback','lineage_repair']
for reg in regimes:
    x=mem.copy(); x['regime']=reg; x['quarantined']=0; x['removed']=0; x['repair_action']='NONE'
    if reg=='quarantine_only':
        # detector catches most roots/descendants but leaves them in store, unavailable to retrieval.
        caught=x['contamination_truth'].eq(1) & (~x['memory_id'].str.endswith(('3','7')))
        x.loc[caught,'quarantined']=1; x.loc[caught,'repair_action']='QUARANTINE'
    elif reg=='root_rollback':
        roots=(x['contamination_truth'].eq(1) & x['parent_memory_id'].eq(''))
        x.loc[roots,'removed']=1; x.loc[roots,'repair_action']='ROLLBACK_ROOT'
    elif reg=='lineage_repair':
        bad=x['contamination_truth'].eq(1)
        x.loc[bad,'removed']=1; x.loc[bad,'repair_action']='PURGE_CONTAMINATED_LINEAGE'
    x.to_csv(out/f'memory_{reg}.csv',index=False)
print('Wrote repair-regime memory states')
