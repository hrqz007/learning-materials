#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--cases',required=True); p.add_argument('--memory-dir',required=True); p.add_argument('--out',required=True); args=p.parse_args()
cases=pd.read_csv(args.cases); mdir=Path(args.memory_dir); regimes=['no_repair','quarantine_only','root_rollback','lineage_repair']; agents=['agent_P','agent_E','agent_R']
rows=[]
for reg in regimes:
    mem=pd.read_csv(mdir/f'memory_{reg}.csv').fillna('')
    active=mem[(mem['removed']==0)&(mem['quarantined']==0)]
    contam=float(active['contamination_truth'].mean()) if len(active) else 0.0
    residual=int(active['contamination_truth'].sum())
    # paired deterministic case/agent noise; regime modifies contamination shock only.
    for _,c in cases.iterrows():
        for ai,a in enumerate(agents):
            u=(float(c.base_u)+(ai*0.173))%1.0
            shock=(float(c.shock_u)+(ai*0.137))%1.0
            base_err=0.08 + (0.03 if c['risk']=='high' else 0)
            contam_err=min(0.42, contam*2.4)
            err = (u < base_err) or (shock < contam_err)
            pred=c['truth'] if not err else ('VALID' if c['truth']=='INVALID' else 'INVALID')
            rows.append(dict(regime=reg,case_id=c.case_id,task_family=c.task_family,risk=c.risk,agent=a,truth=c['truth'],prediction=pred,error=int(err),active_contamination_rate=contam,residual_contaminated_memories=residual))
pd.DataFrame(rows).to_csv(args.out,index=False); print(f'Wrote {len(rows)} judgments')
