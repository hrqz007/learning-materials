#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--judgments',required=True); p.add_argument('--memory-dir',required=True); p.add_argument('--out-dir',required=True); args=p.parse_args()
out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True); df=pd.read_csv(args.judgments); regimes=list(df.regime.unique())
summary=[]
for reg in regimes:
    g=df[df.regime==reg].copy(); piv=g.pivot(index='case_id',columns='agent',values='prediction'); truth=g.groupby('case_id').truth.first(); risk=g.groupby('case_id').risk.first()
    maj=piv.apply(lambda r: r.value_counts().idxmax(),axis=1); err=(maj!=truth); dangerous=((truth=='INVALID')&(maj=='VALID'))
    mem=pd.read_csv(Path(args.memory_dir)/f'memory_{reg}.csv').fillna(''); active=mem[(mem.removed==0)&(mem.quarantined==0)]
    residual=int(active.contamination_truth.sum()); total_bad=int(mem.contamination_truth.sum())
    # Pairwise phi of error indicators
    ep=g.pivot(index='case_id',columns='agent',values='error')
    phis=[]
    for i,a in enumerate(ep.columns):
        for b in ep.columns[i+1:]:
            x=ep[a].values; y=ep[b].values
            den=np.sqrt(x.sum()*(len(x)-x.sum())*y.sum()*(len(y)-y.sum()))
            phis.append(0.0 if den==0 else float(((x*y).sum()*len(x)-x.sum()*y.sum())/den))
    summary.append(dict(regime=reg,residual_contaminated_memories=residual,residual_rate=(residual/total_bad if total_bad else 0),majority_error=float(err.mean()),dangerous_miss=float(dangerous.mean()),avg_pairwise_error_phi=float(np.mean(phis)),clean_utility=float(1-g[g.truth=='VALID'].error.mean())))
pd.DataFrame(summary).to_csv(out/'repair_system_summary.csv',index=False)
# failure cases
fail=[]
for reg in regimes:
    g=df[df.regime==reg]; piv=g.pivot(index='case_id',columns='agent',values='prediction'); truth=g.groupby('case_id').truth.first(); maj=piv.apply(lambda r:r.value_counts().idxmax(),axis=1)
    for cid in maj.index[maj!=truth]: fail.append(dict(regime=reg,case_id=cid,truth=truth[cid],majority=maj[cid]))
pd.DataFrame(fail).to_csv(out/'post_repair_failure_cases.csv',index=False)
print(pd.DataFrame(summary).to_string(index=False))
