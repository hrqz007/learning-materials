#!/usr/bin/env python3
import argparse,pandas as pd
from pathlib import Path
p=argparse.ArgumentParser();p.add_argument('--summary',required=True);p.add_argument('--out',required=True);args=p.parse_args();df=pd.read_csv(args.summary)
lines=['# A17 Repair Pilot Report','', '> Teaching Mock / synthetic evidence only. Do not cite as real model performance.','', '## System summary','',df.to_markdown(index=False),'','## Interpretation checklist','', '- Did residual contamination fall after repair?','- Did dangerous miss fall without unacceptable clean-utility loss?','- Did error correlation fall after lineage repair?','- Was rollback sufficient, or were contaminated descendants still active?']
Path(args.out).write_text('\n'.join(lines),encoding='utf-8')
