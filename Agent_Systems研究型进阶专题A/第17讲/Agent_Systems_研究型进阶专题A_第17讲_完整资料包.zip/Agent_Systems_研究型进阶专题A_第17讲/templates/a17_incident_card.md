# Memory Incident Card

- Incident ID:
- First suspicious memory:
- First observed downstream deviation:
- Affected agents:
- Suspected root / descendants:
- Last-known-good snapshot:
- Quarantine decision:
- Rollback scope:
- Repair validation result:
- Residual uncertainty:
