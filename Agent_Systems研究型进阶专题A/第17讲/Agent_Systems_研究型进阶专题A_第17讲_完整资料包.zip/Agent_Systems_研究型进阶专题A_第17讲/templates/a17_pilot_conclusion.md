# Pilot Conclusion

- 观察到的污染路径：
- Quarantine 是否阻断传播：
- Root-only rollback 是否充分：
- Lineage repair 的额外收益：
- Clean utility 代价：
- 下一轮需要验证的假设：
