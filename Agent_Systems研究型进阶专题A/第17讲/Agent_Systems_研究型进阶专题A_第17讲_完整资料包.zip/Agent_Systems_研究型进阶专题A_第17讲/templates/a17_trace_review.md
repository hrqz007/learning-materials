# Trace Review

1. 哪条 memory 首先进入 retrieval context？
2. 哪个后续 memory 是由它派生/摘要而来？
3. 第一次行为偏离出现在哪里？
4. 如果只删除 root，哪些 descendants 仍然活跃？
5. rollback 后是否仍能通过旧摘要重新污染？
