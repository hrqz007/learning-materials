# QA Notes

- DOCX visual QA: 01=4 pages, 03=2, 04=2, 05=1, 06=1, 07=1; all pages rendered and visually inspected.
- PDF visual QA: lecture PDF=4 pages; independently rendered and visually inspected.
- Teaching Mock rerun from zero: `overall_summary.csv` and `wave_summary.csv` are byte-identical to packaged outputs.
- Paired randomness / paired incident stream: all four regimes share identical event_id/wave/family/variant/severity attributes.
- Mechanism assertions passed: Store-All has higher false-quarantine and lower defense-memory precision than verified replay; Adaptive-Immune has lower mean TTD and blast radius than Static in the Teaching Mock.
- A17→A18 bridge test passed: 12 contamination roots recovered as incident seeds; all explicitly marked `repeat_evidence_available=0`.
- Dependency check in the authoring container: pandas=OK, numpy=OK, litellm=MISSING. Real API triage was not fabricated.
- Security boundary: no attack payload generator; Teaching Mock uses safe incident families and existing-failure classification only.
