# 第18讲学习说明

## 本讲目标
把第17讲的“一次事故恢复”推进到“多次事故之后系统是否学会更快、更安全地恢复”。

## 最低闭环
Repeated Incident Stream → Detect → Contain → Recover → Verify → Incident Card → Defense Memory → Future Incident。

## 推荐顺序
1. 阅读讲义。
2. 跑 Teaching Mock。
3. 画 wave-by-wave MTTD / MTTR / Blast Radius。
4. 对比 repeated vs novel incidents。
5. 阅读实验设计书，再决定是否进行真实 API pilot。

## 安全边界
本讲只使用安全合成 incident labels，不提供攻击 payload，也不研究如何制造真实 poisoning。
