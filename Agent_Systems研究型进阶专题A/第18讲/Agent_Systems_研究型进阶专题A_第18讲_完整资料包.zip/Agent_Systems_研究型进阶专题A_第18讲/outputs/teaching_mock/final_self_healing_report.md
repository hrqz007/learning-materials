# A18 Self-Healing Teaching Mock Report

> Synthetic teaching data only. Do not cite these values as real-model performance.

## Overall
- **adaptive_immune**: repair=90.3%, TTD=2.61, blast=4.71, false-quarantine=0.0%, memory-precision=100.0%
- **static**: repair=54.2%, TTD=5.84, blast=10.53, false-quarantine=0.0%, memory-precision=100.0%
- **store_all**: repair=68.8%, TTD=4.04, blast=7.31, false-quarantine=16.7%, memory-precision=76.2%
- **verified_replay**: repair=82.6%, TTD=3.34, blast=6.00, false-quarantine=0.0%, memory-precision=100.0%

## Interpretation
- Static defense does not improve merely because incidents repeat.
- Store-all can learn quickly but may accumulate bad/spurious defense memory.
- Verified replay learns from successful, validated repairs.
- Adaptive immune memory adds a novelty gate so new variants are escalated instead of blindly forcing an old playbook.