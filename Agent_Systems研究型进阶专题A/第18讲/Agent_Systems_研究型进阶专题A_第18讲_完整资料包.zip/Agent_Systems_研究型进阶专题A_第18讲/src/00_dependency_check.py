import importlib
for m in ['pandas','numpy','litellm']:
    try:
        mod=importlib.import_module(m); print(f'{m}: OK')
    except Exception as e:
        print(f'{m}: MISSING ({type(e).__name__}: {e})')
