#!/usr/bin/env python3
import argparse, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--memory',required=True); p.add_argument('--edges',required=True); p.add_argument('--out',required=True); args=p.parse_args()
m=pd.read_csv(args.memory); e=pd.read_csv(args.edges)
need=['memory_id','task_family','contamination_truth','record_type']
miss=[c for c in need if c not in m.columns]
if miss: raise SystemExit(f'Missing columns: {miss}')
roots=m[(m.contamination_truth==1)&(m.record_type.astype(str).str.contains('POISON|CONTAM',case=False,regex=True))].copy()
# Fallback for A17 Teaching Mock root naming if record_type is generic.
if roots.empty:
    roots=m[(m.contamination_truth==1)&(~m.memory_id.astype(str).isin(set(e.child.astype(str))))].copy()
if roots.empty: raise SystemExit('No contamination roots found. This bridge will not invent incidents.')
child_counts=e.groupby('root').size().to_dict() if not e.empty else {}
max_depth=e.groupby('root').depth.max().to_dict() if ('depth' in e.columns and not e.empty) else {}
out=[]
for _,r in roots.iterrows():
    rid=str(r.memory_id)
    out.append({'incident_seed_id':rid,'incident_family':str(r.task_family),'source_agent':str(r.get('source_agent','unknown')),
                'descendant_count':int(child_counts.get(rid,0)),'max_depth':int(max_depth.get(rid,0)),
                'origin':'A17_root_only','repeat_evidence_available':0})
df=pd.DataFrame(out).drop_duplicates('incident_seed_id')
path=Path(args.out); path.parent.mkdir(parents=True,exist_ok=True); df.to_csv(path,index=False)
print(f'Prepared {len(df)} A17 incident seeds -> {path}')
print('NOTE: A17 contains root incidents, not a longitudinal recurrence stream. Do not duplicate them as real repeated incidents.')
