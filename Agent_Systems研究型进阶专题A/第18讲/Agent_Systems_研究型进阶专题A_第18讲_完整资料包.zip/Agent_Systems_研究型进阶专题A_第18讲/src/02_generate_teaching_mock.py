#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--out-dir',required=True); p.add_argument('--seed',type=int,default=1801); args=p.parse_args()
rng=np.random.default_rng(args.seed); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
intro={'stale_policy':1,'summary_drift':1,'provenance_conflict':2,'retrieval_mismatch':3,'lineage_residual':4}
fams=list(intro)
rows=[]; seen_family=set(); seen_variants={f:set() for f in fams}
for wave in range(1,7):
    available=[f for f in fams if intro[f]<=wave]
    # 24 real incidents + 6 benign anomaly-like events per wave.
    for j in range(30):
        eid=f'w{wave}_{j:02d}'
        is_incident=1 if j<24 else 0
        if is_incident:
            weights=np.array([3.0 if intro[f]==wave else 1.0 for f in available],dtype=float); weights/=weights.sum()
            fam=str(rng.choice(available,p=weights)); variant=int(rng.integers(0,4)); severity=int(rng.choice([1,2,3],p=[.35,.45,.20]))
            first_family=int(fam not in seen_family); first_variant=int(variant not in seen_variants[fam]); repeat=int(not first_family)
            seen_family.add(fam); seen_variants[fam].add(variant)
        else:
            fam='benign_anomaly'; variant=int(rng.integers(0,4)); severity=int(rng.choice([1,2])); first_family=0; first_variant=0; repeat=0
        rows.append({'event_id':eid,'wave':wave,'is_incident':is_incident,'incident_family':fam,'variant':variant,'severity':severity,
                     'first_family_occurrence':first_family,'first_variant_occurrence':first_variant,'repeat_incident':repeat,
                     'u_detect':rng.random(),'u_repair':rng.random(),'u_fp':rng.random(),'u_validate':rng.random(),'noise':rng.normal(0,.25)})
pd.DataFrame(rows).to_csv(out/'incident_stream.csv',index=False)
print(f'Generated {len(rows)} paired events -> {out/"incident_stream.csv"}')
