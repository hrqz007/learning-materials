#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np, math
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--events',required=True); p.add_argument('--out-dir',required=True); args=p.parse_args()
events=pd.read_csv(args.events); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
regimes=['static','store_all','verified_replay','adaptive_immune']
all_rows=[]; mem_rows=[]
for regime in regimes:
    verified={}; anymem={}; variants={}; bad=0; totalmem=0; spurious=0
    for _,r in events.iterrows():
        fam=str(r.incident_family); sev=int(r.severity); is_inc=int(r.is_incident)==1; var=int(r.variant)
        known_v=verified.get(fam,0); known_any=anymem.get(fam,0); var_seen=var in variants.get(fam,set())
        quality=(totalmem-bad)/totalmem if totalmem else 1.0
        detected=0; fp=0; repair=0; reused=0; reuse_correct=0
        if is_inc:
            if regime=='static': pdet=.70+.04*(sev-1); prep=.68+.03*(sev-1); speed=0
            elif regime=='store_all':
                pdet=(.88 if known_any else .72)-.15*(1-quality); prep=(.84 if known_any else .66)-.20*(1-quality); speed=1.4 if known_any else .2; reused=int(known_any>0)
            elif regime=='verified_replay':
                pdet=.92 if known_v else .72; prep=.91 if known_v else .69; speed=1.8 if known_v else .2; reused=int(known_v>0)
            else:
                if known_v>=2 and var_seen: pdet=.97; prep=.95; speed=2.35; reused=1
                elif known_v>=2: pdet=.90; prep=.86; speed=1.35; reused=1
                elif known_v==1: pdet=.84; prep=.80; speed=.85; reused=1
                else: pdet=.75; prep=.73; speed=.25
            pdet=max(.05,min(.99,pdet)); prep=max(.05,min(.99,prep))
            detected=int(float(r.u_detect)<pdet)
            if detected:
                repair=int(float(r.u_repair)<prep)
                reuse_correct=int(reused and repair)
            base_ttd=4.6-.25*(sev-1)
            ttd=max(.6, base_ttd-speed+float(r.noise)) if detected else 8.0+1.2*sev
            ttr=(ttd + (2.2 if repair else 5.0)) if detected else ttd+5.5
            blast=int(max(1,round(ttd*(.8+.55*sev))))
            # learning update
            if regime=='store_all' and detected:
                totalmem+=1; anymem[fam]=known_any+1
                if not repair: bad+=1
                variants.setdefault(fam,set()).add(var)
                mem_rows.append({'regime':regime,'event_id':r.event_id,'family':fam,'verified':repair,'memory_quality_after':(totalmem-bad)/totalmem})
            elif regime in ['verified_replay','adaptive_immune'] and detected and repair and float(r.u_validate)<.96:
                totalmem+=1; verified[fam]=known_v+1; anymem[fam]=known_any+1; variants.setdefault(fam,set()).add(var)
                mem_rows.append({'regime':regime,'event_id':r.event_id,'family':fam,'verified':1,'memory_quality_after':1.0})
        else:
            if regime=='static': pfp=.02
            elif regime=='store_all': pfp=min(.35,.10+.020*spurious+.15*(1-quality))
            elif regime=='verified_replay': pfp=.02
            else: pfp=.015
            fp=int(float(r.u_fp)<pfp); detected=fp
            ttd=1.0 if fp else 0.0; ttr=2.0 if fp else 0.0; blast=0
            if regime=='store_all' and fp:
                spurious+=1; totalmem+=1; bad+=1
                mem_rows.append({'regime':regime,'event_id':r.event_id,'family':'spurious_benign','verified':0,'memory_quality_after':(totalmem-bad)/totalmem})
        quality=(totalmem-bad)/totalmem if totalmem else 1.0
        all_rows.append({'regime':regime,'event_id':r.event_id,'wave':int(r.wave),'is_incident':int(r.is_incident),'incident_family':fam,'variant':var,'severity':sev,
                         'repeat_incident':int(r.repeat_incident),'first_variant_occurrence':int(r.first_variant_occurrence),'detected':detected,'false_quarantine':fp,'repair_success':repair,'ttd':ttd,'ttr':ttr,
                         'blast_radius':blast,'playbook_reused':reused,'playbook_reuse_correct':reuse_correct,'defense_memory_size':totalmem,'defense_memory_precision':quality})
pd.DataFrame(all_rows).to_csv(out/'defense_event_results.csv',index=False)
pd.DataFrame(mem_rows).to_csv(out/'defense_memory_events.csv',index=False)
print(f'Wrote {len(all_rows)} regime-event rows -> {out}')
