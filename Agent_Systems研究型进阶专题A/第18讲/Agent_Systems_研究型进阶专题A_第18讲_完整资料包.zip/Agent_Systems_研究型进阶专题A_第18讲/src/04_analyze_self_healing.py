#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--results',required=True); p.add_argument('--out-dir',required=True); args=p.parse_args()
df=pd.read_csv(args.results); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
rows=[]
for (reg,w),g in df.groupby(['regime','wave']):
    inc=g[g.is_incident==1]; ben=g[g.is_incident==0]
    rows.append({'regime':reg,'wave':int(w),'incident_n':len(inc),'detection_rate':inc.detected.mean(),'repair_success_rate':inc.repair_success.mean(),
                 'mean_ttd':inc.ttd.mean(),'mean_ttr':inc.ttr.mean(),'mean_blast_radius':inc.blast_radius.mean(),
                 'false_quarantine_rate':ben.false_quarantine.mean() if len(ben) else np.nan,
                 'repeat_repair_success':inc[inc.repeat_incident==1].repair_success.mean() if (inc.repeat_incident==1).any() else np.nan,
                 'novel_repair_success':inc[inc.first_variant_occurrence==1].repair_success.mean() if (inc.first_variant_occurrence==1).any() else np.nan,
                 'final_memory_size':int(g.defense_memory_size.iloc[-1]),'final_memory_precision':g.defense_memory_precision.iloc[-1]})
wave=pd.DataFrame(rows); wave.to_csv(out/'wave_summary.csv',index=False)
over=[]
for reg,g in df.groupby('regime'):
    inc=g[g.is_incident==1]; ben=g[g.is_incident==0]
    over.append({'regime':reg,'detection_rate':inc.detected.mean(),'repair_success_rate':inc.repair_success.mean(),'mean_ttd':inc.ttd.mean(),'mean_ttr':inc.ttr.mean(),
                 'mean_blast_radius':inc.blast_radius.mean(),'false_quarantine_rate':ben.false_quarantine.mean(),
                 'repeat_repair_success':inc[inc.repeat_incident==1].repair_success.mean(),'novel_repair_success':inc[inc.first_variant_occurrence==1].repair_success.mean(),
                 'final_memory_size':int(g.defense_memory_size.iloc[-1]),'final_memory_precision':g.defense_memory_precision.iloc[-1]})
over=pd.DataFrame(over); over.to_csv(out/'overall_summary.csv',index=False)
# known-vs-novel and late-wave learning signal
late=wave[wave.wave>=4].copy(); late.to_csv(out/'late_wave_summary.csv',index=False)
print(over.to_string(index=False))
