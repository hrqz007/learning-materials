#!/usr/bin/env python3
import argparse, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--summary',required=True); p.add_argument('--wave',required=True); p.add_argument('--out',required=True); args=p.parse_args()
s=pd.read_csv(args.summary); w=pd.read_csv(args.wave)
lines=['# A18 Self-Healing Teaching Mock Report','','> Synthetic teaching data only. Do not cite these values as real-model performance.','']
lines += ['## Overall']
for _,r in s.iterrows():
    lines.append(f"- **{r.regime}**: repair={r.repair_success_rate:.1%}, TTD={r.mean_ttd:.2f}, blast={r.mean_blast_radius:.2f}, false-quarantine={r.false_quarantine_rate:.1%}, memory-precision={r.final_memory_precision:.1%}")
lines += ['','## Interpretation','- Static defense does not improve merely because incidents repeat.','- Store-all can learn quickly but may accumulate bad/spurious defense memory.','- Verified replay learns from successful, validated repairs.','- Adaptive immune memory adds a novelty gate so new variants are escalated instead of blindly forcing an old playbook.']
Path(args.out).write_text('\n'.join(lines),encoding='utf-8')
