#!/usr/bin/env python3
"""Safe skeleton for incident triage/recovery. It classifies existing incident traces; it does not generate attacks."""
import argparse, json
p=argparse.ArgumentParser(); p.add_argument('--incident-json',required=True); p.add_argument('--model',default='openai/gpt-4.1-mini'); args=p.parse_args()
try:
    from litellm import completion
except Exception as e:
    raise SystemExit(f'litellm unavailable: {e}')
incident=json.load(open(args.incident_json,encoding='utf-8'))
prompt=(
    "You are an incident triage component for an LLM agent system. Classify the EXISTING failure trace.\n"
    "Return JSON only with: incident_family, confidence_0_1, containment_action, recovery_action, reusable_playbook(bool), reason.\n"
    "Do not invent attack instructions or payloads.\nIncident:\n"
    + json.dumps(incident,ensure_ascii=False)
)
resp=completion(model=args.model,messages=[{'role':'user','content':prompt}],temperature=0)
print(resp.choices[0].message.content)
