# Incident Learning Card

- incident_id:
- family:
- first_seen_at:
- detection_signal:
- containment_action:
- root_cause_evidence:
- verified_repair:
- post_repair_validation:
- reusable_scope:
- known_variants:
- novelty_boundary:
- retirement_condition:
- false_positive_risk:
