# A18 Trace Review

## Incident
- event_id:
- wave:
- family:
- repeat / novel:

## Timings
- detect_at:
- contain_at:
- recover_at:

## Defense memory
- reused card:
- playbook matched:
- novelty gate fired:

## Outcome
- repair success:
- blast radius:
- clean utility impact:

## First bad span / first recovery span
- ...
