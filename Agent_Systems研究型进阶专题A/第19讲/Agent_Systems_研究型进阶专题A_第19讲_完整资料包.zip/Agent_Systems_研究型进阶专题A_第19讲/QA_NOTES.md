# QA Notes

- Teaching Mock is synthetic and must not be reported as real model performance.
- All Python sources passed `compileall` after the final patch.
- Teaching Mock analysis was rerun from the frozen synthetic judgments; `condition_summary.csv`, `memory_swap_check.csv`, and `pilot_gate.json` matched byte-for-byte.
- Prior-evidence bridge successfully read A13 endpoint heterogeneity, A14 longitudinal dynamics, and A15 sharing-boundary artifacts from their ZIP packages.
- DOCX render QA: 01=5 pages, 03=2 pages, 04=2 pages, 05=1 page, 06=1 page, 07=1 page; all pages visually inspected.
- Lecture PDF render QA: 5 pages; all pages independently rendered and visually inspected.
- Dependency check in this build environment: pandas/numpy/scipy/statsmodels=OK; litellm=MISSING. No real commercial-model results were fabricated.
- Pilot Gate thresholds are teaching/staging rules, not universal publication criteria; pre-register real thresholds before confirmatory runs.
