# 第19讲学习说明

本讲是专题 A 的倒数第2讲。目标不是再扩知识面，而是把第13-18讲压缩成一个最小、可证伪、资源可控的论文级机制实验。

核心主链：

Experience Divergence → Functional Heterogeneity → Error Decorrelation → Collective Gain

本讲所有 Teaching Mock 数字都是合成数据，只验证分析管线与论证结构。真正论文必须替换为真实 API/benchmark 结果。
