# Teaching Mock - Paper Table Skeleton

| Condition | Member Error | Spec. Index | Avg phi | Majority Error | Collective Gain |
|---|---:|---:|---:|---:|---:|
| no_memory | 0.143 | -0.019 | 0.292 | 0.122 | 0.020 |
| shared_experience | 0.085 | 0.019 | 0.476 | 0.089 | -0.004 |
| divergent_experience | 0.111 | 0.133 | 0.024 | 0.033 | 0.078 |
| divergent_memory_off | 0.143 | -0.019 | 0.292 | 0.122 | 0.020 |
| memory_swap | 0.113 | -0.097 | 0.043 | 0.039 | 0.074 |
| full_share_boundary | 0.080 | 0.028 | 0.445 | 0.072 | 0.007 |

## Memory-swap manipulation check
| agent   | divergent_best_family   | memory_swap_best_family   | expected_swap_family   |   swap_follows_bank |
|:--------|:------------------------|:--------------------------|:-----------------------|--------------------:|
| P       | policy                  | evidence                  | evidence               |                   1 |
| E       | evidence                | parameter                 | parameter              |                   1 |
| R       | parameter               | policy                    | policy                 |                   1 |

> Teaching Mock only. Real paper must replace all values with registered real experiment results.