#!/usr/bin/env python3
import argparse, zipfile, io, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--a13',required=True); p.add_argument('--a14',required=True); p.add_argument('--a15',required=True); p.add_argument('--out',required=True); args=p.parse_args()
rows=[]
def read_csv_from_zip(zpath, suffix):
    with zipfile.ZipFile(zpath) as z:
        names=[n for n in z.namelist() if n.endswith(suffix)]
        if not names: return None
        return pd.read_csv(io.BytesIO(z.read(names[0])))
# A13 endpoint evidence
for label,z,suf in [
    ('A13 endpoint heterogeneity',args.a13,'outputs/teaching_mock/condition_summary.csv'),
    ('A14 longitudinal dynamics',args.a14,'outputs/teaching_mock/checkpoint_summary.csv'),
    ('A15 sharing boundary',args.a15,'outputs/teaching_mock/sharing_dynamics.csv')]:
    df=read_csv_from_zip(z,suf)
    if df is None: rows.append({'source':label,'status':'MISSING','rows':0,'note':suf})
    else: rows.append({'source':label,'status':'FOUND','rows':len(df),'note':','.join(df.columns[:8])})
out=Path(args.out); out.parent.mkdir(parents=True,exist_ok=True); pd.DataFrame(rows).to_csv(out,index=False)
print(pd.DataFrame(rows).to_string(index=False))
