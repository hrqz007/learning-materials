#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--out-dir',required=True); p.add_argument('--seed',type=int,default=1901); p.add_argument('--n-per-family',type=int,default=60); args=p.parse_args()
rng=np.random.default_rng(args.seed); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
fams=['policy','evidence','parameter']; agents=['P','E','R']; own={'P':'policy','E':'evidence','R':'parameter'}
conditions=['no_memory','shared_experience','divergent_experience','divergent_memory_off','memory_swap','full_share_boundary']
cases=[]
for f in fams:
    for i in range(args.n_per_family):
        cases.append({'case_id':f'{f[:3]}_{i:03d}','task_family':f,'risk':int(rng.choice([0,1],p=[.65,.35])),'difficulty':float(rng.beta(2.2,3.3)),'block':i%4})
cases=pd.DataFrame(cases); cases.to_csv(out/'cases.csv',index=False)
rows=[]
# paired random numbers per case/agent to make conditions comparable
base_random={}
for _,r in cases.iterrows():
    for a in agents:
        base_random[(r.case_id,a)]={'u':rng.random(),'u2':rng.random(),'z':rng.normal()}
for _,r in cases.iterrows():
    d=float(r.difficulty); f=r.task_family
    shared_u=float(rng.random())
    for a in agents:
        rr=base_random[(r.case_id,a)]
        for c in conditions:
            # p_err and common-weight define ability + error coupling
            if c in ['no_memory','divergent_memory_off']:
                p_err=.17+.23*d; common=.55
            elif c=='shared_experience':
                p_err=.10+.18*d; common=.78
            elif c=='divergent_experience':
                p_err=(.035+.09*d) if own[a]==f else (.15+.20*d); common=.16
            elif c=='memory_swap':
                # rotate banks: P gets evidence, E gets parameter, R gets policy
                bank={'P':'evidence','E':'parameter','R':'policy'}[a]
                p_err=(.025+.07*d) if bank==f else (.16+.21*d); common=.16
            else: # full share boundary
                p_err=.095+.18*d; common=.76
            score=common*shared_u+(1-common)*rr['u']
            err=int(score<p_err)
            # for causal clarity, memory-off exactly reuses no-memory judgment
            if c=='divergent_memory_off':
                pass
            rows.append({'case_id':r.case_id,'task_family':f,'block':int(r.block),'risk':int(r.risk),'agent':a,'condition':c,'error':err,'correct':1-err})
jud=pd.DataFrame(rows)
# force memory-off to equal no-memory row-by-row
nm=jud[jud.condition=='no_memory'][['case_id','agent','error','correct']].rename(columns={'error':'error_nm','correct':'correct_nm'})
idx=jud.condition=='divergent_memory_off'; tmp=jud.loc[idx].merge(nm,on=['case_id','agent'],how='left')
jud.loc[idx,'error']=tmp.error_nm.to_numpy(); jud.loc[idx,'correct']=tmp.correct_nm.to_numpy()
jud.to_csv(out/'judgments.csv',index=False)
print(f'Generated {len(cases)} cases and {len(jud)} judgments -> {out}')
