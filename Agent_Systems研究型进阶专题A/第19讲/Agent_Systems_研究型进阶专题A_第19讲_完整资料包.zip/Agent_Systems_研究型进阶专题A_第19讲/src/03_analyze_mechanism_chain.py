#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np, math
from itertools import combinations
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--cases',required=True); p.add_argument('--judgments',required=True); p.add_argument('--out-dir',required=True); args=p.parse_args()
cases=pd.read_csv(args.cases); j=pd.read_csv(args.judgments); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True)
own={'P':'policy','E':'evidence','R':'parameter'}
def phi(x,y):
    a=np.asarray(x,dtype=int); b=np.asarray(y,dtype=int); n11=((a==1)&(b==1)).sum(); n10=((a==1)&(b==0)).sum(); n01=((a==0)&(b==1)).sum(); n00=((a==0)&(b==0)).sum(); den=math.sqrt((n11+n10)*(n01+n00)*(n11+n01)*(n10+n00)); return (n11*n00-n10*n01)/den if den else np.nan
# agent-family matrix
fam=[]
for (c,a,f),g in j.groupby(['condition','agent','task_family']): fam.append({'condition':c,'agent':a,'task_family':f,'error_rate':g.error.mean(),'n':len(g)})
fam=pd.DataFrame(fam); fam.to_csv(out/'agent_family_matrix.csv',index=False)
# specialization index: own-family accuracy - out-family accuracy
spec=[]
for (c,a),g in j.groupby(['condition','agent']):
    ownacc=g[g.task_family==own[a]].correct.mean(); outacc=g[g.task_family!=own[a]].correct.mean(); spec.append({'condition':c,'agent':a,'own_accuracy':ownacc,'out_accuracy':outacc,'specialization_index':ownacc-outacc})
pd.DataFrame(spec).to_csv(out/'specialization.csv',index=False)
# pairwise error structure
pairs=[]
for c,gc in j.groupby('condition'):
    piv=gc.pivot_table(index='case_id',columns='agent',values='error',aggfunc='first')
    for a,b in combinations(['P','E','R'],2):
        pairs.append({'condition':c,'pair':a+'-'+b,'phi':phi(piv[a],piv[b]),'double_fault':float(((piv[a]==1)&(piv[b]==1)).mean())})
pairs=pd.DataFrame(pairs); pairs.to_csv(out/'pairwise_error_structure.csv',index=False)
# system outcomes
summ=[]
for c,gc in j.groupby('condition'):
    piv=gc.pivot_table(index='case_id',columns='agent',values='error',aggfunc='first')
    maj=(piv.sum(axis=1)>=2).astype(int); oracle=(piv.min(axis=1)==0).astype(int)
    member_err=float(gc.error.mean()); maj_err=float(maj.mean()); best=float(gc.groupby('agent').error.mean().min())
    summ.append({'condition':c,'mean_member_error':member_err,'best_member_error':best,'majority_error':maj_err,'oracle_coverage':float(oracle.mean()),'collective_gain_vs_mean':member_err-maj_err,'avg_phi':pairs[pairs.condition==c].phi.mean(),'avg_specialization':pd.DataFrame(spec).query('condition==@c').specialization_index.mean()})
summ=pd.DataFrame(summ); summ.to_csv(out/'condition_summary.csv',index=False)
# block-level mechanism consistency
blocks=[]
for (c,f,b),g in j.groupby(['condition','task_family','block']):
    if g.case_id.nunique()<5: continue
    piv=g.pivot_table(index='case_id',columns='agent',values='error',aggfunc='first')
    vals=[phi(piv[a],piv[b]) for a,b in combinations(['P','E','R'],2)]; finite=[v for v in vals if not np.isnan(v)]; ph=float(np.mean(finite)) if finite else np.nan
    maj=(piv.sum(axis=1)>=2).mean(); mem=g.error.mean()
    blocks.append({'condition':c,'task_family':f,'block':b,'mean_member_error':mem,'avg_phi':ph,'majority_error':maj,'collective_gain':mem-maj})
pd.DataFrame(blocks).to_csv(out/'mechanism_blocks.csv',index=False)
# causal checks: specialization follows swapped bank identity
swap_map={'P':'evidence','E':'parameter','R':'policy'}
checks=[]
for a in ['P','E','R']:
    de=fam[(fam.condition=='divergent_experience')&(fam.agent==a)].sort_values('error_rate').iloc[0].task_family
    sw=fam[(fam.condition=='memory_swap')&(fam.agent==a)].sort_values('error_rate').iloc[0].task_family
    checks.append({'agent':a,'divergent_best_family':de,'memory_swap_best_family':sw,'expected_swap_family':swap_map[a],'swap_follows_bank':int(sw==swap_map[a])})
pd.DataFrame(checks).to_csv(out/'memory_swap_check.csv',index=False)
print(summ.to_string(index=False))
