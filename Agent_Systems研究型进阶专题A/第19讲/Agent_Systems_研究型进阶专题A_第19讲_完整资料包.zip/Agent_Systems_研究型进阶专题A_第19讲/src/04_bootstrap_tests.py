#!/usr/bin/env python3
import argparse, pandas as pd, numpy as np
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--judgments',required=True); p.add_argument('--out-dir',required=True); p.add_argument('--seed',type=int,default=19); p.add_argument('--B',type=int,default=1000); args=p.parse_args()
j=pd.read_csv(args.judgments); out=Path(args.out_dir); out.mkdir(parents=True,exist_ok=True); rng=np.random.default_rng(args.seed)
# paired bootstrap by case for majority-error differences
conds=['shared_experience','divergent_experience','divergent_memory_off','memory_swap','full_share_boundary']
base='no_memory'
def maj_by_case(df,cond):
    x=df[df.condition==cond].pivot_table(index='case_id',columns='agent',values='error',aggfunc='first'); return (x.sum(axis=1)>=2).astype(int)
allm={c:maj_by_case(j,c) for c in [base]+conds}
ids=allm[base].index.to_numpy(); rows=[]
for c in conds:
    diffs=[]
    for _ in range(args.B):
        samp=rng.choice(ids,size=len(ids),replace=True); diffs.append(float(allm[c].loc[samp].mean()-allm[base].loc[samp].mean()))
    rows.append({'contrast':f'{c}-no_memory','delta_majority_error':float(allm[c].mean()-allm[base].mean()),'ci_low':float(np.quantile(diffs,.025)),'ci_high':float(np.quantile(diffs,.975))})
pd.DataFrame(rows).to_csv(out/'bootstrap_majority_contrasts.csv',index=False)
# simple descriptive mechanism regression on condition-family-block strata
mb_path=out.parent/'mechanism_blocks.csv'
if mb_path.exists():
    mb=pd.read_csv(mb_path).dropna()
    try:
        import statsmodels.api as sm
        X=sm.add_constant(mb[['mean_member_error','avg_phi']]); fit=sm.OLS(mb['collective_gain'],X).fit()
        (out/'mechanism_regression.txt').write_text(fit.summary().as_text(),encoding='utf-8')
    except Exception as e:
        (out/'mechanism_regression.txt').write_text('Regression unavailable: '+repr(e),encoding='utf-8')
print(pd.DataFrame(rows).to_string(index=False))
