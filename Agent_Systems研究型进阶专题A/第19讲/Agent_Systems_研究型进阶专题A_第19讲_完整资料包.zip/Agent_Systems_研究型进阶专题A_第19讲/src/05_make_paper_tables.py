#!/usr/bin/env python3
import argparse, pandas as pd
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--summary',required=True); p.add_argument('--swap',required=True); p.add_argument('--out',required=True); args=p.parse_args()
s=pd.read_csv(args.summary); sw=pd.read_csv(args.swap)
order=['no_memory','shared_experience','divergent_experience','divergent_memory_off','memory_swap','full_share_boundary']; s['ord']=s.condition.map({c:i for i,c in enumerate(order)}); s=s.sort_values('ord')
lines=['# Teaching Mock - Paper Table Skeleton','','| Condition | Member Error | Spec. Index | Avg phi | Majority Error | Collective Gain |','|---|---:|---:|---:|---:|---:|']
for _,r in s.iterrows(): lines.append(f"| {r.condition} | {r.mean_member_error:.3f} | {r.avg_specialization:.3f} | {r.avg_phi:.3f} | {r.majority_error:.3f} | {r.collective_gain_vs_mean:.3f} |")
lines+=['','## Memory-swap manipulation check',sw.to_markdown(index=False),'','> Teaching Mock only. Real paper must replace all values with registered real experiment results.']
Path(args.out).write_text('\n'.join(lines),encoding='utf-8')
print(args.out)
