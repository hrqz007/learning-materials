#!/usr/bin/env python3
import argparse, pandas as pd, json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--summary',required=True); p.add_argument('--swap',required=True); p.add_argument('--out',required=True); args=p.parse_args()
s=pd.read_csv(args.summary).set_index('condition'); sw=pd.read_csv(args.swap)
# These are pilot decision gates, not universal publication criteria.
gates={}
gates['memory_dependence']=bool(s.loc['divergent_memory_off','majority_error'] >= s.loc['divergent_experience','majority_error'] + .03)
gates['specialization_present']=bool(s.loc['divergent_experience','avg_specialization'] >= .04)
gates['decorrelation_present']=bool(s.loc['divergent_experience','avg_phi'] <= s.loc['shared_experience','avg_phi'] - .10)
gates['collective_gain_present']=bool(s.loc['divergent_experience','collective_gain_vs_mean'] >= .03)
gates['swap_follows_bank']=bool(sw.swap_follows_bank.mean()>=.67)
gates['boundary_recoupling']=bool(s.loc['full_share_boundary','avg_phi'] >= s.loc['divergent_experience','avg_phi'] + .10)
gates['scale_to_full_experiment']=all(gates.values())
Path(args.out).write_text(json.dumps(gates,indent=2,ensure_ascii=False),encoding='utf-8')
print(json.dumps(gates,indent=2,ensure_ascii=False))
