#!/usr/bin/env python3
import argparse, json
from pathlib import Path
p=argparse.ArgumentParser(); p.add_argument('--out',required=True); p.add_argument('--model',default='MODEL_TO_SET'); p.add_argument('--user-model',default='USER_MODEL_TO_SET'); p.add_argument('--tasks',type=int,default=30); p.add_argument('--trials',type=int,default=2); args=p.parse_args()
manifest={
 'benchmark':'tau2-bench v1.0.1 / text half-duplex',
 'primary_domain':'retail',
 'agent_model':args.model,'user_simulator_model':args.user_model,
 'fixed':{'base_model':True,'system_prompt':True,'role':True,'tools':True,'temperature':True,'memory_capacity':True,'retrieval_top_k':True},
 'conditions':['no_memory','shared_experience','divergent_experience','divergent_memory_off','memory_swap'],
 'boundary_condition':'full_share_boundary',
 'heldout_tasks':args.tasks,'trials':args.trials,'agents_per_condition':3,
 'estimated_agent_trajectories_core':args.tasks*args.trials*3*5,
 'pilot_gate':'Run 10 tasks first. Scale only if manipulation check + specialization + decorrelation + collective gain are directionally present.',
 'primary_metrics':['specialization_index','pairwise_error_phi','double_fault','majority_error','oracle_coverage','collective_gain'],
 'secondary_metrics':['cost','latency','retrieval_hit','memory_usage','failure_family'],
 'do_not_claim':['causal mediation from correlation alone','general multi-agent superiority','experience effect without memory-off or swap manipulation checks']
}
Path(args.out).write_text(json.dumps(manifest,indent=2,ensure_ascii=False),encoding='utf-8'); print(json.dumps(manifest,indent=2,ensure_ascii=False))
