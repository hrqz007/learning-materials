# A19 Failure Case Card

- case_id:
- task_family:
- condition:
- agent:
- retrieved_experience_ids:
- first_bad_span:
- failure_type:
- did experience help/harm?:
- did another agent fail differently?:
- implication for mechanism chain:
