# A19 Hypothesis / Pre-registration Card

- H1 Experience manipulation:
- H2 Functional heterogeneity:
- H3 Error decorrelation:
- H4 Collective gain:
- H5 Memory-off / memory-swap causal check:
- Boundary: Full-share recoupling:
- Primary metric:
- Minimum effect worth scaling:
- Pilot stop rule:
- Falsification pattern that would reject the story:
