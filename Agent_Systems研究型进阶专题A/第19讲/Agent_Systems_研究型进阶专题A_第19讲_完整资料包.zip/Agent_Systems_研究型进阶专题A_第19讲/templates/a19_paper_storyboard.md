# A19 Paper Storyboard

1. Phenomenon: same initial agents develop functional differences under divergent experience streams.
2. Mechanism: differences change who fails where, not only mean accuracy.
3. System effect: lower correlated failure improves aggregation.
4. Causal checks: memory-off + memory-swap.
5. Boundary: full sharing can recouple errors.
6. Limitations: one benchmark/domain/model does not establish universality.
