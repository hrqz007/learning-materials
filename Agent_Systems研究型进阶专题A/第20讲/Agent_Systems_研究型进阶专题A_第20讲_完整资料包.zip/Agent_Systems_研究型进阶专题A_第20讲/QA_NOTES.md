# QA Notes — 第20讲（最终）

## 文档渲染
- 01_零基础讲义.docx：6 页，逐页检查通过。
- 03_实验指导书.docx：2 页，逐页检查通过。
- 04_实验设计书.docx：2 页，逐页检查通过。
- 05_练习题.docx：1 页，逐页检查通过。
- 06_练习题答案.docx：1 页，逐页检查通过。
- 07_术语速查表.docx：1 页，逐页检查通过。
- 02_零基础讲义.pdf：6 页，使用独立 PDF renderer 逐页检查通过。

## 代码 / 项目功能 QA
- Python `compileall`：通过。
- `src/00_project_package_check.py`：A20_PROJECT_PACKAGE_OK。
- Manifest validation：通过。
- Dry-run planner：Smoke=90、Pilot=300、Confirmatory=900 planned trajectories。
- Teaching Pilot Gate：manipulation / heterogeneity / decorrelation / collective 全部通过（教学合成数据，仅用于验证流程）。
- 第19讲 Teaching Mock 已接入第20讲项目分析骨架并重新分析成功。
- Project reproducibility SHA256 audit：通过。

## 当前制作环境依赖实测
- pandas: OK
- numpy: OK
- scipy: OK
- statsmodels: OK
- litellm: MISSING
- tau2: MISSING

因此：真实 API / τ³-bench 实验未在资料制作环境伪造执行。正式开工时必须先在真实 tau2-bench v1.0.1 环境执行 `src/00_preflight.py`。
