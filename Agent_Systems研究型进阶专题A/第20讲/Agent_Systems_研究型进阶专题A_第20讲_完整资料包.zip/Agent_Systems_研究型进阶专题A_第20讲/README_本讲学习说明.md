# 第20讲学习说明

这是《Agent Systems 研究型进阶专题 A》的最后一讲。

本讲不再扩展新知识，而是把第19讲的论文级机制链转换成可直接执行的项目目录。

**课程结束后的下一动作：** 打开 `project/experience_divergence_paper/README.md`，运行 `python src/00_preflight.py`，冻结真实 manifest，然后开始 Smoke Test。

不要继续设计“第21讲”。后续学习由真实实验中的 blocker、Failure Trace 和审稿需求触发。
