# Decision Gates

## Gate 0 — Engineering validity
PASS only if task IDs align across conditions, schemas validate, retrieval state is observable, and infra errors are separated from model failures.

## Gate 1 — Manipulation
PASS if experience/memory is demonstrably used and Memory-Off changes behavior in the expected direction.

## Gate 2 — Functional heterogeneity
PASS if C2 creates stable agent × task-family specialization beyond C1.

## Gate 3 — Error decorrelation
PASS if C2 reduces pairwise error phi and/or double-fault relative to C1.

## Gate 4 — Collective consequence
PASS if fixed majority benefits from the new error structure.

## Responses to failure
- Gate 0 fail: fix implementation and rerun.
- Gate 1 fail: memory manipulation invalid; stop scientific interpretation.
- Gate 2 fail: reject current experience manipulation.
- Gate 3 fail: pivot to “specialization without complementary errors”.
- Gate 4 fail: pivot to aggregation/usability bottleneck.

Never scale simply because one metric looks promising.
