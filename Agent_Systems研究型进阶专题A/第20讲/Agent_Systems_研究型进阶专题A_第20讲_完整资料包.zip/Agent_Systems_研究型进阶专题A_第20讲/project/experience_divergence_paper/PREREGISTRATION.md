# Preregistration (fill before Confirmatory)

## RQ1
Does experience divergence induce stable family-specific functional heterogeneity?

## RQ2
Does that heterogeneity reduce pairwise error correlation / double-fault?

## RQ3
Does the changed error structure produce collective gain under fixed majority aggregation?

## Primary contrast
C2 Divergent Experience vs C1 Shared Experience.

## Mechanism checks
- C2 vs C3 Memory-Off
- C2 vs C4 Memory-Swap

## Boundary check
C5 Full-Share after divergent experience.

## Primary metrics
- specialization_index
- pairwise_error_phi
- double_fault
- majority_error
- collective_gain

## Secondary metrics
- memory_retrieval_hit
- cost_usd
- latency_s
- failure_family
- oracle_coverage

## Pilot minimum directional pattern required to scale
- memory usage observable / Memory-Off rollback
- C2 specialization > C1
- C2 phi or double-fault < C1
- C2 majority error < C1 and collective_gain > 0

## Falsification pattern
[Fill before Confirmatory]
