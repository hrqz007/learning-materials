# Project Charter

## Working title
Experience Divergence Induces Functional Heterogeneity and Error Decorrelation in Persistent LLM Agent Teams

## Scientific object
Persistent LLM agents with identical base configuration but different long-term experience streams.

## Primary claim to test
Different long-term experiences can induce functional heterogeneity that changes error correlation and can be exploited by a fixed aggregation rule.

## In scope
- experience stream manipulation
- memory on/off and memory swap
- task-family specialization
- pairwise error structure
- fixed majority aggregation
- full-share boundary

## Out of scope for paper 1
- memory poisoning / self-healing as a primary contribution
- dynamic communication topology
- new foundation-model training
- SOTA benchmark leaderboard claim
- complex learned router as primary contribution

## Falsification
The main story is rejected if divergent experience does not produce stable functional heterogeneity, does not reduce shared failure, or does not yield collective gain under the frozen analysis.
