# Experience Divergence → Functional Heterogeneity → Error Decorrelation → Collective Gain

## Start here

1. Read `PROJECT_CHARTER.md`.
2. Read/fill `PREREGISTRATION.md`.
3. Copy `configs/experiment_manifest.example.json` to `configs/experiment_manifest.json`.
4. Run:

```bash
python src/00_preflight.py
python src/01_validate_manifest.py configs/experiment_manifest.json
python src/02_plan_experiment.py configs/experiment_manifest.json --phase smoke
```

5. Inspect `outputs/teaching_dryrun/planned_runs_smoke.csv`.
6. Only then implement/run the real τ³-bench Smoke pipeline.

## Non-negotiable

- Do not fabricate missing task-family labels.
- Do not mix training/experience cases with held-out evaluation cases.
- Do not change primary metrics after Confirmatory begins.
- Do not hand-edit result CSVs used for paper figures.
- Do not automatically scale when a Pilot Gate fails.

## Paper core

C0 No Memory; C1 Shared Experience; C2 Divergent Experience; C3 Memory-Off; C4 Memory-Swap.
C5 Full-Share is a boundary experiment.

Primary mechanism chain: `Experience Divergence → Functional Heterogeneity → Error Decorrelation → Collective Gain`.
