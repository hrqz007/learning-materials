# Confirmatory Checklist
- [ ] preregistration frozen before data generation
- [ ] git commit recorded
- [ ] task list frozen
- [ ] no prompt/model/metric drift
- [ ] raw outputs immutable
- [ ] all missing runs documented
- [ ] paired analysis only on aligned cases
