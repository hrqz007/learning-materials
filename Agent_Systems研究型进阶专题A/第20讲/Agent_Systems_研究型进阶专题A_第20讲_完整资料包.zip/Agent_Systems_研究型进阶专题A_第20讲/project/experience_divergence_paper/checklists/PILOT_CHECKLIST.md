# Pilot Checklist
- [ ] preregistration draft saved
- [ ] 10 tasks and 2 trials frozen
- [ ] all five core conditions complete
- [ ] Gate 1 manipulation
- [ ] Gate 2 specialization
- [ ] Gate 3 decorrelation
- [ ] Gate 4 collective gain
- [ ] projected confirmatory cost calculated
- [ ] explicit GO / STOP / PIVOT decision written
