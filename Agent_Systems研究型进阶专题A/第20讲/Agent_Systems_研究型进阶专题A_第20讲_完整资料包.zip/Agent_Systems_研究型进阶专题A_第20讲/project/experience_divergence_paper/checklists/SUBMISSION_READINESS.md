# Submission Readiness
- [ ] figures/tables rebuild from raw outputs
- [ ] all paper numbers trace to scripts
- [ ] conditions and versions fully documented
- [ ] failure cases include contrary evidence, not only successes
- [ ] limitations include benchmark/domain/model scope
- [ ] no Teaching Mock numbers in paper results
- [ ] independent analysis rerun matches stored outputs
