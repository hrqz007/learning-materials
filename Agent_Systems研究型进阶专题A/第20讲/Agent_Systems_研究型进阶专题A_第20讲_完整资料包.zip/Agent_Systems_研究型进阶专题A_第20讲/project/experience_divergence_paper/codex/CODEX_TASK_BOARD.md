# Codex Task Board

## Phase 0 — Repo and preflight
- [ ] validate manifest
- [ ] dependency/version audit
- [ ] schema unit tests
- [ ] dry-run plan
- [ ] cost projection placeholder

## Phase 1 — Smoke runner
- [ ] load frozen task IDs
- [ ] C0/C1/C2/C3/C4 construction
- [ ] retrieval logging
- [ ] raw output persistence
- [ ] retry/infra-error handling

## Phase 2 — Pilot
- [ ] 10-task run plan
- [ ] two trials / paired cases
- [ ] mechanism summary
- [ ] Pilot Gate report

## Phase 3 — Confirmatory
- [ ] freeze preregistration hash
- [ ] run 30-task plan
- [ ] no config drift
- [ ] analysis + CI

## Phase 4 — Paper
- [ ] figure scripts
- [ ] table scripts
- [ ] failure-case cards
- [ ] reproduction audit
