# Teaching Dry-Run Data
These are synthetic/teaching-only files copied or generated to test project plumbing. **Never use these rows as paper results.**
