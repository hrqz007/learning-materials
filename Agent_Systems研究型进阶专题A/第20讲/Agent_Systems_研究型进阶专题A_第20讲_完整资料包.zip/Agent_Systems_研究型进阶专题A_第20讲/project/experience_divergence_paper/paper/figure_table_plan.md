# Figure / Table Plan

## Figure 1 — Mechanism chain and conditions
A conceptual diagram, not a result plot.

## Figure 2 — Agent × Task-family specialization matrix
Show C1 vs C2; optionally C4 swap.

## Figure 3 — Error correlation structure
Pairwise phi / double-fault for C1 vs C2.

## Figure 4 — Individual vs collective performance
Mean member error and majority error with paired CI.

## Figure 5 — Causal checks
Memory-Off rollback and Memory-Swap specialty transfer.

## Table 1 — Experiment conditions / frozen variables
## Table 2 — Main metrics with 95% CI
## Table 3 — Failure taxonomy / cost / latency (secondary)
