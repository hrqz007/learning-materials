# Paper Outline

## 1 Introduction
Problem: persistent agents may diverge through experience; system consequence is poorly understood.

## 2 Related Work
Agent memory; experience reuse; multi-agent diversity; error correlation; collective intelligence.

## 3 Research Question and Hypotheses
Experience divergence → functional heterogeneity → error decorrelation → collective gain.

## 4 Method
Benchmark, tasks, experience streams, conditions C0-C5, fixed variables, metrics.

## 5 Results
5.1 manipulation checks  
5.2 functional heterogeneity  
5.3 error structure  
5.4 collective gain  
5.5 Memory-Off / Swap  
5.6 Full-Share boundary

## 6 Failure Analysis
When heterogeneity fails, negative transfer, shared blind spots, retrieval failures.

## 7 Discussion
What experience-induced heterogeneity means for persistent agent teams; limitations.

## 8 Conclusion
No SOTA claim; mechanism-focused contribution.
