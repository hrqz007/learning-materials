# Results Writing Guardrails

Use these only after real results exist. Replace brackets with script-generated values.

- “Compared with Shared Experience, Divergent Experience changed the specialization index by [Δ] (paired bootstrap 95% CI [L, U]).”
- “Pairwise error correlation changed from [x] to [y]; this is evidence of a changed error structure, not by itself proof of causal mediation.”
- “Under the fixed majority rule, collective gain was [g].”
- “Memory-Off caused [rollback/no rollback], while Memory-Swap caused [bank-following/no bank-following], supporting / failing to support the experience-dependence interpretation.”

Never write “significantly better” unless the registered analysis supports that wording.
