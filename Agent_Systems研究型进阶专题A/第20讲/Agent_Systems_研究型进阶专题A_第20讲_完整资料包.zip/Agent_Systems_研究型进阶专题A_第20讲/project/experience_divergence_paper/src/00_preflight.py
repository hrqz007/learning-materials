import importlib.util, json, platform, subprocess
from pathlib import Path
mods=["pandas","numpy","scipy","statsmodels","litellm","tau2"]
print("Python",platform.python_version())
for m in mods:
    print(f"{m}: {'OK' if importlib.util.find_spec(m) else 'MISSING'}")
try:
    out=subprocess.check_output(["git","--version"],text=True).strip(); print(out)
except Exception as e: print("git: ERROR",e)
print("Project root:",Path(__file__).resolve().parents[1])
