import json,sys
from pathlib import Path
REQ=["project","benchmark","models","conditions","phases","primary_metrics","budget_guard"]
p=Path(sys.argv[1] if len(sys.argv)>1 else "configs/experiment_manifest.example.json")
d=json.loads(p.read_text(encoding="utf-8"))
missing=[k for k in REQ if k not in d]
assert not missing, f"Missing top-level fields: {missing}"
assert len(d["conditions"])==5, "Core design expects five core conditions"
for phase in ["smoke","pilot","confirmatory"]:
    for k in ["tasks","trials","agents"]: assert k in d["phases"][phase]
assert d["seed_policy"]["paired_cases_across_conditions"] is True
print("MANIFEST_OK",p)
