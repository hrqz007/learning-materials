import json,csv,argparse
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument("manifest"); ap.add_argument("--phase",choices=["smoke","pilot","confirmatory"],default="smoke"); ap.add_argument("--out",default=None); args=ap.parse_args()
d=json.loads(Path(args.manifest).read_text(encoding="utf-8")); ph=d["phases"][args.phase]
out=Path(args.out or f"outputs/teaching_dryrun/planned_runs_{args.phase}.csv"); out.parent.mkdir(parents=True,exist_ok=True)
rows=[]
for ti in range(ph["tasks"]):
  task=f"TASK_{ti+1:03d}"
  for trial in range(ph["trials"]):
    for cond in d["conditions"]:
      for ai in range(ph["agents"]):
        rows.append([args.phase,task,trial,cond,f"Agent_{ai+1}",d["seed_policy"]["master_seed"]+trial])
with out.open("w",newline="",encoding="utf-8") as f:
  w=csv.writer(f); w.writerow(["phase","task_id","trial","condition","agent_id","seed"]); w.writerows(rows)
print("PLANNED",len(rows),"trajectories ->",out)
