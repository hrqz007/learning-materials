import json, csv
from pathlib import Path
out=Path("outputs/teaching_dryrun"); out.mkdir(parents=True,exist_ok=True)
# Synthetic pilot summary only: verifies decision-gate plumbing, not scientific evidence.
rows=[
 ["shared_experience",0.03,0.42,0.12,0.08],
 ["divergent_experience",0.14,0.08,0.04,0.11],
 ["divergent_memory_off",0.01,0.39,0.11,0.02],
]
with (out/"synthetic_pilot_summary.csv").open("w",newline="",encoding="utf-8") as f:
 w=csv.writer(f); w.writerow(["condition","specialization_index","pairwise_phi","majority_error","collective_gain"]); w.writerows(rows)
print("TEACHING_ONLY",out/"synthetic_pilot_summary.csv")
