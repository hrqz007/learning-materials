import csv,json,sys
from pathlib import Path
p=Path(sys.argv[1] if len(sys.argv)>1 else "outputs/teaching_dryrun/synthetic_pilot_summary.csv")
rows={r["condition"]:r for r in csv.DictReader(p.open(encoding="utf-8"))}
c1=rows["shared_experience"]; c2=rows["divergent_experience"]; c3=rows["divergent_memory_off"]
res={
 "manipulation": float(c3["specialization_index"]) < float(c2["specialization_index"]),
 "heterogeneity": float(c2["specialization_index"]) > float(c1["specialization_index"]),
 "decorrelation": float(c2["pairwise_phi"]) < float(c1["pairwise_phi"]),
 "collective": float(c2["majority_error"]) < float(c1["majority_error"]) and float(c2["collective_gain"])>0,
}
res["decision"]="GO_CONFIRMATORY" if all(res.values()) else "STOP_OR_PIVOT"
out=p.parent/"pilot_gate_teaching.json"; out.write_text(json.dumps(res,indent=2),encoding="utf-8"); print(json.dumps(res,indent=2)); print("TEACHING_ONLY",out)
