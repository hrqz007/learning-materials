import argparse,hashlib,csv
from pathlib import Path
ap=argparse.ArgumentParser(); ap.add_argument("root",nargs="?",default="."); args=ap.parse_args(); root=Path(args.root)
rows=[]
for p in sorted(root.rglob("*")):
 if p.is_file() and ".git" not in p.parts and p.name!="FILE_SHA256.tsv":
  h=hashlib.sha256(p.read_bytes()).hexdigest(); rows.append((str(p.relative_to(root)),h,p.stat().st_size))
out=root/"FILE_SHA256.tsv"
with out.open("w",newline="",encoding="utf-8") as f:
 w=csv.writer(f,delimiter="	"); w.writerow(["path","sha256","bytes"]); w.writerows(rows)
print("AUDIT_HASHES",len(rows),"->",out)
