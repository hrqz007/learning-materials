from pathlib import Path
root=Path(__file__).resolve().parents[1]
required=["project/experience_divergence_paper/README.md","project/experience_divergence_paper/PROJECT_CHARTER.md","project/experience_divergence_paper/PREREGISTRATION.md","project/experience_divergence_paper/DECISION_GATES.md","project/experience_divergence_paper/codex/CODEX_MASTER_PROMPT.md"]
missing=[x for x in required if not (root/x).exists()]
assert not missing, missing
print("A20_PROJECT_PACKAGE_OK")
