"""01_fixed_program.py
固定流程程序：它能完成任务，但控制逻辑全部由程序员预先写死。
"""

def main():
    # 第1步：程序员明确写死“先计算”。
    result = 23 * 17
    print(f"[固定程序] 计算结果: {result}")

    # 第2步：程序员明确写死“再保存”。
    notes = []
    notes.append(f"23*17={result}")
    print("[固定程序] 已保存到 notes")

    # 第3步：程序员明确写死“最后读取”。
    print("[固定程序] 当前 notes:", notes)


if __name__ == "__main__":
    main()
