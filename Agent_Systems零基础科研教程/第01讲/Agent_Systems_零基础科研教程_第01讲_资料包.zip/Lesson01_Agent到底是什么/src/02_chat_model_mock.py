"""02_chat_model_mock.py
模拟“只会生成文字”的聊天模型。
注意：这不是 LLM，只是为了演示“说已经做了”不等于外部动作真的发生。
"""

def mock_chat_model(user_message: str) -> str:
    if "23" in user_message and "17" in user_message:
        return "23×17=391。我已经帮你记下来了。"
    return "我理解了你的问题。"


def main():
    user_message = "计算23×17，并把结果记下来。"
    reply = mock_chat_model(user_message)
    print("[Mock Chat]", reply)

    # 关键：这里根本没有 notes 存储，也没有 save_note 工具。
    print("[现实检查] 程序中没有任何可读取的 notes 状态。")


if __name__ == "__main__":
    main()
