"""03_minimal_agent.py
第一讲的“透明版最小 Agent System”。

它包含：
- MockDecisionModel：模拟决策核心（不是 LLM）
- Tools：calculator / save_note / read_notes
- State：history / last_result / notes
- Agent Loop：观察 -> 决策 -> 行动 -> 反馈

只使用 Python 标准库，不需要网络和 API Key。
"""

from __future__ import annotations
from dataclasses import dataclass, field
from typing import Any, Callable
import ast
import operator
import re

MAX_STEPS = 8


# -------------------- Environment / Memory --------------------
@dataclass
class Environment:
    notes: list[str] = field(default_factory=list)


# -------------------- Tools --------------------
_ALLOWED = {
    ast.Add: operator.add,
    ast.Sub: operator.sub,
    ast.Mult: operator.mul,
    ast.Div: operator.truediv,
    ast.FloorDiv: operator.floordiv,
    ast.Mod: operator.mod,
    ast.Pow: operator.pow,
    ast.USub: operator.neg,
}


def _safe_eval(node):
    if isinstance(node, ast.Expression):
        return _safe_eval(node.body)
    if isinstance(node, ast.Constant) and isinstance(node.value, (int, float)):
        return node.value
    if isinstance(node, ast.BinOp) and type(node.op) in _ALLOWED:
        return _ALLOWED[type(node.op)](_safe_eval(node.left), _safe_eval(node.right))
    if isinstance(node, ast.UnaryOp) and type(node.op) in _ALLOWED:
        return _ALLOWED[type(node.op)](_safe_eval(node.operand))
    raise ValueError("只允许简单算术表达式")


def calculator(expression: str) -> str:
    tree = ast.parse(expression, mode="eval")
    return str(_safe_eval(tree))


def save_note(env: Environment, text: str) -> str:
    env.notes.append(text)
    return f"saved: {text}"


def read_notes(env: Environment) -> str:
    return " | ".join(env.notes) if env.notes else "<empty>"


# 工具注册表：可以把某一项注释掉，观察消融后的行为。
TOOL_REGISTRY: dict[str, Callable[..., str]] = {
    "calculator": calculator,
    "save_note": save_note,
    "read_notes": read_notes,
}


# -------------------- State --------------------
@dataclass
class AgentState:
    task: str
    history: list[dict[str, Any]] = field(default_factory=list)
    last_result: str | None = None
    finished: bool = False


# -------------------- Mock Decision Model --------------------
class MockDecisionModel:
    """规则决策器，用来把 Agent 的控制结构展示清楚。不是 LLM。"""

    def decide(self, state: AgentState, env: Environment) -> dict[str, Any]:
        # 1) 如果还没有计算结果，先找一个 a*b 算式并调用 calculator。
        if state.last_result is None:
            m = re.search(r"(\d+)\s*[×xX*]\s*(\d+)", state.task)
            if m:
                expression = f"{m.group(1)}*{m.group(2)}"
                return {"type": "tool", "name": "calculator", "args": {"expression": expression}}

        # 2) 有计算结果，但 notes 还为空：保存。
        if state.last_result is not None and not env.notes:
            return {
                "type": "tool",
                "name": "save_note",
                "args": {"text": f"计算结果={state.last_result}"},
            }

        # 3) 已有 notes：读取并结束。
        if env.notes:
            return {"type": "tool", "name": "read_notes", "args": {}}

        return {"type": "final", "answer": "无法继续。"}


# -------------------- Agent Runtime / Loop --------------------
class MinimalAgent:
    def __init__(self, model: MockDecisionModel, env: Environment):
        self.model = model
        self.env = env

    def run(self, task: str, max_steps: int = MAX_STEPS) -> str:
        state = AgentState(task=task)

        for step in range(1, max_steps + 1):
            print(f"\n[STEP {step}]")
            print("OBSERVATION:", {"task": state.task, "last_result": state.last_result, "notes": self.env.notes})

            decision = self.model.decide(state, self.env)
            print("DECISION:", decision)
            state.history.append({"step": step, "decision": decision})

            if decision["type"] == "final":
                state.finished = True
                return decision["answer"]

            tool_name = decision["name"]
            args = decision.get("args", {})

            if tool_name not in TOOL_REGISTRY:
                return f"FAILED: tool '{tool_name}' is unavailable"

            try:
                if tool_name == "calculator":
                    result = TOOL_REGISTRY[tool_name](**args)
                    state.last_result = result
                elif tool_name == "save_note":
                    result = TOOL_REGISTRY[tool_name](self.env, **args)
                elif tool_name == "read_notes":
                    result = TOOL_REGISTRY[tool_name](self.env)
                    state.finished = True
                    print("TOOL RESULT:", result)
                    print("STATE:", {"last_result": state.last_result, "notes": self.env.notes})
                    return f"任务完成，笔记内容：{result}"
                else:
                    result = TOOL_REGISTRY[tool_name](**args)
            except Exception as e:
                return f"FAILED during tool execution: {type(e).__name__}: {e}"

            print("TOOL RESULT:", result)
            print("STATE:", {"last_result": state.last_result, "notes": self.env.notes})

        return f"FAILED: reached max_steps={max_steps} before finishing"


def main():
    env = Environment()
    agent = MinimalAgent(MockDecisionModel(), env)
    final = agent.run("计算23×17，并把结果保存到笔记，然后读取笔记。")
    print("\nFINAL:", final)


if __name__ == "__main__":
    main()
