# 第1讲源码说明

1. 在本目录打开终端。
2. 运行 `python run_all.py`。
3. 再分别运行三个脚本，对比固定程序、Mock Chat 和 Minimal Agent。

## 重要
`MockDecisionModel` 不是 LLM。它只是规则决策器，用于透明展示 Agent 的系统骨架。

## 必做消融
- 在 `03_minimal_agent.py` 的 `TOOL_REGISTRY` 中暂时注释 `calculator`。
- 恢复后再注释 `save_note`。
- 把 `MAX_STEPS = 8` 改成 `1`。

每次只改一个条件，并把结果记录到 `../data/实验记录模板.csv`。
