"""run_all.py - 依次运行三种程序，方便对比。"""
import subprocess
import sys

files = ["01_fixed_program.py", "02_chat_model_mock.py", "03_minimal_agent.py"]
for f in files:
    print("\n" + "=" * 72, flush=True)
    print("RUN:", f, flush=True)
    print("=" * 72, flush=True)
    subprocess.run([sys.executable, f], check=True)
