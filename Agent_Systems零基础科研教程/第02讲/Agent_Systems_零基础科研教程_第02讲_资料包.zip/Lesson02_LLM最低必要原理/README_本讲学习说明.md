# Agent Systems 零基础科研教程 - 第2讲

## 主题
**LLM 最低必要原理：理解 Agent 的“决策核心”到底在做什么**

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. 不看答案先做 `05_练习题.docx` 的 A/B 两部分
3. 按 `03_实验指导书.docx` 运行四个实验
4. 填写 `data/实验记录模板.csv`
5. 阅读 `04_实验设计书.docx`，把“跑代码”转换成“变量-对照-证据”
6. 最后核对 `06_练习题答案.docx`
7. 复习 `07_术语速查表.docx`

## 本讲最低目标
你至少应该能独立解释：
- 为什么 LLM 是逐 token 自回归生成；
- token / embedding / logits / probability 的关系；
- Temperature 为什么影响随机性；
- weights、context、external memory 的区别；
- context window 为什么会成为 Agent 长任务的瓶颈；
- 为什么 Agent 失败不能只归因于底层模型。

## 代码环境
Python 3.9+。本讲源码只使用标准库，不需要 API Key，也不需要安装第三方包。

## 重要边界
所有源码都是教学 toy model，用来观察结构和因果关系，不代表任何商业 LLM 的真实 tokenizer、网络权重或服务端解码实现。
