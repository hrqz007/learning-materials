# 第2讲实验1：Toy Tokenizer（教学版）
# 目的：观察“文本 -> token id -> token”这一过程。
# 注意：它不是 GPT/Gemini/DeepSeek 等真实模型的 tokenizer，只用于理解概念。

VOCAB = {
    "智能体": 101,
    "系统": 102,
    "需要": 103,
    "工具": 104,
    "记忆": 105,
    "。": 106,
}

# 未登录词按单个字符拆分，并分配到 9000+ 的演示 id。
def toy_tokenize(text: str):
    words = sorted(VOCAB, key=len, reverse=True)  # 最长词优先
    tokens = []
    i = 0
    while i < len(text):
        matched = None
        for w in words:
            if text.startswith(w, i):
                matched = w
                break
        if matched:
            tokens.append((matched, VOCAB[matched]))
            i += len(matched)
        else:
            ch = text[i]
            if ch.isspace():
                i += 1
                continue
            tokens.append((ch, 9000 + ord(ch) % 1000))
            i += 1
    return tokens

if __name__ == "__main__":
    text = "智能体系统需要工具和记忆。"
    print("原文本：", text)
    for token, token_id in toy_tokenize(text):
        print(f"token={token!r:8s} -> id={token_id}")
