# 第2讲实验2：Toy 自回归生成
# 目的：观察“生成一个 token -> 放回上下文 -> 再预测下一个 token”的循环。
# 这里使用人为设计的转移表，不是神经网络。

TRANSITIONS = {
    "<BOS>": [("Agent", 0.75), ("模型", 0.25)],
    "Agent": [("需要", 0.70), ("可以", 0.30)],
    "需要": [("工具", 0.55), ("状态", 0.25), ("记忆", 0.20)],
    "工具": [("。", 1.0)],
    "状态": [("。", 1.0)],
    "记忆": [("。", 1.0)],
    "可以": [("调用", 1.0)],
    "调用": [("工具", 1.0)],
    "模型": [("生成", 1.0)],
    "生成": [("token", 1.0)],
    "token": [("。", 1.0)],
}

# 为了让流程最清楚，这里每一步都选择概率最大的候选（argmax）。
def choose_argmax(candidates):
    return max(candidates, key=lambda x: x[1])[0]

if __name__ == "__main__":
    context = ["<BOS>"]
    print("开始上下文:", context)
    for step in range(10):
        last = context[-1]
        candidates = TRANSITIONS.get(last)
        if not candidates:
            break
        next_token = choose_argmax(candidates)
        print(f"第{step+1}步：根据 {last!r} 预测 -> {next_token!r}")
        context.append(next_token)
        if next_token == "。":
            break
    print("最终生成:", "".join(t for t in context if t != "<BOS>"))
