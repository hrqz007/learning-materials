# 第2讲实验3：Temperature 对采样分布的影响
# 只使用 Python 标准库，不需要安装第三方包。

import math
import random
import csv
from pathlib import Path

ACTIONS = ["继续计算", "调用工具", "直接回答", "请求澄清"]
LOGITS = [3.2, 2.4, 1.6, 0.8]
TEMPERATURES = [0.2, 0.7, 1.0, 1.5, 2.0]
REPEATS = 5000
SEED = 20260926


def softmax_with_temperature(logits, temperature):
    if temperature <= 0:
        probs = [0.0] * len(logits)
        probs[max(range(len(logits)), key=lambda i: logits[i])] = 1.0
        return probs
    scaled = [x / temperature for x in logits]
    m = max(scaled)
    exps = [math.exp(x - m) for x in scaled]
    s = sum(exps)
    return [x / s for x in exps]


def entropy(probs):
    return -sum(p * math.log(p, 2) for p in probs if p > 0)


def sample_index(probs, rng):
    r = rng.random()
    total = 0.0
    for i, p in enumerate(probs):
        total += p
        if r <= total:
            return i
    return len(probs) - 1


if __name__ == "__main__":
    out_path = Path(__file__).resolve().parent.parent / "data" / "temperature_results.csv"
    rng = random.Random(SEED)
    rows = []
    for T in TEMPERATURES:
        probs = softmax_with_temperature(LOGITS, T)
        counts = [0] * len(ACTIONS)
        for _ in range(REPEATS):
            counts[sample_index(probs, rng)] += 1
        print(f"\nT={T:.1f}  entropy={entropy(probs):.3f} bits")
        for action, p, c in zip(ACTIONS, probs, counts):
            freq = c / REPEATS
            print(f"  {action:6s}: 理论={p:.3f}  实测={freq:.3f}")
            rows.append([T, action, round(p, 6), c, round(freq, 6), round(entropy(probs), 6)])

    with out_path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["temperature", "action", "theoretical_probability", "count", "observed_frequency", "entropy_bits"])
        w.writerows(rows)
    print("\n结果已写入:", out_path)
