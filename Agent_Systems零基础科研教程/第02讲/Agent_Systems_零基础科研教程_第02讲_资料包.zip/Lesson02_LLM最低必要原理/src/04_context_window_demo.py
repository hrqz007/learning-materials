# 第2讲实验4：Toy Context Window
# 目的：演示“窗口有限 -> 旧信息可能被移出 -> 外部记忆重新注入”的基本机制。

MAX_TOKENS = 12

def add_to_context(context, new_tokens):
    context.extend(new_tokens)
    # 教学用最简单策略：只保留最近 MAX_TOKENS 个 token
    if len(context) > MAX_TOKENS:
        removed = context[:-MAX_TOKENS]
        context[:] = context[-MAX_TOKENS:]
        return removed
    return []

if __name__ == "__main__":
    context = []
    external_memory = {"research_direction": "Agent Systems"}

    turns = [
        ["用户", "说", "研究方向", "是", "Agent", "Systems"],
        ["后来", "又", "讨论", "工具", "记忆", "状态", "运行时"],
        ["再后来", "继续", "讨论", "评测", "轨迹", "失败", "恢复"],
    ]

    for i, tokens in enumerate(turns, 1):
        removed = add_to_context(context, tokens)
        print(f"\n第{i}轮后 context = {context}")
        if removed:
            print("被移出窗口的旧 token =", removed)

    print("\n此时仅靠 context，早期信息可能已经不完整。")
    print("从 external_memory 重新取回：", external_memory["research_direction"])
    context.append("[MEMORY:" + external_memory["research_direction"] + "]")
    print("重新注入后的 context =", context)
