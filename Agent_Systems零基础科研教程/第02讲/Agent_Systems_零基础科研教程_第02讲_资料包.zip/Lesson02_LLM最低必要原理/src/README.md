# 第2讲源码说明

建议按 01 -> 02 -> 03 -> 04 顺序运行。

- `01_toy_tokenizer.py`：理解文本与 token 的映射。
- `02_next_token_generation.py`：理解自回归生成循环。
- `03_temperature_experiment.py`：重复 5000 次采样，观察 Temperature 如何改变分布与随机性。
- `04_context_window_demo.py`：观察上下文窗口有限时旧信息如何被移出，以及外部记忆如何重新注入。
- `run_all.py`：一次运行全部实验。

所有代码均为教学 toy model，不代表商业 LLM 的真实内部实现。重点是看懂结构和因果关系。
