import runpy
from pathlib import Path

base = Path(__file__).resolve().parent
for name in [
    "01_toy_tokenizer.py",
    "02_next_token_generation.py",
    "03_temperature_experiment.py",
    "04_context_window_demo.py",
]:
    print("\n" + "=" * 72)
    print("RUN", name)
    print("=" * 72)
    runpy.run_path(str(base / name), run_name="__main__")
