# Agent Systems 零基础科研教程 - 第3讲资料包

## 主题
API、HTTP、JSON 与 Agent

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. 独立完成 `05_练习题.docx`（先不要看答案）
3. 按 `03_实验指导书.docx` 完成必做实验1-4和实验6
4. 阅读 `04_实验设计书.docx`，理解“错误类型 × 重试策略”的对照思想
5. 查看 `06_练习题答案.docx`
6. 用 `07_术语速查表.docx` 复习
7. 有自己的API Key且愿意产生可能费用时，再选做 `src/05_real_openai_optional.py`

## 必做实验不需要任何第三方依赖
只需要 Python 3.9+。

## 文件结构
- `src/01_json_basics.py`：JSON 序列化/反序列化
- `src/02_mock_model_server.py`：本地 Mock HTTP API Server
- `src/03_call_mock_api.py`：POST JSON 并解析响应
- `src/04_error_retry.py`：500 + 指数退避重试
- `src/05_real_openai_optional.py`：可选真实 OpenAI API
- `src/06_invalid_request_demo.py`：400 客户端错误
- `data/`：示例 request / response JSON
- `figures/`：讲义原理图
- `run_outputs/`：资料包制作阶段的验证运行结果

## 本讲最低掌握标准
你能够不看资料解释：
- API 不是模型，它是接口；
- JSON 文本不是 Python dict；
- Request 至少要看 URL/Method/Headers/Body；
- Response 至少要看 Status Code 和 Body；
- 400/401 不能靠盲目重试解决；
- 429/5xx/timeout 可能需要有限重试；
- API Key 不写死在代码中；
- Agent 任务失败不等于模型推理失败。

## 版本说明
真实 OpenAI 示例依据 2026-09-26 官方 Developer Quickstart。模型与 SDK 会更新，因此代码允许通过 `OPENAI_MODEL` 环境变量覆盖默认模型。
