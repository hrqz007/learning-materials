# 第3讲实验1：JSON 基础
# 目标：理解 Python dict/list 与 JSON 文本之间的转换。

import json

request_data = {
    "model": "demo-model",
    "input": "请计算 2 + 3",
    "stream": False,
    "metadata": {
        "user_id": "u001",
        "trial": 1
    }
}

print("1) Python 对象：")
print(request_data)
print("类型：", type(request_data))

json_text = json.dumps(request_data, ensure_ascii=False, indent=2)
print("\n2) 序列化后的 JSON 文本：")
print(json_text)
print("类型：", type(json_text))

restored = json.loads(json_text)
print("\n3) 从 JSON 恢复成 Python 对象：")
print(restored)
print("类型：", type(restored))

print("\n4) 访问字段：")
print("model =", restored["model"])
print("metadata.user_id =", restored["metadata"]["user_id"])
