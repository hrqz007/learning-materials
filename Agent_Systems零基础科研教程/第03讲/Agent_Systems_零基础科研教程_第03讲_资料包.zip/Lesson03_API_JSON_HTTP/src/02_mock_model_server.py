# 第3讲实验2：本地 Mock Model API Server
# 目标：不联网、不花钱，也能观察 HTTP Request / Response。
# 运行：python 02_mock_model_server.py
# 默认监听：http://127.0.0.1:8765

from http.server import BaseHTTPRequestHandler, HTTPServer
import json
import time

HOST = "127.0.0.1"
PORT = 8765
unstable_counter = 0

class Handler(BaseHTTPRequestHandler):
    def _send_json(self, status, obj):
        body = json.dumps(obj, ensure_ascii=False).encode("utf-8")
        self.send_response(status)
        self.send_header("Content-Type", "application/json; charset=utf-8")
        self.send_header("Content-Length", str(len(body)))
        self.end_headers()
        self.wfile.write(body)

    def log_message(self, fmt, *args):
        print("[server]", fmt % args)

    def do_GET(self):
        if self.path == "/health":
            self._send_json(200, {"status": "ok", "service": "mock-model-api"})
        else:
            self._send_json(404, {"error": "not_found", "path": self.path})

    def do_POST(self):
        global unstable_counter

        length = int(self.headers.get("Content-Length", "0"))
        raw = self.rfile.read(length)

        try:
            data = json.loads(raw.decode("utf-8"))
        except Exception:
            self._send_json(400, {"error": "invalid_json"})
            return

        if self.path == "/v1/mock-responses":
            if "input" not in data:
                self._send_json(400, {"error": "missing_field", "field": "input"})
                return

            # 教学用固定规则，不是真实 LLM。
            user_input = str(data["input"])
            output_text = f"[Mock模型] 我收到了：{user_input}"
            response = {
                "id": "resp_demo_001",
                "model": data.get("model", "mock-model"),
                "output_text": output_text,
                "usage": {"input_chars": len(user_input), "output_chars": len(output_text)}
            }
            self._send_json(200, response)
            return

        if self.path == "/v1/unstable":
            unstable_counter += 1
            if unstable_counter <= 2:
                self._send_json(500, {"error": "temporary_server_error", "attempt": unstable_counter})
            else:
                self._send_json(200, {"status": "success", "attempt": unstable_counter})
            return

        self._send_json(404, {"error": "not_found", "path": self.path})

if __name__ == "__main__":
    print(f"Mock API 正在运行：http://{HOST}:{PORT}")
    print("按 Ctrl+C 停止服务器。")
    HTTPServer((HOST, PORT), Handler).serve_forever()
