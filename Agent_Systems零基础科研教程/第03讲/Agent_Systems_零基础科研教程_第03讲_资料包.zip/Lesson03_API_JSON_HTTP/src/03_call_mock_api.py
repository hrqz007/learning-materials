# 第3讲实验3：用 Python 调用本地 Mock API
# 只用标准库 urllib，不需要 pip install requests。
# 先在另一个终端运行：python 02_mock_model_server.py

import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

URL = "http://127.0.0.1:8765/v1/mock-responses"

payload = {
    "model": "mock-model",
    "input": "Agent 和 LLM 有什么区别？"
}

body = json.dumps(payload, ensure_ascii=False).encode("utf-8")
request = Request(
    URL,
    data=body,
    method="POST",
    headers={"Content-Type": "application/json"}
)

print("=== 即将发送的请求 ===")
print("URL:", URL)
print("Method: POST")
print("Body:", json.dumps(payload, ensure_ascii=False, indent=2))

try:
    with urlopen(request, timeout=5) as response:
        status = response.status
        raw = response.read().decode("utf-8")
        result = json.loads(raw)
        print("\n=== 收到的响应 ===")
        print("HTTP Status:", status)
        print(json.dumps(result, ensure_ascii=False, indent=2))
        print("\n程序真正关心的字段：")
        print(result["output_text"])
except HTTPError as e:
    print("HTTPError:", e.code, e.read().decode("utf-8", errors="replace"))
except URLError as e:
    print("URLError:", e.reason)
