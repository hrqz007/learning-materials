# 第3讲实验4：暂时性错误与重试
# 先启动 02_mock_model_server.py。
# /v1/unstable 会故意让前两次请求返回 500，第三次成功。

import json
import time
from urllib.request import Request, urlopen
from urllib.error import HTTPError, URLError

URL = "http://127.0.0.1:8765/v1/unstable"
MAX_ATTEMPTS = 4

for attempt in range(1, MAX_ATTEMPTS + 1):
    request = Request(
        URL,
        data=b"{}",
        method="POST",
        headers={"Content-Type": "application/json"}
    )
    try:
        with urlopen(request, timeout=3) as response:
            result = json.loads(response.read().decode("utf-8"))
            print(f"第 {attempt} 次：成功，status={response.status}, body={result}")
            break
    except HTTPError as e:
        body = e.read().decode("utf-8", errors="replace")
        print(f"第 {attempt} 次：HTTP {e.code}，body={body}")
        # 这里只对 429 / 5xx 做演示性重试。
        if e.code == 429 or 500 <= e.code <= 599:
            if attempt == MAX_ATTEMPTS:
                print("达到最大重试次数，停止。")
                break
            delay = 2 ** (attempt - 1)  # 1s, 2s, 4s ...
            print(f"等待 {delay} 秒后重试...")
            time.sleep(delay)
        else:
            print("这类错误通常应先修正请求，而不是盲目重试。")
            break
    except URLError as e:
        print(f"第 {attempt} 次：网络错误 {e.reason}")
        break
