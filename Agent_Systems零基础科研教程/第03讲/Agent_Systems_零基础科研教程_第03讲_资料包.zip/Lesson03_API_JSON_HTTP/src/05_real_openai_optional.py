# 第3讲实验5（可选）：调用真实 OpenAI API
# 截至 2026-09-26，官方 Python SDK 的推荐基础用法是 Responses API。
# 此脚本不会在资料包制作阶段运行，因为需要你自己的 API Key，并可能产生费用。
#
# 准备：
#   pip install openai
#   Windows PowerShell（永久写入用户环境变量）：
#       setx OPENAI_API_KEY "你的Key"
#   重新打开终端后再运行本程序。
#
# 模型名可能随时间变化，因此优先用环境变量 OPENAI_MODEL 指定；
# 当前示例默认值依据 2026-09-26 OpenAI 官方 quickstart。

import os
from openai import OpenAI

model = os.getenv("OPENAI_MODEL", "gpt-6-astra")

# OpenAI() 会自动从 OPENAI_API_KEY 环境变量读取密钥。
client = OpenAI()

response = client.responses.create(
    model=model,
    input="请用一句话解释：API 为什么对 Agent 很重要？"
)

print("model =", model)
print("output_text =", response.output_text)
