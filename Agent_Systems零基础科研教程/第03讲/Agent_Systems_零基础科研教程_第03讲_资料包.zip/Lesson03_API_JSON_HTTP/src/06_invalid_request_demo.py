# 第3讲实验6：故意发送错误请求，观察 400
# 先启动 02_mock_model_server.py。

import json
from urllib.request import Request, urlopen
from urllib.error import HTTPError

URL = "http://127.0.0.1:8765/v1/mock-responses"
# 故意缺少必须字段 input
payload = {"model": "mock-model"}
body = json.dumps(payload).encode("utf-8")
request = Request(URL, data=body, method="POST", headers={"Content-Type": "application/json"})

try:
    with urlopen(request, timeout=3) as response:
        print(response.read().decode("utf-8"))
except HTTPError as e:
    print("HTTP Status:", e.code)
    print("Body:", e.read().decode("utf-8"))
