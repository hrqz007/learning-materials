# Agent Systems 零基础科研教程 · 第4讲

## 主题
**从普通 LLM 到 Agent：最重要的 Agent Loop**

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `05_练习题.docx`（先独立完成基础题）
3. `03_实验指导书.docx`
4. 进入 `src/` 依次运行 01～06
5. 打开 `run_outputs/agent_trace.jsonl`，手工读 Trace
6. 填写 `templates/实验记录模板.md`
7. 阅读 `04_实验设计书.docx`
8. 最后查看 `06_练习题答案.docx`
9. 随时用 `07_术语速查表.docx` 查概念

## 必做实验
全部使用 Python 标准库，无需 API Key：
- One-shot vs Loop
- 最小 Agent Loop
- Feedback 丢失故障
- Failure Recovery
- Trace → JSONL
- 最小对照实验

## 可选实验
`07_optional_real_llm_adapter.py` 需要 OpenAI SDK 和 API Key，只用于把规则 decision model 替换成真实模型。不是第4讲必做内容。

## 本讲最低闭环
你能从源码中准确指出：
`Observe → Decide → Act → Feedback → State Update → Stop/Continue`
并能解释删除其中任何一环可能出现什么故障。
