"""实验1：一次调用 vs Agent Loop。
目标：观察“只决定一次”和“决定-执行-反馈-再决定”的差别。
"""
from common_tools import calculator, write_note, read_note, reset_workspace

TASK = "计算 23*17，把结果写入 memory.txt，再读取文件确认结果。"


def one_shot_decision(task):
    # 模拟一次模型调用：它只能给出一个“建议”，程序不会继续闭环。
    return {"action": "calculator", "expression": "23*17"}


def run_one_shot():
    reset_workspace()
    decision = one_shot_decision(TASK)
    print("任务:", TASK)
    print("一次决策:", decision)
    if decision["action"] == "calculator":
        result = calculator(decision["expression"])
        print("只执行了一步，计算结果 =", result)
    print("memory.txt 是否已创建？", False)
    print("结论：一次调用可以完成一步，但任务链没有自动继续。")


if __name__ == "__main__":
    run_one_shot()
