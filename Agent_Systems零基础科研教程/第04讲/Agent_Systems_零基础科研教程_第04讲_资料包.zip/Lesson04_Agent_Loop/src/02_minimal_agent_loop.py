"""实验2：最小 Agent Loop。
注意：这里的 decision_model 是显式规则，不是真实 LLM。
我们故意这样做，是为了先把 Agent Loop 的“系统骨架”看清楚。
"""
from common_tools import calculator, write_note, read_note, reset_workspace

TASK = "计算 23*17，把结果写入 memory.txt，再读取文件确认结果。"


def decision_model(state):
    """根据当前 state 决定下一步。
    真实 Agent 中，这个位置通常由 LLM/策略模型参与决策。
    """
    if "calc_result" not in state:
        return {"action": "calculator", "expression": "23*17"}
    if not state.get("written"):
        return {"action": "write_note", "text": state["calc_result"]}
    if "read_back" not in state:
        return {"action": "read_note"}
    return {"action": "final", "answer": f"任务完成，文件中读回：{state['read_back']}"}


def execute(action):
    name = action["action"]
    if name == "calculator":
        return calculator(action["expression"])
    if name == "write_note":
        return write_note(action["text"])
    if name == "read_note":
        return read_note()
    if name == "final":
        return action["answer"]
    raise ValueError(f"未知动作: {name}")


def run_agent(max_turns=10):
    reset_workspace()
    state = {"task": TASK}

    for turn in range(1, max_turns + 1):
        print(f"\n===== Turn {turn} =====")
        print("Observe / State:", state)

        action = decision_model(state)
        print("Decide:", action)

        if action["action"] == "final":
            print("Stop: task_complete")
            print("Final:", action["answer"])
            return state

        try:
            feedback = execute(action)
            print("Act + Feedback:", feedback)
        except Exception as e:
            feedback = f"ERROR: {type(e).__name__}: {e}"
            print("Act + Feedback:", feedback)

        # 把环境反馈写回 state，下一轮才能“知道刚才发生了什么”。
        if action["action"] == "calculator" and not feedback.startswith("ERROR"):
            state["calc_result"] = feedback
        elif action["action"] == "write_note" and not feedback.startswith("ERROR"):
            state["written"] = True
        elif action["action"] == "read_note" and not feedback.startswith("ERROR"):
            state["read_back"] = feedback
        state["last_feedback"] = feedback

    print("Stop: max_turns_reached")
    return state


if __name__ == "__main__":
    run_agent()
