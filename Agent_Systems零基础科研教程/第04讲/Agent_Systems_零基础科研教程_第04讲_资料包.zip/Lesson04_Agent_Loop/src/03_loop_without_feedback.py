"""实验3：移除 Feedback，观察为什么闭环会坏掉。
程序故意不把 calculator 的结果写回 state。
"""
from common_tools import calculator, reset_workspace


def decision_model(state):
    if "calc_result" not in state:
        return {"action": "calculator", "expression": "23*17"}
    return {"action": "final"}


def run(max_turns=4):
    reset_workspace()
    state = {"task": "计算 23*17"}
    for turn in range(1, max_turns + 1):
        action = decision_model(state)
        print(f"Turn {turn}: Decide -> {action}")
        if action["action"] == "final":
            print("Final")
            return
        feedback = calculator(action["expression"])
        print("Feedback ->", feedback)
        # 故意删除关键代码：state["calc_result"] = feedback
        print("BUG: 反馈没有进入 state。下一轮仍以为还没算过。")
    print("Stop: max_turns_reached（避免无限循环）")


if __name__ == "__main__":
    run()
