"""实验4：工具失败与恢复。
第一次读取文件会失败；Agent 根据错误反馈，下一轮改为先创建文件。
"""
from common_tools import write_note, read_note, reset_workspace


def decision_model(state):
    if state.get("confirmed"):
        return {"action": "final", "answer": state["read_back"]}
    if state.get("last_error") == "FileNotFoundError" and not state.get("created"):
        return {"action": "write_note", "text": "recovered"}
    if state.get("created") and "read_back" not in state:
        return {"action": "read_note"}
    return {"action": "read_note"}


def run(max_turns=6):
    reset_workspace()
    state = {"task": "读取 memory.txt；如果不存在，就创建后再读取。"}

    for turn in range(1, max_turns + 1):
        action = decision_model(state)
        print(f"\nTurn {turn}\nState: {state}\nDecision: {action}")
        if action["action"] == "final":
            print("Stop: task_complete ->", action["answer"])
            return
        try:
            if action["action"] == "read_note":
                result = read_note()
                state["read_back"] = result
                state["confirmed"] = True
            elif action["action"] == "write_note":
                result = write_note(action["text"])
                state["created"] = True
            print("Feedback:", result)
            state.pop("last_error", None)
        except Exception as e:
            print("Feedback ERROR:", type(e).__name__, str(e))
            state["last_error"] = type(e).__name__
            state["last_feedback"] = str(e)

    print("Stop: max_turns_reached")


if __name__ == "__main__":
    run()
