"""实验5：把每轮 Agent 行为保存为 JSONL Trace。
JSONL = 每一行一个 JSON 对象，科研实验里很适合保存轨迹。
"""
import json
from pathlib import Path
from common_tools import calculator, write_note, read_note, reset_workspace

OUT = Path(__file__).resolve().parent.parent / "run_outputs" / "agent_trace.jsonl"
TASK = "计算 23*17，把结果写入 memory.txt，再读取确认。"


def decision_model(state):
    if "calc_result" not in state:
        return {"action": "calculator", "expression": "23*17"}
    if not state.get("written"):
        return {"action": "write_note", "text": state["calc_result"]}
    if "read_back" not in state:
        return {"action": "read_note"}
    return {"action": "final", "answer": state["read_back"]}


def execute(action):
    if action["action"] == "calculator": return calculator(action["expression"])
    if action["action"] == "write_note": return write_note(action["text"])
    if action["action"] == "read_note": return read_note()
    return action.get("answer", "")


def run():
    reset_workspace(); OUT.parent.mkdir(exist_ok=True)
    state = {"task": TASK}
    records = []
    for turn in range(1, 10):
        before = dict(state)
        action = decision_model(state)
        if action["action"] == "final":
            records.append({"turn":turn,"event":"final","state_before":before,"action":action,"stop_reason":"task_complete"})
            break
        try:
            feedback = execute(action); status="ok"
        except Exception as e:
            feedback = f"{type(e).__name__}: {e}"; status="error"
        if action["action"] == "calculator" and status=="ok": state["calc_result"] = feedback
        elif action["action"] == "write_note" and status=="ok": state["written"] = True
        elif action["action"] == "read_note" and status=="ok": state["read_back"] = feedback
        state["last_feedback"] = feedback
        records.append({"turn":turn,"event":"tool_step","state_before":before,"action":action,"feedback":feedback,"status":status,"state_after":dict(state)})
    with OUT.open("w",encoding="utf-8") as f:
        for r in records:
            f.write(json.dumps(r,ensure_ascii=False)+"\n")
    print("Trace saved to:", OUT)
    print("records =", len(records))
    for r in records:
        print(r["turn"], r["event"], r["action"]["action"], r.get("status","-"))

if __name__ == "__main__": run()
