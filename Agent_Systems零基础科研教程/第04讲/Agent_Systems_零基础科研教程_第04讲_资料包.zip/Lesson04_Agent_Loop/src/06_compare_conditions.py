"""实验6：一个最小“对照实验”。
比较 A=正常闭环 与 B=反馈丢失 两个条件。
这是教学实验，不是论文级 benchmark。
"""

def simulate(feedback_enabled=True, max_turns=6):
    state={}; calls=0
    for turn in range(1,max_turns+1):
        if "result" not in state:
            action="calculate"
        else:
            return {"success":True,"turns":turn,"tool_calls":calls,"stop":"task_complete"}
        calls += 1
        feedback="391"
        if feedback_enabled:
            state["result"] = feedback
    return {"success":False,"turns":max_turns,"tool_calls":calls,"stop":"max_turns"}

if __name__ == "__main__":
    for name, flag in [("A 正常闭环", True),("B 反馈丢失", False)]:
        result=simulate(flag)
        print(name, result)
