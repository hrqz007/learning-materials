"""可选：把第4讲 decision_model 换成真实 LLM 的最小接口骨架。
不是必做实验。需要：pip install openai，并设置 OPENAI_API_KEY。
当前思路是“Responses API 负责模型响应，你的 Python 程序自己拥有 Agent Loop”。
具体参数请以你运行时的官方文档为准。
"""
import os


def real_model_decision(context_text: str) -> str:
    if not os.getenv("OPENAI_API_KEY"):
        raise RuntimeError("未设置 OPENAI_API_KEY；本文件只是可选扩展。")

    from openai import OpenAI
    client = OpenAI()
    response = client.responses.create(
        model="gpt-6-astra",
        input=(
            "你是一个教学 Agent 的决策模块。根据当前上下文，只返回下一步动作的 JSON。\n"
            + context_text
        ),
    )
    return response.output_text


if __name__ == "__main__":
    print(real_model_decision("任务：计算23*17。当前还没有结果。可用工具：calculator。"))
