"""第4讲公共工具。
只用 Python 标准库，不需要安装第三方包。
"""
from pathlib import Path

WORKDIR = Path(__file__).resolve().parent / "workspace"
WORKDIR.mkdir(exist_ok=True)
NOTE_FILE = WORKDIR / "memory.txt"


def calculator(expression: str) -> str:
    """教学用安全计算器：只允许数字和基本四则运算字符。"""
    allowed = set("0123456789+-*/(). %")
    if not expression or any(ch not in allowed for ch in expression):
        raise ValueError("表达式包含不允许的字符")
    # 这里仅为教学演示；真实系统不要对不可信字符串直接 eval。
    result = eval(expression, {"__builtins__": {}}, {})
    return str(result)


def write_note(text: str) -> str:
    NOTE_FILE.write_text(text, encoding="utf-8")
    return f"已写入 {NOTE_FILE.name}"


def read_note() -> str:
    if not NOTE_FILE.exists():
        raise FileNotFoundError("memory.txt 尚不存在")
    return NOTE_FILE.read_text(encoding="utf-8")


def reset_workspace() -> None:
    if NOTE_FILE.exists():
        NOTE_FILE.unlink()
