# Agent Systems 零基础科研教程 · 第5讲

## 主题
**第一个最小 Agent：把 Model、Instructions、Tools、State 与 Runtime 真正组装起来**

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. 不看答案完成 `05_练习题.docx` 的 A/B 部分
3. 阅读 `src/common_agent.py`，只搞清“谁负责什么”
4. 依次运行 `01`～`06` 六个必做实验
5. 用 `templates/实验记录模板.md` 记录至少两个条件
6. 阅读 `04_实验设计书.docx`，理解 Tool Ablation / State Isolation
7. 完成剩余练习，再看 `06_练习题答案.docx`
8. 用 `07_术语速查表.docx` 做复习

## 必做实验依赖
- Python 3.10+
- 无第三方库
- 无需联网
- 无需 API Key

## 本讲最低闭环能力
你应能解释：
- Agent Definition 为什么不等于 Runtime
- Configuration 为什么不等于 State
- 模型“提出工具调用”为什么不等于工具已经执行
- 为什么不同 Run 必须默认状态隔离
- 为什么组件化直接服务于科研中的消融实验

## 重要说明
`MockDecisionModel` 是确定性的教学替身，不是 LLM。它的作用是先固定“模型智能”这一变量，让你看清 Agent System 的骨架。
