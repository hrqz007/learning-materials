from common_agent import AgentConfig, MockDecisionModel, MinimalAgent, build_registry

config = AgentConfig(
    name="MiniResearchAgent",
    instructions="先读取数据，再统计，再写结果。",
    allowed_tools=("read_file", "count_keyword", "write_file")
)
agent = MinimalAgent(config, MockDecisionModel(), build_registry())
print("Agent name:", agent.config.name)
print("Instructions:", agent.config.instructions)
print("Allowed tools:", agent.config.allowed_tools)
print("Model class:", type(agent.model).__name__)
print("注意：此时还没有开始任务，因为 Runtime 尚未运行。")
