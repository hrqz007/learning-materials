from pathlib import Path
from common_agent import AgentConfig, MockDecisionModel, MinimalAgent, AgentRuntime, build_registry, dump_state

workspace = Path("workspace_exp2")
workspace.mkdir(exist_ok=True)
(workspace / "notes.txt").write_text(
    "Agent systems use models and tools. An agent can observe results. "
    "Reliable agent research studies the whole agent system.", encoding="utf-8")

config = AgentConfig(
    name="MiniResearchAgent",
    instructions="先读取 notes.txt，统计 agent 出现次数，然后写入 summary.txt。",
    allowed_tools=("read_file", "count_keyword", "write_file")
)
agent = MinimalAgent(config, MockDecisionModel(), build_registry())
runtime = AgentRuntime(workspace)
state = runtime.run(agent, task="统计 notes.txt 中 agent 出现次数并保存。")
print("\nFINAL STATE")
print(dump_state(state))
print("\nsummary.txt =>", (workspace/"summary.txt").read_text(encoding="utf-8").strip())
