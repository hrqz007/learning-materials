from pathlib import Path
from common_agent import AgentConfig, MockDecisionModel, MinimalAgent, AgentRuntime, build_registry

config = AgentConfig("ReusableAgent", "执行统计任务。", ("read_file","count_keyword","write_file"))
agent = MinimalAgent(config, MockDecisionModel(), build_registry())

for name, text in [
    ("run_A", "agent agent system"),
    ("run_B", "agent system without repeated keyword")
]:
    ws = Path(name); ws.mkdir(exist_ok=True)
    (ws/"notes.txt").write_text(text, encoding="utf-8")
    state = AgentRuntime(ws).run(agent, f"处理 {name}", verbose=False)
    print(name, "count=", state.facts.get("agent_count"), "turn=", state.turn, "state_id=", id(state))

print("两个 state_id 不同，说明同一个 Agent 配置可以产生互不共享的运行状态。")
