from pathlib import Path
from common_agent import AgentConfig, MockDecisionModel, MinimalAgent, AgentRuntime, build_registry

ws=Path("workspace_exp4"); ws.mkdir(exist_ok=True)
(ws/"notes.txt").write_text("agent agent agent", encoding="utf-8")

full = AgentConfig("FullAgent", "正常条件", ("read_file","count_keyword","write_file"))
ablated = AgentConfig("NoCountAgent", "去掉 count_keyword 工具", ("read_file","write_file"))

for cfg in [full, ablated]:
    state = AgentRuntime(ws/cfg.name).run(
        MinimalAgent(cfg, MockDecisionModel(), build_registry()),
        "统计 agent", verbose=False
    ) if False else None

# 为每个条件准备独立 workspace，确保不是共享文件造成差异
for cfg in [full, ablated]:
    w=ws/cfg.name; w.mkdir(parents=True, exist_ok=True)
    (w/"notes.txt").write_text("agent agent agent", encoding="utf-8")
    st=AgentRuntime(w).run(MinimalAgent(cfg, MockDecisionModel(), build_registry()), "统计 agent", verbose=False)
    print(cfg.name, "done=", st.done, "error=", st.error, "count=", st.facts.get("agent_count"))
