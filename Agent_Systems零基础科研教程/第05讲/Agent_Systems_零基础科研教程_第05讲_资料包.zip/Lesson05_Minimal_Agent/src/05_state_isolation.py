from dataclasses import dataclass, field

@dataclass
class BadSharedAgent:
    observations: list = field(default_factory=list)  # 如果同一对象跨任务复用，这里会残留

bad = BadSharedAgent()
bad.observations.append("任务A：读过文件A")
print("开始任务B前，错误设计仍然看到：", bad.observations)

print("\n正确设计：Agent 保存配置，Run State 每次新建。")
from common_agent import AgentState
state_a = AgentState(task="任务A")
state_b = AgentState(task="任务B")
state_a.observations.append({"msg":"A的观察"})
print("state_a:", state_a.observations)
print("state_b:", state_b.observations)
