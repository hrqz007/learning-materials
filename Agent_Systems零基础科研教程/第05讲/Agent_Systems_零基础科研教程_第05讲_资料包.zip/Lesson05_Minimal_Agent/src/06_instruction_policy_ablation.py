from pathlib import Path
from common_agent import AgentConfig, MockDecisionModel, MinimalAgent, AgentRuntime, build_registry

base=Path("workspace_exp6"); base.mkdir(exist_ok=True)
configs=[
    AgentConfig("FastAgent", "完成后即可结束。", ("read_file","count_keyword","write_file","verify_file")),
    AgentConfig("VerifyAgent", "完成后必须 VERIFY_OUTPUT，再结束。", ("read_file","count_keyword","write_file","verify_file")),
]
for cfg in configs:
    w=base/cfg.name; w.mkdir(exist_ok=True)
    (w/"notes.txt").write_text("agent systems agent", encoding="utf-8")
    st=AgentRuntime(w).run(MinimalAgent(cfg, MockDecisionModel(), build_registry()), "统计并保存", verbose=False)
    actions=[x['action'] for x in st.observations]
    print(cfg.name, "turns=", st.turn, "actions=", actions, "verified=", 'verified_text' in st.facts)
