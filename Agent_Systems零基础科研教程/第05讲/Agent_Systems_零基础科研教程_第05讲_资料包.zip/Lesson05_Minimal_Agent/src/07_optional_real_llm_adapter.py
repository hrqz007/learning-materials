"""可选：真实 LLM 适配器骨架。本讲不要求运行，也不把 API 写死到某家公司。"""
# 目标：让真正的模型只负责 decide()，其余 Tool Registry / Runtime / State 保持不变。
# 伪代码：
# class RealLLMDecisionModel:
#     def decide(self, agent, state):
#         context = build_context(agent.config, state)
#         response = call_model_api(context)
#         action = parse_structured_action(response)
#         return Action(action["name"], action.get("args", {}))
#
# 关键思想：替换模型适配器，不需要重写整个 Agent Runtime。
print("本文件是结构示例，不需要 API Key，不执行联网请求。")
