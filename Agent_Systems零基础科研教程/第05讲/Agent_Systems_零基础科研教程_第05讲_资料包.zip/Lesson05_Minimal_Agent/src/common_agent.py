"""第5讲公共组件：完全使用 Python 标准库，无需 API Key。"""
from __future__ import annotations
from dataclasses import dataclass, field
from pathlib import Path
from typing import Any, Callable
import json

@dataclass
class Action:
    name: str
    args: dict[str, Any] = field(default_factory=dict)

@dataclass
class AgentState:
    task: str
    turn: int = 0
    observations: list[dict[str, Any]] = field(default_factory=list)
    facts: dict[str, Any] = field(default_factory=dict)
    done: bool = False
    final_answer: str | None = None
    error: str | None = None

@dataclass(frozen=True)
class AgentConfig:
    name: str
    instructions: str
    allowed_tools: tuple[str, ...]

class ToolRegistry:
    def __init__(self):
        self._tools: dict[str, Callable[..., Any]] = {}

    def register(self, name: str, func: Callable[..., Any]):
        self._tools[name] = func

    def execute(self, agent: AgentConfig, action: Action):
        if action.name not in agent.allowed_tools:
            return {"ok": False, "error": f"TOOL_NOT_ALLOWED: {action.name}"}
        if action.name not in self._tools:
            return {"ok": False, "error": f"TOOL_NOT_FOUND: {action.name}"}
        try:
            value = self._tools[action.name](**action.args)
            return {"ok": True, "value": value}
        except Exception as e:
            return {"ok": False, "error": f"{type(e).__name__}: {e}"}

class MockDecisionModel:
    """教学用的确定性“假模型”。它不是 LLM，只用于暴露系统骨架。"""
    def decide(self, agent: AgentConfig, state: AgentState) -> Action:
        # 任务固定：读取 notes.txt -> 统计 agent -> 写 summary.txt -> 可选验证 -> 完成
        names = [o.get("action") for o in state.observations]
        if "read_file" not in names:
            return Action("read_file", {"path": "notes.txt"})
        if "count_keyword" not in names:
            last_text = state.facts.get("notes_text", "")
            return Action("count_keyword", {"text": last_text, "keyword": "agent"})
        if "write_file" not in names:
            count = state.facts.get("agent_count")
            return Action("write_file", {"path": "summary.txt", "content": f"agent 出现次数: {count}\n"})
        if "VERIFY_OUTPUT" in agent.instructions and "verify_file" not in names:
            return Action("verify_file", {"path": "summary.txt"})
        return Action("finish", {})

class MinimalAgent:
    def __init__(self, config: AgentConfig, model: MockDecisionModel, tools: ToolRegistry):
        self.config = config
        self.model = model
        self.tools = tools

class AgentRuntime:
    def __init__(self, workspace: str | Path):
        self.workspace = Path(workspace)
        self.workspace.mkdir(parents=True, exist_ok=True)

    def run(self, agent: MinimalAgent, task: str, max_turns: int = 8, verbose: bool = True):
        state = AgentState(task=task)
        for _ in range(max_turns):
            state.turn += 1
            action = agent.model.decide(agent.config, state)
            if verbose:
                print(f"[turn {state.turn}] action={action.name} args={action.args}")
            if action.name == "finish":
                state.done = True
                state.final_answer = f"任务完成；agent_count={state.facts.get('agent_count')}"
                state.observations.append({"turn": state.turn, "action": "finish", "result": {"ok": True}})
                break

            # 自动把相对文件路径放到 workspace 中，避免写到未知目录
            args = dict(action.args)
            if "path" in args:
                args["path"] = str(self.workspace / args["path"])
            result = agent.tools.execute(agent.config, Action(action.name, args))
            state.observations.append({"turn": state.turn, "action": action.name, "result": result})

            if not result.get("ok"):
                state.error = result.get("error")
                if verbose: print("  -> error:", state.error)
                break

            value = result.get("value")
            if action.name == "read_file":
                state.facts["notes_text"] = value
            elif action.name == "count_keyword":
                state.facts["agent_count"] = value
            elif action.name == "verify_file":
                state.facts["verified_text"] = value
            if verbose: print("  -> result:", value)
        else:
            state.error = f"MAX_TURNS_EXCEEDED: {max_turns}"
        return state

def build_registry() -> ToolRegistry:
    r = ToolRegistry()
    r.register("read_file", lambda path: Path(path).read_text(encoding="utf-8"))
    r.register("count_keyword", lambda text, keyword: text.lower().count(keyword.lower()))
    def write_file(path, content):
        Path(path).write_text(content, encoding="utf-8")
        return f"WROTE {path}"
    r.register("write_file", write_file)
    r.register("verify_file", lambda path: Path(path).read_text(encoding="utf-8"))
    return r

def dump_state(state: AgentState):
    return json.dumps(state.__dict__, ensure_ascii=False, indent=2)
