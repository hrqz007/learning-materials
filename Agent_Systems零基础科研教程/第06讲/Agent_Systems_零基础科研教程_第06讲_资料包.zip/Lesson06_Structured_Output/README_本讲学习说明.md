# Agent Systems 零基础科研教程 · 第6讲

## 主题
**Structured Output：让 Agent 的“决定”变成机器可靠理解的 Action**

## 推荐学习顺序
1. 阅读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. 先做练习题 1-12，不看答案
3. 阅读 `src/common_structured.py`，只标出 Parse / Validate / Semantic / Execute 四层
4. 依次运行 01-06 六个必做实验
5. 打开 `run_outputs/failure_injection_results.csv` 看每一行属于哪种故障
6. 填一份 `templates/实验记录模板.md`
7. 阅读 `04_实验设计书.docx`
8. 做完剩余练习，再看答案

## 必做依赖
- Python 3.10+
- 无第三方库
- 无需联网
- 无需 API Key

## 可选真实 API
`src/07_optional_openai_structured_output.py` 需要：
- `pip install openai pydantic`
- `OPENAI_API_KEY`
- 运行前重新核对官方 API 文档和模型名

## 本讲最低闭环能力
你应能独立说清楚：
`自然语言 → JSON → Schema → Action → Semantic Guard → Execute`

并且知道：
**Schema-valid 不等于 decision-correct。**
