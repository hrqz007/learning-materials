import re
from pathlib import Path

lines = (Path(__file__).parents[1]/"data"/"free_text_variants.txt").read_text(encoding="utf-8").splitlines()

def naive_parser(text: str):
    # 故意写得很“像初学者”：只识别固定的几种字面形式
    m = re.search(r"search\s*\((.*?)\)", text, re.I)
    if m:
        return {"action":"search", "query":m.group(1)}
    m = re.search(r"Action:\s*search;\s*query=(.*)", text, re.I)
    if m:
        return {"action":"search", "query":m.group(1).strip()}
    if text.startswith("请先搜索 "):
        return {"action":"search", "query":text.removeprefix("请先搜索 ").strip()}
    return None

ok = 0
for i, text in enumerate(lines, 1):
    parsed = naive_parser(text)
    print(f"{i:02d}. {text}")
    print("    ->", parsed)
    ok += parsed is not None
print(f"\n解析成功 {ok}/{len(lines)}；同一个意思的自然语言变体会让脆弱 parser 失效。")
