import json
from pathlib import Path

path = Path(__file__).parents[1]/"data"/"action_samples.jsonl"
for line in path.read_text(encoding="utf-8").splitlines():
    item = json.loads(line)
    text = item["text"]
    try:
        obj = json.loads(text)
        print(item["id"], "json.loads=OK", obj, "expected=", item["expected"])
    except json.JSONDecodeError as e:
        print(item["id"], "json.loads=FAIL", e.msg, "expected=", item["expected"])
