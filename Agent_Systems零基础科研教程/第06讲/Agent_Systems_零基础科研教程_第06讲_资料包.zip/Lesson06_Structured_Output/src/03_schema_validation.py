import json
from pathlib import Path
from common_structured import parse_and_validate, StructuredOutputError

path = Path(__file__).parents[1]/"data"/"action_samples.jsonl"
for line in path.read_text(encoding="utf-8").splitlines():
    item = json.loads(line)
    try:
        action = parse_and_validate(item["text"])
        print(item["id"], "ACCEPT", action)
    except StructuredOutputError as e:
        print(item["id"], "REJECT", type(e).__name__, str(e))
