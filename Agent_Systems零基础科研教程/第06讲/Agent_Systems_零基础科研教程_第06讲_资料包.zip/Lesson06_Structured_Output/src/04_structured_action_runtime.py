from common_structured import parse_and_validate, semantic_guard, execute, StructuredOutputError

cases = [
    ("请计算 12*7", '{"action":"calculate","query":"12*7"}'),
    ("请查 Agent benchmark 的资料", '{"action":"search","query":"Agent benchmark"}'),
    ("任务结束", '{"action":"finish","query":null}'),
]
for task, model_output in cases:
    print("\nTASK:", task)
    print("MODEL_OUTPUT:", model_output)
    try:
        action = parse_and_validate(model_output)
        semantic_guard(action, task)
        result = execute(action)
        print("ACTION:", action)
        print("RESULT:", result)
    except StructuredOutputError as e:
        print("REJECT:", type(e).__name__, e)
