import json, random, csv
from pathlib import Path
from common_structured import parse_and_validate, StructuredOutputError

random.seed(6)
valid = []
for i in range(20):
    valid.append(("valid", json.dumps({"action":"search","query":f"topic-{i}"}, ensure_ascii=False)))
bad = []
for i in range(10): bad.append(("syntax", '{"action":"search","query":"x"'))
for i in range(10): bad.append(("missing", json.dumps({"action":"search"})))
for i in range(10): bad.append(("wrong_type", json.dumps({"action":123,"query":"x"})))
for i in range(10): bad.append(("enum", json.dumps({"action":"dance","query":"x"})))
rows = valid + bad
random.shuffle(rows)

results=[]
for kind,text in rows:
    json_ok=True
    try: json.loads(text)
    except Exception: json_ok=False
    schema_ok=True
    try: parse_and_validate(text)
    except StructuredOutputError: schema_ok=False
    should_accept = kind == "valid"
    results.append({"kind":kind,"json_ok":json_ok,"schema_ok":schema_ok,"should_accept":should_accept})

print("kind counts:")
from collections import Counter
print(Counter(r["kind"] for r in results))
print("json.loads accepted:", sum(r["json_ok"] for r in results), "/", len(results))
print("schema validator accepted:", sum(r["schema_ok"] for r in results), "/", len(results))
print("schema false accept:", sum(r["schema_ok"] and not r["should_accept"] for r in results))
print("schema false reject:", sum((not r["schema_ok"]) and r["should_accept"] for r in results))

out = Path(__file__).parents[1]/"run_outputs"/"failure_injection_results.csv"
with out.open("w",newline="",encoding="utf-8-sig") as f:
    w=csv.DictWriter(f,fieldnames=["kind","json_ok","schema_ok","should_accept"]); w.writeheader(); w.writerows(results)
print("saved:", out)
