from common_structured import parse_and_validate, semantic_guard, execute, StructuredOutputError

cases = [
    ("请计算 18*4", '{"action":"calculate","query":"18*4"}'),
    # 下面结构完全合法，但语义上选错了工具
    ("请计算 18*4", '{"action":"search","query":"18*4"}'),
    ("请查多智能体通信论文", '{"action":"search","query":"multi-agent communication papers"}'),
    # 同样：结构合法，但任务需要搜索，却选了 calculate
    ("请查多智能体通信论文", '{"action":"calculate","query":"2+2"}'),
]
for task, text in cases:
    print("\nTASK:", task)
    action = parse_and_validate(text)
    print("SCHEMA: PASS", action)
    try:
        semantic_guard(action, task)
        print("SEMANTIC_GUARD: PASS")
        print("EXECUTE:", execute(action))
    except StructuredOutputError as e:
        print("SEMANTIC_GUARD: REJECT", type(e).__name__, e)
