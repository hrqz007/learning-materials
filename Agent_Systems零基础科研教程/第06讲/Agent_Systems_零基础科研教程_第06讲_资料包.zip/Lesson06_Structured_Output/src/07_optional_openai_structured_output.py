"""可选：真实 OpenAI Structured Outputs 示例（不属于必做实验）。
截至 2026-09-26，官方文档提供 Responses API + responses.parse + Pydantic 的方式。
需要：pip install openai pydantic，并设置 OPENAI_API_KEY。
"""
from typing import Literal
from pydantic import BaseModel
from openai import OpenAI

class AgentAction(BaseModel):
    action: Literal["search", "calculate", "finish"]
    query: str | None

client = OpenAI()
response = client.responses.parse(
    model="gpt-6-astra",
    input=[
        {"role":"system", "content":"把用户任务转换为一个下一步 Agent action。finish 时 query=null。"},
        {"role":"user", "content":"请搜索 2026 年最新的 Agent benchmark 资料。"},
    ],
    text_format=AgentAction,
)

print(response.output_parsed)
