"""第6讲公共代码：结构化 Action、解析、校验、语义检查与执行。
主实验只使用 Python 标准库，无需 API Key。
"""
from dataclasses import dataclass
from typing import Any
import json

ALLOWED_ACTIONS = {"search", "calculate", "finish"}
REQUIRED_KEYS = {"action", "query"}

@dataclass(frozen=True)
class Action:
    action: str
    query: str | None

class StructuredOutputError(Exception):
    pass

class SyntaxOutputError(StructuredOutputError):
    pass

class SchemaOutputError(StructuredOutputError):
    pass

class SemanticOutputError(StructuredOutputError):
    pass

def parse_json(text: str) -> dict[str, Any]:
    try:
        obj = json.loads(text)
    except json.JSONDecodeError as e:
        raise SyntaxOutputError(f"JSON_SYNTAX_ERROR: {e.msg}") from e
    if not isinstance(obj, dict):
        raise SchemaOutputError("TOP_LEVEL_MUST_BE_OBJECT")
    return obj

def validate_action_schema(obj: dict[str, Any]) -> Action:
    keys = set(obj.keys())
    missing = REQUIRED_KEYS - keys
    extra = keys - REQUIRED_KEYS
    if missing:
        raise SchemaOutputError(f"MISSING_REQUIRED: {sorted(missing)}")
    if extra:
        raise SchemaOutputError(f"ADDITIONAL_PROPERTIES_NOT_ALLOWED: {sorted(extra)}")
    if not isinstance(obj["action"], str):
        raise SchemaOutputError("action MUST_BE_STRING")
    if obj["action"] not in ALLOWED_ACTIONS:
        raise SchemaOutputError(f"action INVALID_ENUM: {obj['action']!r}")
    if obj["query"] is not None and not isinstance(obj["query"], str):
        raise SchemaOutputError("query MUST_BE_STRING_OR_NULL")
    if obj["action"] in {"search", "calculate"} and not obj["query"]:
        raise SchemaOutputError(f"query REQUIRED_FOR_ACTION: {obj['action']}")
    if obj["action"] == "finish" and obj["query"] is not None:
        raise SchemaOutputError("finish REQUIRES query=null")
    return Action(action=obj["action"], query=obj["query"])

def parse_and_validate(text: str) -> Action:
    return validate_action_schema(parse_json(text))

def semantic_guard(action: Action, task: str) -> None:
    """教学用的极简语义检查，不代表真实智能判断。"""
    if "计算" in task or any(ch.isdigit() for ch in task):
        if action.action not in {"calculate", "finish"}:
            raise SemanticOutputError("TASK_LOOKS_NUMERIC_BUT_ACTION_IS_NOT_CALCULATE")
    if "搜索" in task or "查" in task or "资料" in task:
        if action.action not in {"search", "finish"}:
            raise SemanticOutputError("TASK_LOOKS_SEARCH_BUT_ACTION_IS_NOT_SEARCH")

def execute(action: Action):
    # 教学演示。真实 Agent 不要直接对模型输出使用 eval；这里仅允许极小的算术字符集并禁用 builtins。
    if action.action == "search":
        return {"ok": True, "result": f"MOCK_SEARCH_RESULT[{action.query}]"}
    if action.action == "calculate":
        expr = action.query or ""
        if not all(c in "0123456789+-*/(). " for c in expr):
            return {"ok": False, "error": "UNSAFE_EXPRESSION"}
        try:
            return {"ok": True, "result": eval(expr, {"__builtins__": {}}, {})}
        except Exception as e:
            return {"ok": False, "error": f"CALC_ERROR: {type(e).__name__}: {e}"}
    if action.action == "finish":
        return {"ok": True, "result": "FINISHED"}
    return {"ok": False, "error": "UNKNOWN_ACTION"}
