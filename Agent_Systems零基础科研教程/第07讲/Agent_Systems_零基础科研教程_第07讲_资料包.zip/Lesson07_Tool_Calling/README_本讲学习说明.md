# Agent Systems 零基础科研教程 · 第7讲资料包

主题：**Tool Calling——Agent 怎样真正“长出手脚”**

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `05_练习题.docx`（先独立做）
3. `src/01` → `src/07` 依次运行
4. `03_实验指导书.docx`
5. `04_实验设计书.docx`
6. `06_练习题答案.docx`
7. `07_术语速查表.docx`

## 必做实验
- 01 Tool Registry
- 02 Tool Call 完整执行链
- 03 参数故障注入
- 04 Tool Description Ablation（Mock Router，仅教学）
- 05 执行失败与恢复
- 06 Permission / Approval
- 07 批量分层指标

必做实验均只使用 Python 标准库，不需要 API Key。

`08_optional_openai_tool_calling.py` 是可选真实 API 示例，需要自行安装 `openai` 包并配置 API Key。

## 本讲最低掌握标准
你应该能够解释：

`Tool Spec → Tool Call → Parse → Validate → Authorize → Execute → Tool Result → Observation → Next Decision`

并能够把失败分成 selection / arguments / permission / execution / result / recovery 等不同层。

## 版本说明
可选真实 API 示例根据 2026-09-26 的 OpenAI 官方 Function Calling / Tools 文档核对；主教程原理不依赖某个具体框架或模型型号。
