from tool_runtime import build_demo_registry

reg = build_demo_registry("../data")
print("=== 已注册工具 ===")
for spec in reg.list_specs():
    print(f"- {spec.name:12s} | permission={spec.permission:11s} | {spec.description}")
