from tool_runtime import build_demo_registry

reg = build_demo_registry("../data")

# 这里用“预先写好的 Tool Call”模拟模型决定，先把执行链路看清楚。
calls = [
    {"name":"calculator","arguments":{"a":23,"b":17,"op":"mul"}},
    {"name":"read_file","arguments":{"path":"notes.txt"}},
    {"name":"search_local","arguments":{"query":"agent loop"}},
]

for i, call in enumerate(calls, 1):
    print(f"\n--- Case {i} ---")
    print("Tool Call:", call)
    result = reg.execute(call)
    print("Tool Result:", result)
