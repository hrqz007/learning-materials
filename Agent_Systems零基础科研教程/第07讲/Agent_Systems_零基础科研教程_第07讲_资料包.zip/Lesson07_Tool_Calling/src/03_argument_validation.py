from tool_runtime import build_demo_registry

reg = build_demo_registry("../data")
cases = [
    ("合法", {"name":"calculator","arguments":{"a":8,"b":5,"op":"mul"}}),
    ("缺参数", {"name":"calculator","arguments":{"a":8}}),
    ("类型错误", {"name":"calculator","arguments":{"a":"8","b":5}}),
    ("枚举错误", {"name":"calculator","arguments":{"a":8,"b":5,"op":"pow"}}),
    ("多余参数", {"name":"calculator","arguments":{"a":8,"b":5,"unit":"kg"}}),
    ("未知工具", {"name":"weather","arguments":{"city":"Baotou"}}),
]

for label, call in cases:
    r = reg.execute(call)
    print(f"{label:8s} -> ok={r.ok}, error_type={r.error_type}, message={r.error_message}, output={r.output}")
