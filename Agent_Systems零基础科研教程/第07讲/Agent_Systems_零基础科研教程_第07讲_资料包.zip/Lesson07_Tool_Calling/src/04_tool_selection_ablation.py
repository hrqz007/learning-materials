# 教学用 Mock Router：不是 LLM 性能测试，而是说明“工具描述”会影响路由边界。
from dataclasses import dataclass

@dataclass
class Tool:
    name: str
    description: str


def mock_route(task: str, tools):
    text = task.lower()
    # 极简规则：根据描述中的关键词做匹配，仅用于教学。
    scores=[]
    for t in tools:
        s=0
        for kw in ["计算","算术","文件","读取","搜索","检索","知识库"]:
            if kw in task and kw in t.description:
                s+=1
        if any(ch.isdigit() for ch in task) and ("计算" in t.description or "算术" in t.description):
            s+=2
        scores.append((s,t.name))
    return max(scores)[1]

clear = [
    Tool("calculator","用于确定性的算术计算，例如加减乘除"),
    Tool("search_local","用于搜索或检索本地知识库中的文本信息"),
]
ambiguous = [
    Tool("calculator","用于处理用户问题"),
    Tool("search_local","用于获得问题答案"),
]

tasks=["计算 23 × 17", "搜索知识库里的 agent loop", "计算 88 + 12"]
for label, tools in [("清晰描述",clear),("模糊描述",ambiguous)]:
    print("\n==",label,"==")
    for task in tasks:
        print(task, "->", mock_route(task, tools))
