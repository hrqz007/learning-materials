from tool_runtime import build_demo_registry

reg = build_demo_registry("../data")

print("Step 1: Agent 试图读取不存在的文件")
call1={"name":"read_file","arguments":{"path":"missing.txt"}}
r1=reg.execute(call1)
print(r1)

print("\nStep 2: Runtime 把错误作为 observation 返回。Agent 改用知识库检索")
call2={"name":"search_local","arguments":{"query":"tool calling"}}
r2=reg.execute(call2)
print(r2)

print("\nStep 3: 根据成功的 Tool Result 形成最终回答")
if r2.ok:
    print("最终回答：", r2.output[0])
