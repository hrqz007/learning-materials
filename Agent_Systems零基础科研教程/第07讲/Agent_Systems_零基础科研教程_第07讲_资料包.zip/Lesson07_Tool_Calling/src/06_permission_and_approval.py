from tool_runtime import build_demo_registry
from pathlib import Path

base="../data"
reg=build_demo_registry(base)

cases=[
    ("pure 自动执行", {"name":"calculator","arguments":{"a":6,"b":7,"op":"mul"}}, False),
    ("write 未授权", {"name":"save_note","arguments":{"path":"new_note.txt","content":"hello agent"}}, False),
    ("write 已授权", {"name":"save_note","arguments":{"path":"new_note.txt","content":"hello agent"}}, True),
    ("destructive 即使请求也阻断", {"name":"delete_file","arguments":{"path":"new_note.txt"}}, True),
]
for label,call,approved in cases:
    r=reg.execute(call, approved_write=approved)
    print(f"{label:24s} -> ok={r.ok}, error={r.error_type}, output={r.output}, message={r.error_message}")
