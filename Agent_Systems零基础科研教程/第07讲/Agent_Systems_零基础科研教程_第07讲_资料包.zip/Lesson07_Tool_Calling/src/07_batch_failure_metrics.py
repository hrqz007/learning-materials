# 生成一个“可控故障注入”批量实验，演示科研中为什么要分层统计。
import random, csv
from collections import Counter

random.seed(7)
N=120
rows=[]
for i in range(N):
    # 人工设定概率，只用于教学，不代表真实模型。
    selection_ok = random.random() > 0.12
    args_ok = selection_ok and random.random() > 0.08
    permission_ok = args_ok and random.random() > 0.05
    execution_ok = permission_ok and random.random() > 0.07
    recovery_ok = (not execution_ok) and random.random() > 0.45
    task_success = execution_ok or recovery_ok
    if not selection_ok: failure="selection"
    elif not args_ok: failure="arguments"
    elif not permission_ok: failure="permission"
    elif not execution_ok and not recovery_ok: failure="execution_or_recovery"
    else: failure="none"
    rows.append([i,selection_ok,args_ok,permission_ok,execution_ok,recovery_ok,task_success,failure])

with open("../results/tool_call_metrics.csv","w",newline="",encoding="utf-8-sig") as f:
    w=csv.writer(f); w.writerow(["id","selection_ok","args_ok","permission_ok","execution_ok","recovery_ok","task_success","failure"]); w.writerows(rows)

print("N=",N)
for idx,name in [(1,"selection_ok"),(2,"args_ok"),(3,"permission_ok"),(4,"execution_ok"),(6,"task_success")]:
    print(f"{name:16s}: {sum(r[idx] for r in rows)/N:.3f}")
print("failure counts:",Counter(r[7] for r in rows))
print("注意：概率是人为设置的教学数据，不代表任何真实 LLM。")
