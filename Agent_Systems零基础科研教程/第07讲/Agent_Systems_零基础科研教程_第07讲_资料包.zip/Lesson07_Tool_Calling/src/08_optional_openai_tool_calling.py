"""可选：真实 OpenAI Responses API Tool Calling 完整闭环示例。

使用前：
  pip install openai
  设置 OPENAI_API_KEY
  可选设置 OPENAI_MODEL；默认 gpt-5.6

说明：真实 API 会产生费用。本文件不是必做实验。
"""
import os
import json
from openai import OpenAI

client = OpenAI()
model = os.getenv("OPENAI_MODEL", "gpt-5.6")


def calculator(a: float, b: float, op: str):
    if op == "add":
        return a + b
    if op == "sub":
        return a - b
    if op == "mul":
        return a * b
    if op == "div":
        if b == 0:
            raise ZeroDivisionError("不能除以 0")
        return a / b
    raise ValueError(f"不支持的运算: {op}")


tools = [{
    "type": "function",
    "name": "calculator",
    "description": "进行确定性的基础算术运算。用户要求精确计算时使用。",
    "parameters": {
        "type": "object",
        "properties": {
            "a": {"type": "number"},
            "b": {"type": "number"},
            "op": {"type": "string", "enum": ["add", "sub", "mul", "div"]},
        },
        "required": ["a", "b", "op"],
        "additionalProperties": False,
    },
    "strict": True,
}]

# 1) 保存整个输入历史，后面把 Tool Result 追加回去。
input_list = [{"role": "user", "content": "请计算 23×17，并用一句话解释结果。需要时使用工具。"}]

# 2) 第一次请求：把 tools 提供给模型。
response = client.responses.create(model=model, input=input_list, tools=tools)
input_list += response.output

# 3) 找到模型提出的 function_call，并在“应用侧”执行真实函数。
for item in response.output:
    if item.type != "function_call":
        continue

    print("模型请求调用工具：", item.name)
    args = json.loads(item.arguments)
    print("参数：", args)

    if item.name != "calculator":
        result = {"ok": False, "error": f"未知工具: {item.name}"}
    else:
        try:
            value = calculator(**args)
            result = {"ok": True, "result": value}
        except Exception as exc:
            result = {"ok": False, "error": str(exc)}

    # 4) 把真实 Tool Result 连同 call_id 返回给模型。
    input_list.append({
        "type": "function_call_output",
        "call_id": item.call_id,
        "output": json.dumps(result, ensure_ascii=False),
    })

# 5) 第二次请求：模型看见 Tool Result 后生成最终回答。
final_response = client.responses.create(model=model, input=input_list, tools=tools)
print("最终回答：", final_response.output_text)
