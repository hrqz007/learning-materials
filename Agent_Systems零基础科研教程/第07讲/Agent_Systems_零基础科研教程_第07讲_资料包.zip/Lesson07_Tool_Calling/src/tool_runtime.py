from __future__ import annotations
from dataclasses import dataclass
from typing import Any, Callable, Dict, Optional
import json

@dataclass
class ToolSpec:
    name: str
    description: str
    parameters: dict
    permission: str = "read-only"  # pure | read-only | write | destructive

@dataclass
class ToolResult:
    ok: bool
    tool_name: str
    output: Any = None
    error_type: Optional[str] = None
    error_message: Optional[str] = None

class ToolRegistry:
    def __init__(self):
        self.specs: Dict[str, ToolSpec] = {}
        self.handlers: Dict[str, Callable[..., Any]] = {}

    def register(self, spec: ToolSpec, handler: Callable[..., Any]):
        if spec.name in self.specs:
            raise ValueError(f"重复注册工具: {spec.name}")
        self.specs[spec.name] = spec
        self.handlers[spec.name] = handler

    def list_specs(self):
        return list(self.specs.values())

    def get_spec(self, name: str) -> ToolSpec:
        if name not in self.specs:
            raise KeyError(f"未知工具: {name}")
        return self.specs[name]

    def validate_arguments(self, spec: ToolSpec, args: dict):
        schema = spec.parameters
        if not isinstance(args, dict):
            return False, "arguments 必须是 object/dict"
        props = schema.get("properties", {})
        required = schema.get("required", [])
        for key in required:
            if key not in args:
                return False, f"缺少必需参数: {key}"
        if schema.get("additionalProperties") is False:
            extras = set(args) - set(props)
            if extras:
                return False, f"出现未声明参数: {sorted(extras)}"
        py_types = {"number": (int, float), "integer": int, "string": str, "boolean": bool}
        for key, val in args.items():
            if key not in props:
                continue
            t = props[key].get("type")
            if t in py_types and not isinstance(val, py_types[t]):
                return False, f"参数 {key} 类型错误，期望 {t}"
            if t == "number" and isinstance(val, bool):
                return False, f"参数 {key} 不能是 bool"
            if "enum" in props[key] and val not in props[key]["enum"]:
                return False, f"参数 {key} 不在允许集合 {props[key]['enum']} 中"
        return True, "OK"

    def execute(self, call: dict, approved_write=False) -> ToolResult:
        name = call.get("name")
        args = call.get("arguments", {})
        if name not in self.specs:
            return ToolResult(False, str(name), error_type="unknown_tool", error_message="工具不存在")
        spec = self.specs[name]
        valid, msg = self.validate_arguments(spec, args)
        if not valid:
            return ToolResult(False, name, error_type="argument_error", error_message=msg)
        if spec.permission == "write" and not approved_write:
            return ToolResult(False, name, error_type="permission_denied", error_message="写入工具需要显式批准")
        if spec.permission == "destructive":
            return ToolResult(False, name, error_type="permission_denied", error_message="破坏性工具在本教程 Runtime 中默认阻断")
        try:
            out = self.handlers[name](**args)
            return ToolResult(True, name, output=out)
        except Exception as e:
            return ToolResult(False, name, error_type=type(e).__name__, error_message=str(e))


def build_demo_registry(base_dir="."):
    from pathlib import Path
    base = Path(base_dir)
    reg = ToolRegistry()

    def calculator(a: float, b: float, op: str = "mul"):
        if op == "add": return a + b
        if op == "sub": return a - b
        if op == "mul": return a * b
        if op == "div":
            if b == 0: raise ZeroDivisionError("不能除以 0")
            return a / b
        raise ValueError("不支持的运算")

    def read_file(path: str):
        p = base / path
        return p.read_text(encoding="utf-8")

    def search_local(query: str):
        kb = {
            "agent loop": "Agent Loop 常见结构：Observe → Decide → Act → Feedback。",
            "tool calling": "Tool Calling 让模型请求外部函数或服务，由 Runtime 实际执行。",
            "structured output": "Structured Output 用 Schema 约束模型输出结构。",
        }
        q = query.lower()
        hits = [v for k,v in kb.items() if q in k or k in q]
        return hits or ["未找到匹配条目"]

    def save_note(path: str, content: str):
        p = base / path
        p.write_text(content, encoding="utf-8")
        return {"saved": str(p), "chars": len(content)}

    def delete_file(path: str):
        p = base / path
        p.unlink()
        return {"deleted": str(p)}

    reg.register(ToolSpec("calculator", "进行确定性的基础算术运算", {
        "type":"object","properties":{"a":{"type":"number"},"b":{"type":"number"},"op":{"type":"string","enum":["add","sub","mul","div"]}},
        "required":["a","b"],"additionalProperties":False}, "pure"), calculator)
    reg.register(ToolSpec("read_file", "读取指定的本地文本文件", {
        "type":"object","properties":{"path":{"type":"string"}},"required":["path"],"additionalProperties":False}, "read-only"), read_file)
    reg.register(ToolSpec("search_local", "在本地小型知识库中检索概念", {
        "type":"object","properties":{"query":{"type":"string"}},"required":["query"],"additionalProperties":False}, "read-only"), search_local)
    reg.register(ToolSpec("save_note", "将文本写入本地笔记文件", {
        "type":"object","properties":{"path":{"type":"string"},"content":{"type":"string"}},"required":["path","content"],"additionalProperties":False}, "write"), save_note)
    reg.register(ToolSpec("delete_file", "删除指定本地文件", {
        "type":"object","properties":{"path":{"type":"string"}},"required":["path"],"additionalProperties":False}, "destructive"), delete_file)
    return reg
