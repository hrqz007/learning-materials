# Agent Systems 零基础科研教程 - 第8讲

主题：真正完整的 Agent Loop。

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立做）
3. 运行 src/01-08 必做实验
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
- 01 完整多步 Agent Loop
- 02 逐轮拆解
- 03 停止条件
- 04 失败恢复
- 05 Feedback/State Ablation
- 06 Trace Logging
- 07 Batch Metrics
- 08 Replay

必做实验仅使用 Python 标准库，不需要 API Key。
09_optional_openai_agent_loop.py 为可选真实 API 示例。

## 本讲最重要的三个结论
1. Tool Calling 不等于完整 Agent；多轮闭环还需要 State、Runtime、Stop/Guard。
2. Retry ≠ Recovery。真正恢复意味着失败后改变后续策略。
3. Agent Systems 科研要看 Trace/Trajectory，不要只看最终 Success Rate。
