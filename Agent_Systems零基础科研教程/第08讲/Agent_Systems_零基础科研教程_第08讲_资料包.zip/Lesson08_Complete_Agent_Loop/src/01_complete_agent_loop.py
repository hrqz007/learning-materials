from agent_runtime import ToolRegistry, MockPolicy, AgentRuntime
reg=ToolRegistry("../data")
rt=AgentRuntime(reg,MockPolicy(),trace_path="../results/trace_01.jsonl")
state=rt.run("请计算 23×17，把结果保存到笔记")
print("status=",state.status)
print("stop_reason=",state.stop_reason)
print("turns=",state.turn)
print("memory=",state.memory)
print("final_answer=",state.final_answer)
