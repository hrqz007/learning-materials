from agent_runtime import ToolRegistry, MockPolicy, RunState
reg=ToolRegistry("../data"); policy=MockPolicy(); state=RunState("请解释 agent loop")
for turn in range(1,5):
    state.turn=turn
    action=policy.decide(state)
    print(f"\nTURN {turn}")
    print("memory before:",state.memory)
    print("action:",action)
    if action.type=="finish":
        print("finish:",action.answer); break
    result=reg.execute(action.name,action.arguments)
    print("result:",result)
    if action.name=="search_local" and result.ok: state.memory["lookup"]=result.output
    print("memory after:",state.memory)
