from agent_runtime import ToolRegistry, MockPolicy, BadRepeatingPolicy, AgentRuntime
reg=ToolRegistry("../data")
for label,policy,max_turns,no_progress in [
    ("正常完成",MockPolicy(),8,3),
    ("no_progress 保护",BadRepeatingPolicy(),20,2),
    ("max_turns 保护",BadRepeatingPolicy(),2,99),
]:
    rt=AgentRuntime(reg,policy,max_turns=max_turns,no_progress_limit=no_progress)
    s=rt.run("missing 文件测试")
    print(label,"->",s.status,s.stop_reason,"turns=",s.turn)
