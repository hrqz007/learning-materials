from agent_runtime import ToolRegistry, MockPolicy, AgentRuntime
reg=ToolRegistry("../data")
rt=AgentRuntime(reg,MockPolicy(),trace_path="../results/trace_04.jsonl")
s=rt.run("请读取 missing 文件中的 agent loop 信息")
print("status=",s.status,"stop_reason=",s.stop_reason)
print("observations=")
for x in s.observations: print(x)
print("final=",s.final_answer)
