# 对照实验：有状态写回 vs 删除关键状态写回
from agent_runtime import ToolRegistry, MockPolicy, AgentRuntime

class BrokenRuntime(AgentRuntime):
    def _update_state(self,state,action,result):
        # 只记 observation，不把 calculator/save_note 结果写入 memory
        state.observations.append({"tool":action.name,"ok":result.ok,"output":result.output})

reg=ToolRegistry("../data")
normal=AgentRuntime(reg,MockPolicy(),max_turns=8,no_progress_limit=2).run("请计算 23×17，把结果保存到笔记")
broken=BrokenRuntime(reg,MockPolicy(),max_turns=8,no_progress_limit=2).run("请计算 23×17，把结果保存到笔记")
print("normal:",normal.status,normal.stop_reason,normal.turn,normal.memory)
print("broken:",broken.status,broken.stop_reason,broken.turn,broken.memory)
