from pathlib import Path
import json
from agent_runtime import ToolRegistry, MockPolicy, AgentRuntime
path="../results/trace_06.jsonl"
Path(path).unlink(missing_ok=True)
s=AgentRuntime(ToolRegistry("../data"),MockPolicy(),trace_path=path).run("请计算 23×17，把结果保存到笔记")
print("trace path:",path)
for line in Path(path).read_text(encoding="utf-8").splitlines():
    obj=json.loads(line); print(obj.get("event"),"turn=",obj.get("turn"),"stop=",obj.get("stop_reason"))
