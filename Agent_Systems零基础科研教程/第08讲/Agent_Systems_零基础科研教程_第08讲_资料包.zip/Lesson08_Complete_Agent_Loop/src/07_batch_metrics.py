# 教学用批量仿真：人为注入成功、恢复、循环等概率，不代表任何真实 LLM。
import random,csv
from collections import Counter
random.seed(8); N=200; rows=[]
for i in range(N):
    first_ok=random.random()>0.18
    recovered=(not first_ok) and random.random()>0.42
    looped=(not first_ok and not recovered and random.random()<0.35)
    success=first_ok or recovered
    turns=2 if first_ok else (4 if recovered else (8 if looped else 3))
    stop="explicit_finish" if success else ("no_progress" if looped else "fatal_or_other")
    tool_calls=1 if first_ok else (2 if recovered else turns)
    rows.append([i,first_ok,recovered,looped,success,turns,tool_calls,stop])
with open("../results/agent_loop_metrics.csv","w",newline="",encoding="utf-8-sig") as f:
    w=csv.writer(f); w.writerow(["id","first_ok","recovered","looped","success","turns","tool_calls","stop_reason"]); w.writerows(rows)
print("N=",N)
print("success_rate=",round(sum(r[4] for r in rows)/N,3))
print("recovery_rate_on_failures=",round(sum(r[2] for r in rows)/max(1,sum(not r[1] for r in rows)),3))
print("loop_rate=",round(sum(r[3] for r in rows)/N,3))
print("avg_turns=",round(sum(r[5] for r in rows)/N,3))
print("stop reasons=",Counter(r[7] for r in rows))
print("注意：这是人为概率的教学数据，不代表任何真实模型。")
