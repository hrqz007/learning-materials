# 从 trace 重放“发生了什么”，不重新执行工具。
from pathlib import Path
import json
path=Path("../results/trace_01.jsonl")
if not path.exists():
    raise SystemExit("请先运行 01_complete_agent_loop.py")
print("=== REPLAY ===")
for line in path.read_text(encoding="utf-8").splitlines():
    e=json.loads(line)
    if e["event"]=="turn":
        print(f"TURN {e['turn']}: action={e['action']}")
        if "tool_result" in e: print("  result=",e["tool_result"])
        if "stop_reason" in e: print("  stop=",e["stop_reason"])
    else:
        print(e["event"],{k:v for k,v in e.items() if k!="event"})
