"""可选：真实 OpenAI Responses API + Function Calling 的多轮 Agent Loop 示例。
使用前：pip install openai，并设置 OPENAI_API_KEY 与 OPENAI_MODEL。
本脚本示范 previous_response_id + function_call_output 的循环。
"""
import os,json
from openai import OpenAI
client=OpenAI(); model=os.environ.get("OPENAI_MODEL","gpt-6-astra")

def calculator(a,b,op):
    return {"add":a+b,"sub":a-b,"mul":a*b,"div":a/b}[op]

tools=[{"type":"function","name":"calculator","description":"进行确定性的基础算术运算","parameters":{
    "type":"object","properties":{"a":{"type":"number"},"b":{"type":"number"},"op":{"type":"string","enum":["add","sub","mul","div"]}},
    "required":["a","b","op"],"additionalProperties":False},"strict":True}]

next_input="请计算 23×17，并用一句话解释结果。需要时使用工具。"
previous_response_id=None
for turn in range(1,8):
    kwargs={"model":model,"tools":tools,"input":next_input}
    if previous_response_id: kwargs["previous_response_id"]=previous_response_id
    response=client.responses.create(**kwargs)
    calls=[x for x in response.output if x.type=="function_call"]
    if not calls:
        print("FINAL:",response.output_text); break
    outputs=[]
    for call in calls:
        args=json.loads(call.arguments)
        if call.name!="calculator": raise ValueError(call.name)
        result=calculator(**args)
        print(f"TURN {turn}: {call.name}{args} -> {result}")
        outputs.append({"type":"function_call_output","call_id":call.call_id,"output":json.dumps(result,ensure_ascii=False)})
    previous_response_id=response.id
    next_input=outputs
else:
    raise RuntimeError("达到轮数上限，请检查轨迹")
