from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
import json, time

@dataclass
class ToolResult:
    ok: bool
    tool_name: str
    output: Any = None
    error_type: Optional[str] = None
    error_message: Optional[str] = None

class ToolRegistry:
    def __init__(self, base_dir="."):
        self.base = Path(base_dir)
        self.handlers: Dict[str, Callable[..., Any]] = {}
        self.register("calculator", self.calculator)
        self.register("read_file", self.read_file)
        self.register("search_local", self.search_local)
        self.register("save_note", self.save_note)

    def register(self, name, fn): self.handlers[name]=fn
    def calculator(self,a,b,op="mul"):
        if op=="add": return a+b
        if op=="sub": return a-b
        if op=="mul": return a*b
        if op=="div":
            if b==0: raise ZeroDivisionError("不能除以 0")
            return a/b
        raise ValueError("不支持的运算")
    def read_file(self,path): return (self.base/path).read_text(encoding="utf-8")
    def search_local(self,query):
        kb={
            "agent loop":"Agent Loop = Observe → Decide → Act → Feedback → Update State → Stop/Continue。",
            "tool calling":"Tool Calling 让模型请求工具，由 Runtime 执行并返回 Tool Result。",
            "structured output":"Structured Output 用 Schema 约束模型的机器可读输出。",
        }
        q=query.lower(); hits=[v for k,v in kb.items() if q in k or k in q]
        return hits or ["未找到匹配条目"]
    def save_note(self,path,content):
        p=self.base/path; p.write_text(content,encoding="utf-8"); return {"saved":str(p),"chars":len(content)}
    def execute(self,name,args):
        if name not in self.handlers: return ToolResult(False,name,error_type="unknown_tool",error_message="工具不存在")
        try: return ToolResult(True,name,output=self.handlers[name](**args))
        except Exception as e: return ToolResult(False,name,error_type=type(e).__name__,error_message=str(e))

@dataclass
class Action:
    type: str                  # tool | finish
    name: Optional[str]=None
    arguments: dict=field(default_factory=dict)
    answer: Optional[str]=None

@dataclass
class RunState:
    task: str
    turn: int=0
    memory: Dict[str,Any]=field(default_factory=dict)
    observations: List[dict]=field(default_factory=list)
    status: str="running"
    stop_reason: Optional[str]=None
    final_answer: Optional[str]=None

class TraceLogger:
    def __init__(self,path=None): self.path=Path(path) if path else None; self.events=[]
    def log(self,event):
        self.events.append(event)
        if self.path:
            self.path.parent.mkdir(parents=True,exist_ok=True)
            with self.path.open("a",encoding="utf-8") as f: f.write(json.dumps(event,ensure_ascii=False)+"\n")

class MockPolicy:
    """教学策略：用确定规则模拟模型决策。目的不是模拟 LLM 智力，而是把 Agent Loop 结构看清楚。"""
    def decide(self,state:RunState)->Action:
        task=state.task.lower()
        # 多步任务A：计算并保存
        if "23" in task and "17" in task and ("保存" in task or "笔记" in task):
            if "calc" not in state.memory:
                return Action("tool","calculator",{"a":23,"b":17,"op":"mul"})
            if "saved" not in state.memory:
                return Action("tool","save_note",{"path":"answer.txt","content":f"23×17={state.memory['calc']}"})
            return Action("finish",answer=f"已计算 {state.memory['calc']}，并保存到 answer.txt")
        # 多步任务B：读取失败后回退检索
        if "missing" in task:
            if not state.memory.get("tried_file"):
                return Action("tool","read_file",{"path":"missing.txt"})
            if "fallback" not in state.memory:
                return Action("tool","search_local",{"query":"agent loop"})
            return Action("finish",answer="原文件不存在，已改用本地知识库完成查询。")
        # 简单查询
        if "agent loop" in task:
            if "lookup" not in state.memory:
                return Action("tool","search_local",{"query":"agent loop"})
            return Action("finish",answer=state.memory["lookup"][0])
        return Action("finish",answer="MockPolicy 没有为这个教学任务配置规则。")

class BadRepeatingPolicy:
    def decide(self,state):
        return Action("tool","read_file",{"path":"missing.txt"})

class AgentRuntime:
    def __init__(self,registry,policy,max_turns=8,no_progress_limit=3,trace_path=None):
        self.registry=registry; self.policy=policy; self.max_turns=max_turns; self.no_progress_limit=no_progress_limit; self.trace=TraceLogger(trace_path)

    def _update_state(self,state:RunState,action:Action,result:ToolResult):
        # 这个映射只是教学示例；真实系统通常会把更多内容写入上下文/消息历史。
        if action.name=="calculator" and result.ok: state.memory["calc"]=result.output
        if action.name=="save_note" and result.ok: state.memory["saved"]=True
        if action.name=="read_file": state.memory["tried_file"]=True
        if action.name=="search_local" and result.ok:
            if "missing" in state.task.lower(): state.memory["fallback"]=result.output
            else: state.memory["lookup"]=result.output
        state.observations.append({"tool":action.name,"ok":result.ok,"output":result.output,"error_type":result.error_type,"error_message":result.error_message})

    def run(self,task):
        state=RunState(task=task); last_fingerprint=None; repeated=0
        self.trace.log({"event":"run_start","task":task})
        while state.status=="running":
            if state.turn>=self.max_turns:
                state.status="stopped"; state.stop_reason="max_turns"; break
            state.turn += 1
            action=self.policy.decide(state)
            event={"event":"turn","turn":state.turn,"memory_before":dict(state.memory),"action":asdict(action)}
            if action.type=="finish":
                state.status="completed"; state.stop_reason="explicit_finish"; state.final_answer=action.answer
                event["stop_reason"]=state.stop_reason; self.trace.log(event); break
            result=self.registry.execute(action.name,action.arguments)
            event["tool_result"]=asdict(result)
            self._update_state(state,action,result)
            event["memory_after"]=dict(state.memory)
            fingerprint=json.dumps({"action":asdict(action),"memory_after":state.memory},sort_keys=True,ensure_ascii=False,default=str)
            repeated = repeated+1 if fingerprint==last_fingerprint else 0
            last_fingerprint=fingerprint
            if repeated>=self.no_progress_limit:
                state.status="stopped"; state.stop_reason="no_progress"; event["stop_reason"]="no_progress"; self.trace.log(event); break
            self.trace.log(event)
        self.trace.log({"event":"run_end","status":state.status,"stop_reason":state.stop_reason,"turns":state.turn,"final_answer":state.final_answer,"memory":state.memory})
        return state
