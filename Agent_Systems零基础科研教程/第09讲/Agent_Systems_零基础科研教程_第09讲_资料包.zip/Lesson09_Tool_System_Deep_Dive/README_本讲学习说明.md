# Agent Systems 零基础科研教程 - 第9讲

主题：工具系统深入（Tool Selection、语义重叠、Timeout、Retry、Fallback、幂等性、Result Validation）。

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立做）
3. 运行 src/01-08 必做实验
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
- 01 Tool Selection Baseline
- 02 Description Overlap Ablation
- 03 Tool Count & Routing
- 04 Argument Validation
- 05 Timeout & Retry
- 06 Idempotency & Side Effects
- 07 Result Validation & Fallback
- 08 Batch Layered Metrics

必做实验仅使用 Python 标准库，不需要 API Key。
09_optional_openai_tool_control.py 为可选真实 API 示例。

## 本讲最重要的四个结论
1. Tool failure 必须拆层：Selection → Arguments → Permission → Execution → Result → Recovery。
2. 工具描述、候选集合和路由策略本身就是 Agent Runtime 的一部分。
3. Timeout 后不能机械重试；先判断错误类型和工具是否具有副作用/幂等性。
4. Execution success ≠ valid result ≠ task success。
