from tool_system import ToolSpec, SimpleSelector
specs=[
    ToolSpec("search_docs","搜索本地课程文档和内部知识库","search"),
    ToolSpec("search_web","搜索互联网最新网页信息","search"),
    ToolSpec("calculator","计算加减乘除等确定性算术","compute"),
    ToolSpec("read_file","读取本地文件内容","file"),
]
selector=SimpleSelector()
tasks=[
    ("查本地课程文档中的 Agent Loop 定义","search_docs"),
    ("搜索互联网最新网页上的 Agent 工具资料","search_web"),
    ("计算 23 乘 17","calculator"),
    ("读取文件 course_notes.txt","read_file"),
]
for task, expected in tasks:
    chosen, scored=selector.choose(task,specs)
    print("TASK:",task)
    print("EXPECTED:",expected,"CHOSEN:",chosen,"OK:",chosen==expected)
    print("SCORES:",scored,"\n")
