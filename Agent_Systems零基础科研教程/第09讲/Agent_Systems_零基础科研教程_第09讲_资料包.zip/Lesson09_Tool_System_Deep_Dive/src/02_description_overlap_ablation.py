from tool_system import ToolSpec

def score(task, spec):
    cues=["本地","课程","文档","互联网","最新","网页","搜索"]
    return sum(2 for c in cues if c in task and c in spec.description)
def choose(task,specs):
    scored=[(score(task,s),i,s.name) for i,s in enumerate(specs)]
    scored.sort(key=lambda x:(-x[0],x[1]))
    return scored[0][2],scored

task="查本地课程文档中的 Agent Loop 定义"
clear=[
    ToolSpec("search_docs","搜索本地课程文档和内部知识库","search"),
    ToolSpec("search_web","搜索互联网最新网页信息","search"),
]
ambiguous=[
    ToolSpec("search_web","搜索信息和资料","search"),
    ToolSpec("search_docs","搜索信息和资料","search"),
]
for name,specs in [("CLEAR",clear),("AMBIGUOUS",ambiguous)]:
    chosen, scored=choose(task,specs)
    print(name,"chosen=",chosen,"scores=",scored)
print("\n解释：AMBIGUOUS 中两工具的 description 不再提供数据源边界，出现同分；此时选择对候选顺序敏感。")
