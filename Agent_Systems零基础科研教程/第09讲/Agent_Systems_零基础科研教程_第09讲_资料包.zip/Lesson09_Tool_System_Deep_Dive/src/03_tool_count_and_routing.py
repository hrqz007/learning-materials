from tool_system import ToolSpec

def score(task,spec):
 cues=["本地","课程","文档","互联网","最新","网页","Agent","计算","乘","加","读取","文件",".txt","保存","笔记"]
 return sum(2 for c in cues if c in task and c in spec.description)
def choose(task,specs):
 scored=[(score(task,s),i,s.name) for i,s in enumerate(specs)]
 scored.sort(key=lambda x:(-x[0],x[1]))
 return scored[0][2],scored
base=[
 ToolSpec("search_docs","搜索本地课程文档和内部知识库","search"),
 ToolSpec("search_web","搜索互联网最新 Agent 网页信息","search"),
 ToolSpec("calculator","计算乘法加法等确定性算术","compute"),
 ToolSpec("read_file","读取本地 .txt 文件内容","file"),
 ToolSpec("write_note","保存笔记并写入文件","write"),
]
confusers=[
 ToolSpec("archive_course_docs","整理本地课程文档并写入归档文件","write"),
 ToolSpec("save_web_snapshot","保存互联网最新网页到文件","write"),
 ToolSpec("math_formula_search","搜索计算乘法加法公式文档","search"),
 ToolSpec("file_indexer","读取文件并写入索引","write"),
 ToolSpec("read_saved_notes","读取保存的笔记文件","file"),
]
extras=[
 ToolSpec("search_news","搜索互联网最新新闻网页","search"),
 ToolSpec("search_papers","搜索论文文档","search"),
 ToolSpec("read_pdf","读取 PDF 文件","file"),
 ToolSpec("save_report","保存报告到文件","write"),
 ToolSpec("calculator_stats","计算统计量","compute"),
]
sets={5:base,10:confusers[:3]+extras[:2]+base,15:confusers+extras+base}
tasks=[
 ("查本地课程文档中的 Agent Loop 定义","search_docs","search"),
 ("搜索互联网最新网页上的 Agent 工具资料","search_web","search"),
 ("计算 23 乘 17","calculator","compute"),
 ("读取文件 course_notes.txt","read_file","file"),
 ("保存笔记到文件","write_note","write"),
]
def evaluate(specs):
 ok=0
 for task,exp,_ in tasks:
  chosen,_=choose(task,specs); ok += chosen==exp
 return ok/len(tasks)
for n,specs in sets.items(): print(f"flat tools={n:2d} accuracy={evaluate(specs):.2f}")
def route(task):
 if "保存" in task or "写入" in task: return "write"
 if "计算" in task or "乘" in task or "加" in task: return "compute"
 if "搜索" in task or "查" in task: return "search"
 if "读取" in task or "文件" in task: return "file"
 return "search"
specs=sets[15]; ok=0
for task,exp,_ in tasks:
 c=route(task); subset=[s for s in specs if s.category==c]
 chosen,scored=choose(task,subset); ok += chosen==exp
 print("ROUTED",task,"category=",c,"chosen=",chosen,"expected=",exp,"scores=",scored)
print("routed accuracy=",ok/len(tasks))
print("注意：这是教学选择器的受控实验，用于演示候选集/路由机制，不代表真实 LLM 的性能曲线。")
