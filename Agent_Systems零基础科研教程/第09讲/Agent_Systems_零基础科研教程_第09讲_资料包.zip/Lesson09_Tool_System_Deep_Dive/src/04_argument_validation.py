from tool_system import ToolRegistry, ToolSpec
reg=ToolRegistry("../data")
reg.register(ToolSpec("calculator","计算加减乘除","compute",required_args={"a":int,"b":int,"op":str}), lambda a,b,op: a*b if op=="mul" else a+b)
cases=[
 ("valid",{"a":23,"b":17,"op":"mul"}),
 ("missing",{"a":23,"b":17}),
 ("extra",{"a":23,"b":17,"op":"mul","unit":"x"}),
 ("wrong_type",{"a":"23","b":17,"op":"mul"}),
]
for name,args in cases:
 result=reg.execute("calculator",args)
 print(name, result)
