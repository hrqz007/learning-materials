from tool_system import backoff_retry
class TransientService:
 def __init__(self): self.calls=0
 def call(self):
  self.calls+=1
  print("transient call",self.calls)
  if self.calls<3: raise TimeoutError("模拟短暂超时")
  return {"status":"ok","value":42}
class PermanentService:
 def call(self):
  print("permanent call")
  raise ValueError("参数格式永久错误")

svc=TransientService()
value,attempts=backoff_retry(svc.call,max_attempts=4,base_delay=0.01)
print("transient recovered:",value,"attempts=",attempts)

try:
 backoff_retry(PermanentService().call,max_attempts=4,base_delay=0.01)
except Exception as e:
 print("permanent not retried by policy:",type(e).__name__,str(e))
