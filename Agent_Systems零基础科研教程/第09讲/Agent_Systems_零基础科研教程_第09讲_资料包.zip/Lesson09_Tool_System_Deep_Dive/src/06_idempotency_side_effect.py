from tool_system import stable_id
class RemoteAppendService:
 def __init__(self):
  self.rows=[]; self.seen={}; self.first=True
 def naive_append(self,text):
  self.rows.append(text)
  if self.first:
   self.first=False
   raise TimeoutError("服务已写入，但响应在网络中丢失")
  return {"row":len(self.rows)-1}
 def safe_append(self,text,key):
  if key in self.seen: return self.seen[key]
  self.rows.append(text); result={"row":len(self.rows)-1,"key":key}; self.seen[key]=result
  if self.first:
   self.first=False
   raise TimeoutError("服务已写入，但响应丢失；key 已记录")
  return result

# naive retry
svc=RemoteAppendService()
for i in range(2):
 try:
  print("naive result",svc.naive_append("提交订单A")); break
 except TimeoutError as e:
  print("naive timeout -> retry",e)
print("naive rows=",svc.rows)

# idempotent retry
svc=RemoteAppendService(); key=stable_id("task42-step3-orderA")
for i in range(2):
 try:
  print("safe result",svc.safe_append("提交订单A",key)); break
 except TimeoutError as e:
  print("safe timeout -> retry with same key",e)
print("safe rows=",svc.rows)
