import time

def primary_search(query):
 # 函数正常返回，但业务结果不合格：空数据 + 过期时间戳
 return {"status":"ok","items":[],"timestamp":time.time()-86400*30}
def fallback_search(query):
 return {"status":"ok","items":["Agent Loop 教程条目"],"timestamp":time.time()}
def validate(result,max_age_seconds=3600):
 if not isinstance(result,dict): return False,"not_dict"
 if result.get("status")!="ok": return False,"status_not_ok"
 if not result.get("items"): return False,"empty_items"
 if time.time()-result.get("timestamp",0)>max_age_seconds: return False,"stale"
 return True,"ok"

r1=primary_search("agent loop"); ok,reason=validate(r1)
print("primary execution ok=True result_valid=",ok,"reason=",reason)
if not ok:
 r2=fallback_search("agent loop"); ok2,reason2=validate(r2)
 print("fallback execution ok=True result_valid=",ok2,"reason=",reason2,"items=",r2["items"])
