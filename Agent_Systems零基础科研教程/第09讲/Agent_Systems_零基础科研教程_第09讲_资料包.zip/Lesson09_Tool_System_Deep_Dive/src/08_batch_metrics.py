import csv, random
from pathlib import Path
random.seed(9)
rows=[]
# 人为生成的教学故障注入，不代表真实模型。每条任务依次经历 6 个阶段。
for i in range(200):
 selection = random.random() > 0.12
 args = selection and random.random() > 0.06
 permission = args and random.random() > 0.03
 execution = permission and random.random() > 0.10
 valid_result = execution and random.random() > 0.08
 recovered = False
 if selection and (not execution or not valid_result):
  recovered = random.random() < 0.55
 success = valid_result or recovered
 redundant_calls = 1 if random.random()<0.09 else 0
 retries = 0 if execution else (1 if random.random()<0.7 else 2)
 rows.append({"task_id":i+1,"selection_ok":int(selection),"args_ok":int(args),"permission_ok":int(permission),"execution_ok":int(execution),"valid_result":int(valid_result),"recovered":int(recovered),"redundant_calls":redundant_calls,"retries":retries,"task_success":int(success)})
RESULT_DIR = Path(__file__).resolve().parent.parent / "results"
RESULT_DIR.mkdir(parents=True, exist_ok=True)
with open(RESULT_DIR / "tool_system_metrics.csv","w",newline="",encoding="utf-8-sig") as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
def rate(k): return sum(r[k] for r in rows)/len(rows)
for k in ["selection_ok","args_ok","permission_ok","execution_ok","valid_result","recovered","task_success"]:
 print(k, f"{rate(k):.3f}")
print("avg_retries",sum(r["retries"] for r in rows)/len(rows))
print("redundant_call_rate",rate("redundant_calls"))
print("注意：以上数字来自人为故障注入，仅用于学习分层指标。")
