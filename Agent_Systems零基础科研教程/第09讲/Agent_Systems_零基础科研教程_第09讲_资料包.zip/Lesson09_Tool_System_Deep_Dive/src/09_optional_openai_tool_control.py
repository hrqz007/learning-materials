"""可选真实 API 示例。需要：pip install openai + OPENAI_API_KEY。
展示：strict schema、tool_choice / allowed_tools 的基本位置。
请以运行时官方文档为准选择你账户可用模型。
"""
import os, json
from openai import OpenAI
client=OpenAI()
model=os.getenv("OPENAI_MODEL","gpt-5.4-mini")

tools=[
 {"type":"function","name":"search_docs","description":"仅用于搜索本地课程文档；不要用于互联网最新信息。","parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"],"additionalProperties":False},"strict":True},
 {"type":"function","name":"search_web_mock","description":"教学示例：表示互联网搜索工具；不要用于本地课程文档。","parameters":{"type":"object","properties":{"query":{"type":"string"}},"required":["query"],"additionalProperties":False},"strict":True},
]
response=client.responses.create(
 model=model,
 input="请查找本地课程文档中的 Agent Loop 定义。",
 tools=tools,
 # 默认 tool_choice='auto'；也可按官方文档改成 required / forced / allowed_tools。
 tool_choice="auto",
 parallel_tool_calls=False,
)
for item in response.output:
 if item.type=="function_call":
  print("function_call",item.name,json.loads(item.arguments),"call_id=",item.call_id)
print("如果模型未调用工具，请检查任务、工具描述、tool_choice 与模型能力。")
