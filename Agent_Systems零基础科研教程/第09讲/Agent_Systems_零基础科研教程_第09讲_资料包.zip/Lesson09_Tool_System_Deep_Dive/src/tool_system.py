from __future__ import annotations
from dataclasses import dataclass, field, asdict
from pathlib import Path
from typing import Any, Callable, Dict, List, Optional
import json, time, hashlib

@dataclass
class ToolSpec:
    name: str
    description: str
    category: str
    risk: str = "read"       # read | write | destructive
    required_args: Dict[str, type] = field(default_factory=dict)

@dataclass
class ToolResult:
    ok: bool
    tool_name: str
    output: Any = None
    error_type: Optional[str] = None
    error_message: Optional[str] = None
    attempts: int = 1

class ToolRegistry:
    def __init__(self, base_dir="."):
        self.base = Path(base_dir)
        self.handlers: Dict[str, Callable[..., Any]] = {}
        self.specs: Dict[str, ToolSpec] = {}

    def register(self, spec: ToolSpec, fn: Callable[..., Any]):
        self.specs[spec.name] = spec
        self.handlers[spec.name] = fn

    def validate_args(self, name: str, args: dict):
        if name not in self.specs:
            return False, "unknown_tool"
        spec = self.specs[name]
        if set(args) != set(spec.required_args):
            return False, f"argument_keys_mismatch expected={list(spec.required_args)} got={list(args)}"
        for k, typ in spec.required_args.items():
            if not isinstance(args[k], typ):
                return False, f"argument_type_error {k}: expected {typ.__name__}, got {type(args[k]).__name__}"
        return True, None

    def execute(self, name: str, args: dict, allowed_risks=("read", "write")):
        if name not in self.specs:
            return ToolResult(False, name, error_type="unknown_tool", error_message="工具不存在")
        spec = self.specs[name]
        if spec.risk not in allowed_risks:
            return ToolResult(False, name, error_type="permission_denied", error_message=f"risk={spec.risk} 不在允许范围")
        ok, err = self.validate_args(name, args)
        if not ok:
            return ToolResult(False, name, error_type="argument_error", error_message=err)
        try:
            return ToolResult(True, name, output=self.handlers[name](**args))
        except Exception as e:
            return ToolResult(False, name, error_type=type(e).__name__, error_message=str(e))

class SimpleSelector:
    """教学选择器：基于少量语义 cue 计算分数。它不是 LLM，只用于控制变量实验。"""
    CUES = ["本地", "课程", "文档", "互联网", "最新", "网页", "计算", "乘", "加", "读取", "文件", "写入", "保存", "天气", "论文", "代码", "新闻", "记忆"]

    def score(self, task: str, spec: ToolSpec):
        text = (spec.name + " " + spec.description).lower()
        score = 0
        for cue in self.CUES:
            if cue in task and cue in text:
                score += 2
        # 工具名字中的关键词也略加权
        aliases = {"search_docs":["本地","文档","课程"], "search_web":["互联网","网页","最新"], "calculator":["计算","乘","加"], "read_file":["读取","文件"], "write_note":["写入","保存"]}
        for cue in aliases.get(spec.name,[]):
            if cue in task: score += 1
        return score

    def choose(self, task: str, specs: List[ToolSpec]):
        scored=[(self.score(task,s), i, s.name) for i,s in enumerate(specs)]
        scored.sort(key=lambda x:(-x[0], x[1]))  # 同分时按候选顺序，便于观察“顺序敏感性”
        return scored[0][2], scored

def backoff_retry(fn, max_attempts=3, base_delay=0.02, retry_on=(TimeoutError, ConnectionError)):
    attempt = 0
    while True:
        attempt += 1
        try:
            return fn(), attempt
        except retry_on:
            if attempt >= max_attempts:
                raise
            time.sleep(base_delay * (2 ** (attempt-1)))

def stable_id(text: str):
    return hashlib.sha256(text.encode("utf-8")).hexdigest()[:12]
