# Agent Systems 零基础科研教程 - 第10讲

主题：Context Engineering - Agent 到底“看见”了什么。

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立做）
3. 运行 src/01-08
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
01 Context Assembly
02 Prompt vs Context
03 Pollution Ablation
04 Truncation Budget
05 Conflict & Priority
06 Tool-result Ablation
07 Compaction
08 Batch Context Metrics

必做实验只使用 Python 标准库，无需 API Key。09_optional_openai_context.py 为可选。

## 四个必须记住的结论
1. Prompt ≠ Context；Prompt 只是 Context 的一部分。
2. Memory ≠ Context；只有被检索并放入当前 Context，模型才真正看见。
3. 更大的 Context Window ≠ 应该塞更多信息；目标是 minimal sufficient context。
4. Context 失败应拆成 pollution、missing evidence、truncation、conflict、staleness、compaction error 等层。

## 延伸阅读（官方）
- Anthropic: Effective context engineering for AI agents (2025-09-29)
- OpenAI Developers: Prompt engineering
- OpenAI Developers/Cookbook: Context Engineering / Sessions / Memory / Compaction 相关材料
