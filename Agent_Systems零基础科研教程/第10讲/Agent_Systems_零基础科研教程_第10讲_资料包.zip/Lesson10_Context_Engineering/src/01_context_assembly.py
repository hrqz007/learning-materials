from context_core import *
s=ContextState(
 instructions=[ContextItem('instructions','你是课程助教；只能依据当前上下文回答。',9)],
 history=[ContextItem('history','上一轮用户询问了 Agent Loop。',3)],
 tool_results=[ContextItem('tool','Agent Loop = Observe → Decide → Act → Feedback。',8)],
 memory=[ContextItem('memory','用户偏好零基础解释。',2)],
 retrieved=[ContextItem('rag','Agent 是模型+工具+状态+运行循环的系统。',5)])
ctx=ContextBuilder(1000).build('请解释 Agent Loop',s)
print(ctx)
