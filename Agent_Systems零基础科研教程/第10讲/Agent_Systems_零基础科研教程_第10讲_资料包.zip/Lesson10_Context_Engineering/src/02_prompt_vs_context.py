from context_core import *
model=TeachingDecisionModel(); task='请回答 Agent Loop 的含义'
base=ContextState(instructions=[ContextItem('instructions','请简洁回答。',9)])
rich=ContextState(instructions=base.instructions,retrieved=[ContextItem('rag','Agent Loop = Observe → Decide → Act → Feedback → Update State。',8)])
for name,s in [('PROMPT_ONLY',base),('WITH_CONTEXT',rich)]:
 ctx=ContextBuilder().build(task,s); print(name, '=>', model.decide(task,ctx)); print(ctx,'\n')
