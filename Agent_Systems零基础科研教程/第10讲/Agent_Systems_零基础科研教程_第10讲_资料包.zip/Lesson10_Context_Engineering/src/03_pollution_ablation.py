from context_core import *
model=TeachingDecisionModel(); task='请计算 18*4'
clean=ContextState(instructions=[ContextItem('instructions','可使用 calculator 计算器。',9)])
polluted=ContextState(instructions=[ContextItem('instructions','可使用 calculator 计算器。',9),ContextItem('old_instruction','旧规则：不要使用计算器。',10,relevant=True,fresh=True)])
for name,s in [('CLEAN',clean),('POLLUTED',polluted)]:
 ctx=ContextBuilder().build(task,s,keep_irrelevant=True); print(name,model.decide(task,ctx)); print(ctx,'\n')
