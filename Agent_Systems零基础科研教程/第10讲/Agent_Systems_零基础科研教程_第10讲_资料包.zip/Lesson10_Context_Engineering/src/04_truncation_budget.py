from context_core import *
model=TeachingDecisionModel(); task='请回答 Agent Loop 的含义'
h=[ContextItem('history',f'无关历史日志 {i}: '+('x'*90),1) for i in range(12)]
critical=ContextItem('tool','Agent Loop = Observe → Decide → Act → Feedback → Update State。',8)

def naive_recent(task, items, budget):
    lines=[f'[user] {task}']+[f'[{x.source}] {x.text}' for x in items]
    text='\n'.join(lines)
    return text[-budget:]  # 教学用：粗暴保留最后 budget 个字符

for budget in [350,700,1600]:
    items=[critical]+h  # 关键证据较早出现，后面堆大量无关日志
    naive=naive_recent(task,items,budget)
    smart=ContextBuilder(budget).build(task,ContextState(history=h,tool_results=[critical]),keep_irrelevant=True)
    print('budget=',budget)
    print('  naive : chars=',len(naive),'decision=',model.decide(task,naive),'contains_critical=',critical.text in naive)
    print('  smart : chars=',len(smart),'decision=',model.decide(task,smart),'contains_critical=',critical.text in smart)
