from context_core import *
items=[ContextItem('old_tool','search_web：搜索互联网最新网页。',4),ContextItem('latest_tool','search_docs：搜索本地课程文档。',8),ContextItem('old_history','用户曾经想查互联网。',2)]
s=ContextState(tool_results=items)
for task in ['请查本地课程里的 Agent Loop','请查最新 Agent 新闻']:
 ctx=ContextBuilder(800).build(task,s,keep_irrelevant=True); print(task,'\n',ctx,'\nTeachingDecision=',TeachingDecisionModel().decide(task,ctx),'\n')
