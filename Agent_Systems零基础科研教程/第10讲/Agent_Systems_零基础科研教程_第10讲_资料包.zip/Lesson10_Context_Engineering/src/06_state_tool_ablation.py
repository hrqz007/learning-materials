from context_core import *
model=TeachingDecisionModel(); task='请回答 Agent Loop 的含义'
with_result=ContextState(tool_results=[ContextItem('tool','Agent Loop = Observe → Decide → Act → Feedback → Update State。',8)])
without=ContextState()
for name,s in [('WITH_TOOL_RESULT',with_result),('WITHOUT_TOOL_RESULT',without)]:
 ctx=ContextBuilder().build(task,s); print(name,'=>',model.decide(task,ctx))
