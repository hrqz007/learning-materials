from context_core import *
raw=[ContextItem('history',f'Turn {i}: 执行步骤 {i}; '+('重复日志 '*12),1) for i in range(1,21)]
raw.append(ContextItem('history','关键事实：Agent Loop = Observe → Decide → Act → Feedback → Update State。',8))
summary=[ContextItem('summary','已完成前20步；关键事实：Agent Loop = Observe → Decide → Act → Feedback → Update State；当前等待最终回答。',8)]
task='请回答 Agent Loop 的含义'; model=TeachingDecisionModel()
for name,history in [('RAW',raw),('COMPACT',summary)]:
 ctx=ContextBuilder(650).build(task,ContextState(history=history),keep_irrelevant=True)
 print(name,'chars=',len(ctx),'decision=',model.decide(task,ctx)); print(ctx[:700],'\n')
