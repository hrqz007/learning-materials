import csv
from pathlib import Path
rows=[
 {'condition':'clean','context_precision':1.00,'context_recall':1.00,'conflict_rate':0.00,'decision_accuracy':1,'task_success':1},
 {'condition':'polluted','context_precision':0.50,'context_recall':1.00,'conflict_rate':0.50,'decision_accuracy':0,'task_success':0},
 {'condition':'truncated','context_precision':0.80,'context_recall':0.00,'conflict_rate':0.00,'decision_accuracy':0,'task_success':0},
 {'condition':'compacted','context_precision':1.00,'context_recall':1.00,'conflict_rate':0.00,'decision_accuracy':1,'task_success':1},
]
out=Path('../results/context_metrics.csv'); out.parent.mkdir(exist_ok=True)
with out.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('saved',out)
