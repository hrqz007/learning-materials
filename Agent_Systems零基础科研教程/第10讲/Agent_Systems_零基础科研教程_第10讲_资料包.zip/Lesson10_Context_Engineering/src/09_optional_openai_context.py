"""可选真实 API 示例。运行前：pip install openai，并设置 OPENAI_API_KEY / OPENAI_MODEL。"""
import os
from openai import OpenAI
client=OpenAI(); model=os.environ['OPENAI_MODEL']
instructions='你是 Agent Systems 课程助教。只能依据 <course_context> 内材料回答；若材料不足，明确说不足。'
context='<course_context>\nAgent Loop = Observe → Decide → Act → Feedback → Update State → Stop/Continue。\n</course_context>'
resp=client.responses.create(model=model,instructions=instructions,input=context+'\n用户问题：什么是 Agent Loop？')
print(resp.output_text)
