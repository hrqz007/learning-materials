from dataclasses import dataclass, field
from typing import List, Dict, Any
import re

@dataclass
class ContextItem:
    source: str
    text: str
    priority: int = 1
    relevant: bool = True
    fresh: bool = True

@dataclass
class ContextState:
    instructions: List[ContextItem] = field(default_factory=list)
    history: List[ContextItem] = field(default_factory=list)
    tool_results: List[ContextItem] = field(default_factory=list)
    memory: List[ContextItem] = field(default_factory=list)
    retrieved: List[ContextItem] = field(default_factory=list)

class ContextBuilder:
    def __init__(self, max_chars=1200):
        self.max_chars=max_chars
    def build(self, task:str, state:ContextState, keep_irrelevant=False):
        items=[]
        items += state.instructions
        items.append(ContextItem('user',task,priority=10,relevant=True,fresh=True))
        items += state.history + state.tool_results + state.memory + state.retrieved
        if not keep_irrelevant:
            items=[x for x in items if x.relevant and x.fresh]
        items.sort(key=lambda x:(-x.priority, x.source))
        out=[]; used=0
        for x in items:
            line=f'[{x.source}] {x.text}'
            if used+len(line)+1>self.max_chars: continue
            out.append(line); used+=len(line)+1
        return '\n'.join(out)

class TeachingDecisionModel:
    """可控教学模型：根据 context 中显式证据选动作。不是 LLM。"""
    def decide(self, task, context):
        c=context.lower(); t=task.lower()
        if '不要使用计算器' in context and ('计算' in task or '*' in task):
            return 'answer_without_tool'
        if ('计算' in task or '*' in task) and ('calculator' in c or '计算器' in c):
            return 'calculator'
        if 'agent loop' in t and ('agent loop = observe' in c or 'agent loop 是 observe' in c):
            return 'answer_from_context'
        if '最新' in task and ('search_web' in c or '互联网搜索' in c):
            return 'search_web'
        if '本地' in task and ('search_docs' in c or '本地文档' in c):
            return 'search_docs'
        return 'insufficient_context'

def context_metrics(items):
    kept=[x for x in items if x.relevant and x.fresh]
    precision=sum(1 for x in kept if x.relevant)/max(1,len(kept))
    return {'kept':len(kept),'precision':round(precision,3)}
