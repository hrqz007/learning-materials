# Agent Systems 零基础科研教程 - 第11讲

主题：Agent Memory - 智能体所谓的“记忆”到底是什么？

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立做）
3. 运行 src/01-08
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
01 Write & Retrieve
02 State vs Memory
03 Short-term vs Long-term
04 Episodic / Semantic / Procedural
05 Retrieval Top-k
06 Stale / Conflict Memory
07 Forgetting & Consolidation
08 Batch Memory Metrics

必做实验只使用 Python 标准库，无需 API Key。09_optional_openai_session_memory.py 为可选。

## 本讲必须记住的 6 句话
1. Agent 说“记得”通常不等于模型参数被更新。
2. Memory ≠ Context；存起来不代表模型当前看得见。
3. State ≠ Long-term Memory；State 更偏当前 run 的工作进度。
4. Memory ≠ RAG；二者可能共享检索技术，但职责不同。
5. 长期记忆不是越多越好；必须解决 write、retrieve、update、forget、consolidate。
6. Memory failure 要分层：没写、写错、没取、取错、过期、冲突、注入错、更新/删除失败。

## 当前延伸阅读
- OpenAI Developers: Running agents - Sessions / conversation state
- OpenAI Developers: Sandbox Agents - Persist memory across runs
- OpenAI: Dreaming: Better memory for a more helpful ChatGPT (2026-06-04)
- Hu et al., Memory in the Age of AI Agents, arXiv:2512.13564
- Huang et al., Rethinking Memory Mechanisms of Foundation Agents in the Second Half, arXiv:2602.06052
