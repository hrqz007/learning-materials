from memory_core import *
store=MemoryStore()
store.add('semantic','Agent Loop 包含 Observe、Decide、Act、Feedback 和状态更新。',importance=0.9)
store.add('preference','用户喜欢零基础、通俗、带实验的教程。',importance=0.8)
store.add('episodic','第10讲做过 Context Pollution 消融实验。',importance=0.6)
print('ALL MEMORY:')
for x in store.active_items(): print(x.id,x.kind,x.text)
print('\nQUERY: Agent Loop 是什么？')
for x in store.retrieve('Agent Loop 是什么？',top_k=1): print(x.id,x.kind,x.text)
