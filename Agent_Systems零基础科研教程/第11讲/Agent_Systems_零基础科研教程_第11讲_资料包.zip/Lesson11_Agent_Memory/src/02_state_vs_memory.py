from memory_core import *
store=MemoryStore(); state=WorkingState()
store.add('semantic','项目长期主题：Agent Systems。',importance=0.9)
state.current_task='分析第1个任务'; state.last_observation='工具返回 391'; state.step=3
print('BEFORE RESET:',state.__dict__)
print('LONG TERM:',[(x.id,x.text) for x in store.active_items()])
state.reset()
print('AFTER RESET:',state.__dict__)
print('LONG TERM STILL EXISTS:',[(x.id,x.text) for x in store.active_items()])
