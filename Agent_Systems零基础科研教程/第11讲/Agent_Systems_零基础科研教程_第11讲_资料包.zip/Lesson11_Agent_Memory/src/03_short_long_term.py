from memory_core import *
recent=['用户：计算 23*17','工具：391','Agent：已保存结果']
long=MemoryStore(); long.add('semantic','用户偏好：解释底层原理并举例。',importance=0.9)
print('SHORT-TERM / SESSION HISTORY:')
for x in recent: print('-',x)
print('\n模拟关闭本次会话：recent = []')
recent=[]
print('short-term=',recent)
print('long-term=',[(x.id,x.text) for x in long.active_items()])
