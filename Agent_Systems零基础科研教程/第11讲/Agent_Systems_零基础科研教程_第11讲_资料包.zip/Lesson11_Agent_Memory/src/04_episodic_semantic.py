from memory_core import *
store=MemoryStore()
store.add('episodic','2026-09-26：在实验中删除 Feedback 后，Agent 重复计算直到 no_progress。',importance=0.8)
store.add('semantic','经验总结：Agent Loop 必须把 observation 写回下一轮 context，否则容易重复动作。',importance=0.95)
store.add('procedural','调试步骤：先看 trace，再定位 selection/argument/execution/state/stop 层。',importance=0.9)
for query in ['之前哪次实验出现 no_progress？','为什么 Agent 会重复动作？','Agent 失败时怎么调试？']:
 print('\nQUERY:',query)
 for x in store.retrieve(query,top_k=2): print(x.kind,'=>',x.text)
