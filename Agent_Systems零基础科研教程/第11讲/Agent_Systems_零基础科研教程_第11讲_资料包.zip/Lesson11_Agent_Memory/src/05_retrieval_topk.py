from memory_core import *
store=MemoryStore()
texts=[
 ('semantic','Agent Loop = Observe → Decide → Act → Feedback。',0.9),
 ('semantic','Tool Calling 需要工具描述、参数校验和执行结果回传。',0.8),
 ('semantic','Context Engineering 决定本轮模型实际看到哪些信息。',0.9),
 ('episodic','昨天吃了苹果。',0.1),
 ('episodic','某次实验输出了 391。',0.2),
 ('semantic','Memory 需要检索后才能进入当前 Context。',0.95),
]
for k,t,imp in texts: store.add(k,t,importance=imp)
q='Memory 和 Context 有什么关系？'
for topk in [1,2,4,6]:
 r=store.retrieve(q,top_k=topk)
 print('\nTOP_K=',topk)
 for x in r: print('-',x.id,x.text)
