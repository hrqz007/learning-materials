from memory_core import *
from datetime import datetime, timedelta
store=MemoryStore()
past=(datetime.now()-timedelta(days=1)).isoformat(timespec='seconds')
store.add('semantic','项目当前默认模型：Model-A。',importance=0.8,expires_at=past)
store.add('semantic','项目当前默认模型：Model-B。',importance=0.9)
store.add('semantic','旧计划：优先研究时间序列。',importance=0.5)
store.add('semantic','当前计划：优先研究 Agent Systems。',importance=0.95)
print('DEFAULT (expired filtered):')
for x in store.retrieve('项目当前默认模型和研究方向',top_k=5): print(x.id,x.text,'expired=',x.is_expired())
print('\nINCLUDING EXPIRED (展示污染风险):')
for x in store.retrieve('项目当前默认模型和研究方向',top_k=5,include_expired=True): print(x.id,x.text,'expired=',x.is_expired())
