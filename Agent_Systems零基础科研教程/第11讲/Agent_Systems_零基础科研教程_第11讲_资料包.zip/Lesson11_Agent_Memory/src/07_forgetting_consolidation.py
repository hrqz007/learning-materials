from memory_core import *
store=MemoryStore()
for i in range(1,8): store.add('episodic',f'第{i}次实验：工具调用成功；重复日志。',importance=0.2)
store.add('episodic','关键失败：Feedback 未写回导致重复动作。',importance=0.9)
print('RAW COUNT=',len(store.active_items()))
# 教学版 consolidation：把多个重复 episode 归纳为 1 条 semantic memory，并停用低价值重复项
summary=store.add('semantic','经验：成功工具调用本身无需逐次长期保存；应优先保留异常、失败和可复用结论。',importance=0.95)
for x in list(store.active_items()):
    if x.kind=='episodic' and '重复日志' in x.text and x.importance<0.5: store.delete(x.id)
print('AFTER CONSOLIDATION ACTIVE=',len(store.active_items()))
for x in store.active_items(): print(x.id,x.kind,x.text)
