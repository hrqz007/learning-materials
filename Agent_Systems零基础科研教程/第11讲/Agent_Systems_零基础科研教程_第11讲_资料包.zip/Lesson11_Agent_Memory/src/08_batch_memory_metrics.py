import csv
from pathlib import Path
rows=[
 {'condition':'clean_memory','write_precision':1.00,'retrieval_precision':1.00,'retrieval_recall':1.00,'staleness_rate':0.00,'memory_utility':1,'task_success':1},
 {'condition':'noisy_memory','write_precision':0.50,'retrieval_precision':0.67,'retrieval_recall':1.00,'staleness_rate':0.00,'memory_utility':0,'task_success':0},
 {'condition':'stale_memory','write_precision':1.00,'retrieval_precision':0.50,'retrieval_recall':1.00,'staleness_rate':0.50,'memory_utility':0,'task_success':0},
 {'condition':'missing_memory','write_precision':1.00,'retrieval_precision':1.00,'retrieval_recall':0.00,'staleness_rate':0.00,'memory_utility':0,'task_success':0},
 {'condition':'consolidated','write_precision':1.00,'retrieval_precision':1.00,'retrieval_recall':1.00,'staleness_rate':0.00,'memory_utility':1,'task_success':1},
]
out=Path('../results/memory_metrics.csv'); out.parent.mkdir(exist_ok=True)
with out.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('saved',out)
