"""可选：真实 OpenAI Agents SDK 的 Session 示例。
注意：SDK/API 会变化；运行前请按当前官方文档安装并设置 OPENAI_API_KEY。
"""
import asyncio
from agents import Agent, Runner, SQLiteSession

async def main():
    agent=Agent(name='MemoryTutor',instructions='你是 Agent Systems 课程助教，回答简洁。')
    session=SQLiteSession('lesson11_demo')
    r1=await Runner.run(agent,'记住：我的示例项目叫 MemoryLab。',session=session)
    print(r1.final_output)
    r2=await Runner.run(agent,'刚才我的示例项目叫什么？',session=session)
    print(r2.final_output)

if __name__=='__main__':
    asyncio.run(main())
