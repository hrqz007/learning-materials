from dataclasses import dataclass, field
from typing import List, Optional
from datetime import datetime, timedelta
import re

@dataclass
class MemoryItem:
    id: str
    kind: str          # episodic / semantic / procedural / preference
    text: str
    created_at: str
    source: str = 'agent'
    importance: float = 0.5
    confidence: float = 1.0
    expires_at: Optional[str] = None
    active: bool = True

    def is_expired(self, now=None):
        if not self.expires_at:
            return False
        now = now or datetime.now()
        return now >= datetime.fromisoformat(self.expires_at)

class MemoryStore:
    def __init__(self):
        self.items: List[MemoryItem] = []
        self._counter = 0

    def add(self, kind, text, source='agent', importance=0.5, confidence=1.0, expires_at=None):
        self._counter += 1
        item = MemoryItem(
            id=f'm{self._counter:03d}', kind=kind, text=text,
            created_at=datetime.now().isoformat(timespec='seconds'), source=source,
            importance=importance, confidence=confidence, expires_at=expires_at
        )
        self.items.append(item)
        return item

    def delete(self, item_id):
        for x in self.items:
            if x.id == item_id:
                x.active = False
                return True
        return False

    def update(self, item_id, new_text):
        for x in self.items:
            if x.id == item_id and x.active:
                x.text = new_text
                x.created_at = datetime.now().isoformat(timespec='seconds')
                return True
        return False

    @staticmethod
    def tokens(text):
        return set(re.findall(r'[A-Za-z0-9_]+|[\u4e00-\u9fff]', text.lower()))

    def retrieve(self, query, top_k=3, kinds=None, include_expired=False):
        q = self.tokens(query)
        scored=[]
        for x in self.items:
            if not x.active: continue
            if kinds and x.kind not in kinds: continue
            if x.is_expired() and not include_expired: continue
            t = self.tokens(x.text)
            overlap = len(q & t) / max(1, len(q | t))
            score = overlap + 0.20*x.importance + 0.10*x.confidence
            scored.append((score,x))
        scored.sort(key=lambda z:(-z[0], z[1].id))
        return [x for _,x in scored[:top_k]]

    def active_items(self):
        return [x for x in self.items if x.active]

class WorkingState:
    def __init__(self):
        self.current_task = ''
        self.last_observation = ''
        self.step = 0

    def reset(self):
        self.current_task=''; self.last_observation=''; self.step=0

def render_context(memories):
    if not memories:
        return '[memory] <none>'
    return '\n'.join(f'[memory:{m.kind}:{m.id}] {m.text}' for m in memories)
