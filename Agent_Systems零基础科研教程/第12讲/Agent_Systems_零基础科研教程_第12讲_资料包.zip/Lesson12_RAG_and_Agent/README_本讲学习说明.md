# Agent Systems 零基础科研教程 - 第12讲

主题：RAG 与 Agent - 检索知识和“记住过去”到底有什么区别？

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立做）
3. 运行 src/01-08
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
01 Chunk Documents
02 Build Search Index
03 Top-k Tradeoff
04 Chunk Size Ablation
05 Stale Knowledge + Metadata Filter
06 Retrieval vs Generation Failure
07 Memory vs RAG Demo
08 Batch RAG Metrics

必做实验只使用 Python 标准库，无需 API Key。09_optional_openai_file_search.py 为可选。

## 本讲必须记住的 7 句话
1. RAG 主要解决“如何从外部知识源找证据”。
2. Memory 主要解决“如何保存并重新利用过去”。
3. RAG ≠ Memory，虽然二者都可以使用向量检索并进入 Context。
4. RAG 的第一步不是向量数据库，而是可靠 Ingestion + Chunking。
5. 最终回答错误不等于 LLM 一定幻觉；先做 Failure Decomposition。
6. Top-k、Chunk Size、Filter、Rerank 都是系统超参数，不是越大越好。
7. 真正科研要同时报告 Retrieval 指标与 End-to-End 指标。

## 当前延伸阅读
- OpenAI Developers: File search
  https://developers.openai.com/api/docs/guides/tools-file-search
- OpenAI Developers: Retrieval
  https://developers.openai.com/api/docs/guides/retrieval

## 说明
本讲的 TF-IDF 检索器是教学实现，用于把底层结构看清楚，不代表生产级 RAG 性能。
