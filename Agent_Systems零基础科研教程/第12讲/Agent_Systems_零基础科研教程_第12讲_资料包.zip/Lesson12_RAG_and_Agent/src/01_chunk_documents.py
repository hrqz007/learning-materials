import json
from pathlib import Path
from rag_core import *
kb=json.loads(Path('../data/knowledge_base.json').read_text(encoding='utf-8'))
for size,overlap in [(1,0),(2,0),(2,1)]:
    chunks=[]
    for doc_id,text in kb.items(): chunks += chunk_text(doc_id,text,chunk_sentences=size,overlap_sentences=overlap)
    print(f'\nchunk_sentences={size}, overlap={overlap}, count={len(chunks)}')
    for c in chunks[:5]: print(c.id,'=>',c.text)
