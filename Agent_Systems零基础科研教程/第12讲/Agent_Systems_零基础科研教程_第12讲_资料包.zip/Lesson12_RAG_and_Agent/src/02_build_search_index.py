import json
from pathlib import Path
from rag_core import *
kb=json.loads(Path('../data/knowledge_base.json').read_text(encoding='utf-8'))
chunks=[]
for doc_id,text in kb.items(): chunks += chunk_text(doc_id,text,chunk_sentences=1)
index=TfidfIndex(chunks)
for q in ['RAG 从哪里找知识？','Agent Memory 保存什么？','Tool Calling 有什么作用？']:
    print('\nQUERY:',q)
    for score,c in index.search(q,top_k=3): print(f'{score:.3f}',c.id,c.text)
