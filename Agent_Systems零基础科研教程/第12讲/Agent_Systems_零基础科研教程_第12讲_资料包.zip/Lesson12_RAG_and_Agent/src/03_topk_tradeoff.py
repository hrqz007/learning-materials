import json
from pathlib import Path
from rag_core import *
kb=json.loads(Path('../data/knowledge_base.json').read_text(encoding='utf-8'))
# 加入一些同领域但对当前问题无关的干扰片段
kb['noise1']='Agent Runtime 负责循环、状态与停止条件。Trace 用于重放 Agent 轨迹。'
kb['noise2']='多智能体系统包含通信、协作、角色分工和编排。'
chunks=[]
for doc_id,text in kb.items(): chunks += chunk_text(doc_id,text,chunk_sentences=1)
idx=TfidfIndex(chunks); q='RAG 主要从哪里获得证据？'
for k in [1,2,4,8]:
    rows=idx.search(q,top_k=k)
    relevant=sum(1 for _,c in rows if c.doc_id=='rag')
    precision=relevant/max(1,len(rows)); recall=1.0 if relevant else 0.0
    print(f'\nTOP_K={k} precision={precision:.2f} recall={recall:.2f}')
    for s,c in rows: print(f' {s:.3f}',c.doc_id,c.text)
