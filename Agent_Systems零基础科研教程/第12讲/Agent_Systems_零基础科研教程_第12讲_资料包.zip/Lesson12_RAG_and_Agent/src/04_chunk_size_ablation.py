from rag_core import *
# 关键答案跨两个相邻句子：如果切得过碎，单个 chunk 缺信息；有 overlap/更大 chunk 则更容易保留语义。
text='Memory 与 RAG 都可能使用检索技术。Memory 的信息来源主要是过去交互、轨迹和长期状态。RAG 的信息来源主要是外部文档和知识库。二者最终都可能把检索结果注入 Context。'
q='Memory 和 RAG 的信息来源有什么区别？'
for size,overlap in [(1,0),(2,0),(2,1),(3,1)]:
    chunks=chunk_text('compare',text,chunk_sentences=size,overlap_sentences=overlap)
    rows=TfidfIndex(chunks).search(q,top_k=1)
    top=rows[0][1].text if rows else ''
    has_memory='过去交互' in top
    has_rag='外部文档' in top
    print(f'size={size} overlap={overlap} chunks={len(chunks)} complete_evidence={has_memory and has_rag}')
    print(' TOP1:',top)
