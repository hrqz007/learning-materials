import json
from pathlib import Path
from rag_core import *
docs=json.loads(Path('../data/versioned_docs.json').read_text(encoding='utf-8'))
chunks=[]
for d in docs:
    chunks += chunk_text(d['doc_id'],d['text'],chunk_sentences=1,metadata={'version':d['version'],'status':d['status']})
idx=TfidfIndex(chunks); q='Agent 项目默认允许几个工具？'
print('WITHOUT FILTER:')
for s,c in idx.search(q,top_k=5): print(f'{s:.3f}',c.doc_id,c.metadata,c.text)
print('\nFILTER status=current:')
for s,c in idx.search(q,top_k=5,filters={'status':'current'}): print(f'{s:.3f}',c.doc_id,c.metadata,c.text)
