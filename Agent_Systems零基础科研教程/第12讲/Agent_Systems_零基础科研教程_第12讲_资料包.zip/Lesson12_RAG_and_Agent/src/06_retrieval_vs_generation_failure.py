import json
from pathlib import Path
from rag_core import *
kb=json.loads(Path('../data/knowledge_base.json').read_text(encoding='utf-8'))
chunks=[]
for doc_id,text in kb.items(): chunks += chunk_text(doc_id,text,chunk_sentences=1)
idx=TfidfIndex(chunks)
q='RAG 的信息来源主要是什么？'
# Case A: retrieval miss——故意把 k=0 模拟成没拿到证据
rows=[]
print('CASE A retrieval miss: evidence=',rows,'answer=',answer_from_evidence(q,rows))
# Case B: retrieval success + grounded generator
rows=idx.search(q,top_k=2)
print('\nCASE B retrieval success:')
for s,c in rows: print(f'{s:.3f}',c.id,c.text)
print('answer=',answer_from_evidence(q,rows))
# Case C: retrieval success but bad generator——人为忽略证据，展示 generation failure
bad_answer='RAG 主要依靠模型参数自动记住用户历史。'
print('\nCASE C retrieval success but generator ignores evidence:')
print('bad_answer=',bad_answer)
