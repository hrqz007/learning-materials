from rag_core import *
external='RAG 从外部知识源、文档和数据库检索证据。'
past='昨天这个 Agent 在 missing file 后改用 local search 完成了恢复。'
rag_chunks=chunk_text('external_kb',external,1,metadata={'source_type':'knowledge'})
memory_chunks=chunk_text('agent_history',past,1,metadata={'source_type':'memory'})
for name,chunks,q in [
 ('RAG',rag_chunks,'RAG 从哪里找证据？'),
 ('MEMORY',memory_chunks,'昨天 Agent 失败后是怎么恢复的？')]:
 print('\n',name,'QUERY:',q)
 for s,c in TfidfIndex(chunks).search(q,top_k=1): print(c.metadata,'=>',c.text)
print('\n底层都可以 search，但信息来源与语义职责不同。')
