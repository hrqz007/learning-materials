import csv
from pathlib import Path
rows=[
 {'condition':'clean_top2','retrieval_recall':1.00,'retrieval_precision':1.00,'grounded_answer':1,'task_success':1,'context_chunks':2},
 {'condition':'top1_miss','retrieval_recall':0.00,'retrieval_precision':0.00,'grounded_answer':0,'task_success':0,'context_chunks':1},
 {'condition':'top8_noisy','retrieval_recall':1.00,'retrieval_precision':0.25,'grounded_answer':1,'task_success':1,'context_chunks':8},
 {'condition':'stale_unfiltered','retrieval_recall':1.00,'retrieval_precision':0.50,'grounded_answer':0,'task_success':0,'context_chunks':2},
 {'condition':'metadata_filtered','retrieval_recall':1.00,'retrieval_precision':1.00,'grounded_answer':1,'task_success':1,'context_chunks':1},
]
out=Path('../results/rag_metrics.csv'); out.parent.mkdir(exist_ok=True)
with out.open('w',newline='',encoding='utf-8-sig') as f:
 w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('saved',out)
