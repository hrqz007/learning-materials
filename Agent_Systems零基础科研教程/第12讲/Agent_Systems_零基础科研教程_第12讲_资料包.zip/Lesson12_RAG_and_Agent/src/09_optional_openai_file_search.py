"""可选：OpenAI Responses API 的 File Search / Vector Store 示例骨架。
运行前：pip install openai；设置 OPENAI_API_KEY、OPENAI_VECTOR_STORE_ID、OPENAI_MODEL。
本文件不会被必做实验自动执行。
"""
import os
from openai import OpenAI

vs_id=os.getenv('OPENAI_VECTOR_STORE_ID')
model=os.getenv('OPENAI_MODEL')
if not vs_id or not model:
    raise SystemExit('请先设置 OPENAI_VECTOR_STORE_ID 与 OPENAI_MODEL。')
client=OpenAI()
response=client.responses.create(
    model=model,
    input='根据知识库说明：RAG 与 Agent Memory 的核心区别是什么？',
    tools=[{'type':'file_search','vector_store_ids':[vs_id],'max_num_results':3}],
    include=['file_search_call.results'],
)
print(response.output_text)
