from dataclasses import dataclass
from typing import List, Dict, Optional
from collections import Counter
import math, re

@dataclass
class Chunk:
    id: str
    doc_id: str
    text: str
    metadata: Dict[str, str]


def tokenize(text: str):
    # 教学版 tokenizer：英文单词/数字 + 中文单字。
    # 真实中文 RAG 通常应使用更好的分词、embedding 或混合检索。
    return re.findall(r'[A-Za-z0-9_]+|[\u4e00-\u9fff]', text.lower())


def sentence_split(text: str):
    parts=re.split(r'(?<=[。！？.!?])\s*', text.strip())
    return [p.strip() for p in parts if p.strip()]


def chunk_text(doc_id: str, text: str, chunk_sentences=2, overlap_sentences=0, metadata=None):
    sents=sentence_split(text)
    chunks=[]; step=max(1,chunk_sentences-overlap_sentences); idx=0
    for start in range(0,len(sents),step):
        part=sents[start:start+chunk_sentences]
        if not part: break
        idx+=1
        chunks.append(Chunk(f'{doc_id}_c{idx:02d}',doc_id,' '.join(part),dict(metadata or {})))
        if start+chunk_sentences>=len(sents): break
    return chunks


class TfidfIndex:
    def __init__(self, chunks: List[Chunk]):
        self.chunks=chunks
        self.docs=[Counter(tokenize(c.text)) for c in chunks]
        n=max(1,len(chunks)); df=Counter()
        for c in self.docs:
            for t in c: df[t]+=1
        self.idf={t:math.log((n+1)/(v+1))+1.0 for t,v in df.items()}

    def _vec(self, counts):
        return {t:v*self.idf.get(t,1.0) for t,v in counts.items()}

    @staticmethod
    def _cos(a,b):
        dot=sum(v*b.get(k,0.0) for k,v in a.items())
        na=math.sqrt(sum(v*v for v in a.values())); nb=math.sqrt(sum(v*v for v in b.values()))
        return dot/(na*nb) if na and nb else 0.0

    def search(self, query: str, top_k=3, filters: Optional[Dict[str,str]]=None):
        q=self._vec(Counter(tokenize(query))); rows=[]
        for chunk,counts in zip(self.chunks,self.docs):
            if filters and any(str(chunk.metadata.get(k))!=str(v) for k,v in filters.items()):
                continue
            score=self._cos(q,self._vec(counts))
            rows.append((score,chunk))
        rows.sort(key=lambda x:(-x[0],x[1].id))
        return rows[:top_k]


def render_context(rows):
    if not rows: return '[retrieval] <none>'
    return '\n'.join(f'[source={c.doc_id} chunk={c.id} score={s:.3f}] {c.text}' for s,c in rows)


def answer_from_evidence(query, rows):
    # 教学版“生成器”：只在检索证据中找预定义关键词，避免把检索实验和真实 LLM 混在一起。
    joined=' '.join(c.text for _,c in rows)
    if 'Memory' in query or '记忆' in query:
        if '过去' in joined and ('跨时间' in joined or '跨会话' in joined):
            return 'Memory 主要保存跨时间有用的过去信息。'
    if 'RAG' in query:
        if '外部知识' in joined or '外部文档' in joined:
            return 'RAG 主要从外部知识源检索证据，并把证据加入当前 Context。'
    if 'Tool Calling' in query or '工具' in query:
        if '外部函数' in joined or '工具' in joined:
            return 'Tool Calling 让 Agent 选择并调用外部工具或函数。'
    if 'Context' in query:
        if '看到' in joined or '上下文' in joined:
            return 'Context Engineering 决定模型在当前一轮实际看到哪些信息。'
    return 'INSUFFICIENT_EVIDENCE'
