# Agent Systems 零基础科研教程 - 第13讲

主题：MCP 与工具生态 - Agent 为什么开始拥有统一的“外部世界接口”？

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立做）
3. 运行 src/01-08
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
01 Discover Primitives
02 JSON-RPC Request / Response
03 Tool Discovery + Schema
04 Resources vs Tools
05 Prompt Template
06 stdio Transport Demo
07 Failure + Permission Metrics
08 Dynamic Discovery / Interop

必做实验只使用 Python 标准库，无需 API Key。

## 可选真实实验
09 官方 MCP Python SDK Server
10 官方 MCP Python SDK Client
11 OpenAI Responses API + Remote MCP

## 本讲必须记住的 8 句话
1. MCP 不是模型，也不是 Agent；它是协议。
2. Host 承载 AI 应用，Client 负责连接，Server 发布能力。
3. Tool = 做事情；Resource = 给上下文；Prompt = 可复用模板。
4. Function Calling 与 MCP 不是同一层。
5. Discovery 让能力不必全部硬编码。
6. 当前主流标准 transport 是 stdio 与 Streamable HTTP；SSE 是 legacy。
7. 可连接 ≠ 可信任；高风险 Tool 必须考虑审批和最小权限。
8. “MCP 失败”要拆成 discovery / selection / schema / auth / execution / transport 等层。

## 当前规范（生成日期 2026-09-26）
- MCP specification current final: 2026-07-28
- MCP Python SDK v2 is current stable line

## 官方参考
- https://modelcontextprotocol.io/
- https://github.com/modelcontextprotocol/python-sdk
- https://developers.openai.com/api/docs/guides/tools-connectors-mcp
- https://developers.openai.com/api/docs/guides/agents-api/tools/mcp
- https://developers.openai.com/learn/docs-mcp

## 说明
mcp_teaching.py 是为了理解协议层的教学实现，不是完整 MCP 兼容实现。真正接入生产系统请使用官方 SDK，并固定协议与 SDK 版本。
