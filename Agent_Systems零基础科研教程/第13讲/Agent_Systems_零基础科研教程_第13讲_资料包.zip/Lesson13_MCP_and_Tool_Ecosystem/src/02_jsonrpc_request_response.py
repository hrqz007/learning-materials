import json
from mcp_teaching import *
s=build_demo_server()
requests=[
 {'jsonrpc':'2.0','id':1,'method':'server/discover','params':{}},
 {'jsonrpc':'2.0','id':2,'method':'tools/list','params':{}},
 {'jsonrpc':'2.0','id':3,'method':'tools/call','params':{'name':'add','arguments':{'a':18,'b':24}}},
]
for req in requests:
    print('REQUEST',json.dumps(req,ensure_ascii=False))
    print('RESPONSE',json.dumps(s.handle(req),ensure_ascii=False))
