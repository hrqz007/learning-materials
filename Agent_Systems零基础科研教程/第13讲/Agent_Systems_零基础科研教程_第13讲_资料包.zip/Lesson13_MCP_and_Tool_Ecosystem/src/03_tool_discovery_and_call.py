from mcp_teaching import *
s=build_demo_server()
print('discovered tools =',[x['name'] for x in s.list_tools()])
print('valid:',s.call_tool('add',{'a':7,'b':8}))
for args in [{'a':7},{'a':'7','b':8}]:
    try: print(s.call_tool('add',args))
    except MCPError as e: print('invalid args:',e.code,e.message)
