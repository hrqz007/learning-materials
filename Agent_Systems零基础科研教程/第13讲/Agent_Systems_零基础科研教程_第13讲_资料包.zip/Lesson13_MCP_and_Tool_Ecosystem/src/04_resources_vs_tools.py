from mcp_teaching import *
s=build_demo_server()
print('RESOURCE READ (read-only context):')
print(s.read_resource('config://policy'))
print('\nTOOL CALL (action/function):')
print(s.call_tool('search_notes',{'query':'MCP'}))
print('\nKey idea: Resource answers “what data can I read?”, Tool answers “what action/function can I invoke?”.')
