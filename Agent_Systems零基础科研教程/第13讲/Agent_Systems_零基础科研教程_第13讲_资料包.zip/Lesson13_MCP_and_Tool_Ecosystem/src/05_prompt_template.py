from mcp_teaching import *
s=build_demo_server()
print(s.list_prompts())
print(s.get_prompt('code_review',{'language':'Python'}))
try: print(s.get_prompt('code_review',{}))
except MCPError as e: print(e.code,e.message)
