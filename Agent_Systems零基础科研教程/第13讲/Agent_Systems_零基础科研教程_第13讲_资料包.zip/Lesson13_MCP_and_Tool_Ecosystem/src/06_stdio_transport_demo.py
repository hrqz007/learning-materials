import subprocess, json, sys
p=subprocess.Popen([sys.executable,'stdio_server_demo.py'],stdin=subprocess.PIPE,stdout=subprocess.PIPE,stderr=subprocess.PIPE,text=True,bufsize=1)
for req in [
 {'jsonrpc':'2.0','id':1,'method':'tools/list','params':{}},
 {'jsonrpc':'2.0','id':2,'method':'tools/call','params':{'name':'add','arguments':{'a':20,'b':22}}},
]:
    line=json.dumps(req,ensure_ascii=False)
    print('CLIENT ->',line)
    p.stdin.write(line+'\n'); p.stdin.flush()
    print('SERVER ->',p.stdout.readline().strip())
p.stdin.close(); p.terminate(); p.wait(timeout=3)
