from mcp_teaching import *
s=build_demo_server()
cases=[
 ('ok', lambda: s.call_tool('add',{'a':1,'b':2})),
 ('unknown_tool', lambda: s.call_tool('missing',{})),
 ('invalid_args', lambda: s.call_tool('add',{'a':1})),
 ('approval_required', lambda: s.call_tool('delete_note',{'note_id':'n1'})),
 ('approved_destructive', lambda: s.call_tool('delete_note',{'note_id':'n1'},approved=True)),
 ('execution_error', lambda: s.call_tool('unstable_tool',{})),
]
counts={}
for name,fn in cases:
    try:
        print(name,'=>',fn()); key='SUCCESS'
    except MCPError as e:
        print(name,'=>',e.code,e.message); key=e.code
    counts[key]=counts.get(key,0)+1
print('\nLAYER COUNTS',counts)
