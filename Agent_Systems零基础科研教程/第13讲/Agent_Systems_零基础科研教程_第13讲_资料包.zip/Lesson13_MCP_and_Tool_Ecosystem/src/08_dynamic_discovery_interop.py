from mcp_teaching import *
for version in ['1.0.0','2.0.0']:
    s=build_demo_server(version)
    names=[x['name'] for x in s.list_tools()]
    print(f'v{version}:',names)
    if 'summarize_notes' in names:
        print('dynamic client can use new tool without hard-coding its existence:',s.call_tool('summarize_notes',{}))
    else:
        print('tool not published yet')
