"""可选：官方 MCP Python SDK v2 示例（截至 2026-09-26）。
安装：pip install "mcp[cli]"
开发调试：mcp dev 09_optional_real_mcp_server.py
运行 stdio：python 09_optional_real_mcp_server.py
部署 HTTP：mcp run 09_optional_real_mcp_server.py --transport streamable-http
"""
from mcp.server import MCPServer

mcp = MCPServer("AgentSystemsLesson13")

@mcp.tool()
def add(a: int, b: int) -> int:
    """Add two integers."""
    return a + b

@mcp.resource("lesson://summary")
def lesson_summary() -> str:
    """Read the lesson summary."""
    return "MCP standardizes how AI applications discover and use tools, resources, and prompts."

@mcp.prompt()
def review_agent_code(language: str) -> str:
    """Create a reusable agent-code review prompt."""
    return f"Review this {language} agent code for correctness, permissions, and failure handling."

if __name__ == '__main__':
    mcp.run()
