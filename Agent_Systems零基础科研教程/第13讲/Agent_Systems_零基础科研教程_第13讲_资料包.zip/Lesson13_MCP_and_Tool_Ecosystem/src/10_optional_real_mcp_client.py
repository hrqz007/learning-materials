"""可选：与 09_optional_real_mcp_server.py 配套的 HTTP Client。
先运行：mcp run 09_optional_real_mcp_server.py --transport streamable-http
再运行本文件。
"""
import asyncio
from mcp import Client

async def main():
    async with Client("http://127.0.0.1:8000/mcp") as client:
        print('protocol =',client.protocol_version)
        print('tools =',[t.name for t in (await client.list_tools()).tools])
        result=await client.call_tool('add',{'a':20,'b':22})
        print('result =',result.structured_content or result.content)

asyncio.run(main())
