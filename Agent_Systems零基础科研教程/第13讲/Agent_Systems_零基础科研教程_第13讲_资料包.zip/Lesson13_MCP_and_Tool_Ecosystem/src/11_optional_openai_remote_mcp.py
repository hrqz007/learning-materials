"""可选：OpenAI Responses API 连接远程 MCP Server。
截至 2026-09-26，OpenAI Responses API 支持 type='mcp' + server_url。
请先设置 OPENAI_API_KEY 和 OPENAI_MODEL。本例连接 OpenAI 的公开文档 MCP Server。
"""
import os
from openai import OpenAI
model=os.getenv('OPENAI_MODEL')
if not model: raise SystemExit('请设置 OPENAI_MODEL')
client=OpenAI()
resp=client.responses.create(
    model=model,
    input='请通过 MCP 文档工具查找：Responses API 的 tools 参数是什么？简要回答。',
    tools=[{
        'type':'mcp',
        'server_label':'openai_docs',
        'server_url':'https://developers.openai.com/mcp',
        'require_approval':'never'
    }]
)
print(resp.output_text)
