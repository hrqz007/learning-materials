from dataclasses import dataclass, field
from typing import Any, Callable, Dict
import json

class MCPError(Exception):
    def __init__(self, code: str, message: str):
        super().__init__(message); self.code=code; self.message=message

@dataclass
class ToolSpec:
    name: str
    description: str
    input_schema: Dict[str, Any]
    fn: Callable[..., Any]
    risk: str='read'

@dataclass
class ResourceSpec:
    uri: str
    name: str
    description: str
    read_fn: Callable[[], Any]

@dataclass
class PromptSpec:
    name: str
    description: str
    arguments: list[str]
    render_fn: Callable[..., str]

class TeachingMCPServer:
    """教学版 MCP Server：只模拟 MCP 的语义层，不冒充官方 SDK。"""
    def __init__(self, name='TeachingServer', version='1.0.0'):
        self.name=name; self.version=version
        self.tools: Dict[str,ToolSpec]={}
        self.resources: Dict[str,ResourceSpec]={}
        self.prompts: Dict[str,PromptSpec]={}

    def tool(self, name, description, input_schema, fn, risk='read'):
        self.tools[name]=ToolSpec(name,description,input_schema,fn,risk)

    def resource(self, uri, name, description, read_fn):
        self.resources[uri]=ResourceSpec(uri,name,description,read_fn)

    def prompt(self, name, description, arguments, render_fn):
        self.prompts[name]=PromptSpec(name,description,arguments,render_fn)

    def discover(self):
        return {
            'server': {'name':self.name,'version':self.version},
            'capabilities': {
                'tools': bool(self.tools),
                'resources': bool(self.resources),
                'prompts': bool(self.prompts),
            }
        }

    def list_tools(self):
        return [
            {'name':t.name,'description':t.description,'inputSchema':t.input_schema,'risk':t.risk}
            for t in self.tools.values()
        ]

    def list_resources(self):
        return [{'uri':r.uri,'name':r.name,'description':r.description} for r in self.resources.values()]

    def list_prompts(self):
        return [{'name':p.name,'description':p.description,'arguments':p.arguments} for p in self.prompts.values()]

    def _validate(self, schema, args):
        if schema.get('type')!='object': return
        required=schema.get('required',[])
        for key in required:
            if key not in args: raise MCPError('INVALID_PARAMS',f'missing required argument: {key}')
        props=schema.get('properties',{})
        typemap={'string':str,'integer':int,'number':(int,float),'boolean':bool}
        for k,v in args.items():
            if k in props and 'type' in props[k]:
                py=typemap.get(props[k]['type'])
                if py and not isinstance(v,py): raise MCPError('INVALID_PARAMS',f'{k} must be {props[k]["type"]}')

    def call_tool(self, name, arguments, approved=False):
        if name not in self.tools: raise MCPError('UNKNOWN_TOOL',name)
        t=self.tools[name]; self._validate(t.input_schema,arguments)
        if t.risk in {'write','destructive'} and not approved:
            raise MCPError('APPROVAL_REQUIRED',f'{name} requires explicit approval')
        try:
            return {'tool':name,'result':t.fn(**arguments)}
        except MCPError: raise
        except Exception as e: raise MCPError('EXECUTION_ERROR',repr(e))

    def read_resource(self, uri):
        if uri not in self.resources: raise MCPError('UNKNOWN_RESOURCE',uri)
        return {'uri':uri,'contents':self.resources[uri].read_fn()}

    def get_prompt(self, name, arguments):
        if name not in self.prompts: raise MCPError('UNKNOWN_PROMPT',name)
        p=self.prompts[name]
        missing=[x for x in p.arguments if x not in arguments]
        if missing: raise MCPError('INVALID_PARAMS','missing: '+','.join(missing))
        return {'name':name,'messages':[{'role':'user','content':p.render_fn(**arguments)}]}

    def handle(self, request, approved=False):
        req_id=request.get('id'); method=request.get('method'); params=request.get('params') or {}
        try:
            if method=='server/discover': result=self.discover()
            elif method=='tools/list': result={'tools':self.list_tools()}
            elif method=='tools/call': result=self.call_tool(params['name'],params.get('arguments',{}),approved=approved)
            elif method=='resources/list': result={'resources':self.list_resources()}
            elif method=='resources/read': result=self.read_resource(params['uri'])
            elif method=='prompts/list': result={'prompts':self.list_prompts()}
            elif method=='prompts/get': result=self.get_prompt(params['name'],params.get('arguments',{}))
            else: raise MCPError('METHOD_NOT_FOUND',str(method))
            return {'jsonrpc':'2.0','id':req_id,'result':result}
        except MCPError as e:
            return {'jsonrpc':'2.0','id':req_id,'error':{'code':e.code,'message':e.message}}

def build_demo_server(version='1.0.0'):
    import pathlib
    s=TeachingMCPServer('AgentLab',version)
    s.tool('add','Add two integers.',{'type':'object','properties':{'a':{'type':'integer'},'b':{'type':'integer'}},'required':['a','b']},lambda a,b:a+b)
    s.tool('search_notes','Search note titles by keyword.',{'type':'object','properties':{'query':{'type':'string'}},'required':['query']},lambda query:[x for x in ['Agent Loop','MCP','Security'] if query.lower() in x.lower()])
    s.tool('delete_note','Delete a note by id.',{'type':'object','properties':{'note_id':{'type':'string'}},'required':['note_id']},lambda note_id:{'deleted':note_id},risk='destructive')
    s.tool('unstable_tool','Always fail for failure-injection.',{'type':'object','properties':{},'required':[]},lambda:1/0)
    if version.startswith('2'):
        s.tool('summarize_notes','Summarize all notes.',{'type':'object','properties':{},'required':[]},lambda:'3 notes: Agent Loop, MCP, Security')
    s.resource('notes://index','Notes index','Read-only list of note titles.',lambda:['Agent Loop','MCP','Security'])
    s.resource('config://policy','Policy','Current agent policy.',lambda:'destructive tools require explicit approval')
    s.prompt('code_review','Reusable code-review prompt.',['language'],lambda language:f'Review the following {language} code for correctness, security, and maintainability.')
    return s
