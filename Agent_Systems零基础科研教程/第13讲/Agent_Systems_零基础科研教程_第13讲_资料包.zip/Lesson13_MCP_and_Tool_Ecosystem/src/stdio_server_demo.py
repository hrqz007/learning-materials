import sys,json
from mcp_teaching import build_demo_server
s=build_demo_server()
for line in sys.stdin:
    line=line.strip()
    if not line: continue
    try: req=json.loads(line); resp=s.handle(req)
    except Exception as e: resp={'jsonrpc':'2.0','id':None,'error':{'code':'BAD_MESSAGE','message':repr(e)}}
    sys.stdout.write(json.dumps(resp,ensure_ascii=False)+'\n'); sys.stdout.flush()
