# Agent Systems 零基础科研教程 - 第14讲

## 主题
ReAct：为什么 Agent 会表现出“边想、边做、边观察”？

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. 独立完成 `05_练习题.docx`
3. 按 `03_实验指导书.docx` 跑实验 01-08
4. 查看 `results/` 与 `06_练习题答案.docx`
5. 用 `04_实验设计书.docx` 尝试自己改一个变量做消融

## 必做实验
01-08 均不需要 API Key，只用 Python 标准库。数字仅用于教学机制，不代表任何真实 LLM 的性能。

## 可选实验
`09_optional_openai_tool_loop.py` 需要 OpenAI API Key 与 openai Python 包。

## 本讲最低闭环
能看懂并解释一条 ReAct trace：Observation 如何改变 Action；失败发生在哪一层；Runtime 为什么停止；如何设计一个单变量对照实验。
