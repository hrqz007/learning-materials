from react_teaching import *
world = MiniWorld()
state = ReActRuntime(world, TeachingReActController()).run("读取 alpha 当前值，乘以 multiplier，保存结果")
print_trace(state)
print("saved=", world.saved)
