from react_teaching import *
print("DIRECT: 没有读取环境，答案=UNKNOWN")
world = MiniWorld()
state = ReActRuntime(world, TeachingReActController()).run("读取 alpha 当前值，乘以 multiplier，保存结果")
print("REACT:", state.final, "tool_calls=", sum(1 for x in state.trace if x['action']!='finish'))
