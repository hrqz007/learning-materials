from react_teaching import *
# 固定计划：错误 key 写死后会重复失败
world = MiniWorld()
fixed_plan = [Action('lookup', {'key':'sensor/alpha'}, '固定计划第1步'), Action('lookup', {'key':'multiplier'}), Action('calculate', {'a':0,'b':1.8})]
print("FIXED PLAN")
for a in fixed_plan:
    print(a.name, '->', world.execute(a).__dict__)

# ReAct：观察 NOT_FOUND 后修改下一动作
class Adaptive:
    def decide(self, s):
        if 'sensor' not in s.facts:
            if s.facts.get('last_error','').startswith('NOT_FOUND'):
                return Action('lookup', {'key':'sensor_alpha'}, '根据错误提示改用正确 key')
            return Action('lookup', {'key':'sensor/alpha'}, '先尝试任务中给出的路径')
        if 'multiplier' not in s.facts: return Action('lookup', {'key':'multiplier'}, '获取系数')
        if 'result' not in s.facts: return Action('calculate', {'a':s.facts['sensor'],'b':s.facts['multiplier']}, '计算')
        return Action('finish', {'answer':s.facts['result']}, '完成')
world2 = MiniWorld(); state = ReActRuntime(world2, Adaptive()).run('动态环境任务')
print("REACT")
print_trace(state)
