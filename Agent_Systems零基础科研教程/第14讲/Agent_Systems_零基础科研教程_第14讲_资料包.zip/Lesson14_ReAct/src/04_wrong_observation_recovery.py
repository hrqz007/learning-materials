from react_teaching import *
class RecoverController:
    def decide(self, s):
        if 'sensor' not in s.facts:
            if s.facts.get('last_error') == 'MALFORMED_VALUE':
                return Action('lookup', {'key':'sensor_alpha_backup'}, '主源返回异常，切换备用源')
            return Action('lookup', {'key':'flaky_sensor_alpha'}, '先读主数据源')
        return Action('finish', {'answer':f"sensor={s.facts['sensor']}"}, '已获得有效值')
state = ReActRuntime(MiniWorld(), RecoverController()).run('读取 alpha 传感器')
print_trace(state)
