from react_teaching import *
world = MiniWorld()
stale = world.lookup('stale_sensor_alpha'); current = world.lookup('sensor_alpha')
print('stale=', stale.__dict__)
print('current=', current.__dict__)
# 天真策略：先来的就用
naive = stale.value
# 新鲜度策略：只接受 current
validated = current.value if current.freshness == 'current' else None
print('naive_value=', naive)
print('freshness_validated_value=', validated)
print('naive_correct=', naive == 37)
print('validated_correct=', validated == 37)
