from react_teaching import *
class Buggy:
    def decide(self, s):
        return Action('lookup', {'key':'sensor_alpha'}, 'Bug: 永远重复同一动作')
state = ReActRuntime(MiniWorld(), Buggy(), max_turns=20, repeat_limit=2).run('演示循环保护')
print_trace(state)
print('turns=', state.turn)
