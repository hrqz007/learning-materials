from react_teaching import *
for budget in [2,3,4,5,6]:
    w=MiniWorld(); s=ReActRuntime(w, TeachingReActController(), max_turns=budget).run('完整任务')
    success = bool(s.final and s.final.startswith('alpha_scaled='))
    print(f'budget={budget}, success={success}, turns={s.turn}, final={s.final}')
