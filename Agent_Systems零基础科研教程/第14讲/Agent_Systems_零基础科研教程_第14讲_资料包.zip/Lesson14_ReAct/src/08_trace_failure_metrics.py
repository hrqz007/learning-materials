import csv
from pathlib import Path
rows = [
 {'case':'normal','decision_ok':1,'action_ok':1,'observation_ok':1,'recovery_ok':1,'task_success':1,'failure_layer':'NONE'},
 {'case':'wrong_action','decision_ok':0,'action_ok':0,'observation_ok':1,'recovery_ok':0,'task_success':0,'failure_layer':'DECISION'},
 {'case':'bad_args','decision_ok':1,'action_ok':0,'observation_ok':1,'recovery_ok':0,'task_success':0,'failure_layer':'ACTION'},
 {'case':'stale_observation','decision_ok':1,'action_ok':1,'observation_ok':0,'recovery_ok':0,'task_success':0,'failure_layer':'OBSERVATION'},
 {'case':'tool_error_recovered','decision_ok':1,'action_ok':1,'observation_ok':0,'recovery_ok':1,'task_success':1,'failure_layer':'RECOVERED'},
 {'case':'loop','decision_ok':0,'action_ok':1,'observation_ok':1,'recovery_ok':0,'task_success':0,'failure_layer':'CONTROL'},
]
out = Path(__file__).resolve().parents[1]/'results'/'react_metrics.csv'
with out.open('w', newline='', encoding='utf-8-sig') as f:
    w=csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
from collections import Counter
c=Counter(r['failure_layer'] for r in rows)
print('failure_counts=', dict(c))
print('task_success_rate=', sum(r['task_success'] for r in rows)/len(rows))
print('csv=', out)
