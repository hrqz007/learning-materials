"""可选：真实 API 示例。需要 OPENAI_API_KEY 与 openai 包。
本示例不要求也不打印模型私有 chain-of-thought；只观察工具调用、工具结果和最终回答。
请以当前 OpenAI 官方 function calling / reasoning 文档为准。
"""
import os, json
from openai import OpenAI
client = OpenAI()

tools=[{"type":"function","name":"get_sensor","description":"读取 alpha 传感器当前值","parameters":{"type":"object","properties":{},"additionalProperties":False}}]
resp = client.responses.create(model="gpt-5.6", input="读取 alpha 传感器，然后告诉我值。", tools=tools)
items = list(resp.output)
for item in items:
    if getattr(item, 'type', None) == 'function_call' and item.name == 'get_sensor':
        result = json.dumps({"value":37,"unit":"C"}, ensure_ascii=False)
        resp = client.responses.create(model="gpt-5.6", previous_response_id=resp.id,
            input=[{"type":"function_call_output","call_id":item.call_id,"output":result}])
print(resp.output_text)
