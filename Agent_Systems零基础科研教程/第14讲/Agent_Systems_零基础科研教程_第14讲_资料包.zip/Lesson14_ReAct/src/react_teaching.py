"""第14讲：ReAct 教学运行时（无第三方依赖）
注意：这里的 rationale 是人为设计的“简短控制说明”，用于教学和可观测性；
它不代表、也不要求暴露真实模型的私有 chain-of-thought。
"""
from dataclasses import dataclass, field
from typing import Any, Dict, List, Optional
import json, time

@dataclass
class Action:
    name: str
    args: Dict[str, Any] = field(default_factory=dict)
    rationale: str = ""

@dataclass
class Observation:
    ok: bool
    value: Any = None
    error: Optional[str] = None
    source: str = ""
    freshness: str = "current"

@dataclass
class RunState:
    task: str
    facts: Dict[str, Any] = field(default_factory=dict)
    trace: List[Dict[str, Any]] = field(default_factory=list)
    turn: int = 0
    done: bool = False
    final: Optional[str] = None

class MiniWorld:
    def __init__(self):
        self.kb = {
            "sensor_alpha": 37,
            "sensor_alpha_backup": 37,
            "multiplier": 1.8,
            "stale_sensor_alpha": 50,
        }
        self.saved = {}
        self.flaky_once = True

    def lookup(self, key: str) -> Observation:
        if key == "sensor/alpha":
            return Observation(False, error="NOT_FOUND; try key sensor_alpha", source="kb")
        if key == "flaky_sensor_alpha" and self.flaky_once:
            self.flaky_once = False
            return Observation(False, error="MALFORMED_VALUE", source="primary_sensor")
        if key == "flaky_sensor_alpha":
            return Observation(True, value=37, source="primary_sensor")
        if key in self.kb:
            freshness = "stale" if key.startswith("stale_") else "current"
            return Observation(True, value=self.kb[key], source="kb", freshness=freshness)
        return Observation(False, error="NOT_FOUND", source="kb")

    def calculate(self, a: float, b: float) -> Observation:
        return Observation(True, value=round(float(a) * float(b), 4), source="calculator")

    def save(self, key: str, value: Any) -> Observation:
        self.saved[key] = value
        return Observation(True, value={"saved": key, "value": value}, source="storage")

    def execute(self, action: Action) -> Observation:
        if action.name == "lookup":
            return self.lookup(**action.args)
        if action.name == "calculate":
            return self.calculate(**action.args)
        if action.name == "save":
            return self.save(**action.args)
        if action.name == "finish":
            return Observation(True, value=action.args.get("answer"), source="runtime")
        return Observation(False, error=f"UNKNOWN_ACTION:{action.name}", source="runtime")

class TeachingReActController:
    """根据已观察到的 facts 做下一步决定。"""
    def decide(self, state: RunState) -> Action:
        f = state.facts
        if "sensor" not in f:
            return Action("lookup", {"key":"sensor_alpha"}, "需要先获取当前传感器值")
        if "multiplier" not in f:
            return Action("lookup", {"key":"multiplier"}, "需要获取计算系数")
        if "result" not in f:
            return Action("calculate", {"a":f["sensor"], "b":f["multiplier"]}, "证据已齐，执行计算")
        if "saved" not in f:
            return Action("save", {"key":"alpha_scaled", "value":f["result"]}, "将结果写入外部环境")
        return Action("finish", {"answer":f"alpha_scaled={f['result']}"}, "任务目标已满足")

class ReActRuntime:
    def __init__(self, world: MiniWorld, controller, max_turns=8, repeat_limit=3):
        self.world = world
        self.controller = controller
        self.max_turns = max_turns
        self.repeat_limit = repeat_limit

    def _update(self, state: RunState, action: Action, obs: Observation):
        if not obs.ok:
            state.facts["last_error"] = obs.error
            return
        if action.name == "lookup":
            key = action.args.get("key")
            if key in ("sensor_alpha", "flaky_sensor_alpha", "sensor_alpha_backup"):
                state.facts["sensor"] = obs.value
            elif key == "multiplier":
                state.facts["multiplier"] = obs.value
        elif action.name == "calculate":
            state.facts["result"] = obs.value
        elif action.name == "save":
            state.facts["saved"] = True
        elif action.name == "finish":
            state.done = True
            state.final = str(obs.value)

    def run(self, task: str) -> RunState:
        state = RunState(task=task)
        last_sig = None; repeated = 0
        for t in range(1, self.max_turns + 1):
            state.turn = t
            action = self.controller.decide(state)
            sig = (action.name, json.dumps(action.args, ensure_ascii=False, sort_keys=True))
            repeated = repeated + 1 if sig == last_sig else 1
            last_sig = sig
            if repeated > self.repeat_limit:
                state.final = "STOP:no_progress"
                break
            obs = self.world.execute(action)
            state.trace.append({
                "turn": t,
                "rationale": action.rationale,
                "action": action.name,
                "args": action.args,
                "observation": obs.__dict__.copy(),
            })
            self._update(state, action, obs)
            if action.name == "finish" and obs.ok:
                break
        else:
            state.final = "STOP:max_turns"
        return state

def print_trace(state: RunState):
    for row in state.trace:
        o = row["observation"]
        print(f"Turn {row['turn']}: {row['rationale']}")
        print("  Action:", row['action'], row['args'])
        print("  Observation:", o)
    print("FINAL:", state.final)
