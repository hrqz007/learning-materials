# Agent Systems 零基础科研教程 - 第15讲 Planning

## 推荐学习顺序
1. `01_零基础讲义.docx` / `02_零基础讲义.pdf`
2. 先做 `05_练习题.docx`，再看答案
3. 按 `03_实验指导书.docx` 跑 `src/01` 到 `src/08`
4. 重点比较实验04、05、06、08
5. 阅读 `04_实验设计书.docx`，学习如何把 Planning 机制变成科研对照实验

## 必做实验
- 01 最小 Planning
- 02 Planning vs ReAct
- 03 依赖错误
- 04 Fixed Plan vs Replanning
- 05 Plan Granularity Ablation
- 06 Stale Plan 与 Replan
- 07 Budget-aware Planning
- 08 Failure Metrics

## 可选实验
`src/09_optional_openai_planner.py` 需要 OpenAI API Key。它只输出显式结构化计划，不要求暴露私有 Chain-of-Thought。

## 本讲最低闭环
能解释 Plan、Step、Dependency、State、Replan、Stale Plan；能跑通实验04并说明 Fixed Plan 为什么失败、Replanning 为什么恢复；能设计一个简单 Planning 消融实验。
