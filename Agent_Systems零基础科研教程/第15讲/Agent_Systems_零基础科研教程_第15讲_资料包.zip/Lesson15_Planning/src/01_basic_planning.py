from planning_teaching import Plan, PlanStep, topo_valid
p=Plan("写研究简报",[
 PlanStep("S1","搜索资料"),
 PlanStep("S2","读取资料",["S1"]),
 PlanStep("S3","提取证据",["S2"]),
 PlanStep("S4","写摘要",["S3"]),
])
print("goal:",p.goal)
for s in p.steps: print(s.id,s.description,"depends_on=",s.depends_on)
print("dependency_valid=",topo_valid(p))
print("ready=",[s.id for s in p.ready_steps()])
