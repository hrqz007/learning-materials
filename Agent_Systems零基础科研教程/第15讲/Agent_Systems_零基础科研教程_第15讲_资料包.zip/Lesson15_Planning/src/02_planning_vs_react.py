# 教学对比：Planning 维护中期路线；ReAct 每轮只决定下一步。
planning=["search", "read", "extract", "write"]
react=[]
observations=["need_sources","source_found","evidence_found","ready_to_write"]
for obs in observations:
    react.append({"need_sources":"search","source_found":"read","evidence_found":"extract","ready_to_write":"write"}[obs])
print("planning_plan=",planning)
print("react_actions=",react)
print("same_goal_different_control_granularity=", planning==react)
