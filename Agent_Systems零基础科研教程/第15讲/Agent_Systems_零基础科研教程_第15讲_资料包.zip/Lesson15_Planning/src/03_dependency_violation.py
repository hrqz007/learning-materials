from planning_teaching import Plan, PlanStep, topo_valid
bad=Plan("写摘要",[
 PlanStep("S1","写摘要",["S3"]),
 PlanStep("S2","搜索资料"),
 PlanStep("S3","提取证据",["S2"]),
])
good=Plan("写摘要",[
 PlanStep("S2","搜索资料"),
 PlanStep("S3","提取证据",["S2"]),
 PlanStep("S1","写摘要",["S3"]),
])
print("bad_dependency_valid=",topo_valid(bad))
print("good_dependency_valid=",topo_valid(good))
