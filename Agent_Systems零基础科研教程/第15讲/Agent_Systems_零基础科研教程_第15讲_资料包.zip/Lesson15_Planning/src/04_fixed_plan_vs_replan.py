from planning_teaching import make_basic_plan, ToyWorld, execute_replanning_plan
# fixed: 到 read paper_A.txt 失败后停止
p=make_basic_plan(); w=ToyWorld()
fixed=[]
for sid,action,arg in [("S1","search","agent planning"),("S2","read","paper_A.txt")]:
    ok,out=w.execute(action,arg); fixed.append((sid,ok,out))
    if not ok: break
print("FIXED_PLAN")
for x in fixed: print(x)
print("success=False")
print("\nREPLANNING")
r=execute_replanning_plan()
for x in r["log"]: print(x)
print("success=",r["success"],"replans=",r["replans"],"plan_version=",r["plan"].version)
