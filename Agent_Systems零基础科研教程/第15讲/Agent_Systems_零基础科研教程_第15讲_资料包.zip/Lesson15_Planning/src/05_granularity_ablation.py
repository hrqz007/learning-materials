conditions={
 "coarse":{"steps":1,"observable_checkpoints":0,"planning_overhead":1,"failure_localization":"poor"},
 "balanced":{"steps":4,"observable_checkpoints":4,"planning_overhead":4,"failure_localization":"good"},
 "overfine":{"steps":12,"observable_checkpoints":12,"planning_overhead":12,"failure_localization":"good_but_expensive"},
}
for k,v in conditions.items(): print(k,v)
