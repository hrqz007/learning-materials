# 环境最初说 source=A，随后 source 改成 B。
plan={"source":"A","version":1}
environment={"source":"B"}
print("before:",plan,"environment:",environment)
if plan["source"] != environment["source"]:
    print("STALE_PLAN_DETECTED")
    plan["source"]=environment["source"]; plan["version"]+=1
print("after_replan:",plan)
