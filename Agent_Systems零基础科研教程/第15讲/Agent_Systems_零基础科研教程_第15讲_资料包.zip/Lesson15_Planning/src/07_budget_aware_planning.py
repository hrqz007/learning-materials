plans={
 "deep":{"steps":8,"cost":8,"expected_quality":0.95},
 "medium":{"steps":5,"cost":5,"expected_quality":0.88},
 "light":{"steps":3,"cost":3,"expected_quality":0.72},
}
for budget in [3,5,8]:
    feasible=[(k,v) for k,v in plans.items() if v["cost"]<=budget]
    best=max(feasible,key=lambda kv: kv[1]["expected_quality"])
    print("budget",budget,"->",best[0],best[1])
