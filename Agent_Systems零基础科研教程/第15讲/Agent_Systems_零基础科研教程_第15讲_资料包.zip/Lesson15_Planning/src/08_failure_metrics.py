import csv
from pathlib import Path
runs=[
 {"run":"R1","success":1,"decomposition_error":0,"dependency_error":0,"stale_plan":0,"replans":0,"invalid_steps":0},
 {"run":"R2","success":0,"decomposition_error":1,"dependency_error":0,"stale_plan":0,"replans":0,"invalid_steps":1},
 {"run":"R3","success":0,"decomposition_error":0,"dependency_error":1,"stale_plan":0,"replans":0,"invalid_steps":1},
 {"run":"R4","success":1,"decomposition_error":0,"dependency_error":0,"stale_plan":1,"replans":1,"invalid_steps":0},
 {"run":"R5","success":0,"decomposition_error":0,"dependency_error":0,"stale_plan":1,"replans":0,"invalid_steps":1},
]
out=Path(__file__).resolve().parent.parent/'results'/'planning_metrics.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=runs[0].keys()); w.writeheader(); w.writerows(runs)
print("runs=",len(runs),"success_rate=",sum(r['success'] for r in runs)/len(runs))
for k in ['decomposition_error','dependency_error','stale_plan','replans','invalid_steps']:
    print(k,'=',sum(r[k] for r in runs))
print('csv=',out)
