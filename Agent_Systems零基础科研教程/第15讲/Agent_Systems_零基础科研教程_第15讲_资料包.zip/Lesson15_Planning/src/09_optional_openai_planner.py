"""可选：需要 OPENAI_API_KEY 与 openai 包。示例只展示显式计划，不要求或打印私有 Chain-of-Thought。"""
from openai import OpenAI
import json, os
client=OpenAI()
prompt="你是任务规划器。把目标拆成 3-6 个可执行步骤，只返回 JSON：\\n{\"goal\":\"...\",\"steps\":[{\"id\":\"S1\",\"task\":\"...\",\"depends_on\":[]}]}\\n目标：为 Agent Planning 写一页研究简报。"
r=client.responses.create(model=os.environ['OPENAI_MODEL'],input=prompt)
print(r.output_text)
