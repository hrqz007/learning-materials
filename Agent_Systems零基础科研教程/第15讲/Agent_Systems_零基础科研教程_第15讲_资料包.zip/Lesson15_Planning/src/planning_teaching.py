from __future__ import annotations
from dataclasses import dataclass, field
from typing import Dict, List, Optional, Tuple
import json

@dataclass
class PlanStep:
    id: str
    description: str
    depends_on: List[str] = field(default_factory=list)
    status: str = "PENDING"  # PENDING/RUNNING/DONE/FAILED
    result: Optional[str] = None

@dataclass
class Plan:
    goal: str
    steps: List[PlanStep]
    version: int = 1

    def get(self, step_id: str) -> PlanStep:
        for s in self.steps:
            if s.id == step_id:
                return s
        raise KeyError(step_id)

    def ready_steps(self) -> List[PlanStep]:
        done = {s.id for s in self.steps if s.status == "DONE"}
        return [s for s in self.steps if s.status == "PENDING" and all(d in done for d in s.depends_on)]

    def summary(self) -> str:
        return " | ".join(f"{s.id}:{s.status}" for s in self.steps)

class ToyWorld:
    """离线教学环境。故意设计少量可控状态，便于观察 Planning 行为。"""
    def __init__(self):
        self.files = {"paper_B.txt": "Agent planning: evidence = planning should replan after environment changes."}
        self.notes: Dict[str, str] = {}
        self.search_db = {
            "agent planning": ["paper_A.txt", "paper_B.txt"],
            "planning metrics": ["metrics.txt"],
        }
        self.metrics_text = "metrics: success, steps, invalid_steps, replans, recovery"

    def execute(self, action: str, arg: str = "") -> Tuple[bool, str]:
        if action == "search":
            return True, json.dumps(self.search_db.get(arg, []), ensure_ascii=False)
        if action == "read":
            if arg == "metrics.txt":
                return True, self.metrics_text
            if arg not in self.files:
                return False, f"FILE_NOT_FOUND:{arg}"
            return True, self.files[arg]
        if action == "save":
            key, value = arg.split("=", 1)
            self.notes[key] = value
            return True, "SAVED"
        if action == "summarize":
            return True, "SUMMARY:" + arg[:80]
        return False, f"UNKNOWN_ACTION:{action}"


def make_basic_plan() -> Plan:
    return Plan("写一份 Agent Planning 小摘要", [
        PlanStep("S1", "搜索 agent planning"),
        PlanStep("S2", "读取 paper_B.txt", ["S1"]),
        PlanStep("S3", "总结证据", ["S2"]),
        PlanStep("S4", "保存摘要", ["S3"]),
    ])


def execute_basic(plan: Plan, world: ToyWorld, allow_replan: bool = True) -> Dict:
    log=[]; replans=0; invalid_steps=0
    while True:
        ready=plan.ready_steps()
        if not ready:
            if all(s.status == "DONE" for s in plan.steps):
                return {"success": True, "replans": replans, "invalid_steps": invalid_steps, "log": log, "plan": plan}
            return {"success": False, "replans": replans, "invalid_steps": invalid_steps, "log": log, "plan": plan}
        step=ready[0]; step.status="RUNNING"
        if step.id == "S1": ok,out=world.execute("search","agent planning")
        elif step.id == "S2": ok,out=world.execute("read","paper_A.txt")  # 故意失效，用来触发 replan
        elif step.id == "S3":
            prev=plan.get("S2").result or ""; ok,out=world.execute("summarize",prev)
        elif step.id == "S4":
            prev=plan.get("S3").result or ""; ok,out=world.execute("save","planning_summary="+prev)
        else: ok,out=False,"NO_MAPPING"
        log.append((step.id, ok, out))
        if ok:
            step.status="DONE"; step.result=out
            continue
        step.status="FAILED"; step.result=out
        if allow_replan and step.id == "S2" and out.startswith("FILE_NOT_FOUND"):
            # 用环境反馈修订原计划：把失败步骤改为可用文件，再继续。
            step.description="读取 paper_B.txt（由失败反馈触发 Replan）"
            step.status="PENDING"; step.result=None
            # 让执行映射识别已发生 replan
            step.id="S2B"
            plan.get("S3").depends_on=["S2B"]
            replans += 1; plan.version += 1
            continue
        return {"success": False, "replans": replans, "invalid_steps": invalid_steps, "log": log, "plan": plan}


def execute_replanning_plan() -> Dict:
    plan=make_basic_plan(); world=ToyWorld(); log=[]; replans=0
    while True:
        ready=plan.ready_steps()
        if not ready:
            return {"success": all(s.status in ("DONE","SUPERSEDED") for s in plan.steps), "replans":replans, "log":log, "plan":plan}
        s=ready[0]; s.status="RUNNING"
        if s.id=="S1": ok,out=world.execute("search","agent planning")
        elif s.id=="S2": ok,out=world.execute("read","paper_A.txt")
        elif s.id=="S2B": ok,out=world.execute("read","paper_B.txt")
        elif s.id=="S3":
            src=plan.get("S2B").result if any(x.id=="S2B" for x in plan.steps) else plan.get("S2").result
            ok,out=world.execute("summarize",src or "")
        elif s.id=="S4": ok,out=world.execute("save","planning_summary="+(plan.get("S3").result or ""))
        else: ok,out=False,"NO_MAPPING"
        log.append((s.id,ok,out))
        if ok:
            s.status="DONE"; s.result=out; continue
        s.status="FAILED"; s.result=out
        if s.id=="S2" and out.startswith("FILE_NOT_FOUND"):
            # 将失败步骤替换为新步骤，避免把失败状态直接伪装成成功。
            new=PlanStep("S2B","读取 paper_B.txt",["S1"])
            idx=plan.steps.index(s); plan.steps.insert(idx+1,new)
            s.status="SUPERSEDED"
            plan.get("S3").depends_on=["S2B"]
            replans+=1; plan.version+=1
            continue
        return {"success":False,"replans":replans,"log":log,"plan":plan}


def topo_valid(plan: Plan) -> bool:
    seen=set()
    for s in plan.steps:
        if not all(d in seen for d in s.depends_on):
            return False
        seen.add(s.id)
    return True
