# Agent Systems 零基础科研教程 - 第16讲 Reflection / Critic / Verifier

## 推荐学习顺序
1. 先看 `01_零基础讲义.docx` 或 PDF。
2. 先做练习题，再看答案。
3. 跑 `src/01` 到 `src/08`。
4. 重点观察实验 02、05、06、07、08。
5. 阅读实验设计书，理解怎样把“自我反思”拆成可测组件。

## 必做实验
- 01 Objective Verifier
- 02 Shared Blind Spot
- 03 Code Test + Refine
- 04 Critic vs Verifier
- 05 False Positive Critique
- 06 Over-Refinement + Stop
- 07 Independent Critic Ablation
- 08 Failure Metrics

## 可选实验
`src/09_optional_openai_reflection.py` 需要 `OPENAI_API_KEY`、`OPENAI_MODEL` 与 `openai` 包。只要求显式 feedback/verdict，不要求暴露私有 Chain-of-Thought。

## 本讲最低闭环
能解释 Critic、Verifier、Judge、Reviewer 的差别；能说明为什么同模型 Self-Critique 会有共享盲点；能跑通 False Positive 与 Over-Refinement 实验；能设计一个 Self-Critic vs External Verifier 对照实验。
