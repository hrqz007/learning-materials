from reflection_teaching import ArithmeticVerifier
v=ArithmeticVerifier()
for answer in [74,72]:
    r=v.verify("18*4",answer)
    print(answer,r)
