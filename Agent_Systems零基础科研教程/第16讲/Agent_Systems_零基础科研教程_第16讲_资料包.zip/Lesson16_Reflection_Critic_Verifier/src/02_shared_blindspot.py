# 受控教学模拟：Generator 与 Self-Critic 共享同一个错误规则。
def wrong_rule(n): return n*2+1
candidate=wrong_rule(5)  # 11，但任务真实规则应为 n*2=10
self_critic_expected=wrong_rule(5)
self_critic_ok=(candidate==self_critic_expected)
external_expected=5*2
external_ok=(candidate==external_expected)
print("candidate=",candidate)
print("same_model_critic_accepts=",self_critic_ok)
print("external_verifier_accepts=",external_ok)
print("lesson=shared assumptions can hide errors")
