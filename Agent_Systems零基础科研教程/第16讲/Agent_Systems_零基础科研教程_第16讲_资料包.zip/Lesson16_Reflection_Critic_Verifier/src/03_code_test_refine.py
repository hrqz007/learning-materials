from reflection_teaching import CodeVerifier
v=CodeVerifier()
def buggy_square(x): return x+x
def fixed_square(x): return x*x
for name,fn in [("buggy",buggy_square),("fixed",fixed_square)]:
    print(name,v.verify(fn))
