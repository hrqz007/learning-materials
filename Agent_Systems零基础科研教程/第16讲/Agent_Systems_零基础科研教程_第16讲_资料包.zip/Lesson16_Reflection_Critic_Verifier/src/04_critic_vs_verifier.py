text="Agent Planning 很重要。"
# Critic 能指出质量问题，但不是客观真值测试。
critic_feedback=["缺少具体例子","没有定义 Planning","缺少证据来源"]
# Verifier 检查明确条件。
required=["Planning","例子","来源"]
verifier={k:(k in text) for k in required}
print("critic_feedback=",critic_feedback)
print("verifier_checks=",verifier)
