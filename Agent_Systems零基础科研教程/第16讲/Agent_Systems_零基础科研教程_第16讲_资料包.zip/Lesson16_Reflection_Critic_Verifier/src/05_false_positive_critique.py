from reflection_teaching import ArithmeticVerifier,noisy_critic,conservative_reviser
answer=72
critique=noisy_critic(answer)
blind_revision=74 if "74" in critique else answer
safe_revision,action=conservative_reviser(answer,critique,ArithmeticVerifier())
print("original=",answer)
print("critique=",critique)
print("blind_revision=",blind_revision,"verified=",ArithmeticVerifier().verify("18*4",blind_revision).ok)
print("verified_revision=",safe_revision,"action=",action,"verified=",ArithmeticVerifier().verify("18*4",safe_revision).ok)
