# 受控序列：第1次修订已正确；继续机械修订，第3次反而变错。
versions=[74,72,72,73]
for i,v in enumerate(versions):
    passed=(v==72)
    print("iteration",i,"answer",v,"verifier_pass",passed)
    if passed:
        print("STOP_EARLY at",i)
        break
print("fixed_three_revision_final=",versions[3],"correct=",versions[3]==72)
