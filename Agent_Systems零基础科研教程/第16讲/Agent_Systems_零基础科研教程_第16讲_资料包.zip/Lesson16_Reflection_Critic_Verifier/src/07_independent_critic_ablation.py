cases=[
 {"id":"C1","truth":10,"generator":11,"same_critic":11,"independent_critic":10},
 {"id":"C2","truth":12,"generator":12,"same_critic":12,"independent_critic":12},
 {"id":"C3","truth":14,"generator":15,"same_critic":15,"independent_critic":14},
]
for c in cases:
    same_detect=(c['same_critic']!=c['generator'])
    independent_detect=(c['independent_critic']!=c['generator'])
    print(c['id'],"generator_correct=",c['generator']==c['truth'],"same_detect=",same_detect,"independent_detect=",independent_detect)
