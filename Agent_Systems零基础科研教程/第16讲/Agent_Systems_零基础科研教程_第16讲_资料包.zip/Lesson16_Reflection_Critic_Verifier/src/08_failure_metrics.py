import csv
from pathlib import Path
runs=[
 {"run":"R1","initial_correct":0,"detected":1,"false_positive":0,"repair_success":1,"final_correct":1,"iterations":1},
 {"run":"R2","initial_correct":0,"detected":0,"false_positive":0,"repair_success":0,"final_correct":0,"iterations":1},
 {"run":"R3","initial_correct":1,"detected":1,"false_positive":1,"repair_success":0,"final_correct":0,"iterations":1},
 {"run":"R4","initial_correct":0,"detected":1,"false_positive":0,"repair_success":0,"final_correct":0,"iterations":2},
 {"run":"R5","initial_correct":1,"detected":0,"false_positive":0,"repair_success":0,"final_correct":1,"iterations":0},
]
out=Path(__file__).resolve().parent.parent/'results'/'reflection_metrics.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=runs[0].keys()); w.writeheader(); w.writerows(runs)
wrong=[r for r in runs if not r['initial_correct']]
detection=sum(r['detected'] for r in wrong)/len(wrong)
final=sum(r['final_correct'] for r in runs)/len(runs)
print("runs=",len(runs),"detection_rate_on_wrong=",round(detection,3),"final_accuracy=",round(final,3))
print("false_positives=",sum(r['false_positive'] for r in runs),"repair_successes=",sum(r['repair_success'] for r in runs))
print("csv=",out)
