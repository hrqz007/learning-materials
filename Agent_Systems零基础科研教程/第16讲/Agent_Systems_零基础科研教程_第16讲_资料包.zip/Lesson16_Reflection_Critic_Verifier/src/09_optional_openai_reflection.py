"""可选真实 API 实验：需要 OPENAI_API_KEY、OPENAI_MODEL 与 openai 包。
只要求显式 critique/verification summary，不要求或打印私有 Chain-of-Thought。
"""
import os, json
from openai import OpenAI
client=OpenAI()
model=os.environ["OPENAI_MODEL"]
q="计算 18*4，并只给出整数答案。"
r1=client.responses.create(model=model,input=q)
answer=r1.output_text.strip()
print("draft=",answer)
review_prompt=f"请检查候选答案是否满足问题。只输出JSON：{{\"verdict\":\"PASS或FAIL\",\"feedback\":\"简短说明\"}}。问题：{q} 候选：{answer}"
r2=client.responses.create(model=model,input=review_prompt)
print("review=",r2.output_text)
