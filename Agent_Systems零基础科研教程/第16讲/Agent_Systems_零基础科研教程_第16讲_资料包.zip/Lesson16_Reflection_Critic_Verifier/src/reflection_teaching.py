from dataclasses import dataclass
from typing import Callable, Dict, Any, Tuple

@dataclass
class CheckResult:
    ok: bool
    label: str
    feedback: str

class ArithmeticVerifier:
    def verify(self, expression: str, answer: int) -> CheckResult:
        expected = eval(expression, {"__builtins__": {}}, {})
        if answer == expected:
            return CheckResult(True, "PASS", f"verified:{expression}={expected}")
        return CheckResult(False, "WRONG_VALUE", f"expected={expected}, got={answer}")

class CodeVerifier:
    def verify(self, fn: Callable[[int], int]) -> CheckResult:
        tests={0:0,1:1,3:9,-2:4}
        for x,y in tests.items():
            try:
                got=fn(x)
            except Exception as e:
                return CheckResult(False,"EXECUTION_ERROR",repr(e))
            if got != y:
                return CheckResult(False,"TEST_FAIL",f"f({x}) expected {y}, got {got}")
        return CheckResult(True,"PASS","all unit tests passed")

def noisy_critic(answer: int) -> str:
    # 教学故障注入：故意把正确的 72 误报为错误。
    return "答案可能有误，建议改成74" if answer == 72 else "未发现明显问题"

def conservative_reviser(answer: int, critique: str, verifier: ArithmeticVerifier) -> Tuple[int,str]:
    # 不盲从 critique，先让客观 verifier 检查。
    vr=verifier.verify("18*4",answer)
    if vr.ok:
        return answer,"KEEP_VERIFIED"
    return 72,"REVISE_BY_VERIFIER"
