# Agent Systems 零基础科研教程 - 第17讲

## 主题
状态机与控制逻辑：State / Event / Guard / Transition / Checkpoint / Stop

## 推荐学习顺序
1. 01_零基础讲义.docx 或 02_零基础讲义.pdf
2. 独立完成 05_练习题.docx
3. 按 03_实验指导书.docx 运行 src/01-08
4. 打开 results/ 对照自己的输出
5. 阅读 04_实验设计书.docx，把控制机制改写成科研变量
6. 最后核对 06_练习题答案.docx

## 运行命令
```bash
cd src
python 01_basic_state_machine.py
python 02_invalid_transition.py
python 03_missing_state_update.py
python 04_guard_approval.py
python 05_checkpoint_resume.py
python 06_deadlock_livelock.py
python 07_explicit_vs_implicit_state.py
python 08_batch_failure_metrics.py
```

## 本讲最重要的一句话
LLM 可以提出下一步，但 Runtime 应尽量把“哪些路径合法、哪些条件必须满足、何时停止”变成可验证的控制逻辑。

## 可选真实 API
`09_optional_real_llm_controller.py` 仅用于观察“LLM 提议事件 + 外层状态机校验”的混合架构。不是必做实验。

## 当前工程资料（核验日期：2026-09-26）
- OpenAI Developers - Running agents: https://developers.openai.com/api/docs/guides/agents/running-agents
- OpenAI Developers - Sandbox Agents: https://developers.openai.com/api/docs/guides/agents/sandboxes

注意：课程强调底层概念，不依赖某个 SDK 的具体 API。
