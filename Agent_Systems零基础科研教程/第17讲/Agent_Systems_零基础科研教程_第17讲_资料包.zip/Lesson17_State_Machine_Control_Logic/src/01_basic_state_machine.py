from state_machine_core import *
sm=StateMachine()
for e in [Event.START,Event.PLAN_READY,Event.TOOL_OK,Event.VERIFY_OK]:
    print(sm.state.value,'+',e.value,end=' -> ')
    sm.send(e); print(sm.state.value)
print('final=',sm.state.value)
