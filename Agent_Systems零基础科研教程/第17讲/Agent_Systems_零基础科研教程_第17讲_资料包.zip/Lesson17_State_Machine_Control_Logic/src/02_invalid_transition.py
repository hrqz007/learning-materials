from state_machine_core import *
sm=StateMachine()
try:
    sm.send(Event.VERIFY_OK)
except InvalidTransition as e:
    print('REJECTED',e)
print('state still =',sm.state.value)
