# 教学故障注入：工具执行成功，但控制状态没有从 RUNNING 更新到 VERIFYING。
state='RUNNING'; progress=0; same_action=0
for turn in range(1,6):
    action='calculate'
    print('turn',turn,'state=',state,'action=',action)
    tool_result=391
    progress += 1 if turn==1 else 0
    # BUG: 忘了 state='VERIFYING'
    same_action += 1
    if same_action>=3:
        print('STOP no_progress: repeated action 3 times')
        break
