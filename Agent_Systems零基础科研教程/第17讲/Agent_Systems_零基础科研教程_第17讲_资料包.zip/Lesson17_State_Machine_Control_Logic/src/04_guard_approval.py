from state_machine_core import *
sm=StateMachine(); sm.send(Event.START); sm.send(Event.PLAN_READY)
sm.send(Event.NEED_APPROVAL)
print('after high-risk request:',sm.state.value)
try:
    sm.send(Event.APPROVED)
except GuardRejected as e:
    print('blocked:',e)
sm.data.approved=True
sm.send(Event.APPROVED)
print('after human approval:',sm.state.value)
