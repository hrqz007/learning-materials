from state_machine_core import *
from pathlib import Path
p=Path('checkpoint.json')
sm=StateMachine(); sm.send(Event.START); sm.send(Event.PLAN_READY)
sm.data.step=2; sm.data.result='partial-output'; sm.checkpoint(p)
print('saved',sm.state.value,sm.data.step)
# 模拟进程退出后重新加载
sm2=StateMachine.resume(p)
print('resumed',sm2.state.value,sm2.data.step,sm2.data.result)
sm2.send(Event.TOOL_OK); sm2.send(Event.VERIFY_OK)
print('final',sm2.state.value)
p.unlink(missing_ok=True)
