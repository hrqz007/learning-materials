# Deadlock: 没有合法下一步；Livelock: 一直转移但 progress 不增加。
print('DEADLOCK example: state=WAITING_APPROVAL, no APPROVED/REJECTED event arrives')
state='RUNNING'; progress=0; last_progress=0; stagnant=0
for i in range(1,8):
    state = 'RETRYING' if state=='RUNNING' else 'RUNNING'
    print('livelock turn',i,'state=',state,'progress=',progress)
    stagnant = stagnant+1 if progress==last_progress else 0
    last_progress=progress
    if stagnant>=4:
        print('WATCHDOG STOP: livelock/no_progress')
        break
