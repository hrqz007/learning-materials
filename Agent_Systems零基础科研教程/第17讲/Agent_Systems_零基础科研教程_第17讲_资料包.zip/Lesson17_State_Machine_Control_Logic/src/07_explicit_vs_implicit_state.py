# 受控对照：隐式状态依赖最近一句自然语言；显式状态用枚举字段。
history=['任务开始','工具成功，准备验证','旧消息：任务仍在执行']
implicit_state = 'RUNNING' if '执行' in history[-1] else 'VERIFYING'
explicit_state = 'VERIFYING'
print('implicit_state =',implicit_state)
print('explicit_state =',explicit_state)
print('implicit next =','call_tool_again' if implicit_state=='RUNNING' else 'verify')
print('explicit next =','verify' if explicit_state=='VERIFYING' else 'other')
