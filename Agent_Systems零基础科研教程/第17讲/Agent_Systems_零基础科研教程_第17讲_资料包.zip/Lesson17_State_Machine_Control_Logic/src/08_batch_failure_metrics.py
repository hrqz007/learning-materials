import csv
cases=[
 ('normal',0,0,0,0,1),
 ('invalid_transition',1,0,0,0,0),
 ('guard_violation',0,1,0,0,0),
 ('checkpoint_corrupt',0,0,1,0,0),
 ('premature_stop',0,0,0,1,0),
 ('livelock',0,0,0,1,0),
]
with open('state_machine_metrics.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['case','invalid_transition','guard_violation','checkpoint_error','control_error','task_success']); w.writerows(cases)
for r in cases: print(r)
print('wrote state_machine_metrics.csv')
