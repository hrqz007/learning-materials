"""可选：让真实 LLM 只提出 event/action，外层 StateMachine 仍负责验证合法转移。
需要：pip install openai，并设置 OPENAI_API_KEY。
本脚本不是必做实验。
"""
import os, json
from state_machine_core import *
try:
    from openai import OpenAI
except Exception:
    print('请先安装 openai: pip install openai'); raise SystemExit
if not os.getenv('OPENAI_API_KEY'):
    print('未设置 OPENAI_API_KEY，跳过真实 API。'); raise SystemExit
client=OpenAI()
sm=StateMachine(); sm.send(Event.START); sm.send(Event.PLAN_READY)
prompt=f"当前状态={sm.state.value}。任务：计算23*17。只输出JSON，例如 {{\"event\":\"TOOL_OK\",\"note\":\"...\"}}。"
r=client.responses.create(model='gpt-5.6',input=prompt)
print(r.output_text)
print('说明：真实系统仍应对 event 做白名单/Schema/Transition 校验，而不是直接执行模型文本。')
