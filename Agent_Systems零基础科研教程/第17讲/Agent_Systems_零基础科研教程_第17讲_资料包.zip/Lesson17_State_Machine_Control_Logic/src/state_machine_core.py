from dataclasses import dataclass, asdict
from enum import Enum
from typing import Dict, Tuple, Callable, Optional, Any
import json

class State(str, Enum):
    IDLE = "IDLE"
    PLANNING = "PLANNING"
    RUNNING = "RUNNING"
    WAITING_APPROVAL = "WAITING_APPROVAL"
    VERIFYING = "VERIFYING"
    RETRYING = "RETRYING"
    COMPLETED = "COMPLETED"
    FAILED = "FAILED"

class Event(str, Enum):
    START = "START"
    PLAN_READY = "PLAN_READY"
    TOOL_OK = "TOOL_OK"
    TOOL_ERROR = "TOOL_ERROR"
    NEED_APPROVAL = "NEED_APPROVAL"
    APPROVED = "APPROVED"
    REJECTED = "REJECTED"
    VERIFY_OK = "VERIFY_OK"
    VERIFY_FAIL = "VERIFY_FAIL"
    RETRY = "RETRY"
    ABORT = "ABORT"

@dataclass
class RunData:
    step: int = 0
    result: Optional[Any] = None
    error: Optional[str] = None
    approved: bool = False
    retries: int = 0
    progress: int = 0

@dataclass
class Snapshot:
    control_state: str
    data: dict
    version: int = 1

class InvalidTransition(Exception): pass
class GuardRejected(Exception): pass

class StateMachine:
    def __init__(self, state: State = State.IDLE, data: Optional[RunData] = None):
        self.state = state
        self.data = data or RunData()
        self.trace = []
        self.transitions: Dict[Tuple[State, Event], Tuple[State, Optional[Callable[[RunData], bool]]]] = {
            (State.IDLE, Event.START): (State.PLANNING, None),
            (State.PLANNING, Event.PLAN_READY): (State.RUNNING, None),
            (State.RUNNING, Event.TOOL_OK): (State.VERIFYING, None),
            (State.RUNNING, Event.TOOL_ERROR): (State.RETRYING, None),
            (State.RUNNING, Event.NEED_APPROVAL): (State.WAITING_APPROVAL, None),
            (State.WAITING_APPROVAL, Event.APPROVED): (State.RUNNING, lambda d: d.approved),
            (State.WAITING_APPROVAL, Event.REJECTED): (State.FAILED, None),
            (State.VERIFYING, Event.VERIFY_OK): (State.COMPLETED, None),
            (State.VERIFYING, Event.VERIFY_FAIL): (State.RETRYING, None),
            (State.RETRYING, Event.RETRY): (State.RUNNING, lambda d: d.retries <= 2),
            (State.RETRYING, Event.ABORT): (State.FAILED, None),
        }

    def send(self, event: Event):
        key=(self.state,event)
        if key not in self.transitions:
            raise InvalidTransition(f"{self.state.value} --{event.value}--> ?")
        new_state, guard = self.transitions[key]
        if guard and not guard(self.data):
            raise GuardRejected(f"guard rejected: {self.state.value} + {event.value}")
        old=self.state
        self.state=new_state
        self.trace.append({"from":old.value,"event":event.value,"to":new_state.value})
        return new_state

    def checkpoint(self, path):
        snap=Snapshot(self.state.value, asdict(self.data))
        with open(path,'w',encoding='utf-8') as f: json.dump(asdict(snap),f,ensure_ascii=False,indent=2)

    @classmethod
    def resume(cls,path):
        with open(path,encoding='utf-8') as f: raw=json.load(f)
        return cls(State(raw['control_state']), RunData(**raw['data']))
