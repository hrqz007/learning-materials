# Agent Systems 零基础科研教程 - 第18讲

## 主题
长任务为什么越来越容易失败：Error Accumulation、Context Drift、Wrong Branching、State Pollution 与 Recovery

## 推荐学习顺序
1. 01_零基础讲义.docx 或 02_零基础讲义.pdf
2. 独立完成 05_练习题.docx
3. 按 03_实验指导书.docx 运行 src/01-08
4. 查看 results/ 并对照自己的预测
5. 阅读 04_实验设计书.docx，把长任务 Failure 改写成科研变量
6. 最后核对 06_练习题答案.docx

## 必做实验
```bash
cd src
python 01_multiplicative_success.py
python 02_early_vs_late_error.py
python 03_wrong_branching.py
python 04_context_drift.py
python 05_state_pollution.py
python 06_checkpoint_recovery_cost.py
python 07_stop_conditions.py
python 08_batch_long_horizon_metrics.py
```

## 本讲最重要的一句话
长任务可靠性不是“模型一次都不犯错”，而是：错误能否被尽早发现、限制、恢复，并且不继续污染后续轨迹。

## 可选真实 API
`09_optional_real_llm_long_task.py` 只演示结构化 state 的思路，不是必做实验。

## 当前工程资料（核验日期：2026-09-26）
- OpenAI Compaction: https://developers.openai.com/api/docs/guides/compaction
- OpenAI Running agents: https://developers.openai.com/api/docs/guides/agents/running-agents
- OpenAI Agents API overview: https://developers.openai.com/api/docs/guides/agents-api/overview

注意：课程强调系统机制，不依赖某个 SDK 的具体语法。
