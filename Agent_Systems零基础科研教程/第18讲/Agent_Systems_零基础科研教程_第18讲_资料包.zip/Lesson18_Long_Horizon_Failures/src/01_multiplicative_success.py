import random, csv, math
random.seed(18)
p=0.97
lengths=[1,5,10,20,40]
rows=[]
for n in lengths:
    trials=5000
    succ=0
    for _ in range(trials):
        ok=True
        for _ in range(n):
            if random.random()>=p:
                ok=False; break
        succ += int(ok)
    empirical=succ/trials
    theory=p**n
    rows.append((n,theory,empirical))
    print(f'n={n:2d} theory={theory:.4f} empirical={empirical:.4f}')
with open('multiplicative_success.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['steps','theory_p_power_n','empirical_success']); w.writerows(rows)
print('注意：p^n 是“每步独立且成功率恒定”的教学近似，不是现实 Agent 的普遍定律。')
