def run(total, error_step):
    wrong_state=False; corrupted=0
    for step in range(1,total+1):
        if step==error_step:
            wrong_state=True
            print(f'step {step}: ERROR injected')
        elif wrong_state:
            corrupted += 1
            print(f'step {step}: downstream uses corrupted state')
        else:
            print(f'step {step}: ok')
    return corrupted
print('EARLY ERROR')
a=run(10,2); print('downstream_corrupted=',a)
print('\nLATE ERROR')
b=run(10,8); print('downstream_corrupted=',b)
