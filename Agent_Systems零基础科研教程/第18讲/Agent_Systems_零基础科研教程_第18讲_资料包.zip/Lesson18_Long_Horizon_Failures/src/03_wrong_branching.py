def execute(observed_type, verify=False):
    # 真值应该走 research 分支；错误 observation 会把它路由到 shopping。
    true_type='research'
    observed=observed_type
    if verify and observed != true_type:
        print('verification gate: branch mismatch -> corrected to research')
        observed=true_type
    branch='search_papers' if observed=='research' else 'search_products'
    success=(branch=='search_papers')
    print('observed=',observed_type,'verify=',verify,'branch=',branch,'success=',success)
    return success
execute('shopping',verify=False)
execute('shopping',verify=True)
