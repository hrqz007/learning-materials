goal='比较 Agent A 与 Agent B 的恢复率'
key_fact='必须同时报告 task_success 和 recovery_rate'
logs=[f'tool-log-{i}: retry / verbose output' for i in range(1,9)]
context=[goal,key_fact]+logs
# naive recent-only window
naive=context[-5:]
# priority-aware keeps goal/fact + recent evidence
priority=[goal,key_fact]+logs[-3:]
for name,c in [('naive',naive),('priority',priority)]:
    print('\n',name)
    print('contains_goal=',goal in c)
    print('contains_key_fact=',key_fact in c)
    print('items=',c)
