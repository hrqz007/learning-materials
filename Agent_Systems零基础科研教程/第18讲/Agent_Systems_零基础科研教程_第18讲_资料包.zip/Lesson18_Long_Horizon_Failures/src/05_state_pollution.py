def baseline():
    state={'verified':False,'result':None}
    # step1 accidentally writes impossible state
    state['verified']=True
    state['result']=None
    # downstream trusts polluted state
    action='finish' if state['verified'] else 'compute'
    print('baseline state=',state,'next_action=',action,'success=',False)

def guarded():
    state={'verified':False,'result':None}
    candidate={'verified':True,'result':None}
    invariant_ok=not (candidate['verified'] and candidate['result'] is None)
    if not invariant_ok:
        print('guarded: invariant violation detected -> reject update')
    else:
        state.update(candidate)
    action='compute' if not state['verified'] else 'finish'
    print('guarded state=',state,'next_action=',action,'success=',True)
baseline(); guarded()
