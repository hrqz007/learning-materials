TOTAL=10; FAIL_AT=7
# no checkpoint: first attempt executes 1..7 then full restart 1..10
no_ckpt = FAIL_AT + TOTAL
# checkpoint at step5: first attempt 1..7 then resume from step6..10
checkpoint_step=5
with_ckpt = FAIL_AT + (TOTAL-checkpoint_step)
print('no_checkpoint total_executions=',no_ckpt,'wasted=',no_ckpt-TOTAL)
print('with_checkpoint total_executions=',with_ckpt,'wasted=',with_ckpt-TOTAL)
print('saved_executions=',no_ckpt-with_ckpt)
