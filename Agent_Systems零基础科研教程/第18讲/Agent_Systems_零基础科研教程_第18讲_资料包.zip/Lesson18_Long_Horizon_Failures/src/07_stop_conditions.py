# 场景A：有 partial_result 就错误地提前停止
partial_result=True; verified=False
premature_stop = partial_result
safe_stop = partial_result and verified
print('premature policy stop=',premature_stop,'task_complete=',False)
print('verified policy stop=',safe_stop,'task_complete=',False)
# 当 verifier 通过后才允许完成
verified=True
safe_stop = partial_result and verified
print('after verify stop=',safe_stop,'task_complete=',True)
# 场景B：没有停止条件会产生冗余步
redundant=0
for turn in range(1,6):
    if turn>2: redundant += 1
print('missing_stop redundant_steps=',redundant)
