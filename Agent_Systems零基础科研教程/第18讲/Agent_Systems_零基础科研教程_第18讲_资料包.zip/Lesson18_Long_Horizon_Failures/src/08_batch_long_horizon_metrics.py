import random,csv
random.seed(1801)
lengths=[5,10,20,40]
trials=1000
rows=[]
for n in lengths:
    for condition in ['baseline','guarded']:
        success=0; recovered=0; total_steps=0; first_errors=[]
        for _ in range(trials):
            episode_ok=True; first=None; steps=0
            for step in range(1,n+1):
                steps += 1
                if random.random()<0.04: # 教学故障率 4%
                    if first is None: first=step
                    if condition=='guarded' and random.random()<0.65: # 教学恢复率
                        recovered += 1
                        steps += 1  # 恢复有额外成本
                        continue
                    episode_ok=False; break
            success += int(episode_ok); total_steps += steps
            if first is not None: first_errors.append(first)
        rows.append((condition,n,success/trials,recovered/trials,total_steps/trials,(sum(first_errors)/len(first_errors) if first_errors else '')))
for r in rows: print(r)
with open('long_horizon_metrics.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['condition','task_length','episode_success','recoveries_per_episode','avg_executed_steps','avg_first_error_step']); w.writerows(rows)
print('注意：故障率4%、恢复率65%均为教学设定，不代表任何真实模型或 Agent 系统。')
