"""可选真实模型实验：只演示长任务的结构化控制，不作为必做。
需要：pip install openai；设置 OPENAI_API_KEY。
思路：把长任务拆为多个 milestone，每完成一个阶段就保存结构化 state，并在 context 增长时进行 compaction/摘要。
"""
import os, json
try:
    from openai import OpenAI
except Exception:
    print('请先安装 openai: pip install openai'); raise SystemExit
if not os.getenv('OPENAI_API_KEY'):
    print('未设置 OPENAI_API_KEY，跳过真实 API。'); raise SystemExit
client=OpenAI()
state={'goal':'比较两种 Agent 恢复策略','milestone':'collect_evidence','done':[],'blockers':[]}
prompt='你是长任务控制器。根据结构化 state 给出下一步最小动作，不要输出私有思维过程。只返回简短的 action 摘要。\nSTATE='+json.dumps(state,ensure_ascii=False)
r=client.responses.create(model='gpt-5.6',input=prompt)
print(r.output_text)
print('真实系统建议：把关键状态保存在结构化 state/checkpoint 中，不依赖无限增长的自然语言历史。')
