from dataclasses import dataclass, field
from typing import List, Optional, Dict

@dataclass
class StepRecord:
    step: int
    ok: bool
    state: str
    note: str = ""

@dataclass
class Episode:
    goal: str
    total_steps: int
    records: List[StepRecord] = field(default_factory=list)
    first_error_step: Optional[int] = None
    recovered: bool = False
    success: bool = False

    def add(self, step:int, ok:bool, state:str, note:str=""):
        self.records.append(StepRecord(step,ok,state,note))
        if not ok and self.first_error_step is None:
            self.first_error_step = step

    @property
    def propagation_depth(self):
        if self.first_error_step is None: return 0
        return max(0, self.total_steps - self.first_error_step)
