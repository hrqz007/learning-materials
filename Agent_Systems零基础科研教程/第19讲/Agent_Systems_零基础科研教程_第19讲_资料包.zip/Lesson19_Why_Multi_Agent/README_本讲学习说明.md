# 第19讲学习说明

主题：为什么需要 Multi-Agent？一个 Agent 不够时，多 Agent 真的会更好吗？

## 建议顺序
1. 先读 `01_零基础讲义.docx` 或 PDF。
2. 不看答案完成 `05_练习题.docx`。
3. 按 `03_实验指导书.docx` 依次运行 `src/01` 到 `src/08`。
4. 查看 `results/` 中的实际运行输出和 `manager_worker_trace.jsonl`。
5. 用 `04_实验设计书.docx` 自己设计一次 1/2/4/8 Agent team-size ablation。
6. 最后查看答案和术语表。

## 关键原则
- 必做实验均无需 API Key。
- 所有带概率的数字均为受控教学模拟参数，不代表真实 GPT/Claude/Gemini 等模型性能。
- 不要把“更多 Agent”与“更多计算预算”混为一谈。
- 科研评测至少同时记录 success、cost、messages、duplicate work、coordination failure。

## 可选真实实验
`09_optional_real_openai_multi_agent.py` 使用 OpenAI Agents SDK 的 manager + agents-as-tools 结构。运行前需要安装 `openai-agents` 并设置 `OPENAI_API_KEY`。

## 本讲最低闭环
能回答：什么时候 Multi-Agent 有理由存在？增加 Agent 后，收益来自 specialization/parallelism 还是仅仅更多计算？失败发生在角色、通信、共享状态、协调、相关错误还是 Manager？
