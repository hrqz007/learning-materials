"""受控教学实验：独立子任务在 1/2/4 个 worker 下的并行轮数与通信量。"""
from math import ceil

subtasks = ["A", "B", "C", "D", "E", "F", "G", "H"]
print("team_size,rounds,message_count")
for n in [1, 2, 4, 8]:
    rounds = ceil(len(subtasks) / n)
    # manager 每个子任务发 1 条 assignment，worker 每个子任务回 1 条 result
    messages = 2 * len(subtasks)
    print(f"{n},{rounds},{messages}")

print("\n解释：增加 worker 能降低可并行任务的轮数，但本实验中的总 assignment/result 消息数并不会自动下降。")
