"""受控教学模拟：单一 generalist vs 路由到 specialists。数字不代表真实 LLM。"""
import random
random.seed(19)

types = ["math", "search", "review"]
N = 6000

def trial(p):
    return random.random() < p

generalist_success = 0
specialist_success = 0
for _ in range(N):
    t = random.choice(types)
    if trial(0.74):
        generalist_success += 1
    specialist_p = {"math":0.93, "search":0.91, "review":0.92}[t]
    if trial(specialist_p):
        specialist_success += 1

print(f"tasks={N}")
print(f"single_generalist_success={generalist_success/N:.3f}")
print(f"routed_specialists_success={specialist_success/N:.3f}")
print("NOTE: 这些概率是人为设定的教学参数，只用于理解 specialization ablation。")
