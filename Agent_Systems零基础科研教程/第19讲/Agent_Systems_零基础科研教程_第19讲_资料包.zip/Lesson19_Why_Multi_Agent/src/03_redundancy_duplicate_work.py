"""演示没有明确分工时，多 Agent 可能重复劳动。"""

def duplicate_ratio(assignments):
    total = len(assignments)
    unique = len(set(assignments))
    return (total - unique) / total

uncoordinated = ["paper_A", "paper_A", "paper_B", "paper_A"]
managed = ["paper_A", "paper_B", "paper_C", "paper_D"]

for name, arr in [("uncoordinated", uncoordinated), ("manager_assigned", managed)]:
    print(name)
    print(" assignments =", arr)
    print(" unique_work =", len(set(arr)))
    print(" duplicate_ratio =", f"{duplicate_ratio(arr):.2f}")
