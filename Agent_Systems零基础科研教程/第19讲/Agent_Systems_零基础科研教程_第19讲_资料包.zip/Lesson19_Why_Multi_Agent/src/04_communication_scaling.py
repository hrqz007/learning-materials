"""比较 all-to-all 与 manager-worker 的理论通信边数/消息量。"""
import csv
from pathlib import Path

rows=[]
for n in [2,4,8,16,32]:
    peer_pairs = n*(n-1)//2
    directed_peer_messages = n*(n-1)
    manager_round_trip = 2*n  # manager->worker + worker->manager
    rows.append((n, peer_pairs, directed_peer_messages, manager_round_trip))

print("agents,peer_pairs,directed_peer_messages,manager_round_trip")
for r in rows:
    print(",".join(map(str,r)))
