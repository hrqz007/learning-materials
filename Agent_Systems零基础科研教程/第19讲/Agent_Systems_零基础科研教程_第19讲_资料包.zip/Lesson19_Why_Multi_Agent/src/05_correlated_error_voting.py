"""受控教学模拟：多数投票只有在错误不高度相关时才明显受益。"""
import random
random.seed(1905)
N=20000

# 3 个 agent。independent: 每个独立以 0.25 出错。
# correlated: 以 0.18 概率触发 shared blind spot，三个都错；否则各自以 0.10 出错。
def majority_correct(errors):
    return sum(not e for e in errors) >= 2

ind_ok=0
corr_ok=0
for _ in range(N):
    errs=[random.random()<0.25 for _ in range(3)]
    ind_ok += majority_correct(errs)

    shared = random.random()<0.18
    if shared:
        errs=[True,True,True]
    else:
        errs=[random.random()<0.10 for _ in range(3)]
    corr_ok += majority_correct(errs)

print(f"trials={N}")
print(f"independent_majority_success={ind_ok/N:.3f}")
print(f"correlated_majority_success={corr_ok/N:.3f}")
print("NOTE: 参数为教学设定；结论是理解 error correlation，而非评测真实模型。")
