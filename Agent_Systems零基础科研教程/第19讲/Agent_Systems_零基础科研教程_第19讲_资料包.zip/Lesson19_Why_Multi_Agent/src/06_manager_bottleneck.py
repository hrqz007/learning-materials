"""受控队列模型：worker 增多后，中央 manager 可能成为吞吐瓶颈。"""
# 每个 worker 每 tick 产生 1 个结果；manager 每 tick 最多处理 capacity 个结果。
manager_capacity = 4
for workers in [1,2,4,8,16]:
    incoming_per_tick = workers
    processed_per_tick = min(incoming_per_tick, manager_capacity)
    backlog_growth = max(0, incoming_per_tick - manager_capacity)
    print(f"workers={workers:2d} incoming/tick={incoming_per_tick:2d} processed/tick={processed_per_tick:2d} backlog_growth/tick={backlog_growth:2d}")
