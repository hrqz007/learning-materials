"""一个不依赖 LLM 的最小 Manager-Worker 系统，展示消息、角色和聚合。"""
from pathlib import Path
from multi_agent_core import Trace

trace = Trace()
manager = "Manager"

task = "基于本地材料生成一份两点式技术小结，并核对 23*17。"
trace.event(stage="start", task=task)

trace.send(manager, "Researcher", "assignment", "读取材料并提取两个要点")
research_result = ["多智能体可通过分工处理不同子任务", "协调与通信本身会带来额外成本"]
trace.send("Researcher", manager, "result", " | ".join(research_result))

trace.send(manager, "Calculator", "assignment", "计算 23*17")
calc_result = 23*17
trace.send("Calculator", manager, "result", str(calc_result))

trace.send(manager, "Reviewer", "assignment", "检查小结是否包含收益与代价两面")
review_result = "PASS: 同时包含分工收益与协调代价"
trace.send("Reviewer", manager, "result", review_result)

final = {
    "summary": research_result,
    "calculation": calc_result,
    "review": review_result,
}
trace.event(stage="finish", final=final)

out = Path(__file__).resolve().parents[1] / "results" / "manager_worker_trace.jsonl"
trace.save_jsonl(str(out))
print("final =", final)
print("messages =", len(trace.messages))
print("trace =", out)
