"""受控教学模拟：team size 增大时，specialization benefit 与 coordination penalty 同时存在。"""
import random, csv
from pathlib import Path
random.seed(1908)

team_sizes=[1,2,4,8]
N=5000
rows=[]
for n in team_sizes:
    # 人为教学参数：小团队先获得分工收益；大团队协调风险继续增加。
    base = {1:0.74, 2:0.82, 4:0.87, 8:0.87}[n]
    coord_fail = {1:0.00, 2:0.02, 4:0.06, 8:0.14}[n]
    duplicate = {1:0.00, 2:0.04, 4:0.10, 8:0.22}[n]
    messages = {1:0, 2:4, 4:12, 8:32}[n]
    success=0
    for _ in range(N):
        ok = random.random() < base
        if ok and random.random() < coord_fail:
            ok=False
        success += ok
    rate=success/N
    rows.append((n,rate,messages,coord_fail,duplicate))

print("team_size,success_rate,mean_messages,coordination_failure_parameter,duplicate_work_parameter")
for r in rows:
    print(f"{r[0]},{r[1]:.3f},{r[2]},{r[3]:.2f},{r[4]:.2f}")

out=Path(__file__).resolve().parents[1]/"results"/"team_size_tradeoff.csv"
with open(out,"w",newline="",encoding="utf-8") as f:
    w=csv.writer(f)
    w.writerow(["team_size","success_rate","mean_messages","coordination_failure_parameter","duplicate_work_parameter"])
    w.writerows(rows)
print("saved:",out)
print("NOTE: 这是受控教学模拟，不是任何真实模型或框架的 benchmark。")
