"""
可选真实实验：OpenAI Agents SDK 的 manager + agents-as-tools 结构。
运行前：pip install openai-agents；设置 OPENAI_API_KEY。
本文件不是必做实验，API/模型默认值可能随时间变化，请以官方文档为准。
"""
from agents import Agent, Runner

researcher = Agent(
    name="Researcher",
    instructions="你只负责提取事实要点，回答简洁。",
)
reviewer = Agent(
    name="Reviewer",
    instructions="你只负责检查答案是否同时说明收益和代价。",
)

manager = Agent(
    name="Manager",
    instructions=(
        "你负责最终回答。必要时调用研究员和审阅员。"
        "最终用中文解释：多智能体为什么可能有用，以及为什么不一定更好。"
    ),
    tools=[
        researcher.as_tool(
            tool_name="research_agent",
            tool_description="提取多智能体问题的关键事实与机制。",
        ),
        reviewer.as_tool(
            tool_name="review_agent",
            tool_description="检查草稿是否同时包含收益、代价与边界条件。",
        ),
    ],
)

result = Runner.run_sync(manager, "用零基础能懂的话解释：为什么多智能体不等于 Agent 越多越强？")
print(result.final_output)
