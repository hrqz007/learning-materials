from dataclasses import dataclass, field
from typing import List, Dict, Any
import json

@dataclass
class Message:
    sender: str
    receiver: str
    kind: str
    content: str

@dataclass
class Agent:
    name: str
    role: str
    capabilities: List[str]

    def can_handle(self, task_type: str) -> bool:
        return task_type in self.capabilities or "general" in self.capabilities

@dataclass
class Trace:
    messages: List[Message] = field(default_factory=list)
    events: List[Dict[str, Any]] = field(default_factory=list)

    def send(self, sender, receiver, kind, content):
        self.messages.append(Message(sender, receiver, kind, content))

    def event(self, **kwargs):
        self.events.append(kwargs)

    def save_jsonl(self, path: str):
        with open(path, "w", encoding="utf-8") as f:
            for m in self.messages:
                f.write(json.dumps({"type":"message", **m.__dict__}, ensure_ascii=False) + "\n")
            for e in self.events:
                f.write(json.dumps({"type":"event", **e}, ensure_ascii=False) + "\n")
