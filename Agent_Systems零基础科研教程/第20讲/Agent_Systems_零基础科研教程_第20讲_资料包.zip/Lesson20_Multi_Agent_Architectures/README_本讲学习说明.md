# Agent Systems 零基础科研教程 - 第20讲资料包

## 主题
Multi-Agent 基本架构：Manager-Worker、Handoff、Peer-to-Peer、Hierarchical。

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 先做 05_练习题.docx
3. 按 03_实验指导书.docx 跑 src/01-08
4. 对照 results/ 阅读 trace 与 CSV
5. 填写 04_实验设计书.docx
6. 最后看 06_练习题答案.docx

## 必做实验
- 01：四种架构同任务结构对照
- 02：Manager-Worker trace
- 03：Handoff active agent 转移
- 04：Peer-to-Peer 共识与消息数
- 05：Hierarchical 分层编排
- 06：节点故障影响范围
- 07：同步/并行/部分结果与 straggler
- 08：任务类型 × 架构教学匹配矩阵

## 选做实验
src/09_optional_real_openai_architectures.py
需要：`pip install openai-agents` 并设置 `OPENAI_API_KEY`。

## 重要声明
本讲所有“架构适配”数值都是教学用受控场景，不代表任何真实 LLM、OpenAI、Anthropic 或其他产品的性能排名。

## 当前参考资料（截至 2026-09-27）
- OpenAI Agents SDK Agent orchestration: https://openai.github.io/openai-agents-python/multi_agent/
- OpenAI Agents SDK Handoffs: https://openai.github.io/openai-agents-python/handoffs/
- Anthropic multi-agent research system: https://www.anthropic.com/engineering/multi-agent-research-system
