from multi_agent_arch_core import *

def manager_worker():
    t=Trace(); manager=Agent('Manager','orchestrator')
    workers=[Agent('Researcher','research'),Agent('Analyst','analysis'),Agent('Reviewer','review')]
    for i,w in enumerate(workers,1):
        t.add(i*2-1,'Manager',w.name,'delegate',w.role)
        t.add(i*2,w.name,'Manager','result',w.work(w.role))
    return {'architecture':'manager-worker','messages':t.count,'control_transfers':0,'final_owner':'Manager','max_depth':1}

def handoff():
    path=['Triage','Research','Analyst','Writer']; t=Trace()
    for i in range(len(path)-1):
        t.add(i+1,path[i],path[i+1],'handoff',f'active -> {path[i+1]}')
    return {'architecture':'handoff','messages':t.count,'control_transfers':3,'final_owner':'Writer','max_depth':3}

def p2p():
    agents=['A','B','C','D']; t=Trace(); step=0
    for a in agents:
        for b in agents:
            if a!=b:
                step+=1; t.add(step,a,b,'peer_message','share finding')
    return {'architecture':'peer-to-peer','messages':t.count,'control_transfers':0,'final_owner':'consensus','max_depth':1}

def hierarchical():
    # root -> 2 managers -> 4 workers, each assignment/result counts as 2 messages
    return {'architecture':'hierarchical','messages':12,'control_transfers':0,'final_owner':'RootManager','max_depth':2}

for x in [manager_worker(),handoff(),p2p(),hierarchical()]: print(x)
