from multi_agent_arch_core import *
from pathlib import Path
trace=Trace()
workers=[('Researcher','collect sources'),('Analyst','compare evidence'),('Reviewer','check gaps')]
step=0
results=[]
for name,task in workers:
    step+=1; trace.add(step,'Manager',name,'delegate',task)
    out=Agent(name,task).work(task); results.append(out)
    step+=1; trace.add(step,name,'Manager','result',out)
final=' | '.join(results)
trace.add(step+1,'Manager','User','final',final)
print('final_owner=Manager')
print('messages=',trace.count)
print('final=',final)
trace.dump_jsonl(Path(__file__).parents[1]/'results/manager_worker_trace.jsonl')
