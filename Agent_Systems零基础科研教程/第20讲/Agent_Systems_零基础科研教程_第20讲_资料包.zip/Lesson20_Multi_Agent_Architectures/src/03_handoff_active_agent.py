from multi_agent_arch_core import *
path=['Triage','ResearchAgent','AnalysisAgent','WriterAgent']
active=path[0]; trace=Trace()
print('start active=',active)
for i,nxt in enumerate(path[1:],1):
    trace.add(i,active,nxt,'handoff',f'{active} transfers control')
    active=nxt
    print(f'after handoff {i}: active={active}')
print('final_owner=',active)
print('handoffs=',len(path)-1)
