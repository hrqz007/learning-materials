from multi_agent_arch_core import *
agents={'A':'X','B':'X','C':'Y','D':'X'}
trace=Trace(); step=0
for a,va in agents.items():
    for b in agents:
        if a!=b:
            step+=1; trace.add(step,a,b,'broadcast',va)
counts={v:list(agents.values()).count(v) for v in set(agents.values())}
consensus=max(counts,key=counts.get)
print('messages=',trace.count)
print('votes=',agents)
print('consensus=',consensus)
print('central_controller=None')
