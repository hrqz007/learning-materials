from multi_agent_arch_core import *
trace=Trace(); step=0
structure={'ResearchManager':['SearchA','SearchB'],'AnalysisManager':['Stats','Verifier']}
for mgr,workers in structure.items():
    step+=1; trace.add(step,'RootManager',mgr,'delegate',mgr)
    for w in workers:
        step+=1; trace.add(step,mgr,w,'delegate',w)
        step+=1; trace.add(step,w,mgr,'result',f'{w}_done')
    step+=1; trace.add(step,mgr,'RootManager','result',f'{mgr}_summary')
trace.add(step+1,'RootManager','User','final','combined')
print('messages=',trace.count)
print('max_depth=2')
print('root_direct_workers=2')
print('leaf_workers=4')
