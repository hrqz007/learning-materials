scenarios={
 'manager_worker_manager_crash': {'completed_agents':0,'task_success':False,'scope':'global'},
 'handoff_current_agent_crash': {'completed_agents':1,'task_success':False,'scope':'active_path'},
 'p2p_one_agent_crash': {'completed_agents':3,'task_success':True,'scope':'local'},
 'hierarchy_one_domain_manager_crash': {'completed_agents':2,'task_success':False,'scope':'one_subtree'},
}
for k,v in scenarios.items(): print(k,v)
