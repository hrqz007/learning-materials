import csv
from pathlib import Path
rows=[
 {'task':'routing','architecture':'manager-worker','success':1,'messages':4,'coordination_cost':2},
 {'task':'routing','architecture':'handoff','success':1,'messages':1,'coordination_cost':1},
 {'task':'routing','architecture':'peer-to-peer','success':1,'messages':6,'coordination_cost':5},
 {'task':'routing','architecture':'hierarchical','success':1,'messages':5,'coordination_cost':3},
 {'task':'parallel_research','architecture':'manager-worker','success':1,'messages':8,'coordination_cost':3},
 {'task':'parallel_research','architecture':'handoff','success':0,'messages':3,'coordination_cost':2},
 {'task':'parallel_research','architecture':'peer-to-peer','success':1,'messages':12,'coordination_cost':5},
 {'task':'parallel_research','architecture':'hierarchical','success':1,'messages':12,'coordination_cost':4},
 {'task':'coupled_state','architecture':'manager-worker','success':1,'messages':8,'coordination_cost':4},
 {'task':'coupled_state','architecture':'handoff','success':1,'messages':3,'coordination_cost':3},
 {'task':'coupled_state','architecture':'peer-to-peer','success':0,'messages':12,'coordination_cost':5},
 {'task':'coupled_state','architecture':'hierarchical','success':0,'messages':12,'coordination_cost':5},
]
out=Path(__file__).parents[1]/'results/architecture_fit.csv'
with open(out,'w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('说明：这是教学用受控场景，不代表真实模型基准。')
