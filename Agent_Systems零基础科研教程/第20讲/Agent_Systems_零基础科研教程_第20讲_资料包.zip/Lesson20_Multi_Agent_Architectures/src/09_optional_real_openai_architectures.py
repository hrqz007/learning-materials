"""可选真实 API 实验。需要：pip install openai-agents，并设置 OPENAI_API_KEY。
演示当前 OpenAI Agents SDK 中两个核心多智能体编排模式：
1) Manager / agents-as-tools：Manager 保持控制权；
2) Handoff：active agent 转移给 specialist。
具体 API 可能随 SDK 版本变化，运行前请核对官方文档。
"""
from agents import Agent, Runner

researcher = Agent(name='Researcher', instructions='只负责给出研究要点。')
reviewer = Agent(name='Reviewer', instructions='只负责检查研究要点是否有明显缺口。')

manager = Agent(
    name='Manager',
    instructions='你负责最终回答。需要时调用专家。',
    tools=[
        researcher.as_tool(tool_name='research_expert', tool_description='研究子任务'),
        reviewer.as_tool(tool_name='review_expert', tool_description='审查子任务'),
    ],
)

triage = Agent(
    name='Triage',
    instructions='研究问题交给 Researcher；审查问题交给 Reviewer。',
    handoffs=[researcher, reviewer],
)

if __name__ == '__main__':
    r1 = Runner.run_sync(manager, '分析多智能体架构的两点差异。')
    print('manager final:', r1.final_output)
    r2 = Runner.run_sync(triage, '请研究 Manager-Worker 的特点。')
    print('handoff final agent:', r2.last_agent.name)
    print('handoff final:', r2.final_output)
