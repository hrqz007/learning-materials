from dataclasses import dataclass, asdict
from typing import List, Dict, Any
import json

@dataclass
class Message:
    step: int
    sender: str
    receiver: str
    kind: str
    content: str

class Trace:
    def __init__(self):
        self.messages: List[Message] = []
    def add(self, step, sender, receiver, kind, content):
        self.messages.append(Message(step, sender, receiver, kind, content))
    def dump_jsonl(self, path):
        with open(path, 'w', encoding='utf-8') as f:
            for m in self.messages:
                f.write(json.dumps(asdict(m), ensure_ascii=False) + '\n')
    @property
    def count(self): return len(self.messages)

class Agent:
    def __init__(self, name, role):
        self.name=name; self.role=role
    def work(self, task):
        return f"{self.name}完成[{task}]"

class ArchitectureMetrics:
    def __init__(self, architecture):
        self.architecture=architecture
        self.messages=0
        self.handoffs=0
        self.max_depth=0
        self.final_owner=''
        self.success=True
        self.notes=[]
    def to_dict(self): return self.__dict__.copy()
