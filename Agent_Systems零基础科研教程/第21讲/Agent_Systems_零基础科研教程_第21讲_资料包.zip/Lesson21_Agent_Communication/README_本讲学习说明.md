# Agent Systems 零基础科研教程 - 第21讲

主题：Agent Communication——多智能体之间到底怎样“说话”？

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立完成）
3. src/01~08 必做实验
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
- 01 Message Envelope
- 02 Point-to-Point vs Broadcast
- 03 Shared Context vs Blackboard
- 04 Information Loss Chain
- 05 Stale / Duplicate / Conflict
- 06 Communication Budget Ablation
- 07 Blackboard Coordination
- 08 Failure Decomposition

## 重要说明
实验04和06中的概率/信息截断是受控教学模拟，用于理解机制与验证实验管线，不代表任何真实 LLM、框架或公司产品的性能。

## 本讲最低闭环
能构造 Message、实现路由和共享状态、制造 stale/duplicate/routing 等通信故障，并用分层指标分析失败。
