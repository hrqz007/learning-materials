from comm_core import Message
import json
m = Message(sender="researcher", receiver="analyst", msg_type="finding",
            payload={"claim":"Tool description affects selection", "confidence":0.82}, version=3)
print(json.dumps(m.to_dict(), ensure_ascii=False, indent=2))
print("\n观察：message_id / sender / receiver / type / version / payload 都是系统可验证字段。")
