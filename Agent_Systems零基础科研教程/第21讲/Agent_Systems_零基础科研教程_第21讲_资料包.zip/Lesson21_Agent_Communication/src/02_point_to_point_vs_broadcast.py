from comm_core import Message, MessageBus
agents=["A","B","C","D"]
bus=MessageBus(agents)
print("=== Point-to-Point ===")
print(bus.send(Message("A","B","finding",{"x":1})))
print("B inbox:", len(bus.receive_all("B")))
print("C inbox:", len(bus.receive_all("C")))
print("\n=== Broadcast ===")
print(bus.send(Message("A","*","notice",{"task":"sync"})))
for a in ["B","C","D"]:
    print(a, "inbox:", len(bus.receive_all(a)))
