from comm_core import Blackboard
shared_context=[]
for agent in ["A","B","C","D"]:
    shared_context.append("Agent A found: score=0.84")
print("Shared Context copies:", len(shared_context))
print("Approx repeated chars:", sum(map(len, shared_context)))

bb=Blackboard()
bb.write_fact("score",0.84,"A",version=1)
print("Blackboard stored fact count:", len(bb.facts))
print("Blackboard read:", bb.read_fact("score"))
print("观察：Shared Context 常复制消息；Blackboard 只保存一个结构化共享事实。")
