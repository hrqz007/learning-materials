facts=[f"evidence_{i}" for i in range(1,13)]

def summarize(items, keep):
    return items[:keep]

stages=[("original",facts)]
current=facts
for name,keep in [("A_summary",8),("B_summary",5),("C_summary",3),("manager",3)]:
    current=summarize(current,keep)
    stages.append((name,current))
for name,items in stages:
    print(f"{name:10s}: {len(items)} items -> {items}")
print("Retention:", len(stages[-1][1])/len(facts))
print("注意：这是受控教学实验，用确定性截断模拟转述损失，不代表真实模型固定会丢失同样比例。")
