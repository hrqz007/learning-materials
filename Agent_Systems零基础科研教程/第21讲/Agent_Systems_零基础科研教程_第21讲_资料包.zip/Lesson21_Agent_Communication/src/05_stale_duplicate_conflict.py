from comm_core import Message, MessageBus
bus=MessageBus(["A","B"])
new=Message("A","B","plan",{"step":"use tool_v2"},version=2,message_id="m-new")
old=Message("A","B","plan",{"step":"use tool_v1"},version=1,message_id="m-old")
dup=Message("A","B","plan",{"step":"use tool_v2"},version=2,message_id="m-new")
print("new :", bus.send(new))
print("old :", bus.send(old))
print("dup :", bus.send(dup))
