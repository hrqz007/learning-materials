import random, csv
random.seed(21)
budgets=[0,1,2,4,8,16,32]
# 教学模拟：少量通信帮助协调；过多通信引入噪声/冲突。
base_prob={0:.58,1:.67,2:.76,4:.84,8:.86,16:.82,32:.71}
rows=[]
for b in budgets:
    n=4000
    succ=sum(random.random()<base_prob[b] for _ in range(n))/n
    rows.append((b,succ,b))
    print(f"budget={b:2d}  success={succ:.3f}  comm_cost={b}")
with open('../outputs/communication_budget.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['budget','success','comm_cost']); w.writerows(rows)
print("\n注意：概率参数为人为设定的受控教学模拟，不代表任何真实 LLM 或框架的性能。")
