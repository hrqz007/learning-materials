from comm_core import Blackboard
bb=Blackboard()
print(bb.write_fact("dataset", "D1", "Researcher", version=1))
print(bb.write_fact("metric", "accuracy", "Analyst", version=1))
print(bb.write_fact("dataset", "OLD", "Coder", version=0))  # stale write
print("dataset:", bb.read_fact("dataset"))
print("metric :", bb.read_fact("metric"))
print("history:", bb.history)
