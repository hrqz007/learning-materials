from comm_core import Message, MessageBus
bus=MessageBus(["A","B"], max_payload_chars=80)
cases=[
    Message("X","B","note",{"x":1},message_id="auth"),
    Message("A","Z","note",{"x":1},message_id="route"),
    Message("A","B","note",{"v":"ok"},version=2,message_id="fresh2"),
    Message("A","B","note",{"v":"old"},version=1,message_id="fresh1"),
    Message("A","B","note",{"v":"dup"},version=2,message_id="fresh2"),
    Message("A","B","note",{"text":"x"*200},message_id="large"),
]
# inject one schema violation by bypassing dataclass annotation
bad=Message("A","B","note",{"x":1},message_id="schema"); bad.payload="not-a-dict"; cases.insert(2,bad)
for i,m in enumerate(cases,1):
    r=bus.send(m); print(i, r['layer'], r['reason'] if not r['ok'] else 'ok')
print("\nFailure layers should be counted separately, not collapsed into one 'communication failed'.")
