# 可选：真实框架阅读/实验入口（需要自行安装对应 SDK 与 API Key）
# 目的：观察不同多智能体编排模式对“通信语义”的影响。
# OpenAI Agents SDK 当前文档区分：
# 1) Agent.as_tool(): specialist receives generated input; manager remains owner.
# 2) handoff(): specialist receives conversation history and becomes active agent.
#
# 本课不把 SDK API 当作核心知识，先用本地 MessageBus/Blackboard 理解机制。
# 官方文档：
# https://openai.github.io/openai-agents-python/multi_agent/
# https://openai.github.io/openai-agents-python/handoffs/
