from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional
import time, uuid

@dataclass
class Message:
    sender: str
    receiver: str
    msg_type: str
    payload: Dict[str, Any]
    version: int = 1
    message_id: str = ""
    timestamp: float = 0.0

    def __post_init__(self):
        if not self.message_id:
            self.message_id = str(uuid.uuid4())[:8]
        if not self.timestamp:
            self.timestamp = time.time()

    def to_dict(self):
        return asdict(self)

class MessageBus:
    def __init__(self, allowed_agents=None, max_payload_chars=4000):
        self.allowed_agents = set(allowed_agents or [])
        self.max_payload_chars = max_payload_chars
        self.inboxes: Dict[str, List[Message]] = {a: [] for a in self.allowed_agents}
        self.seen_ids = set()
        self.latest_version: Dict[str, int] = {}
        self.trace: List[Dict[str, Any]] = []

    def _fail(self, layer, reason, msg=None):
        item = {"ok": False, "layer": layer, "reason": reason}
        if msg: item["message"] = msg.to_dict()
        self.trace.append(item)
        return item

    def send(self, msg: Message):
        if msg.sender not in self.allowed_agents:
            return self._fail("AUTHORIZATION", "unknown_sender", msg)
        if msg.receiver not in self.allowed_agents and msg.receiver != "*":
            return self._fail("ROUTING", "unknown_receiver", msg)
        if not isinstance(msg.payload, dict):
            return self._fail("SCHEMA", "payload_must_be_object", msg)
        if len(str(msg.payload)) > self.max_payload_chars:
            return self._fail("BUDGET", "payload_too_large", msg)
        if msg.message_id in self.seen_ids:
            return self._fail("DUPLICATION", "duplicate_message", msg)
        key = f"{msg.sender}:{msg.msg_type}"
        if msg.version < self.latest_version.get(key, 0):
            return self._fail("FRESHNESS", "stale_version", msg)
        self.latest_version[key] = max(self.latest_version.get(key, 0), msg.version)
        self.seen_ids.add(msg.message_id)
        targets = self.allowed_agents if msg.receiver == "*" else [msg.receiver]
        for target in targets:
            if target != msg.sender:
                self.inboxes.setdefault(target, []).append(msg)
        item = {"ok": True, "layer": "DELIVERY", "targets": sorted(list(targets)), "message": msg.to_dict()}
        self.trace.append(item)
        return item

    def receive_all(self, agent):
        items = list(self.inboxes.get(agent, []))
        self.inboxes[agent] = []
        return items

class Blackboard:
    def __init__(self):
        self.facts: Dict[str, Dict[str, Any]] = {}
        self.artifacts: Dict[str, Any] = {}
        self.history: List[Dict[str, Any]] = []

    def write_fact(self, key, value, author, version=1):
        old = self.facts.get(key)
        if old and version < old["version"]:
            return {"ok": False, "reason": "stale_write"}
        self.facts[key] = {"value": value, "author": author, "version": version}
        self.history.append({"op":"write_fact","key":key,"author":author,"version":version})
        return {"ok": True}

    def read_fact(self, key):
        return self.facts.get(key)
