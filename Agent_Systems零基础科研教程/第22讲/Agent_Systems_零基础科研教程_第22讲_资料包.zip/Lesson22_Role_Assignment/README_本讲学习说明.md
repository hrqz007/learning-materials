# Agent Systems 零基础科研教程 - 第22讲

主题：Role Assignment——多智能体为什么要分工？

## 推荐学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立完成）
3. src/01~08 必做实验
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 必做实验
- 01 Role Label vs Capability
- 02 Generalist vs Specialist
- 03 Fixed vs Dynamic Assignment
- 04 Capability-Task Matching
- 05 Role Overlap / Redundancy
- 06 Role Collapse
- 07 Specialist Failure / Reassignment
- 08 Role Granularity Ablation

## 重要说明
实验02、03、07、08的概率是人为设定的受控教学模拟，用于理解机制与实验设计，不代表任何真实 LLM、框架或公司的性能。

## 本讲最低闭环
能够区分角色名和真实能力，写一个 capability-aware router，制造 role mismatch / overlap / collapse，并用成功率、成本、Unique Contribution 等指标分析。
