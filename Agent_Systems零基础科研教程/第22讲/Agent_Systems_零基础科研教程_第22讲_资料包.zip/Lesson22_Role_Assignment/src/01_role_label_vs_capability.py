from role_core import AgentProfile, Task, RoleRouter
agents=[
    AgentProfile('A','Search Researcher',{'search':0.45,'code':0.90}),  # 名字像 researcher，但其实更擅长 code
    AgentProfile('B','Generalist',{'search':0.88,'code':0.62}),
]
r=RoleRouter(agents); task=Task('t1','search')
by_label=r.choose_by_label(task); by_cap=r.choose_by_capability(task)
print('label-based:', by_label.name, by_label.role, 'score=',by_label.score('search'))
print('capability-based:', by_cap.name, by_cap.role, 'score=',by_cap.score('search'))
print('观察：Role Name 只是描述；能力信息与真实轨迹才决定是否匹配。')
