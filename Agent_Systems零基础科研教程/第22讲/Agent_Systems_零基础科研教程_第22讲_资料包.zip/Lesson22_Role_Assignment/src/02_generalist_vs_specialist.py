import random, csv
random.seed(22)
tasks=['search','code','stats']*1200
p_general={'search':.76,'code':.73,'stats':.71}
p_spec={'search':.93,'code':.94,'stats':.92}
# specialists are routed to matching task; unmatched specialist would be poor, so here measure matched condition.
for name,ps in [('generalist',p_general),('matched_specialists',p_spec)]:
    succ=0
    for t in tasks: succ += random.random()<ps[t]
    print(name, 'success=', round(succ/len(tasks),3), 'calls=',len(tasks))
print('注意：概率为教学模拟，不代表真实 LLM 性能。')
