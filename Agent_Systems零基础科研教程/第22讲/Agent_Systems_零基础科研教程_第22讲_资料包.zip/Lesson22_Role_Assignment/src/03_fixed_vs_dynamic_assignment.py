import random
random.seed(22)
# 训练期/设计期假设：任务以 search 为主；上线后 code 占比升高（distribution shift）
tasks=['search']*800+['code']*1400+['stats']*800
agents={
 'A':{'search':.92,'code':.48,'stats':.52},
 'B':{'search':.54,'code':.93,'stats':.55},
 'C':{'search':.50,'code':.58,'stats':.91},
}
fixed={'search':'A','code':'A','stats':'A'}  # 错误地长期固定给 A
def dynamic(t): return max(agents,key=lambda a:agents[a][t])
for policy in ['fixed','dynamic']:
    s=0
    for t in tasks:
        a=fixed[t] if policy=='fixed' else dynamic(t)
        s += random.random()<agents[a][t]
    print(policy, 'success=',round(s/len(tasks),3))
print('观察：任务分布变化时，动态 capability-aware assignment 能减少 role-task mismatch。')
