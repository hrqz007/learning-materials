import itertools
agents=['Researcher','Coder','Statistician','Generalist']
tasks=['search','code','stats','mixed']
score={
 'search':[.92,.40,.48,.63], 'code':[.38,.95,.55,.62],
 'stats':[.50,.52,.91,.70], 'mixed':[.72,.70,.68,.78]
}
def total(perm):
    return sum(score[t][agents.index(a)] for t,a in zip(tasks,perm))
best=max(itertools.permutations(agents),key=total)
naive=('Generalist','Researcher','Coder','Statistician')
print('naive assignment:', list(zip(tasks,naive)), 'total=',round(total(naive),2))
print('best assignment :', list(zip(tasks,best)), 'total=',round(total(best),2))
print('观察：Role Assignment 可以被形式化为 task-agent matching，而不只是写几个角色提示词。')
