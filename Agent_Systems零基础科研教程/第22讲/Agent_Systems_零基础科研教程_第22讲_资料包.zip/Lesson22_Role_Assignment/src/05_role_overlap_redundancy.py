tasks={'A':{'paper1','paper2','paper3','summary'},
       'B_overlap':{'paper1','paper2','paper3','summary'},
       'Verifier_complement':{'check_claims','check_citations','edge_cases'}}
def metrics(x,y):
    union=x|y; overlap=x&y
    return len(union), len(overlap)/max(1,len(x)+len(y))
print('two similar researchers:', metrics(tasks['A'],tasks['B_overlap']))
print('researcher + verifier :', metrics(tasks['A'],tasks['Verifier_complement']))
print('Unique contribution rises when roles are complementary rather than merely renamed duplicates.')
