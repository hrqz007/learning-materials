# 用行为标签集合的 Jaccard 相似度模拟“不同角色逐渐做同样的事”。
rounds=[
 ({'search','cite'},{'test','verify'}),
 ({'search','cite','summarize'},{'verify','summarize','search'}),
 ({'search','cite','summarize','draft'},{'verify','summarize','search','draft'}),
 ({'search','summarize','draft','review'},{'search','summarize','draft','review'}),
]
for i,(a,b) in enumerate(rounds,1):
    j=len(a&b)/len(a|b)
    print('round',i,'behavior_similarity=',round(j,3),'A=',sorted(a),'B=',sorted(b))
print('Role Collapse：角色名仍不同，但行为轨迹越来越相似。')
