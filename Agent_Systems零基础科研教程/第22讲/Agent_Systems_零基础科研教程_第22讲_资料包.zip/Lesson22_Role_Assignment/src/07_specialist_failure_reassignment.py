import random
from role_core import AgentProfile, Task, RoleRouter
random.seed(22)
agents=[
 AgentProfile('Coder','code specialist',{'code':.94},available=False),
 AgentProfile('Generalist','generalist',{'code':.72},available=True),
 AgentProfile('Researcher','search specialist',{'code':.35},available=True),
]
r=RoleRouter(agents); task=Task('fix','code')
rank=r.ranked(task)
print('available ranking:',[(a.name,a.score('code')) for a in rank])
chosen=rank[0]
trials=3000; succ=sum(random.random()<chosen.score('code') for _ in range(trials))/trials
print('reassigned_to=',chosen.name,'recovery_success≈',round(succ,3))
print('如果没有 fallback/reassignment policy，专才不可用会直接变成系统级失败。')
