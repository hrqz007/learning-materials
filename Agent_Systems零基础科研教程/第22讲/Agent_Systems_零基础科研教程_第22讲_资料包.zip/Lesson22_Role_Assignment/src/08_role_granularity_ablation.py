import random,csv
random.seed(22)
configs={1:.71,2:.80,4:.86,8:.83,12:.75}
rows=[]
for n,p in configs.items():
    runs=5000; succ=sum(random.random()<p for _ in range(runs))/runs
    cost=n
    rows.append((n,succ,cost))
    print(f'roles={n:2d} success={succ:.3f} coordination_cost={cost}')
with open('../outputs/role_granularity.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['roles','success','coordination_cost']); w.writerows(rows)
print('注意：这是人为构造的教学模拟，用于展示“专精收益 vs 协调成本”，不代表真实模型。')
