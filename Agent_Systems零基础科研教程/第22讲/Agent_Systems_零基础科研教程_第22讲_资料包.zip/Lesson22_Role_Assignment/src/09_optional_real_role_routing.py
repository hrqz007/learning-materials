# 可选真实框架实验入口（需要 openai-agents 与 API Key）
# 目标：观察角色描述如何参与 routing / delegation，而不是把角色名当作能力证明。
#
# OpenAI Agents SDK 当前建议：
# - specialist agents 应有明确、窄化的 instructions / tools；
# - manager 可以把 specialist agent 暴露为 Agent.as_tool()；
# - handoff_description 可帮助 routing agent 判断何时转交给 specialist。
#
# 伪代码：
# from agents import Agent, Runner
# research = Agent(name='Researcher', instructions='Only research evidence...', handoff_description='For evidence search tasks')
# coding = Agent(name='Coder', instructions='Only solve code/debug tasks...', handoff_description='For code tasks')
# triage = Agent(name='Triage', handoffs=[research, coding])
# result = Runner.run_sync(triage, 'Debug this Python error...')
# print(result.last_agent.name)
#
# Official docs:
# https://openai.github.io/openai-agents-python/multi_agent/
# https://openai.github.io/openai-agents-python/handoffs/
