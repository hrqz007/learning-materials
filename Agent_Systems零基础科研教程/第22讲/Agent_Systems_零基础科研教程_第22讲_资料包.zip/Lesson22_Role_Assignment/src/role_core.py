from dataclasses import dataclass, field
from typing import Dict, List, Optional

@dataclass
class AgentProfile:
    name: str
    role: str
    capabilities: Dict[str, float]
    available: bool = True
    cost: float = 1.0

    def score(self, task_type: str) -> float:
        return float(self.capabilities.get(task_type, 0.0))

@dataclass
class Task:
    task_id: str
    task_type: str
    difficulty: float = 0.5

class RoleRouter:
    def __init__(self, agents: List[AgentProfile]):
        self.agents = agents

    def choose_by_label(self, task: Task) -> Optional[AgentProfile]:
        # 教学反例：只看 role 名字关键词，不看真实能力。
        key = task.task_type.lower()
        for a in self.agents:
            if a.available and key in a.role.lower():
                return a
        return next((a for a in self.agents if a.available), None)

    def choose_by_capability(self, task: Task) -> Optional[AgentProfile]:
        candidates = [a for a in self.agents if a.available]
        return max(candidates, key=lambda a: (a.score(task.task_type), -a.cost), default=None)

    def ranked(self, task: Task):
        candidates = [a for a in self.agents if a.available]
        return sorted(candidates, key=lambda a: (a.score(task.task_type), -a.cost), reverse=True)
