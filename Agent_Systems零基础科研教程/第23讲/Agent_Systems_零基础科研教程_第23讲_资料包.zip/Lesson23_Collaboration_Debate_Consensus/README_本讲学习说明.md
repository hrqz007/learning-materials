# Agent Systems 零基础科研教程 - 第23讲

主题：协作、竞争、讨论与共识（Debate / Voting / Consensus / Negotiation）

## 学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立）
3. 运行 src/01-08 必做实验
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 运行
```bash
cd src
python 02_majority_vote_correlation.py
```

## 重要说明
- 所有概率型必做实验都是**受控教学模拟**，不是任何真实大模型的性能。
- 真实科研必须使用真实任务、真实模型、重复实验和 compute-matched baseline。
- 本讲不要求暴露模型私有 chain-of-thought；应记录可研究的 answer / evidence / action / message / judge decision / trace。

## 最低闭环
独立作答 -> 交互协议 -> 聚合 -> ground truth/verifier -> 过程指标 -> 成本指标。
