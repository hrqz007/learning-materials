import random
random.seed(23)
N=5000
base=.72
# independent: use one agent answer; discussion: if at least one other agent has valid counterevidence, 35% of initial errors are corrected, but 5% correct answers are talked out of correctness.
ind=0; disc=0
for _ in range(N):
    correct=random.random()<base
    ind += correct
    if not correct and random.random()<.35: correct=True
    elif correct and random.random()<.05: correct=False
    disc += correct
print('independent success=',round(ind/N,3))
print('discussion success =',round(disc/N,3))
print('注意：这是受控教学模拟，不代表真实模型。')
