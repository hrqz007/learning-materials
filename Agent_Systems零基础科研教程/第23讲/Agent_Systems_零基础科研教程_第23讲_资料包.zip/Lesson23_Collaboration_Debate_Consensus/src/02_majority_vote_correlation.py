import random, csv
random.seed(23)
N=8000
qs=[0,.1,.2,.3,.4,.5]
rows=[]
for q in qs:
    succ=0
    for _ in range(N):
        shared_wrong=random.random()<q
        votes=[]
        for i in range(3):
            if shared_wrong: votes.append(False)
            else: votes.append(random.random()<.78)
        succ += sum(votes)>=2
    rate=succ/N; rows.append((q,rate)); print('q=',q,'majority_success=',round(rate,3))
with open('../outputs/correlation_metrics.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['shared_error_q','majority_success']); w.writerows(rows)
