from collective_core import Opinion, majority_vote, evidence_aggregate
ops=[Opinion('A','X',.82,.35),Opinion('B','X',.78,.30),Opinion('C','Y',.66,.95)]
print('simple majority:',majority_vote(ops),'(wrong in this scenario; truth=Y)')
print('evidence-aware debate result:',evidence_aggregate(ops),'(correct)')
print('观察：讨论收益若存在，关键可能来自“新证据能改变聚合结果”，不是聊天本身。')
