import random
random.seed(23)
N=6000
for rounds in [0,1,2,3,4]:
    survived=0
    for _ in range(N):
        # one correct minority agent; each round has 25% chance to conform to wrong majority unless protected by independent-evidence rule
        ok=True
        for _ in range(rounds):
            if ok and random.random()<.25: ok=False
        survived += ok
    print('rounds=',rounds,'correct-minority-survival=',round(survived/N,3))
