import random
random.seed(23)
N=7000
truthaware=0; persuasion=0
for _ in range(N):
    # correct side: evidence quality high, rhetoric moderate; wrong side: evidence weak, rhetoric strong
    evidence_correct=random.gauss(.85,.08); evidence_wrong=random.gauss(.42,.10)
    rhetoric_correct=random.gauss(.55,.12); rhetoric_wrong=random.gauss(.82,.08)
    truthaware += evidence_correct>=evidence_wrong
    score_c=.35*evidence_correct+.65*rhetoric_correct
    score_w=.35*evidence_wrong+.65*rhetoric_wrong
    persuasion += score_c>=score_w
print('truth-aware verifier accuracy=',round(truthaware/N,3))
print('persuasion-biased judge accuracy=',round(persuasion/N,3))
