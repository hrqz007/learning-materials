import random, csv
random.seed(23)
N=4000
rows=[]
for r in range(7):
    # benefit saturates; after 3 rounds conformity/noise slowly grows
    p=.72 + .15*(1-math.exp(-.9*r)) if False else None
    base=[.72,.79,.83,.85,.85,.83,.80][r]
    succ=sum(random.random()<base for _ in range(N))/N
    cost=3*(r+1)
    rows.append((r,succ,cost)); print('round=',r,'success=',round(succ,3),'cost=',cost)
with open('../outputs/rounds_metrics.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['rounds','success','relative_cost']); w.writerows(rows)
print('停止策略示意：若连续两轮没有新证据/结论不变，可考虑停止。')
