requests={'A':60,'B':50,'C':40}; budget=100
print('raw requests=',requests,'sum=',sum(requests.values()),'budget=',budget)
# weighted negotiation: protect minimum 20 then distribute remainder proportionally to excess request
minimum=20; alloc={k:minimum for k in requests}; rem=budget-minimum*len(requests)
excess={k:max(0,v-minimum) for k,v in requests.items()}; total=sum(excess.values())
for k in alloc: alloc[k]+=round(rem*excess[k]/total)
# fix rounding
while sum(alloc.values())>budget: alloc[max(alloc,key=alloc.get)]-=1
while sum(alloc.values())<budget: alloc[min(alloc,key=alloc.get)]+=1
print('negotiated allocation=',alloc,'sum=',sum(alloc.values()))
print('feasible=',sum(alloc.values())<=budget)
