import random, csv
random.seed(23)
budgets=[0,2,4,8,16,32]
settings={'homogeneous':[.70,.74,.77,.78,.77,.74], 'diverse':[.70,.78,.84,.87,.86,.82]}
N=4500; rows=[]
for team,ps in settings.items():
    for b,p in zip(budgets,ps):
        succ=sum(random.random()<p for _ in range(N))/N
        rows.append((team,b,succ)); print(team,'budget=',b,'success=',round(succ,3))
with open('../outputs/diversity_budget.csv','w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['team','communication_budget','success']); w.writerows(rows)
print('注意：概率为教学模拟。真实结论需要真实模型、任务和重复实验。')
