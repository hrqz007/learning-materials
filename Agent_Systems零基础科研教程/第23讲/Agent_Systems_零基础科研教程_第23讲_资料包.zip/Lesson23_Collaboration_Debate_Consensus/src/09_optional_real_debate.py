"""可选真实模型实验骨架。
需要你自行配置 API Key；默认不运行。
目标：让三个独立模型实例先各自回答，再只交换“可公开的论点摘要/证据”，最后由一个 verifier 按预先定义的 rubric 聚合。
科研注意：记录每个 agent 的初始答案，避免只保留最终共识；同时记录 token/cost/rounds。
"""
import os
if __name__=='__main__':
    if not os.getenv('OPENAI_API_KEY'):
        print('未检测到 OPENAI_API_KEY；这是可选实验，跳过。')
    else:
        print('请按照 README 中的真实实验扩展说明接入当前 Responses API。')
