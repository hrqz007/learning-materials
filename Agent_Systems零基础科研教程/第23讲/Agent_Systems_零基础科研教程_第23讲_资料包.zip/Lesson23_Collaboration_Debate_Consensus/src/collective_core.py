from dataclasses import dataclass
from typing import List
import random

@dataclass
class Opinion:
    agent: str
    answer: str
    confidence: float
    evidence_strength: float


def majority_vote(opinions: List[Opinion]):
    counts={}
    for o in opinions: counts[o.answer]=counts.get(o.answer,0)+1
    return max(counts, key=lambda k:(counts[k], sum(o.confidence for o in opinions if o.answer==k)))

def evidence_aggregate(opinions: List[Opinion]):
    scores={}
    for o in opinions: scores[o.answer]=scores.get(o.answer,0.0)+o.evidence_strength
    return max(scores,key=scores.get)
