# Agent Systems 零基础科研教程 - 第24讲

主题：第一个完整 Multi-Agent 实验

## 本讲系统
Manager -> Researcher -> Analyst -> Reviewer -> Manager

共享 Runtime：MessageBus + ArtifactStore + TraceLogger

## 建议学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立）
3. 运行 src/01-08
4. 打开 outputs/01_team_trace.jsonl 和 artifacts/atlas-001_evidence.json
5. 03_实验指导书.docx
6. 04_实验设计书.docx
7. 06_练习题答案.docx
8. 07_术语速查表.docx

## 运行
```bash
cd src
python 01_complete_multi_agent_run.py
python 02_trace_replay.py
```

## 重要说明
- 01-05 使用确定性教学 Runtime，重点学习系统结构，不评价真实模型能力。
- 06、08 的概率是受控教学模拟，不代表任何真实 LLM。
- 09_optional_real_openai_agents.py 是扩展入口，不默认运行。
- 真正科研必须保存 trace、固定任务集、重复实验、报告 cost，并加入 compute-matched baseline。

## 当前官方工程参照
- OpenAI Agents SDK: manager-style agents-as-tools / handoffs / tracing
- Anthropic Research: orchestrator-worker, parallel subagents, external artifacts, coordination/evaluation/reliability challenges
