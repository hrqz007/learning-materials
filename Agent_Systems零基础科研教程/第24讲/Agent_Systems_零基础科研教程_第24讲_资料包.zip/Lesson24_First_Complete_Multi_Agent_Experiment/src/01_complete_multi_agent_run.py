from pathlib import Path
import json
from multi_agent_core import run_team
ROOT=Path(__file__).resolve().parents[1]
task=json.loads((ROOT/'data/task.json').read_text(encoding='utf-8'))
packet=json.loads((ROOT/'data/research_packet.json').read_text(encoding='utf-8'))
final, events, artifact=run_team(task,packet,ROOT/'artifacts',ROOT/'outputs/01_team_trace.jsonl')
print('final=',json.dumps(final,ensure_ascii=False))
print('trace_events=',len(events))
print('artifact_ref=',artifact)
print('expected answer=Gamma')
