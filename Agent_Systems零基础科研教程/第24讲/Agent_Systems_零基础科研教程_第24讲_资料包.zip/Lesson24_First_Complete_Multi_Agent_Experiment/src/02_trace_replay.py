from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
trace=ROOT/'outputs/01_team_trace.jsonl'
if not trace.exists():
    import subprocess,sys
    subprocess.run([sys.executable,'01_complete_multi_agent_run.py'],cwd=ROOT/'src',check=True)
rows=[json.loads(x) for x in trace.read_text(encoding='utf-8').splitlines() if x.strip()]
print('REPLAY')
for i,r in enumerate(rows,1):
    if r['event']=='message': print(i,'MESSAGE',r['sender'],'->',r['receiver'],r['kind'])
    elif r['event'] in {'analysis','review','revision','agent_failure','artifact_write','run_end'}: print(i,r['event'].upper(),json.dumps({k:v for k,v in r.items() if k not in {'ts','event'}},ensure_ascii=False))
print('event_count=',len(rows))
print('final_event=',rows[-1]['event'])
