from pathlib import Path
import json
from multi_agent_core import run_team, Analyst
ROOT=Path(__file__).resolve().parents[1]
task=json.loads((ROOT/'data/task.json').read_text(encoding='utf-8')); packet=json.loads((ROOT/'data/research_packet.json').read_text(encoding='utf-8'))
final,events,_=run_team(task,packet,ROOT/'artifacts',ROOT/'outputs/03_revision_trace.jsonl',analyst=Analyst(inject_bug=True),max_revisions=2)
reviews=[e for e in events if e['event']=='review']; revisions=[e for e in events if e['event']=='revision']
print('first_review=',json.dumps(reviews[0]['review'],ensure_ascii=False))
print('revision_count=',len(revisions))
print('final=',json.dumps(final,ensure_ascii=False))
