from pathlib import Path
import json
from multi_agent_core import run_team, Researcher
ROOT=Path(__file__).resolve().parents[1]
task=json.loads((ROOT/'data/task.json').read_text(encoding='utf-8')); packet=json.loads((ROOT/'data/research_packet.json').read_text(encoding='utf-8'))
final,events,_=run_team(task,packet,ROOT/'artifacts',ROOT/'outputs/04_reassignment_trace.jsonl',researcher=Researcher('Researcher-A',fail=True),backup_researcher=Researcher('Researcher-B'))
fail=[e for e in events if e['event']=='agent_failure']
msgs=[e for e in events if e['event']=='message' and e['kind']=='reassign']
print('failure=',fail[0]['error'] if fail else None)
print('reassignment_messages=',len(msgs))
print('final=',json.dumps(final,ensure_ascii=False))
