from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
packet=json.loads((ROOT/'data/research_packet.json').read_text(encoding='utf-8'))
summary='Gamma 看起来是最优方案。'
summary_has_constraints=all(k in summary for k in ['0.93','120','45'])
artifact=ROOT/'artifacts/05_evidence_packet.json'; artifact.parent.mkdir(exist_ok=True); artifact.write_text(json.dumps(packet,ensure_ascii=False,indent=2),encoding='utf-8')
full=json.loads(artifact.read_text(encoding='utf-8'))
print('summary=',summary)
print('summary_has_all_constraints=',summary_has_constraints)
print('artifact_constraints=',full['constraints'])
print('artifact_candidate_count=',len(full['candidates']))
print('lesson: lightweight message + artifact_ref can preserve raw evidence better than repeated summaries.')
