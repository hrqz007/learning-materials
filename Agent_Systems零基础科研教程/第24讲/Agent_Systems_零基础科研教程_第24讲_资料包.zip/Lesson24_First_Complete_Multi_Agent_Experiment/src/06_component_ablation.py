import random,csv
from pathlib import Path
random.seed(24); N=5000
# Controlled teaching probabilities, NOT real-model performance.
settings={'full_team':(.93,5.1),'no_reviewer':(.72,3.7),'no_analyst':(.80,3.4),'manager_only':(.61,1.0)}
rows=[]
for name,(p,calls) in settings.items():
    succ=sum(random.random()<p for _ in range(N))/N
    rows.append((name,succ,calls)); print(name,'success=',round(succ,3),'mean_agent_calls=',calls)
out=Path(__file__).resolve().parents[1]/'outputs/component_ablation.csv'
with out.open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['setting','success','mean_agent_calls']); w.writerows(rows)
print('注意：成功率是受控教学模拟，不代表真实LLM。')
