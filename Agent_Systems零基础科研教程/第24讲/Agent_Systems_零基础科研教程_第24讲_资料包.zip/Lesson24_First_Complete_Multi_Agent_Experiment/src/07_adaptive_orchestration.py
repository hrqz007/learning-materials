tasks=[
 {'id':'lookup','type':'direct_lookup'},
 {'id':'constraint','type':'constraint_selection'},
 {'id':'contradiction','type':'contradictory_evidence'}]
fixed_calls=0; adaptive_calls=0
for t in tasks:
    fixed=['Researcher','Analyst','Reviewer']; fixed_calls+=len(fixed)
    if t['type']=='direct_lookup': path=['Researcher']
    elif t['type']=='constraint_selection': path=['Researcher','Analyst','Reviewer']
    else: path=['Researcher-A','Researcher-B','Reviewer']
    adaptive_calls+=len(path)
    print(t['id'],'fixed=',fixed,'adaptive=',path)
print('fixed_total_calls=',fixed_calls)
print('adaptive_total_calls=',adaptive_calls)
print('observation: adaptive orchestration can reduce unnecessary roles while preserving task-specific checks.')
