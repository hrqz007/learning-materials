import random,csv
from pathlib import Path
random.seed(24)
N=3000
layers={'retrieval':.14,'analysis':.18,'review':.09,'orchestration':.11,'state_trace':.05}
rows=[]
for layer,p in layers.items():
    failures=sum(random.random()<p for _ in range(N))
    rows.append((layer,failures,failures/N)); print(layer,'failures=',failures,'rate=',round(failures/N,3))
out=Path(__file__).resolve().parents[1]/'outputs/failure_taxonomy.csv'
with out.open('w',newline='',encoding='utf-8') as f:
    w=csv.writer(f); w.writerow(['layer','failures','rate']); w.writerows(rows)
print('注意：故障概率为教学注入，用来学习failure decomposition。')
