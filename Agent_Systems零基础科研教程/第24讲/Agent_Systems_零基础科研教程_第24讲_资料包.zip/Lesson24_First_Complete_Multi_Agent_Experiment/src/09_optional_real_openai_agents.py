"""可选真实框架示例，不默认运行。
截至 2026-09，OpenAI Agents SDK 的 manager-style 模式可用 Agent.as_tool()：
中央 Manager 保持最终回答控制权，调用 specialist agents 完成有界子任务。
安装和 API Key 请按当前官方文档操作。
"""
import os
if __name__=='__main__':
    if not os.getenv('OPENAI_API_KEY'):
        print('未检测到 OPENAI_API_KEY；可选实验跳过。')
    else:
        print('参考 README：用 Researcher/Analyst/Reviewer 作为 manager 的 agent-tools，并开启 tracing/evals。')
