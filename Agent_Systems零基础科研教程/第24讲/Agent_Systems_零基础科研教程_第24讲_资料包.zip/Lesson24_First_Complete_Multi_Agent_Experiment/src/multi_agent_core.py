from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Any, Dict, List, Optional
import json, time, uuid

@dataclass
class Message:
    message_id: str
    sender: str
    receiver: str
    kind: str
    payload: Dict[str, Any]
    ts: float

class TraceLogger:
    def __init__(self, path: Optional[str] = None):
        self.events: List[Dict[str, Any]] = []
        self.path = Path(path) if path else None
        if self.path:
            self.path.parent.mkdir(parents=True, exist_ok=True)
            self.path.write_text('', encoding='utf-8')
    def log(self, event: str, **data):
        row = {'event': event, 'ts': round(time.time(), 6), **data}
        self.events.append(row)
        if self.path:
            with self.path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(row, ensure_ascii=False) + '\n')
        return row

class MessageBus:
    def __init__(self, trace: TraceLogger): self.trace=trace
    def send(self, sender, receiver, kind, payload):
        msg=Message(str(uuid.uuid4())[:8],sender,receiver,kind,payload,time.time())
        self.trace.log('message', **asdict(msg)); return msg

class ArtifactStore:
    def __init__(self, root):
        self.root=Path(root); self.root.mkdir(parents=True,exist_ok=True)
    def write_json(self,name,obj):
        p=self.root/name; p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8'); return str(p)
    def read_json(self,path): return json.loads(Path(path).read_text(encoding='utf-8'))

class Researcher:
    def __init__(self,name='Researcher', fail=False): self.name=name; self.fail=fail
    def run(self, task, packet):
        if self.fail: raise TimeoutError(f'{self.name} timeout')
        return {'task_id':task['task_id'],'evidence':packet['candidates'],'constraints':packet['constraints'],'sources':packet['sources']}

class Analyst:
    def __init__(self,name='Analyst', inject_bug=False): self.name=name; self.inject_bug=inject_bug
    def run(self,evidence):
        c=evidence['constraints']; valid=[]
        for x in evidence['evidence']:
            ok=(x['reliability']>=c['min_reliability'] and x['latency_ms']<=c['max_latency_ms'] and x['cost']<=c['max_cost'])
            if ok: valid.append(x)
        valid=sorted(valid,key=lambda x:(-x['reliability'],x['cost'],x['latency_ms']))
        choice=valid[0]['name'] if valid else None
        if self.inject_bug and evidence['evidence']:
            choice=evidence['evidence'][1]['name']  # intentionally bad on teaching packet
        return {'choice':choice,'valid_candidates':[x['name'] for x in valid],'reason':'满足约束后按 reliability 优先、cost/latency 次级排序'}

class Reviewer:
    def __init__(self,name='Reviewer'): self.name=name
    def run(self,draft,evidence):
        by_name={x['name']:x for x in evidence['evidence']}; c=evidence['constraints']; choice=draft.get('choice')
        if choice not in by_name: return {'approved':False,'reason':'choice_missing'}
        x=by_name[choice]
        checks={
          'reliability':x['reliability']>=c['min_reliability'],
          'latency':x['latency_ms']<=c['max_latency_ms'],
          'cost':x['cost']<=c['max_cost'],
        }
        return {'approved':all(checks.values()),'checks':checks,'reason':'all_constraints_pass' if all(checks.values()) else 'constraint_violation'}

class Manager:
    def __init__(self,name='Manager'): self.name=name
    def final(self,task,draft,review):
        return {'task_id':task['task_id'],'status':'completed' if review.get('approved') else 'rejected','answer':draft.get('choice'),'review':review}

def run_team(task, packet, artifact_root, trace_path=None, researcher=None, backup_researcher=None, analyst=None, reviewer=None, max_revisions=2):
    trace=TraceLogger(trace_path); bus=MessageBus(trace); store=ArtifactStore(artifact_root)
    manager=Manager(); researcher=researcher or Researcher(); analyst=analyst or Analyst(); reviewer=reviewer or Reviewer()
    trace.log('run_start',task_id=task['task_id'],goal=task['goal'])
    bus.send('Manager',researcher.name,'delegate',{'task':'collect evidence'})
    try:
        evidence=researcher.run(task,packet)
    except Exception as e:
        trace.log('agent_failure',agent=researcher.name,error=type(e).__name__,detail=str(e))
        if not backup_researcher: raise
        bus.send('Manager',backup_researcher.name,'reassign',{'reason':type(e).__name__})
        evidence=backup_researcher.run(task,packet); researcher=backup_researcher
    artifact_ref=store.write_json(f"{task['task_id']}_evidence.json",evidence)
    trace.log('artifact_write',agent=researcher.name,artifact_ref=artifact_ref)
    bus.send(researcher.name,'Manager','result',{'artifact_ref':artifact_ref,'evidence_count':len(evidence['evidence'])})
    bus.send('Manager',analyst.name,'delegate',{'artifact_ref':artifact_ref})
    draft=analyst.run(evidence); trace.log('analysis',agent=analyst.name,draft=draft)
    for revision in range(max_revisions+1):
        bus.send(analyst.name,reviewer.name,'review_request',{'draft':draft,'artifact_ref':artifact_ref})
        review=reviewer.run(draft,evidence); trace.log('review',agent=reviewer.name,revision=revision,review=review)
        if review.get('approved'):
            bus.send(reviewer.name,'Manager','approve',{'draft':draft,'review':review}); break
        if revision>=max_revisions:
            bus.send(reviewer.name,'Manager','reject_final',{'draft':draft,'review':review}); break
        bus.send(reviewer.name,'Manager','reject',{'reason':review.get('reason')})
        bus.send('Manager',analyst.name,'revise',{'review':review,'artifact_ref':artifact_ref})
        analyst.inject_bug=False
        draft=analyst.run(evidence); trace.log('revision',agent=analyst.name,revision=revision+1,draft=draft)
    final=manager.final(task,draft,review); trace.log('run_end',final=final)
    return final, trace.events, artifact_ref
