# Agent Systems 零基础科研教程 - 第25讲

主题：Agent Harness

## 核心结构
Model + Runtime + Context + Tools + Sandbox + Permission + State + Checkpoint + Trace + Recovery + Orchestration

## 建议学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立）
3. 运行 src/01-08
4. 打开 outputs/01_trace.jsonl 与 checkpoint 文件
5. 03_实验指导书.docx
6. 04_实验设计书.docx
7. 06_练习题答案.docx
8. 07_术语速查表.docx

## 运行
```bash
cd src
python 01_full_harness_run.py
python 04_checkpoint_resume.py
python 05_trace_replay.py
```

## 重要说明
- 01-06 是本地确定性教学 Runtime/Harness，不评价真实模型。
- 07-08 的概率数字是受控教学模拟，不代表任何真实 LLM。
- 09_optional_real_openai_agents.py 仅作为真实 SDK 扩展入口，不默认运行。
- 真正科研必须固定模型、任务集、工具和预算，完整记录 Harness 配置。

## 当前工程参照
- OpenAI Agents SDK: Agent loop, tools, sandbox agents, guardrails, sessions, tracing, human-in-the-loop.
- Anthropic Engineering: long-running agent harnesses, context bridging, artifacts, managed agents, harness assumption drift.
