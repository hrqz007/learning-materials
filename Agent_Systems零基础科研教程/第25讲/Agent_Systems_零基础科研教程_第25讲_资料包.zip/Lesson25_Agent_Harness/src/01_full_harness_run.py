from pathlib import Path
import json
from harness_core import AgentHarness
ROOT=Path(__file__).resolve().parents[1]
task=json.loads((ROOT/'data/task.json').read_text(encoding='utf-8'))
# reset output/checkpoint
for p in [ROOT/'workspace/result.json', ROOT/'outputs/checkpoint_01.json']:
    if p.exists(): p.unlink()
h=AgentHarness(ROOT/'workspace',ROOT/'outputs/checkpoint_01.json',ROOT/'outputs/01_trace.jsonl')
r=h.run(task)
print(json.dumps(r,ensure_ascii=False,indent=2))
print('result=',(ROOT/'workspace/result.json').read_text(encoding='utf-8'))
