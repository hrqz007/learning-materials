from pathlib import Path
from harness_core import Sandbox
ROOT=Path(__file__).resolve().parents[1]
# Bare runtime: normal Path join can escape the intended workspace.
bare=(ROOT/'workspace'/'../outside_demo.txt').resolve()
bare.write_text('BARE_RUNTIME_WROTE_HERE',encoding='utf-8')
print('bare_runtime_path=',bare)
# Harness sandbox blocks the same relative path.
s=Sandbox(ROOT/'workspace')
try:
    s.write_json('../outside_demo.json',{'x':1})
except Exception as e:
    print('harness_blocked=',type(e).__name__,str(e))
# cleanup demo file
bare.unlink(missing_ok=True)
