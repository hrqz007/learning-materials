from pathlib import Path
from harness_core import Sandbox, PermissionPolicy
ROOT=Path(__file__).resolve().parents[1]
s=Sandbox(ROOT/'workspace'); policy=PermissionPolicy(allow_write=False)
print('safe_resolve=',s.resolve('subdir/a.json'))
for rel in ['../secret.json','../../etc/passwd']:
    try: print(rel,'->',s.resolve(rel))
    except Exception as e: print(rel,'DENIED',type(e).__name__)
try: policy.check('write_json',{'path':'result.json'})
except Exception as e: print('write policy=',type(e).__name__,str(e))
