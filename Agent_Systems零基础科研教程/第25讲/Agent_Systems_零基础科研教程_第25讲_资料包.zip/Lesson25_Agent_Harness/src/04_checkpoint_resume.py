from pathlib import Path
import json
from harness_core import AgentHarness
ROOT=Path(__file__).resolve().parents[1]; task=json.loads((ROOT/'data/task.json').read_text(encoding='utf-8'))
cp=ROOT/'outputs/checkpoint_04.json'; tr=ROOT/'outputs/04_trace.jsonl'
for p in [cp,ROOT/'workspace/result.json']:
    if p.exists(): p.unlink()
h1=AgentHarness(ROOT/'workspace',cp,tr)
r1=h1.run(task,crash_after=2)
print('first=',r1['status'],'state=',r1['state'])
h2=AgentHarness(ROOT/'workspace',cp,tr)
r2=h2.run(task,resume=True)
print('resume=',r2['status'],'state=',r2['state'])
