from pathlib import Path
import json, subprocess, sys
ROOT=Path(__file__).resolve().parents[1]; trace=ROOT/'outputs/01_trace.jsonl'
if not trace.exists(): subprocess.run([sys.executable,'01_full_harness_run.py'],cwd=Path(__file__).parent,check=True)
rows=[json.loads(x) for x in trace.read_text(encoding='utf-8').splitlines() if x.strip()]
for i,r in enumerate(rows,1):
    print(f"{i:02d} {r['event']:<14} turn={r.get('turn','-')} tool={r.get('tool','-')}")
from collections import Counter
print('counts=',dict(Counter(r['event'] for r in rows)))
