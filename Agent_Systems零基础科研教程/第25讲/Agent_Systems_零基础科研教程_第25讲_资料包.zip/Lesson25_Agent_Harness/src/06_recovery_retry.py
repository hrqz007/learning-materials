from pathlib import Path
import json
from harness_core import AgentHarness
ROOT=Path(__file__).resolve().parents[1]; task=json.loads((ROOT/'data/task.json').read_text(encoding='utf-8'))
for p in [ROOT/'outputs/checkpoint_06.json',ROOT/'workspace/result.json']:
    if p.exists(): p.unlink()
h=AgentHarness(ROOT/'workspace',ROOT/'outputs/checkpoint_06.json',ROOT/'outputs/06_trace.jsonl',flaky_write_once=True)
r=h.run(task)
print('status=',r['status'],'retries=',r['retries'],'result=',r['state'].get('result'))
