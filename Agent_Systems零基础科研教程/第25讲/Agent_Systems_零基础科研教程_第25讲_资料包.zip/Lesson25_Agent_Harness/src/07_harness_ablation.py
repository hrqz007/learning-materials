import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rows=[
 {'setting':'Full Harness','success':0.94,'unsafe_action_rate':0.01,'diagnostic_coverage':0.96,'relative_cost':1.00},
 {'setting':'No Guard','success':0.93,'unsafe_action_rate':0.22,'diagnostic_coverage':0.92,'relative_cost':0.96},
 {'setting':'No Recovery','success':0.71,'unsafe_action_rate':0.02,'diagnostic_coverage':0.89,'relative_cost':0.87},
 {'setting':'No State','success':0.62,'unsafe_action_rate':0.03,'diagnostic_coverage':0.84,'relative_cost':0.78},
 {'setting':'No Trace','success':0.94,'unsafe_action_rate':0.01,'diagnostic_coverage':0.05,'relative_cost':0.95},
]
out=ROOT/'outputs/07_harness_ablation.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('NOTE: controlled teaching simulation, not real LLM performance')
