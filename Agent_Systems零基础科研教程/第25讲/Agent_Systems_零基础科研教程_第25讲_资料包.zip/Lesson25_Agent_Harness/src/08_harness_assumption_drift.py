import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rows=[
 {'policy':'Legacy_overconstrained','success':0.68,'relative_cost':1.80,'invalid_or_unsafe_rate':0.03,'forced_approval_steps':5},
 {'policy':'Balanced_current','success':0.90,'relative_cost':1.00,'invalid_or_unsafe_rate':0.04,'forced_approval_steps':1},
 {'policy':'Loose_underconstrained','success':0.91,'relative_cost':0.85,'invalid_or_unsafe_rate':0.26,'forced_approval_steps':0},
]
out=ROOT/'outputs/08_harness_assumption_drift.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('Interpretation: harness policy should be revalidated as model capability changes.')
print('NOTE: controlled teaching simulation, not real model measurements')
