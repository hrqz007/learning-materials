"""Optional: requires `pip install openai-agents` and OPENAI_API_KEY.
This file is intentionally not run by the lesson build.
"""
import os
if not os.getenv('OPENAI_API_KEY'):
    print('Set OPENAI_API_KEY first. Then use Agents SDK Agent + Runner + function tools + tracing.')
else:
    print('Recommended exercise: build an Agent with one function tool, enable tracing, add a guardrail, and compare with the teaching Harness trace schema.')
