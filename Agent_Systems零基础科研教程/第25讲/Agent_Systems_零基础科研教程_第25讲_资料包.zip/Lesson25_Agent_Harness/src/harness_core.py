from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Dict, List, Optional, Callable
import json, time

@dataclass
class ToolResult:
    ok: bool
    value: Any = None
    error: Optional[str] = None

class TraceLogger:
    def __init__(self, path=None):
        self.events=[]; self.path=Path(path) if path else None
        if self.path:
            self.path.parent.mkdir(parents=True,exist_ok=True); self.path.write_text('',encoding='utf-8')
    def log(self,event,**data):
        row={'event':event,'ts':round(time.time(),6),**data}; self.events.append(row)
        if self.path:
            with self.path.open('a',encoding='utf-8') as f: f.write(json.dumps(row,ensure_ascii=False)+'\n')
        return row

class Sandbox:
    def __init__(self, root): self.root=Path(root).resolve(); self.root.mkdir(parents=True,exist_ok=True)
    def resolve(self, rel):
        p=(self.root/rel).resolve()
        if self.root not in p.parents and p != self.root: raise PermissionError('path escapes sandbox')
        return p
    def read_json(self, rel): return json.loads(self.resolve(rel).read_text(encoding='utf-8'))
    def write_json(self, rel, obj):
        p=self.resolve(rel); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(json.dumps(obj,ensure_ascii=False,indent=2),encoding='utf-8'); return str(p)

class PermissionPolicy:
    def __init__(self, allow_write=True): self.allow_write=allow_write
    def check(self, tool, args):
        if tool=='write_json' and not self.allow_write: raise PermissionError('write denied by policy')
        return True

class CheckpointStore:
    def __init__(self,path): self.path=Path(path); self.path.parent.mkdir(parents=True,exist_ok=True)
    def save(self,state): self.path.write_text(json.dumps(state,ensure_ascii=False,indent=2),encoding='utf-8')
    def load(self): return json.loads(self.path.read_text(encoding='utf-8')) if self.path.exists() else None

class MockDecisionModel:
    def decide(self, task, state):
        if 'input' not in state:
            return {'tool':'read_json','args':{'path':task['input_file']},'why':'need input'}
        if 'result' not in state:
            x=state['input']['value']; m=state['input']['multiplier']
            return {'tool':'calculator','args':{'a':x,'b':m},'why':'compute'}
        if not state.get('written'):
            return {'tool':'write_json','args':{'path':task['output_file'],'obj':{'result':state['result']}},'why':'persist result'}
        return {'tool':'finish','args':{},'why':'done'}

class AgentHarness:
    def __init__(self, workspace, checkpoint, trace_path=None, allow_write=True, flaky_write_once=False):
        self.sandbox=Sandbox(workspace); self.policy=PermissionPolicy(allow_write); self.checkpoints=CheckpointStore(checkpoint); self.trace=TraceLogger(trace_path); self.model=MockDecisionModel(); self.flaky_write_once=flaky_write_once; self._failed_once=False
    def context(self,task,state):
        return {'goal':task['goal'],'state':state,'tool_names':['read_json','calculator','write_json','finish']}
    def execute(self, action):
        tool=action['tool']; args=action['args']; self.policy.check(tool,args)
        if tool=='read_json': return ToolResult(True,self.sandbox.read_json(args['path']))
        if tool=='calculator': return ToolResult(True,args['a']*args['b'])
        if tool=='write_json':
            if self.flaky_write_once and not self._failed_once:
                self._failed_once=True; return ToolResult(False,error='TransientIOError')
            return ToolResult(True,self.sandbox.write_json(args['path'],args['obj']))
        if tool=='finish': return ToolResult(True,'finished')
        return ToolResult(False,error='UNKNOWN_TOOL')
    def run(self,task,max_turns=10,resume=False,crash_after=None):
        state=self.checkpoints.load() if resume else {'turn':0}
        if not state: state={'turn':0}
        self.trace.log('run_start',task=task,resume=resume,state=state)
        retries=0
        while state['turn']<max_turns:
            state['turn']+=1
            ctx=self.context(task,state); self.trace.log('context',turn=state['turn'],context=ctx)
            action=self.model.decide(task,state); self.trace.log('decision',turn=state['turn'],action=action)
            if action['tool']=='finish': self.trace.log('run_end',status='completed',state=state); return {'status':'completed','state':state,'retries':retries}
            try:
                result=self.execute(action)
            except Exception as e:
                result=ToolResult(False,error=type(e).__name__+': '+str(e))
            self.trace.log('tool_result',turn=state['turn'],tool=action['tool'],result=asdict(result))
            if result.ok:
                if action['tool']=='read_json': state['input']=result.value
                elif action['tool']=='calculator': state['result']=result.value
                elif action['tool']=='write_json': state['written']=True; state['output_path']=result.value
            else:
                state['last_error']=result.error
                if result.error=='TransientIOError' and retries<2:
                    retries+=1; state['turn']-=1; self.trace.log('recovery',strategy='retry',retries=retries); continue
                self.trace.log('run_end',status='failed',state=state); return {'status':'failed','state':state,'retries':retries}
            self.checkpoints.save(state); self.trace.log('checkpoint',turn=state['turn'],state=state)
            if crash_after and state['turn']==crash_after:
                self.trace.log('simulated_crash',turn=state['turn']); return {'status':'crashed','state':state,'retries':retries}
        self.trace.log('run_end',status='max_turns',state=state); return {'status':'max_turns','state':state,'retries':retries}
