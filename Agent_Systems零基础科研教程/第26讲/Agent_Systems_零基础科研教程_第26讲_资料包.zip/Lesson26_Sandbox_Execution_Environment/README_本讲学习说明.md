# Agent Systems 零基础科研教程 - 第26讲

主题：Sandbox 与执行环境

## 核心链路
Harness control plane -> Sandbox execution plane -> Filesystem / Shell / Process / Network / Snapshot

## 建议学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx
3. 运行 src/01-08
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 运行
```bash
cd src
python 01_filesystem_isolation.py
python 02_shell_allowlist.py
python 06_snapshot_rollback.py
```

## 安全说明
- 必做实验不执行危险系统命令；危险命令只作为字符串被 policy 拦截。
- Network 实验只做 policy simulation，不发真实网络请求。
- 概率数字是受控教学模拟，不代表真实产品/模型性能。
- 真实高风险 Agent 系统需要独立安全评估与基础设施隔离。

## 当前工程参照
- OpenAI Sandbox Agents 文档把 harness/control plane 与 sandbox/compute plane 明确区分。
- Sandbox workspace 可包含 files、commands、packages、ports、mounts、snapshots 与 resumable state。
