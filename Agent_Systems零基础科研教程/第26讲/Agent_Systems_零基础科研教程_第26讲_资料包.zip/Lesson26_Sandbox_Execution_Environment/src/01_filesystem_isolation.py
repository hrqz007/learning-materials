from pathlib import Path
from sandbox_core import PathSandbox
ROOT=Path(__file__).resolve().parents[1]
s=PathSandbox(ROOT/'workspace')
p=s.write_text('safe/report.txt','inside workspace')
print('inside=',p)
print('read=',s.read_text('safe/report.txt'))
for rel in ['../outside.txt','../../etc/passwd']:
    try: s.write_text(rel,'x')
    except Exception as e: print(rel,'DENIED',type(e).__name__,str(e))
