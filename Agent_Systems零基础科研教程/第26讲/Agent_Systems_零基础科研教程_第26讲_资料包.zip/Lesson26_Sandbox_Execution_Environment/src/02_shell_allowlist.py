from pathlib import Path
from sandbox_core import ProcessRunner, ShellPolicy
ROOT=Path(__file__).resolve().parents[1]
r=ProcessRunner(ShellPolicy(),timeout=1.0)
for argv in [['python','-c','print(23*17)'],['ls'],['rm','-rf','demo']]:
    try:
        p=r.run(argv,cwd=ROOT/'workspace'); print('CMD',argv,'rc=',p.returncode,'out=',p.stdout.strip())
    except Exception as e: print('CMD',argv,'BLOCKED',type(e).__name__,str(e))
