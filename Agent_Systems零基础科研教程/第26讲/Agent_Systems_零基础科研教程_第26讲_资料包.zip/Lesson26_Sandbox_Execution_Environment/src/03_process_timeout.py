from pathlib import Path
from sandbox_core import ProcessRunner, ShellPolicy
ROOT=Path(__file__).resolve().parents[1]
r=ProcessRunner(ShellPolicy(),timeout=0.5)
for argv in [['echo','fast'],['python','-c','import time; time.sleep(1.5); print("late")']]:
    try:
        p=r.run(argv,cwd=ROOT/'workspace'); print(argv,'OK',p.stdout.strip())
    except Exception as e: print(argv,'STOPPED',type(e).__name__)
