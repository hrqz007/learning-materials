from sandbox_core import NetworkPolicy
p=NetworkPolicy({'docs.example','api.example'},default='deny')
for host in ['docs.example','api.example','unknown.example','exfil.example']:
    try: p.check(host,443); print(host,'ALLOW')
    except Exception as e: print(host,'DENY',type(e).__name__)
print('NOTE: policy simulation only; no real network request is made.')
