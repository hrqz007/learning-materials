from pathlib import Path
from sandbox_core import ProcessRunner, ShellPolicy
ROOT=Path(__file__).resolve().parents[1]
r=ProcessRunner(ShellPolicy(),timeout=1.0,base_env={'PATH':__import__('os').environ.get('PATH','')})
code='import os; print("DEMO_SECRET="+str(os.getenv("DEMO_SECRET"))); print("UNRELATED="+str(os.getenv("UNRELATED_SECRET")))'
print('default child env:')
p=r.run(['python','-c',code],cwd=ROOT/'workspace'); print(p.stdout.strip())
print('approved secret injection:')
p=r.run(['python','-c',code],cwd=ROOT/'workspace',extra_env={'DEMO_SECRET':'demo-token-123'}); print(p.stdout.strip())
