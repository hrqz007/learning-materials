from pathlib import Path
from sandbox_core import PathSandbox, SnapshotManager
ROOT=Path(__file__).resolve().parents[1]; w=ROOT/'workspace'; s=PathSandbox(w); m=SnapshotManager(w,ROOT/'snapshots')
s.write_text('state.txt','GOOD_STATE')
m.create('before_change')
s.write_text('state.txt','BROKEN_STATE')
print('after edit=',s.read_text('state.txt'))
m.rollback('before_change')
s2=PathSandbox(w); print('after rollback=',s2.read_text('state.txt'))
