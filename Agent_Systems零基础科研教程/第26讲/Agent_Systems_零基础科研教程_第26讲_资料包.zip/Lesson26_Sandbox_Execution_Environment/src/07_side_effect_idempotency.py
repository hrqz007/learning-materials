from sandbox_core import SideEffectLedger
ledger=SideEffectLedger(); counter={'n':0}
def side_effect(): counter['n']+=1; return f'operation-{counter["n"]}'
for key in ['task-42','task-42','task-43']:
    print(key,ledger.apply_once(key,side_effect))
print('physical side effects=',counter['n'])
