import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rows=[
 {'setting':'Bare','task_success':0.86,'unsafe_or_invalid_rate':0.31,'relative_overhead':0.65},
 {'setting':'Path_only','task_success':0.88,'unsafe_or_invalid_rate':0.18,'relative_overhead':0.78},
 {'setting':'Path+Shell_guard','task_success':0.90,'unsafe_or_invalid_rate':0.09,'relative_overhead':0.88},
 {'setting':'Full_sandbox','task_success':0.92,'unsafe_or_invalid_rate':0.03,'relative_overhead':1.00},
]
out=ROOT/'outputs/08_sandbox_ablation.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('NOTE: controlled teaching simulation, not real model/product performance.')
