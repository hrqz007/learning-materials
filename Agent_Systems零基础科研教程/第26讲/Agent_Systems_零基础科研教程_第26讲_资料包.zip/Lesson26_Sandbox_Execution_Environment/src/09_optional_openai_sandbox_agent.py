"""Optional reference only. Requires current OpenAI Agents SDK + API credentials.
See current docs: https://developers.openai.com/api/docs/guides/agents/sandboxes
"""
print('Suggested exercise: SandboxAgent + Manifest + Shell/Filesystem capabilities; compare Unix-local/Docker/hosted sandbox behavior.')
