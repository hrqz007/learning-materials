from pathlib import Path
import os, json, shutil, subprocess, sys, tempfile, time

class PathSandbox:
    def __init__(self, root):
        self.root=Path(root).resolve(); self.root.mkdir(parents=True,exist_ok=True)
    def resolve(self, rel):
        p=(self.root/rel).resolve()
        if p != self.root and self.root not in p.parents:
            raise PermissionError('path escapes workspace')
        return p
    def write_text(self, rel, text):
        p=self.resolve(rel); p.parent.mkdir(parents=True,exist_ok=True); p.write_text(text,encoding='utf-8'); return p
    def read_text(self, rel):
        return self.resolve(rel).read_text(encoding='utf-8')

class ShellPolicy:
    def __init__(self, allowed=('python','pwd','ls','cat','echo')): self.allowed=set(allowed)
    def check(self, argv):
        if not argv: raise PermissionError('empty command')
        exe=Path(argv[0]).name
        if exe not in self.allowed: raise PermissionError(f'command not allowed: {exe}')
        # shell=False passes argv directly to the executable; do not misclassify
        # language-internal syntax (e.g. Python ';') as shell metacharacters.
        return True

class ProcessRunner:
    def __init__(self, policy=None, timeout=1.0, base_env=None):
        self.policy=policy or ShellPolicy(); self.timeout=timeout; self.base_env=base_env or {'PATH':os.environ.get('PATH','')}
    def run(self, argv, cwd=None, extra_env=None):
        self.policy.check(argv)
        env=dict(self.base_env); env.update(extra_env or {})
        return subprocess.run(argv,cwd=cwd,capture_output=True,text=True,timeout=self.timeout,env=env,check=False)

class NetworkPolicy:
    def __init__(self, allowed_hosts=None, default='deny'):
        self.allowed=set(allowed_hosts or []); self.default=default
    def check(self, host, port=443):
        ok = host in self.allowed if self.default=='deny' else host not in self.allowed
        if not ok: raise PermissionError(f'network denied: {host}:{port}')
        return True

class SnapshotManager:
    def __init__(self, workspace, snapshot_root):
        self.workspace=Path(workspace); self.snapshot_root=Path(snapshot_root); self.snapshot_root.mkdir(parents=True,exist_ok=True)
    def create(self, name):
        dst=self.snapshot_root/name
        if dst.exists(): shutil.rmtree(dst)
        shutil.copytree(self.workspace,dst)
        return dst
    def rollback(self, name):
        src=self.snapshot_root/name
        if not src.exists(): raise FileNotFoundError(name)
        tmp=self.workspace.parent/(self.workspace.name+'_rollback_tmp')
        if tmp.exists(): shutil.rmtree(tmp)
        shutil.copytree(src,tmp)
        if self.workspace.exists(): shutil.rmtree(self.workspace)
        tmp.rename(self.workspace)

class SideEffectLedger:
    def __init__(self): self.done={}
    def apply_once(self, key, fn):
        if key in self.done: return {'duplicate':True,'result':self.done[key]}
        result=fn(); self.done[key]=result; return {'duplicate':False,'result':result}
