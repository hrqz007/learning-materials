# Agent Systems 零基础科研教程 - 第27讲

主题：Agent Runtime 与任务调度

## 核心链路
Task arrival -> Scheduler -> Queue -> Worker/Agent/Tool -> Timeout/Cancel -> Result/Trace/Metrics

## 建议学习顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx
3. 运行 src/01-08
4. 03_实验指导书.docx
5. 04_实验设计书.docx
6. 06_练习题答案.docx
7. 07_术语速查表.docx

## 运行
```bash
cd src
python 01_sync_vs_async.py
python 03_concurrency_limit.py
python 04_queue_backpressure.py
python 06_straggler_tail_latency.py
```

## 注意
- 必做实验只使用 Python 标准库，不需要 API Key。
- 08 的概率与性能数字是受控教学模拟，不代表真实 OpenAI/Claude/Gemini 或任意 Agent Runtime 的性能。
- 实验时关注 end-to-end latency：arrival -> queue -> execution -> completion，而不只是执行时间。

## 当前工程参照
- OpenAI Agents SDK Runner.run() 是 async 接口，Runner.run_sync() 为同步封装，Runner.run_streamed() 为异步流式。
- OpenAI 多智能体编排文档示例使用 Python asyncio.gather 并行运行互不依赖的 agents。
