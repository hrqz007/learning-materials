import asyncio,time
from scheduler_core import fake_io
jobs=[('A',0.4),('B',0.3),('C',0.5)]

def sync_run():
    start=time.perf_counter()
    for name,d in jobs:
        time.sleep(d); print('sync done',name)
    return time.perf_counter()-start

async def async_run():
    start=time.perf_counter()
    rs=await asyncio.gather(*(fake_io(n,d) for n,d in jobs))
    print('async results',rs)
    return time.perf_counter()-start

s=sync_run(); a=asyncio.run(async_run())
print('sync_seconds=',round(s,3)); print('async_seconds=',round(a,3)); print('speedup=',round(s/a,2))
