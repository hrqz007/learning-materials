import asyncio,time
from scheduler_core import fake_io
async def main():
    start=time.perf_counter()
    tasks=[asyncio.create_task(fake_io('research_A',0.35)),asyncio.create_task(fake_io('research_B',0.45)),asyncio.create_task(fake_io('verifier',0.25))]
    results=await asyncio.gather(*tasks)
    merged={'parts':[r['name'] for r in results],'elapsed':round(time.perf_counter()-start,3)}
    print('fanout_results=',results); print('fanin=',merged)
asyncio.run(main())
