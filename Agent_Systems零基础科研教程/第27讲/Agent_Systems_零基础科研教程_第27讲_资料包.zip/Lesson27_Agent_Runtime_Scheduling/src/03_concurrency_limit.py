import asyncio,time
from scheduler_core import limited_io
async def run(limit):
    sem=asyncio.Semaphore(limit); active=[0]; peak=[0]; jobs=[0.22]*8
    st=time.perf_counter(); await asyncio.gather(*(limited_io(f'T{i}',d,sem,active,peak) for i,d in enumerate(jobs)))
    return time.perf_counter()-st,peak[0]
async def main():
    for limit in [1,2,3,8]:
        elapsed,peak=await run(limit); print('limit=',limit,'elapsed=',round(elapsed,3),'peak_active=',peak)
asyncio.run(main())
