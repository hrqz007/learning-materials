import asyncio,time
async def run(maxsize):
    q=asyncio.Queue(maxsize=maxsize); peak=0; producer_wait=0.0
    async def producer():
        nonlocal peak,producer_wait
        for i in range(10):
            t=time.perf_counter(); await q.put(i); producer_wait+=time.perf_counter()-t; peak=max(peak,q.qsize())
        await q.put(None)
    async def consumer():
        while True:
            item=await q.get()
            if item is None: q.task_done(); break
            await asyncio.sleep(0.06); q.task_done()
    st=time.perf_counter(); await asyncio.gather(producer(),consumer())
    return {'maxsize':maxsize,'peak_queue':peak,'producer_wait':round(producer_wait,3),'elapsed':round(time.perf_counter()-st,3)}
async def main():
    for m in [0,3]: print(await run(m))
asyncio.run(main())
