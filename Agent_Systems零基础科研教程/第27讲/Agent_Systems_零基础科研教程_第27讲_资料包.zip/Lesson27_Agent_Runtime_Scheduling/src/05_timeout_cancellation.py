import asyncio
async def slow_job():
    try:
        print('slow_job: start'); await asyncio.sleep(2); print('slow_job: natural finish')
    except asyncio.CancelledError:
        print('slow_job: received CancelledError'); raise
    finally:
        print('slow_job: cleanup finally')
async def main():
    try: await asyncio.wait_for(slow_job(),timeout=0.3)
    except asyncio.TimeoutError: print('caller: timeout')
asyncio.run(main())
