import asyncio,time
async def job(name,d): await asyncio.sleep(d); return name,d,time.perf_counter()
async def main():
    start=time.perf_counter(); specs=[('A',.25),('B',.28),('C',.31),('D_straggler',1.0)]
    tasks=[asyncio.create_task(job(*s)) for s in specs]
    print('as_completed order:')
    for fut in asyncio.as_completed(tasks):
        name,d,t=await fut; print(name,'ready_at=',round(t-start,3))
    print('barrier_complete_at=',round(time.perf_counter()-start,3))
asyncio.run(main())
