import asyncio,time
async def worker(q,start):
    while True:
        pri,seq,name,d=await q.get()
        if name=='STOP': q.task_done(); break
        wait=round(time.perf_counter()-start,3); print('start',name,'priority',pri,'wait',wait)
        await asyncio.sleep(d); print('finish',name); q.task_done()
async def main():
    q=asyncio.PriorityQueue(); start=time.perf_counter(); seq=0
    # lower number = higher priority
    for pri,name,d in [(5,'low_A',.18),(5,'low_B',.18),(1,'urgent_C',.05),(3,'mid_D',.08)]:
        await q.put((pri,seq,name,d)); seq+=1
    w=asyncio.create_task(worker(q,start)); await q.join(); await q.put((999,seq,'STOP',0)); await q.join(); await w
asyncio.run(main())
