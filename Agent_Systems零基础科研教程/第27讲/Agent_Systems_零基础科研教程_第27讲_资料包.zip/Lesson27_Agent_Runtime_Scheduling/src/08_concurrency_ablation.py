import csv
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
rows=[
 {'concurrency':1,'relative_throughput':1.00,'relative_p95_latency':2.00,'retry_rate':0.02,'task_success':0.93},
 {'concurrency':2,'relative_throughput':1.85,'relative_p95_latency':1.20,'retry_rate':0.03,'task_success':0.94},
 {'concurrency':4,'relative_throughput':3.20,'relative_p95_latency':0.82,'retry_rate':0.05,'task_success':0.94},
 {'concurrency':8,'relative_throughput':3.55,'relative_p95_latency':0.94,'retry_rate':0.14,'task_success':0.91},
 {'concurrency':16,'relative_throughput':3.35,'relative_p95_latency':1.35,'retry_rate':0.28,'task_success':0.84},
]
out=ROOT/'outputs/08_concurrency_ablation.csv'
with out.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
for r in rows: print(r)
print('NOTE: controlled teaching simulation, not real provider/model performance.')
