import asyncio, time, heapq
from dataclasses import dataclass, field
from typing import Any

@dataclass(order=True)
class PrioritizedTask:
    priority: int
    seq: int
    name: str=field(compare=False)
    duration: float=field(compare=False, default=0.1)
    payload: Any=field(compare=False, default=None)

class Metrics:
    def __init__(self):
        self.events=[]
    def emit(self,event,**kw):
        self.events.append({'t':time.perf_counter(),'event':event,**kw})
    def duration(self,event_start,event_end):
        s=[e for e in self.events if e['event']==event_start]
        e=[x for x in self.events if x['event']==event_end]
        return (e[-1]['t']-s[0]['t']) if s and e else None

async def fake_io(name,duration,metrics=None):
    if metrics: metrics.emit('start',name=name)
    await asyncio.sleep(duration)
    if metrics: metrics.emit('finish',name=name)
    return {'name':name,'duration':duration}

async def limited_io(name,duration,sem,active,peak):
    async with sem:
        active[0]+=1; peak[0]=max(peak[0],active[0])
        try:
            await asyncio.sleep(duration)
            return name
        finally:
            active[0]-=1
