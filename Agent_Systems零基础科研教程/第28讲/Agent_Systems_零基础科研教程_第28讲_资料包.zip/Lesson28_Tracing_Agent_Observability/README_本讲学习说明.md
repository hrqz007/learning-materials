# Agent Systems 零基础科研教程 - 第28讲

## 主题
Tracing：把 Agent 的 Prompt、Decision、Tool、State、Handoff、Retry、Failure、Recovery 变成可分析的结构化轨迹。

## 推荐顺序
1. 01_零基础讲义.docx / 02_零基础讲义.pdf
2. 05_练习题.docx（先独立完成）
3. src/01~08 必做实验
4. 打开 outputs/*.jsonl 与 08_trace_metrics.csv
5. 03_实验指导书.docx
6. 04_实验设计书.docx
7. 06_练习题答案.docx
8. 07_术语速查表.docx

## 必做实验
- 01 Basic Trace
- 02 Span Hierarchy
- 03 Failure Localization
- 04 Trace Replay
- 05 Trace Ablation
- 06 Latency Bottleneck
- 07 Multi-Agent Trace
- 08 Batch Trace Metrics

## 说明
必做实验全部只依赖 Python 标准库。09_optional_openai_agents_tracing.py 需要 API Key 与 openai-agents，仅作为真实框架扩展入口。

## 参考
- OpenAI Agents SDK Tracing
- OpenAI Agents API Tracing
- OpenTelemetry Trace API
