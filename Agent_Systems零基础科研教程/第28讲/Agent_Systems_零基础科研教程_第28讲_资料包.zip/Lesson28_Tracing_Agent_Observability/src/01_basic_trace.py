from pathlib import Path
import json, time
from trace_core import TraceLogger
OUT=Path(__file__).parents[1]/"outputs"; OUT.mkdir(exist_ok=True)
log=TraceLogger(OUT/"01_basic_trace.jsonl")
with log.span("agent_run", kind="agent", task="23*17"):
    log.event("prompt_received", text="计算23*17并保存结果")
    with log.span("model_turn", kind="generation"):
        time.sleep(0.01); action={"tool":"calculator","a":23,"b":17}
        log.event("decision", action=action)
    with log.span("calculator", kind="tool", tool="calculator"):
        result=action["a"]*action["b"]
        log.event("tool_result", result=result)
    log.event("state_update", result=result)
    with log.span("final_answer", kind="generation"):
        answer=f"结果是 {result}"
        log.event("final", answer=answer)
print("trace_id =", log.trace_id)
print("answer =", answer)
print("spans =", len(log.records))
for x in log.summary(): print(x)
