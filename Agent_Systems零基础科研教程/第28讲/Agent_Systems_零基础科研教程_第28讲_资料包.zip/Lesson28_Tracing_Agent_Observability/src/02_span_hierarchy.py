from pathlib import Path
from trace_core import TraceLogger
OUT=Path(__file__).parents[1]/"outputs"; OUT.mkdir(exist_ok=True)
log=TraceLogger(OUT/"02_span_hierarchy.jsonl")
with log.span("workflow", kind="task"):
    with log.span("turn_1", kind="turn"):
        with log.span("generation", kind="generation"): pass
        with log.span("search_tool", kind="tool"): pass
    with log.span("turn_2", kind="turn"):
        with log.span("generation", kind="generation"): pass
print("TRACE TREE")
recs=log.records
by_id={r.span_id:r for r in recs}
for r in recs:
    depth=0; p=r.parent_id
    while p:
        depth+=1; p=by_id[p].parent_id if p in by_id else None
    print("  "*depth + f"- {r.name} [{r.status}]")
