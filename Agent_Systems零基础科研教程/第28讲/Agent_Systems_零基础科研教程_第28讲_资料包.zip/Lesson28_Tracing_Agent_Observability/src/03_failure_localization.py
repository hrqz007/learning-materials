from pathlib import Path
from trace_core import TraceLogger
OUT=Path(__file__).parents[1]/"outputs"; OUT.mkdir(exist_ok=True)
log=TraceLogger(OUT/"03_failure_localization.jsonl")
try:
    with log.span("agent_run", kind="agent"):
        with log.span("model_turn", kind="generation"): pass
        try:
            with log.span("read_file", kind="tool", path="missing.txt"):
                raise FileNotFoundError("missing.txt")
        except FileNotFoundError as e:
            log.event("recovery_decision", strategy="fallback_search", cause=type(e).__name__)
        with log.span("fallback_search", kind="tool"): log.event("tool_result", value="recovered")
except Exception:
    pass
print("ERROR SPANS")
for r in log.records:
    if r.status=="ERROR": print(r.name, r.events)
print("Root cause can be localized without reading the final answer only.")
