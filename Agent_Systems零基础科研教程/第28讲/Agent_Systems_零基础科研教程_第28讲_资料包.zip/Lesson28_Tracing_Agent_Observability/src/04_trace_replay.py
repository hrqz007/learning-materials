from pathlib import Path
import json
from trace_core import TraceLogger
OUT=Path(__file__).parents[1]/"outputs"; OUT.mkdir(exist_ok=True)
path=OUT/"04_trace_replay.jsonl"
log=TraceLogger(path)
with log.span("run", kind="agent"):
    log.event("state_change", key="input", value="23*17")
    log.event("state_change", key="result", value=391)
    log.event("state_change", key="status", value="completed")
state={}
for line in path.read_text(encoding='utf-8').splitlines():
    rec=json.loads(line)
    for e in rec.get('events',[]):
        if e.get('name')=='state_change': state[e['key']]=e['value']
print("replayed_state =", state)
assert state=={"input":"23*17","result":391,"status":"completed"}
