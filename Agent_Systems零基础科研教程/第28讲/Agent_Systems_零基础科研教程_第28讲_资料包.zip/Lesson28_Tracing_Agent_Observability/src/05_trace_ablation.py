modes={
"full_trace": {"prompt":1,"decision":1,"tool_call":1,"tool_result":1,"state":1,"error":1},
"no_state": {"prompt":1,"decision":1,"tool_call":1,"tool_result":1,"state":0,"error":1},
"no_tool_result": {"prompt":1,"decision":1,"tool_call":1,"tool_result":0,"state":1,"error":1},
"final_only": {"prompt":0,"decision":0,"tool_call":0,"tool_result":0,"state":0,"error":0},
}
needed=["decision","tool_call","tool_result","state","error"]
for name,m in modes.items():
    coverage=sum(m[k] for k in needed)/len(needed)
    root_cause_visible=bool(m['tool_result'] and m['error'])
    print(name, "diagnostic_coverage=", round(coverage,2), "root_cause_visible=", root_cause_visible)
