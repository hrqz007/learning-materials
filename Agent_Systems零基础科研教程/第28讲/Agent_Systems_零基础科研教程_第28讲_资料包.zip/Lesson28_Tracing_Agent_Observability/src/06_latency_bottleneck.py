from pathlib import Path
import time
from trace_core import TraceLogger
OUT=Path(__file__).parents[1]/"outputs"; OUT.mkdir(exist_ok=True)
log=TraceLogger(OUT/"06_latency_bottleneck.jsonl")
with log.span("run", kind="agent"):
    for name,d in [("model",0.03),("retrieve",0.05),("tool",0.07),("retry",0.11),("verify",0.04)]:
        with log.span(name, kind="operation"):
            time.sleep(d)
rows=[]
for r in log.records:
    if r.name!="run": rows.append((r.name, r.ended_at-r.started_at))
rows.sort(key=lambda x:x[1],reverse=True)
print("LATENCY RANKING")
for n,d in rows: print(n, round(d,3))
print("bottleneck =", rows[0][0])
