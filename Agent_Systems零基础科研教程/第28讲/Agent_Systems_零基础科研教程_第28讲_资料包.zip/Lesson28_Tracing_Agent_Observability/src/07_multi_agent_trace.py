from pathlib import Path
from trace_core import TraceLogger
OUT=Path(__file__).parents[1]/"outputs"; OUT.mkdir(exist_ok=True)
log=TraceLogger(OUT/"07_multi_agent_trace.jsonl")
with log.span("team_run", kind="task"):
    with log.span("Manager", kind="agent"):
        log.event("delegate", to="Researcher")
        with log.span("Researcher", kind="agent"):
            log.event("artifact", ref="evidence.json")
        log.event("handoff", to="Analyst")
        with log.span("Analyst", kind="agent"):
            log.event("analysis", choice="Gamma")
        with log.span("Reviewer", kind="agent"):
            log.event("review", verdict="PASS")
        log.event("final", answer="Gamma")
print("trace_id =",log.trace_id)
for r in log.records: print(r.name, "parent=", r.parent_id, "status=",r.status)
