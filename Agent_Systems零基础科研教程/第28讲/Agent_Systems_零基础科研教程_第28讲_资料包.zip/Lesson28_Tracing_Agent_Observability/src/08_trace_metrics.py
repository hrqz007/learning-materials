from pathlib import Path
import csv, random
OUT=Path(__file__).parents[1]/"outputs"; OUT.mkdir(exist_ok=True)
rng=random.Random(28)
rows=[]
causes=["none","tool_error","bad_decision","stale_state","timeout"]
for run_id in range(200):
    x=rng.random()
    if x<.72: cause="none"
    elif x<.80: cause="tool_error"
    elif x<.88: cause="bad_decision"
    elif x<.94: cause="stale_state"
    else: cause="timeout"
    success=cause=="none" or (cause in {"tool_error","timeout"} and rng.random()<.45)
    rows.append({"run_id":run_id,"cause":cause,"success":int(success),"turns":rng.randint(2,7)})
path=OUT/"08_trace_metrics.csv"
with path.open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
from collections import Counter
c=Counter(r['cause'] for r in rows if not r['success'])
print("runs=",len(rows),"success_rate=",round(sum(r['success'] for r in rows)/len(rows),3))
print("failure_causes=",dict(c))
print("csv=",path)
