"""可选：需要 OPENAI_API_KEY 与 openai-agents。
截至课程制作时，OpenAI Agents SDK 默认会记录 agent、generation、function tool、handoff、guardrail 等 spans。
下面只展示最小结构，不作为必做实验。
"""
import os, asyncio
try:
    from agents import Agent, Runner, trace, function_tool
except ImportError:
    raise SystemExit("先安装: pip install openai-agents")

@function_tool
def calculator(a:int,b:int)->int:
    return a*b

agent=Agent(name="TraceDemo", instructions="需要计算时调用 calculator。", tools=[calculator])
async def main():
    if not os.getenv("OPENAI_API_KEY"):
        raise SystemExit("请先设置 OPENAI_API_KEY")
    with trace("lesson28_trace_demo", metadata={"lesson":28}):
        result=await Runner.run(agent,"计算23乘17")
        print(result.final_output)
asyncio.run(main())
