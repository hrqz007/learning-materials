from __future__ import annotations
from dataclasses import dataclass, asdict, field
from pathlib import Path
from typing import Any, Optional
import json, time, uuid, contextlib

@dataclass
class SpanRecord:
    trace_id: str
    span_id: str
    parent_id: Optional[str]
    name: str
    kind: str
    started_at: float
    ended_at: Optional[float] = None
    status: str = "UNSET"
    attributes: dict[str, Any] = field(default_factory=dict)
    events: list[dict[str, Any]] = field(default_factory=list)

class TraceLogger:
    def __init__(self, path: str | Path):
        self.path = Path(path)
        self.path.parent.mkdir(parents=True, exist_ok=True)
        self.trace_id = "trace_" + uuid.uuid4().hex
        self.records: list[SpanRecord] = []
        self._stack: list[SpanRecord] = []

    @contextlib.contextmanager
    def span(self, name: str, kind: str="internal", **attrs):
        parent_id = self._stack[-1].span_id if self._stack else None
        rec = SpanRecord(self.trace_id, "span_" + uuid.uuid4().hex[:16], parent_id,
                         name, kind, time.perf_counter(), attributes=dict(attrs))
        self._stack.append(rec)
        try:
            yield rec
            if rec.status == "UNSET": rec.status = "OK"
        except Exception as e:
            rec.status = "ERROR"
            rec.events.append({"name":"exception", "type":type(e).__name__, "message":str(e)})
            raise
        finally:
            rec.ended_at = time.perf_counter()
            self._stack.pop()
            self.records.append(rec)
            with self.path.open('a', encoding='utf-8') as f:
                f.write(json.dumps(asdict(rec), ensure_ascii=False) + "\n")

    def event(self, name: str, **attrs):
        if not self._stack:
            raise RuntimeError("event() must be called inside a span")
        self._stack[-1].events.append({"name":name, "ts":time.perf_counter(), **attrs})

    def summary(self):
        out=[]
        for r in self.records:
            dur=(r.ended_at-r.started_at) if r.ended_at else None
            out.append({"name":r.name,"kind":r.kind,"status":r.status,"duration":dur,"parent_id":r.parent_id})
        return out
