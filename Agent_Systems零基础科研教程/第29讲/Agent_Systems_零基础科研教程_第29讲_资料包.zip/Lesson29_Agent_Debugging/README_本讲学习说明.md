# Agent Systems 零基础科研教程 - 第29讲

## 主题
第29讲：Agent Debugging——怎样从失败轨迹真正找到 Root Cause

## 推荐学习顺序
1. `01_零基础讲义.docx` / `02_零基础讲义.pdf`
2. 独立完成 `05_练习题.docx`
3. 运行 `src/01_...py` 到 `src/08_...py`
4. 使用 `03_实验指导书.docx` 记录每个实验的 Surface Symptom / First Bad Span / Root Cause
5. 阅读 `04_实验设计书.docx`，把调试变成可复现的研究实验
6. 最后对照 `06_练习题答案.docx`

## 必做实验特点
- 不需要 API Key
- 只使用 Python 标准库
- 所有实验在打包前已实际运行
- 受控教学实验只用于理解机制，不代表真实大模型性能

## 本讲最低闭环
Failure Trace → Reproduce → Localize → Hypothesis → Fault Injection → Patch → Regression Test

## 可选真实框架实验
`src/09_optional_openai_agents_debugging.py` 需要 OpenAI Agents SDK 和 API Key。

## 当前官方参考（核验日期：2026-09-27）
- https://developers.openai.com/api/docs/guides/agent-evals
- https://developers.openai.com/api/docs/guides/trace-grading
- https://openai.github.io/openai-agents-python/tracing/
- https://openai.github.io/openai-agents-python/config/
- https://opentelemetry.io/docs/specs/otel/trace/api/
