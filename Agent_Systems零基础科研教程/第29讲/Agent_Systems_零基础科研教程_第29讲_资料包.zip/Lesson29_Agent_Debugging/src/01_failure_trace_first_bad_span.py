from debug_core import DebugTrace
from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
data=json.load(open(ROOT/'data'/'provider_scenario.json',encoding='utf-8'))
t=DebugTrace()
t.add(1,'Planner','decision','OK',goal=data['goal'])
t.add(2,'Retriever','tool_result','OK',source='catalog_v1',items=len(data['stale_catalog']))
t.add(3,'Parser','state_update','BAD',changes={'catalog_version':'v1-stale','beta_reliability':0.92})
t.add(4,'Analyst','decision','BAD',choice='Beta',reason='cost<=100 and reliability>=0.90')
t.add(5,'Reviewer','verification','ERROR',message='Current catalog says Beta reliability=0.82')
t.save(ROOT/'outputs'/'01_failure_trace.jsonl')
fb=t.first_bad()
print('first_bad_step=',fb.step,'component=',fb.component,'event=',fb.event_type)
print('final_symptom=Reviewer ERROR')
print('root_candidate=Parser accepted stale catalog')
