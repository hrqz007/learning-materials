from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
data=json.load(open(ROOT/'data'/'provider_scenario.json',encoding='utf-8'))

def pipeline(catalog):
    # Analyst picks cheapest provider that appears eligible
    eligible=[x for x in catalog if x['cost']<=100 and x['reliability']>=0.90]
    choice=min(eligible,key=lambda x:x['cost'])['name'] if eligible else None
    current={x['name']:x for x in data['current_catalog']}
    ok=bool(choice and current[choice]['cost']<=100 and current[choice]['reliability']>=0.90)
    return choice,ok

choice,ok=pipeline(data['stale_catalog'])
print('surface_symptom=review_failed')
print('analyst_choice=',choice,'review_ok=',ok)
choice2,ok2=pipeline(data['current_catalog'])
print('replace_only_data_source -> choice=',choice2,'review_ok=',ok2)
print('conclusion=Data freshness is upstream root cause; reviewer is only detector.')
