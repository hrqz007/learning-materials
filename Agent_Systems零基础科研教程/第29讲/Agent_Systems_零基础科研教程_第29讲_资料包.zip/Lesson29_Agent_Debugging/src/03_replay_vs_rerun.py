from pathlib import Path
import random, json
ROOT=Path(__file__).resolve().parents[1]
fixed=[{'step':1,'state':{'x':23}},{'step':2,'state':{'x':23,'y':17}},{'step':3,'state':{'result':391}}]
print('REPLAY:')
state={}
for e in fixed:
    state.update(e['state']); print(e['step'],state)
print('replay_final=',state)
print('\nLIVE RERUN (stochastic mock):')
for seed in [1,2,3,4]:
    r=random.Random(seed)
    decision='calculator' if r.random()>0.25 else 'search'
    print('seed',seed,'decision',decision)
print('lesson=replay is stable evidence; live rerun may choose a different path')
