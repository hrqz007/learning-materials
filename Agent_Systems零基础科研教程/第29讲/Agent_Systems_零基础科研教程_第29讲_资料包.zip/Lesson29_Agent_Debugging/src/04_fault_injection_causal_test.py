from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
data=json.load(open(ROOT/'data'/'provider_scenario.json',encoding='utf-8'))

def run(catalog):
    eligible=[x for x in catalog if x['cost']<=100 and x['reliability']>=0.90]
    if not eligible: return None,False
    choice=min(eligible,key=lambda x:x['cost'])['name']
    truth={x['name']:x for x in data['current_catalog']}[choice]
    return choice, truth['cost']<=100 and truth['reliability']>=0.90

for label,catalog in [('control_current',data['current_catalog']),('inject_stale',data['stale_catalog']),('restore_current',data['current_catalog'])]:
    choice,ok=run(catalog); print(label,'choice=',choice,'success=',ok)
print('causal_support=stale catalog is sufficient to reproduce the failure in this controlled setup')
