from itertools import product

def run(use_freshness_guard,use_reviewer):
    # stale data says Beta=0.92, current truth Beta=0.82, Gamma=0.93
    if use_freshness_guard:
        choice='Gamma'
    else:
        choice='Beta'
    if use_reviewer:
        success=(choice=='Gamma')
    else:
        success=(choice=='Gamma')  # no detector; final correctness still judged externally
    diagnosed = use_reviewer and not success
    return choice,success,diagnosed

print('freshness_guard,reviewer,choice,success,diagnosed')
for fg,rv in product([False,True],[False,True]):
    c,s,d=run(fg,rv); print(fg,rv,c,s,d,sep=',')
print('interpretation=Reviewer improves detection; freshness guard prevents the upstream fault.')
