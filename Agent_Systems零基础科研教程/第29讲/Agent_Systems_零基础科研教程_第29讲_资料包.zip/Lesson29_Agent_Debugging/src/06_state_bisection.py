# Two trajectories: reference and failing. Step 9 is the first divergent state.
reference=[{'step':i,'value':i*10,'mode':'normal'} for i in range(1,17)]
failing=[]
for i in range(1,17):
    mode='normal' if i<9 else 'polluted'
    value=i*10 if i<9 else i*10+7
    failing.append({'step':i,'value':value,'mode':mode})

def same(step):
    return reference[step-1]==failing[step-1]

lo,hi=1,16
checks=[]
while lo<hi:
    mid=(lo+hi)//2
    checks.append(mid)
    if same(mid): lo=mid+1
    else: hi=mid
print('checks=',checks)
print('first_divergent_step=',lo)
print('reference=',reference[lo-1])
print('failing=',failing[lo-1])
