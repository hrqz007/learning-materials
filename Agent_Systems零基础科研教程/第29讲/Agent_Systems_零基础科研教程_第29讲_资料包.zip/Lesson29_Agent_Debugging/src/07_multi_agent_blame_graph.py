from dataclasses import dataclass
@dataclass
class Artifact:
    id:str; producer:str; value:str; parent:str|None
arts=[
    Artifact('a1','Researcher','Beta reliability=0.92 [stale]',None),
    Artifact('a2','Analyst','Choose Beta','a1'),
    Artifact('a3','Reviewer','REJECT: current truth Beta=0.82','a2'),
    Artifact('a4','Manager','Final failure','a3'),
]
by={a.id:a for a in arts}
cur=by['a4']; path=[]
while cur:
    path.append((cur.id,cur.producer,cur.value))
    cur=by.get(cur.parent)
print('blame_path:')
for x in path: print(' <- '.join(map(str,x)))
root=path[-1]
print('root_artifact=',root)
print('lesson=Reviewer exposes the fault; Researcher produced the first bad evidence artifact.')
