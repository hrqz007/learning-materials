"""Optional: real Agents SDK debugging/tracing demo.
Requires: pip install openai-agents ; export OPENAI_API_KEY=...
This script is not run by the lesson build.
"""
import asyncio, logging
from agents import Agent, Runner, function_tool, enable_verbose_stdout_logging

@function_tool
def get_status(item: str) -> str:
    """Return a tiny deterministic status string for debugging."""
    if item == "missing":
        raise FileNotFoundError("item missing")
    return f"{item}:OK"

agent = Agent(
    name="DebuggableAgent",
    instructions="Use get_status when needed. If a tool fails, explain the failure and stop.",
    tools=[get_status],
)

async def main():
    enable_verbose_stdout_logging()
    try:
        result = await Runner.run(agent, "Check status for missing")
        print(result.final_output)
    except Exception as e:
        print("run failed:", type(e).__name__, e)

if __name__ == '__main__':
    asyncio.run(main())
