from __future__ import annotations
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional
import json, time, copy

@dataclass
class Event:
    step: int
    component: str
    event_type: str
    status: str
    payload: Dict[str, Any]

class DebugTrace:
    def __init__(self):
        self.events: List[Event] = []
    def add(self, step, component, event_type, status='OK', **payload):
        self.events.append(Event(step, component, event_type, status, payload))
    def save(self, path):
        with open(path, 'w', encoding='utf-8') as f:
            for e in self.events:
                f.write(json.dumps(asdict(e), ensure_ascii=False) + '\n')
    def first_bad(self):
        for e in self.events:
            if e.status in {'BAD','ERROR'}:
                return e
        return None
    def replay_state(self):
        state = {}
        for e in self.events:
            if e.event_type == 'state_update':
                state.update(e.payload.get('changes', {}))
        return state

def load_jsonl(path):
    items=[]
    with open(path,encoding='utf-8') as f:
        for line in f:
            if line.strip(): items.append(json.loads(line))
    return items
