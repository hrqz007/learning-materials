# 第30讲：Agent Evaluation

建议学习顺序：
1. 先读 `01_零基础讲义.docx` / PDF。
2. 独立完成 `05_练习题.docx`。
3. 按 `03_实验指导书.docx` 运行 01-08 实验。
4. 用 `04_实验设计书.docx` 的框架重新设计一个自己的评测。
5. 最后核对 `06_练习题答案.docx`。

本讲最低闭环：能够对一个 Agent 同时报告 Outcome、Process、Reliability、Resource 四类指标，并解释 Micro/Macro、Recovery Rate、Trace-level metrics 和 Pareto trade-off。

注意：必做实验中的模拟参数只用于教学，不代表任何真实模型性能。
