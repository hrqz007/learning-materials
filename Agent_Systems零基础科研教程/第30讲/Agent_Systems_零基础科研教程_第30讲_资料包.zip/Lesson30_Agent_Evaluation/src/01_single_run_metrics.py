from evaluation_core import Episode, summarize
import json

e=Episode('t1','calc',True,True,2,2,5,0.82,0.018,1,True,True,0.92)
print(json.dumps({'episode': e.__dict__, 'summary': summarize([e])}, ensure_ascii=False, indent=2))
