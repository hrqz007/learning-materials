from evaluation_core import Episode
A=Episode('A','same',True,True,2,2,4,0.7,0.02,0,False,False,1.0)
B=Episode('B','same',True,True,3,7,18,3.9,0.18,4,True,True,0.55)
for e in [A,B]:
    print(e.task_id, 'success=',e.success,'steps=',e.steps,'tool_accuracy=',round(e.tool_accuracy,3),'latency=',e.latency_s,'cost=',e.cost_usd,'trace_score=',e.trace_score)
