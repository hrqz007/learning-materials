from evaluation_core import Episode, summarize
rows=[
 Episode('t1','tool',True,True,2,2,4,.7,.02,0,False,False,.95),
 Episode('t2','tool',False,True,1,2,6,1.2,.04,1,True,False,.55),
 Episode('t3','tool',True,True,2,3,7,1.3,.05,1,True,True,.75),
 Episode('t4','tool',False,False,0,2,5,1.0,.03,2,True,False,.35),
]
print(summarize(rows))
print('selection/execution/recovery should be inspected separately; final success alone hides the path.')
