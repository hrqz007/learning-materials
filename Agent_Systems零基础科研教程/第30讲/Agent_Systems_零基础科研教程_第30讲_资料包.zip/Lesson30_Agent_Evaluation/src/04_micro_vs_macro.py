cats={'easy':(80,.95),'medium':(15,.60),'hard':(5,.20)}
micro=sum(n*r for n,r in cats.values())/sum(n for n,_ in cats.values())
macro=sum(r for _,r in cats.values())/len(cats)
print('micro=',round(micro,3))
print('macro=',round(macro,3))
for k,(n,r) in cats.items(): print(k,n,r)
