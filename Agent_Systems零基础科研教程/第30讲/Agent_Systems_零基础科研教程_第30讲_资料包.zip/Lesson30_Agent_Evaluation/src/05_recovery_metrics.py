from evaluation_core import Episode, summarize
import random
random.seed(30)
rows=[]
for i in range(100):
    fail=random.random()<0.30
    recovered=fail and (random.random()<0.60)
    success=(not fail) or recovered
    rows.append(Episode(str(i),'mixed',success,True,1,1,5+(2 if recovered else 0),.8+(0.4 if recovered else 0),.02+(0.01 if recovered else 0),1 if fail else 0,fail,recovered,.8 if recovered else (1 if success else .4)))
s=summarize(rows)
print(s)
print('encountered_failures=',sum(e.encountered_failure for e in rows),'recovered=',sum(e.recovered for e in rows))
