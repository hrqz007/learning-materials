runs=[
 {'name':'clean','task_success':1,'trace_score':1.00,'steps':4,'retries':0},
 {'name':'messy','task_success':1,'trace_score':0.45,'steps':17,'retries':5},
 {'name':'failed_but_good_process','task_success':0,'trace_score':0.85,'steps':6,'retries':1},
]
for r in runs: print(r)
print('Same outcome can hide very different process quality; process score is not a replacement for outcome score.')
