configs=[
 ('A',.72,.02,.45),('B',.81,.05,.65),('C',.86,.11,.90),('D',.88,.23,1.35),('E',.89,.42,2.20),
]
# Pareto for maximize quality, minimize cost. A-D are nondominated here; E is dominated by D in practical quality-per-cost sense only if strict quality is relaxed.
for x in configs: print(x)
print('Do not collapse quality/cost/latency into one score unless weights are justified.')
