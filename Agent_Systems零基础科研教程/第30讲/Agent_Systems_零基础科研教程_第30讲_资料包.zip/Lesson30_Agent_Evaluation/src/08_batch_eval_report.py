from evaluation_core import Episode, summarize
import random,csv
from collections import defaultdict
random.seed(300)
rows=[]
for cat,n,p in [('easy',80,.94),('medium',15,.68),('hard',5,.30)]:
    for i in range(n):
        fail=random.random()>p
        recovered=fail and random.random()<.35
        success=(not fail) or recovered
        rows.append(Episode(f'{cat}-{i}',cat,success,True,1 if success else 0,1,4+(2 if recovered else 0),.5+(0.3 if recovered else 0),.015+(0.008 if recovered else 0),int(fail),fail,recovered,.9 if success else .4))
print('overall',summarize(rows))
by=defaultdict(list)
for e in rows: by[e.category].append(e)
for k,v in by.items(): print(k,summarize(v))
with open('../outputs/08_batch_episode_metrics.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].__dict__.keys())+['tool_accuracy'])
    w.writeheader()
    for e in rows:
        d=e.__dict__.copy(); d['tool_accuracy']=e.tool_accuracy; w.writerow(d)
