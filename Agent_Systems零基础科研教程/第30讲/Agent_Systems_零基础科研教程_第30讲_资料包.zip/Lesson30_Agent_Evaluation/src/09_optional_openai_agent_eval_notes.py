"""Optional orientation file.
Current OpenAI guidance (Sep 2026): use traces/trace grading for workflow-level diagnosis,
then move to repeatable datasets/evaluation runs when criteria are stable.
The legacy Evals platform is in deprecation, so this lesson keeps the core experiments local
and product-independent. See developers.openai.com/api/docs/guides/agent-evals.
"""
print(__doc__)
