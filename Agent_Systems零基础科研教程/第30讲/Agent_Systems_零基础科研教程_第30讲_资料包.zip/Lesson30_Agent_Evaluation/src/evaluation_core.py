from dataclasses import dataclass, asdict
from typing import List, Dict
import json

@dataclass
class Episode:
    task_id: str
    category: str
    success: bool
    completed: bool
    correct_tool_calls: int
    total_tool_calls: int
    steps: int
    latency_s: float
    cost_usd: float
    errors: int
    encountered_failure: bool
    recovered: bool
    trace_score: float = 1.0

    @property
    def tool_accuracy(self):
        return self.correct_tool_calls / self.total_tool_calls if self.total_tool_calls else 1.0


def summarize(episodes: List[Episode]) -> Dict[str, float]:
    n=len(episodes)
    if not n: return {}
    fail_eps=[e for e in episodes if e.encountered_failure]
    return {
        'n': n,
        'task_success_rate': sum(e.success for e in episodes)/n,
        'completion_rate': sum(e.completed for e in episodes)/n,
        'tool_accuracy': sum(e.correct_tool_calls for e in episodes)/max(1,sum(e.total_tool_calls for e in episodes)),
        'avg_steps': sum(e.steps for e in episodes)/n,
        'avg_latency_s': sum(e.latency_s for e in episodes)/n,
        'avg_cost_usd': sum(e.cost_usd for e in episodes)/n,
        'error_rate_per_episode': sum(e.errors for e in episodes)/n,
        'recovery_rate': (sum(e.recovered for e in fail_eps)/len(fail_eps)) if fail_eps else 0.0,
        'avg_trace_score': sum(e.trace_score for e in episodes)/n,
    }
