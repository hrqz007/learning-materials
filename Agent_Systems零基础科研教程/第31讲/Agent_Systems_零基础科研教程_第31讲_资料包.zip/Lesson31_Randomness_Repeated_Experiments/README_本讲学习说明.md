# Agent Systems 零基础科研教程 · 第31讲

**主题：Agent 的随机性与重复实验——为什么跑一次几乎不能说明问题**

## 1. 本讲目标

学会区分真实成功概率与样本成功率；理解 Mean、样本Variance、SD、SE 和 Wilson 95% CI；在相同任务上做 A/B 配对；识别“同一任务重复多次当作多个独立任务”的伪重复；最后把重复实验、按任务Bootstrap、难度切片、成本和复现清单组合为一次最小可检验的评测。

## 2. 从哪里开始

1. 先阅读 `01_零基础讲义.pdf`（或编辑 `01_零基础讲义.docx`），只做边上的概念预测，不急于看输出。
2. 完成 `05_练习题.docx` 前13题；重点自己算 `[4,5,5,6,10]` 的均值、方差与标准差。
3. 打开 `03_实验指导书.docx`，执行第1-4个实验，掌握统计直觉。
4. 执行第5-8个实验，打开原始CSV，做完整A/B对照，再填写 `templates/实验记录模板.md`。
5. 阅读 `04_实验设计书.docx`，与自己填写的实验设计对照；最后才核对 `06_练习题答案.docx`。

## 3. 环境要求与操作步骤（Windows / VS Code）

- **必做实验：** Python 3.10或更高版本，只有标准库，不需要联网或 API Key，不需要 `pip install`。
- 在 Windows 资源管理器中解压 ZIP，进入解压后的 `Lesson31_Randomness_Repeated_Experiments` 文件夹。
- 打开 VS Code，菜单 **文件 → 打开文件夹**，选择该文件夹。左侧应看到 `src`、`figures`、`outputs`、`config`。
- 菜单 **终端 → 新建终端**。如果打开的是 PowerShell，输入下方代码，一行一行执行：

```powershell
python --version
cd src
python run_all.py
```

- 如果你电脑中只能通过 `py` 启动 Python，就把上面所有 `python` 替换成 `py`。
- 如果终端提示找不到 `src`，先输入 `pwd`（PowerShell）确认当前文件夹；如果已经在 `src` 目录，就不要再执行 `cd src`。
- 一键运行完成后，所有统计 CSV、JSON、JSONL 和每个实验的实际文本输出保存在 `outputs` 中。

也可以逐个练习：

```powershell
python 01_repeat_one_task.py
python 02_mean_sd.py
python 03_binomial_interval.py
python 04_sample_size_precision.py
python 05_paired_comparison.py
python 06_pseudoreplication.py
python 07_seed_reproducibility.py
python 08_full_ablation.py
python -m unittest -v test_eval_core.py
```

## 4. 你应该看到的关键数字（教学模拟）

| 项目 | 预期结果 |
|---|---|
| 实验01 固定seed的10次 | 6次成功 / 10次，虽预设p=0.70 |
| 实验02 样本步数 | 均值6；样本方差5.5；SD约2.345 |
| 实验03 Wilson 95% CI | 7/10约[.397,.892]；70/100约[.604,.781] |
| 实验05/08任务-轮次 | 24任务×8轮=192对、384次模拟策略执行 |
| 实验08 A/B | A约65.6%；B约72.9%，差约+7.3个百分点 |
| 实验08按任务bootstrap | 示例95%区间约[+2.6,+12.5]个百分点 |
| 实验08成本（人为设定） | A约$2.30，B约$3.65 |

**注意：这些概率与费用均是教学参数，不是任何真实LLM的实测结果或API报价。**

## 5. 重要文件

| 文件或目录 | 用途 |
|---|---|
| `src/eval_core.py` | 统计公式、教学任务生成器、配对数据、簇bootstrap |
| `src/run_all.py` | 一键执行8个必做实验和5项单元测试 |
| `src/09_optional_real_api.py` | 仅限显式授权时手动运行的单次真实API示例；默认直接跳过 |
| `outputs/05_paired_runs.csv` | 完整配对原始数据 |
| `outputs/08_pair_trace.jsonl` | 每行一个配对Episode的结构化轨迹 |
| `outputs/08_report.json` | 总体指标、区间、成本和切片 |
| `config/experiment_plan.json` | 提前冻结的科研协议 |
| `figures/` | 10张彩色原理图，均可单独插入讲义/PPT |
| `MANIFEST_SHA256.txt` | 文件完整性校验（最终打包时生成） |

## 6. 安全与科研边界

- **不默认运行收费 API**。可选脚本必须由使用者设置 `L31_ALLOW_PAID_API=YES`、`OPENAI_API_KEY` 与具体 `OPENAI_MODEL` 后才能产生1次调用；服务端/API变化可能使示例需要相应适配。
- **任务样本与模型概率均为人为设计。** 本包用于建立统计方法的直觉和程序操作能力；不能把得到的7.3个百分点写成新的真实Agent研究发现。
- Wilson CI 的基本适用场景是适当独立的二项试验；跨任务泛化必须考虑任务簇、任务抽样和目标总体，不能把192条Episode直接当成192条独立新任务。
- 写论文时，不能因为一个实验的区间碰巧较窄或较宽而事后任意改变停止规则。

## 7. 参考资料

- NIST: https://www.itl.nist.gov/div898/software/dataplot/refman1/auxillar/propconf.htm
- Brown, Cai & DasGupta (2001), *Interval Estimation for a Binomial Proportion*, DOI: 10.1214/ss/1009213286
- Efron & Tibshirani (1993), *An Introduction to the Bootstrap*.
- OpenAI Advanced Usage, Reproducible Outputs: https://developers.openai.com/api/docs/guides/advanced-usage

下一讲：**第32讲 Benchmark 到底是什么，以及怎样科学比较不同Agent System。**
