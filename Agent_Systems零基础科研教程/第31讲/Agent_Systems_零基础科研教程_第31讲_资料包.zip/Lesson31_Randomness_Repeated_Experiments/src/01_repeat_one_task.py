"""实验01：同一个任务重复 10 次，得到 0/1 运行轨迹。"""
from eval_core import OUTPUT, one_task_simulated_sequence, save_csv

P_SUCCESS = 0.70  # 人为设置，非真实 Agent 的成功率
SEED = 3101       # 实验种子：再次运行获得相同教学样本
results = one_task_simulated_sequence(P_SUCCESS, n=10, seed=SEED)
rows = [{'run': i, 'success': x, 'seed': SEED, 'setting': 'mock_one_task'}
        for i, x in enumerate(results, start=1)]
save_csv(OUTPUT / '01_repeated_runs.csv', rows)
print('实验01 | 同任务10次：', results)
print(f'成功 {sum(results)}/10，点估计 {sum(results)/len(results):.3f}')
print('说明：一次成功或失败只是一次抽样；0.70是模拟器预先规定的概率。')
