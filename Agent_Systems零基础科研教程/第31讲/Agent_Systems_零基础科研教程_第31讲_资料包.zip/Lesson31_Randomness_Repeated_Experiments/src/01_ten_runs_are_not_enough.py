from stats_core import *
for seed in range(1,11):
    x=run_bernoulli(10,.70,seed)
    print(seed, sum(x), f"rate={success_rate(x):.2f}")
