"""实验02：从 5 次运行步数计算样本均值、方差、标准差。"""
from eval_core import sample_mean, sample_variance, sample_sd

steps = [4, 5, 5, 6, 10]  # 5 次运行的动作步数，单位“步”
mu = sample_mean(steps)
errors_sq = [(x-mu)**2 for x in steps]
print('实验02 | 步数:', steps)
print('均值 = (4+5+5+6+10)/5 =', mu)
print('离均差平方 =', errors_sq, '总和 =', sum(errors_sq))
print(f'样本方差 = 22/(5-1) = {sample_variance(steps):.4f} 步²')
print(f'样本标准差 = {sample_sd(steps):.4f} 步')
