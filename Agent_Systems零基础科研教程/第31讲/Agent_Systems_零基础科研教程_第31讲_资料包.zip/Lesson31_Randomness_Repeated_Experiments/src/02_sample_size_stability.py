from stats_core import *
import statistics
for n in [10,30,100,500,2000]:
    rates=[success_rate(run_bernoulli(n,.70,s)) for s in range(1,201)]
    print(n, f"mean={statistics.mean(rates):.3f}", f"batch_std={statistics.pstdev(rates):.3f}")
