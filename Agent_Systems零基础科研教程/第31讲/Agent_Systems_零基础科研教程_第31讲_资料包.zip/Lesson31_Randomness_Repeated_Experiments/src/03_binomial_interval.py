"""实验03：相同 7/10 成功率，点估计和置信区间是两种信息。"""
from eval_core import wilson_interval

for s, n in [(7, 10), (70, 100), (0, 10), (10, 10)]:
    low, high = wilson_interval(s, n)
    print(f'实验03 | {s}/{n} 成功；点估计={s/n:.3f}；Wilson 95% CI=[{low:.3f}, {high:.3f}]')
print('注意：这个 95% 是重复抽样构造区间的长期覆盖率解释，不是已观测 p 的后验概率。')
