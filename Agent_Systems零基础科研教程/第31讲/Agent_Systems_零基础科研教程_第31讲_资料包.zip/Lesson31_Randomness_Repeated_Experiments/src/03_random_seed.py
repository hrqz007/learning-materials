from stats_core import *
a=run_bernoulli(20,.65,42); b=run_bernoulli(20,.65,42); c=run_bernoulli(20,.65,43)
print('same seed identical:', a==b)
print('different seed identical:', a==c)
print('seed42:',a)
