import random, statistics
r=random.Random(31)
lat=[max(.05,r.gauss(1.2,.25)) for _ in range(100)]
print('mean',statistics.mean(lat))
print('sample variance',statistics.variance(lat))
print('sample std',statistics.stdev(lat))
print('median',statistics.median(lat))
