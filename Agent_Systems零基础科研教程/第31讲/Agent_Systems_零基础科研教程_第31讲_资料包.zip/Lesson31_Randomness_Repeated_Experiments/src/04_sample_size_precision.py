"""实验04：样本量增加，二项比例区间一般收窄，但成本也增加。"""
from eval_core import OUTPUT, save_csv, wilson_interval

rows = []
for n in [10, 20, 50, 100, 200, 500]:
    success = int(round(n*0.70))
    lo, hi = wilson_interval(success, n)
    # 每次运行0.02美元只是教学假定，非真实模型报价。
    rows.append({'n': n, 'success': success, 'rate': round(success/n, 4),
                 'ci_low': round(lo, 4), 'ci_high': round(hi, 4),
                 'width': round(hi-lo, 4), 'hypothetical_cost_usd': round(n*0.02, 2)})
save_csv(OUTPUT / '04_precision_by_n.csv', rows)
for r in rows:
    print(f"n={r['n']:3d} | 区间=[{r['ci_low']:.3f}, {r['ci_high']:.3f}] | 宽={r['width']:.3f} | 假设成本=${r['hypothetical_cost_usd']:.2f}")
