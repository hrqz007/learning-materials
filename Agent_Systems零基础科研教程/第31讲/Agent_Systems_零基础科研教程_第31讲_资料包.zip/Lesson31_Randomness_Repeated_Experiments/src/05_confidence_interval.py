from stats_core import wilson_interval
for n in [10,50,200]:
    k=round(.70*n); lo,hi=wilson_interval(k,n)
    print(n,k,k/n, f"95% CI=[{lo:.3f},{hi:.3f}] width={hi-lo:.3f}")
