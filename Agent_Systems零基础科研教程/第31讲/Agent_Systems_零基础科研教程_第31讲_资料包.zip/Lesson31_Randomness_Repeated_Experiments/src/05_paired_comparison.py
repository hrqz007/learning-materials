"""实验05：同一批任务、同一重复轮次，对 A/B 做配对比较。"""
from eval_core import OUTPUT, save_csv, teaching_tasks, simulate_pairs, sample_mean, task_cluster_bootstrap

rows = simulate_pairs(teaching_tasks(8), repeats=8)
save_csv(OUTPUT / '05_paired_runs.csv', rows)
A = sample_mean(float(r['success_A']) for r in rows)
B = sample_mean(float(r['success_B']) for r in rows)
D = sample_mean(float(r['paired_difference']) for r in rows)
lo, hi = task_cluster_bootstrap(rows, rounds=3000, seed=305)
print(f'实验05 | {len(rows)} 次成对观测，24个任务，每任务8轮')
print(f'A成功率={A:.3f}，B成功率={B:.3f}，配对差(B-A)={D:+.3f}')
print(f'按任务簇重采样的示例性95% bootstrap CI=[{lo:+.3f}, {hi:+.3f}]')
print('B 比 A 好的结论还应检查任务难度切片、成本以及实验选择偏差。')
