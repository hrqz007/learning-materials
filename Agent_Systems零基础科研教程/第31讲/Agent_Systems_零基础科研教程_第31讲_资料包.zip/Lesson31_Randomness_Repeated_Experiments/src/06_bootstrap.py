import random, statistics
r=random.Random(77)
costs=[max(.001,r.gauss(.040,.012)) for _ in range(60)]
means=[]
for _ in range(5000):
    means.append(statistics.mean(r.choice(costs) for _ in costs))
means.sort()
print('mean',statistics.mean(costs))
print('bootstrap 95% CI',means[125],means[4874])
