"""实验06：任务簇和重复运行不是一回事；展示伪重复风险。"""
import random
from eval_core import OUTPUT, load_csv, sample_mean, task_cluster_bootstrap

rows = load_csv(OUTPUT / '05_paired_runs.csv') if (OUTPUT/'05_paired_runs.csv').exists() else []
if not rows:
    from eval_core import teaching_tasks, simulate_pairs
    rows = simulate_pairs(teaching_tasks(8), repeats=8)
diffs = [float(r['paired_difference']) for r in rows]
cluster_lo, cluster_hi = task_cluster_bootstrap(rows, rounds=3000, seed=306)
# 故意作错误示范：把192条运行当成192个独立任务，通常低估任务抽样不确定性。
rng = random.Random(306)
boot = [sample_mean(rng.choices(diffs, k=len(diffs))) for _ in range(3000)]
boot.sort()
naive_lo, naive_hi = boot[75], boot[2924]  # 经验百分位数，近似2.5%和97.5%
print('实验06 | 真实不同任务数=24，每任务8次，episode数=192')
print(f'错误示范：episode级bootstrap区间=[{naive_lo:+.3f}, {naive_hi:+.3f}]')
print(f'任务簇bootstrap区间=[{cluster_lo:+.3f}, {cluster_hi:+.3f}]')
print('上述两区间宽窄取决于模拟数据；不要机械认为簇区间一定更宽。')
print('如果24个任务来自固定且穷尽的全部任务集，推断目标要先改为“同任务未来重复”。')
