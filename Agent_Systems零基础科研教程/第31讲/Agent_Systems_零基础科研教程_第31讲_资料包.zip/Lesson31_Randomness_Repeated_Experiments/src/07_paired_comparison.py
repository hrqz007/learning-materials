import csv, statistics
rows=list(csv.DictReader(open('../results/07_paired_comparison.csv',encoding='utf-8-sig')))
d=[int(r['paired_diff_B_minus_A']) for r in rows]
print('paired mean B-A =',statistics.mean(d))
print('B wins',sum(x>0 for x in d),'A wins',sum(x<0 for x in d),'ties',sum(x==0 for x in d))
