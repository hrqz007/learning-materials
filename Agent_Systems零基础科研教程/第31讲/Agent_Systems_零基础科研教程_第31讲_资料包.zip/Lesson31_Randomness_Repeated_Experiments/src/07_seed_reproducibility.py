"""实验07：本地种子是可复现采样条件的一部分，不是远端模型确定性保证。"""
import json
from eval_core import OUTPUT, one_task_simulated_sequence, stable_seed

first = one_task_simulated_sequence(0.66, n=12, seed=2026)
second = one_task_simulated_sequence(0.66, n=12, seed=2026)
third = one_task_simulated_sequence(0.66, n=12, seed=2027)
assert first == second
manifest = {
    'experiment': 'lesson31/mock_seed_demo', 'model': 'TeachingBernoulliModel',
    'api_key_used': False, 'generator': 'Python random.Random',
    'temperature': 'not applicable; synthetic p=0.66',
    'seed': 2026, 'task_version': 'L31-task-v1',
    'harness_version': 'L31-eval-core-v1', 'repeats': 12,
    'note': 'This manifest does not imply deterministic output from a real hosted LLM.'
}
(OUTPUT / '07_reproducibility_manifest.json').write_text(
    json.dumps(manifest, ensure_ascii=False, indent=2), encoding='utf-8')
print('实验07 | seed=2026 第一次', first)
print('实验07 | seed=2026 第二次', second)
print('实验07 | seed=2027 第三次', third)
print('相同种子的本地模拟序列一致：', first == second)
print('不同种子的序列不同：', first != third)
