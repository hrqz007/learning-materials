"""实验08：小型科研演练：配对、层次采样、成本、事先冻结停止条件。"""
import json
from collections import defaultdict
from eval_core import (OUTPUT, save_csv, teaching_tasks, simulate_pairs,
                       sample_mean, wilson_interval, task_cluster_bootstrap)

PLAN = {'task_count': 24, 'repeats_per_task': 8,
        'policies': ['A_baseline', 'B_guarded'], 'bootstrap_rounds': 3000,
        'stopping_rule': '所有24任务各8轮完成后停止；不因看到中途结果而扩样',
        'cost_type': 'synthetic_hypothetical', 'model': 'Mock Bernoulli policy'}
rows = simulate_pairs(teaching_tasks(8), repeats=PLAN['repeats_per_task'])
save_csv(OUTPUT / '08_all_episodes.csv', rows)
# 结构化轨迹，每行是一对同任务同轮次 A/B 的结束记录。
with (OUTPUT/'08_pair_trace.jsonl').open('w', encoding='utf-8') as trace_file:
    for row in rows:
        trace_file.write(json.dumps({'event':'paired_episode_end', **row}, ensure_ascii=False)+'\n')
by_diff = defaultdict(list)
for r in rows:
    by_diff[r['difficulty']].append(r)
all_sA = sum(r['success_A'] for r in rows)
all_sB = sum(r['success_B'] for r in rows)
ci_A = wilson_interval(all_sA, len(rows))
ci_B = wilson_interval(all_sB, len(rows))
pair_ci = task_cluster_bootstrap(rows, PLAN['bootstrap_rounds'], seed=308)
summary_rows = []
for difficulty, subset in sorted(by_diff.items()):
    summary_rows.append({'difficulty': difficulty, 'n_episode_pairs': len(subset),
                         'A_success': round(sample_mean(r['success_A'] for r in subset),4),
                         'B_success': round(sample_mean(r['success_B'] for r in subset),4),
                         'paired_delta': round(sample_mean(r['paired_difference'] for r in subset),4)})
save_csv(OUTPUT / '08_difficulty_slices.csv', summary_rows)
report = {
    'experiment_plan': PLAN, 'task_count': 24, 'episode_pairs': len(rows),
    'A_successes': all_sA, 'B_successes': all_sB,
    'A_rate': all_sA/len(rows), 'B_rate': all_sB/len(rows),
    'A_naive_bernoulli_Wilson95': ci_A, 'B_naive_bernoulli_Wilson95': ci_B,
    'NOTE': '上述episode级Wilson仅作公式演示。真实跨任务总体推断以任务簇bootstrap为主要对象。',
    'paired_delta': sample_mean(r['paired_difference'] for r in rows),
    'paired_task_cluster_bootstrap95': pair_ci,
    'A_total_hypothetical_cost_usd': sum(r['cost_A_usd'] for r in rows),
    'B_total_hypothetical_cost_usd': sum(r['cost_B_usd'] for r in rows),
    'slices': summary_rows
}
(OUTPUT/'08_report.json').write_text(json.dumps(report, ensure_ascii=False, indent=2),encoding='utf-8')
print('实验08 |', PLAN['stopping_rule'])
print(f"不同任务={report['task_count']}，episode配对={len(rows)}，A={report['A_rate']:.3f}，B={report['B_rate']:.3f}")
print(f"配对差={report['paired_delta']:+.3f}，按任务簇bootstrap示例性95%区间={[round(x,3) for x in pair_ci]}")
print(f"假设总成本 A=${report['A_total_hypothetical_cost_usd']:.2f} / B=${report['B_total_hypothetical_cost_usd']:.2f}")
for r in summary_rows:
    print(f"  {r['difficulty']:6s}：A={r['A_success']:.3f} B={r['B_success']:.3f} delta={r['paired_delta']:+.3f}")
