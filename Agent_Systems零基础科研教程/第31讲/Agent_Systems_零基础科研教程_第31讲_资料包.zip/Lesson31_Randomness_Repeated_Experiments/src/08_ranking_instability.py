import csv, collections
rows=list(csv.DictReader(open('../results/08_ranking_instability.csv',encoding='utf-8-sig')))
print(collections.Counter(r['winner'] for r in rows))
print('Interpretation: small batches can reverse the observed ranking.')
