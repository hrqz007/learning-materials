"""可选实验：使用自己明确授权的真实 API 做重复实验。

必做实验完全不需要联网或API付费。此脚本默认拒绝执行，防止误扣费。
设置 L31_ALLOW_PAID_API=YES、OPENAI_API_KEY、OPENAI_MODEL 后才可运行。
本例只请求1次；多次调用应在经批准的预算范围内使用，并另外保存响应信息。
服务端推理可能存在非确定性；本脚本不请求不确定是否支持的 seed 参数。
"""
import json
import os


def main():
    if os.getenv('L31_ALLOW_PAID_API') != 'YES':
        print('未授权收费实验，安全跳过。需显式设置 L31_ALLOW_PAID_API=YES。')
        return
    model = os.getenv('OPENAI_MODEL', '').strip()
    if not model or not os.getenv('OPENAI_API_KEY'):
        raise RuntimeError('需要 OPENAI_MODEL 与 OPENAI_API_KEY 环境变量')
    try:
        from openai import OpenAI  # 可选: python -m pip install openai
    except ImportError as exc:
        raise RuntimeError('可选依赖 openai 未安装；必做实验不需要它') from exc
    client = OpenAI(timeout=30.0, max_retries=0)
    r = client.responses.create(model=model, input='请只回答：2+2等于几？')
    print(json.dumps({'model': model, 'response_id': getattr(r,'id',None),
                      'text': getattr(r,'output_text',''),
                      'usage': r.usage.model_dump() if r.usage else None},
                     ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
