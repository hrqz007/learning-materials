"""第31讲：零依赖的 Agent 重复实验统计核心。

重要：本模块只处理本地受控的教学模拟数据，并不调用任何真实大模型。
目的在于练习运行次数、抽样误差、配对比较和任务簇重采样。
"""
from __future__ import annotations

import csv
import hashlib
import math
import random
from pathlib import Path
from typing import Iterable

ROOT = Path(__file__).resolve().parent.parent
DATA = ROOT / 'data'
OUTPUT = ROOT / 'outputs'
OUTPUT.mkdir(exist_ok=True)


def stable_seed(*parts: object) -> int:
    """从任务与轮次产生跨进程稳定的整数种子；不使用 Python 的 hash()。"""
    text = '|'.join(str(x) for x in parts)
    return int.from_bytes(hashlib.sha256(text.encode('utf-8')).digest()[:8], 'big')


def bernoulli(p: float, seed: int) -> int:
    """用独立的 Python Random 实例做一次 0/1 成功试验。"""
    if not 0 <= p <= 1:
        raise ValueError('概率 p 必须在 0 与 1 之间')
    return int(random.Random(seed).random() < p)


def sample_mean(values: Iterable[float]) -> float:
    """样本均值：总和除以样本数量。"""
    xs = list(values)
    if not xs:
        raise ValueError('均值至少需要 1 条观测')
    return sum(xs) / len(xs)


def sample_variance(values: Iterable[float]) -> float:
    """样本方差：偏差平方和除以 n-1；n 小于 2 时无法计算。"""
    xs = list(values)
    if len(xs) < 2:
        raise ValueError('样本方差至少需要 2 条观测')
    mu = sample_mean(xs)
    return sum((x - mu) ** 2 for x in xs) / (len(xs) - 1)


def sample_sd(values: Iterable[float]) -> float:
    return math.sqrt(sample_variance(values))


def wilson_interval(successes: int, n: int, z: float = 1.959963984540054) -> tuple[float, float]:
    """Wilson 双侧二项比例置信区间；假定各次是适当的 Bernoulli 样本。"""
    if n <= 0 or not 0 <= successes <= n:
        raise ValueError('需满足 n>0 且 0<=successes<=n')
    p = successes / n
    z2 = z * z
    denom = 1 + z2 / n
    center = (p + z2 / (2*n)) / denom
    half = z / denom * math.sqrt(p*(1-p)/n + z2/(4*n*n))
    return max(0, center-half), min(1, center+half)


def save_csv(path: Path, rows: list[dict], fieldnames: list[str] | None = None) -> None:
    """保存 UTF-8 BOM CSV，Windows Excel / WPS 中可直接打开。"""
    if not rows:
        raise ValueError('不允许输出空 CSV')
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames or list(rows[0]))
        writer.writeheader()
        writer.writerows(rows)


def load_csv(path: Path) -> list[dict]:
    with path.open('r', encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def teaching_tasks(n_per_group: int = 8) -> list[dict]:
    """产生任务难度层：易/中/难；概率为教学参数，不是模型实测值。"""
    tasks = []
    for difficulty, p_a, p_b in [
        ('easy', 0.86, 0.82), ('medium', 0.68, 0.79), ('hard', 0.38, 0.56)
    ]:
        for i in range(1, n_per_group+1):
            # 一个很小的任务差异，让同一难度内也非完全一致。
            perturb = ((i-1) % 4 - 1.5)*0.018
            tasks.append({'task_id': f'{difficulty}_{i:02d}', 'difficulty': difficulty,
                          'p_A': round(p_a+perturb, 4), 'p_B': round(p_b+perturb, 4)})
    return tasks


def simulate_pairs(tasks: list[dict], repeats: int = 8, batch_seed: int = 20261016) -> list[dict]:
    """针对相同 task_id 和 repeat 生成 A/B 配对观测。

    为清楚演示配对法，这个玩具实验刻意为 A/B 使用相同的 Uniform(0,1) 数。
    这是 COMMON RANDOM NUMBERS 教学控制，不意味着真实 LLM 可以这样精确耦合。
    """
    out = []
    for task in tasks:
        for rep in range(1, repeats+1):
            u = random.Random(stable_seed(batch_seed, task['task_id'], rep)).random()
            result_a = int(u < task['p_A'])
            result_b = int(u < task['p_B'])
            # 资源费用是单纯为了演示权衡的人为设定，不是真实 API 报价。
            task_cost_a = 0.012
            task_cost_b = 0.019
            out.append({
                'task_id': task['task_id'], 'difficulty': task['difficulty'],
                'repeat': rep, 'simulation_seed': batch_seed,
                'success_A': result_a, 'success_B': result_b,
                'paired_difference': result_b-result_a,
                'cost_A_usd': task_cost_a, 'cost_B_usd': task_cost_b,
            })
    return out


def task_cluster_bootstrap(pairs: list[dict], rounds: int = 3000, seed: int = 311) -> tuple[float, float]:
    """按 task_id 整簇抽样，保留同一任务内部多次运行的相关结构。

    返回示例性 percentile bootstrap 的 2.5% 与 97.5% 分位点；
    前提是任务簇可以近似看作从目标任务总体独立抽到的样本。
    """
    by_task: dict[str, list[float]] = {}
    for row in pairs:
        by_task.setdefault(row['task_id'], []).append(float(row['paired_difference']))
    ids = sorted(by_task)
    if len(ids) < 2:
        raise ValueError('至少需要两个不同任务簇才能估计任务间不确定性')
    task_means = {task: sample_mean(by_task[task]) for task in ids}
    rng = random.Random(seed)
    estimates = []
    for _ in range(rounds):
        sampled = rng.choices(ids, k=len(ids))
        estimates.append(sample_mean(task_means[t] for t in sampled))
    estimates.sort()
    def q(p: float) -> float:
        x = p*(len(estimates)-1)
        low = int(math.floor(x)); high = int(math.ceil(x))
        return estimates[low] if high == low else estimates[low]*(high-x) + estimates[high]*(x-low)
    return q(0.025), q(0.975)


def one_task_simulated_sequence(p: float, n: int, seed: int) -> list[int]:
    """用单独 RNG 做 n 次独立 Bernoulli 教学模拟。"""
    rng = random.Random(seed)
    return [int(rng.random() < p) for _ in range(n)]
