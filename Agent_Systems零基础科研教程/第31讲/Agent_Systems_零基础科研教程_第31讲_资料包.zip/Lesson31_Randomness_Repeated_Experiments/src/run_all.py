"""第31讲一键运行全部8个零费用实验与单元测试。"""
import subprocess
import sys
from pathlib import Path

HERE=Path(__file__).resolve().parent
for number in range(1,9):
    match = list(HERE.glob(f'{number:02d}_*.py'))
    assert len(match)==1, f'找不到唯一实验脚本: {number}'
    print('\n'+'='*65)
    print('运行',match[0].name)
    done = subprocess.run([sys.executable,str(match[0])],check=True,cwd=str(HERE),
                          capture_output=True,text=True,encoding='utf-8',errors='replace')
    print(done.stdout)
    (HERE.parent/'outputs'/f'{match[0].stem}.txt').write_text(done.stdout + done.stderr,encoding='utf-8')
print('\n'+'='*65)
print('运行单元测试')
done = subprocess.run([sys.executable,'-m','unittest','-v','test_eval_core.py'],
                      check=True,cwd=str(HERE),capture_output=True,text=True,
                      encoding='utf-8',errors='replace')
print(done.stdout+done.stderr)
(HERE.parent/'outputs'/'unit_test_results.txt').write_text(done.stdout+done.stderr,encoding='utf-8')
print('8个必做实验 + 5项单元测试全部通过。')
