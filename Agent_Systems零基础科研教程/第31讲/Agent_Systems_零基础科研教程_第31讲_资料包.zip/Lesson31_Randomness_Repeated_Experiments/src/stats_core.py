"""第31讲：随机性与重复实验的最小统计工具。仅使用 Python 标准库。"""
import math, random, statistics

def run_bernoulli(n:int,p:float,seed:int):
    r=random.Random(seed)
    return [1 if r.random()<p else 0 for _ in range(n)]

def success_rate(xs):
    return sum(xs)/len(xs)

def wilson_interval(k:int,n:int,z:float=1.96):
    phat=k/n
    d=1+z*z/n
    center=(phat+z*z/(2*n))/d
    half=z*math.sqrt(phat*(1-phat)/n+z*z/(4*n*n))/d
    return center-half, center+half
