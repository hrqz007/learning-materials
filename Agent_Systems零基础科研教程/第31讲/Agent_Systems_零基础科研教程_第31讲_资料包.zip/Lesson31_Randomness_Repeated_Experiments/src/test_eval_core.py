"""本讲单元测试：验证公式边界、随机种子以及簇bootstrap可重复。"""
import math
import unittest
from eval_core import (sample_mean, sample_variance, sample_sd, wilson_interval,
                       stable_seed, one_task_simulated_sequence,
                       teaching_tasks, simulate_pairs, task_cluster_bootstrap)


class TestStatistics(unittest.TestCase):
    def test_mean_sd(self):
        x = [4,5,5,6,10]
        self.assertAlmostEqual(sample_mean(x), 6.0)
        self.assertAlmostEqual(sample_variance(x), 5.5)
        self.assertAlmostEqual(sample_sd(x), math.sqrt(5.5))

    def test_wilson_7_of_10(self):
        lo, hi = wilson_interval(7,10)
        self.assertAlmostEqual(lo, 0.3968, places=3)
        self.assertAlmostEqual(hi, 0.8922, places=3)
        self.assertTrue(0 <= lo < .7 < hi <= 1)

    def test_bounds(self):
        lo,hi = wilson_interval(0,10)
        self.assertEqual(lo, 0)
        self.assertLess(hi, .3)
        with self.assertRaises(ValueError):
            wilson_interval(11,10)
        with self.assertRaises(ValueError):
            sample_variance([7])

    def test_reproducibility(self):
        self.assertEqual(stable_seed('taskA',1),stable_seed('taskA',1))
        self.assertEqual(one_task_simulated_sequence(.7,100,42),
                         one_task_simulated_sequence(.7,100,42))

    def test_cluster_bootstrap(self):
        pairs=simulate_pairs(teaching_tasks(3), repeats=6)
        self.assertEqual(task_cluster_bootstrap(pairs, rounds=50, seed=10),
                         task_cluster_bootstrap(pairs, rounds=50, seed=10))
        self.assertEqual(len(pairs),3*3*6)

if __name__ == '__main__':
    unittest.main()
