# Agent Systems 零基础科研教程 · 第32讲

## 主题

**Benchmark 到底是什么——Agent Benchmark、Task、Environment、Metric 与 Leaderboard**

截至：2026-09-27

## 本讲一句话

Agent Benchmark 不是一张题库，而是一整套“测量系统”。对 Agent Systems，**Task、Environment、Harness、Tool、Metric、预算、版本与 Trace** 都会影响最终分数。

## 建议学习顺序

1. `01_零基础讲义.docx` / `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 运行 `src/generate_tasks.py`、`src/benchmark_lab.py`、`src/analyze_results.py`
4. 打开 `results/traces/*.jsonl`，至少精读 3 条失败轨迹
5. `04_实验设计书.docx`
6. `05_练习题.docx` → 自己完成 → `06_练习题答案.docx`
7. 阅读论文时把 `07_术语速查表.docx` 放在旁边

## 必做实验

> **这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型的实际性能。**

```bash
python src/generate_tasks.py
# Linux/macOS
PYTHONPATH=src python src/benchmark_lab.py
PYTHONPATH=src python src/analyze_results.py
```

Windows PowerShell：

```powershell
$env:PYTHONPATH="src"
python src/benchmark_lab.py
python src/analyze_results.py
```

## 本资料包已经实际运行验证

- 主实验 episode 数：3600
- C1 strict/env1 Task Success：0.529
- C2 robust/env1 Task Success：0.738
- C3 strict/env2 Task Success：0.013
- C4 robust/env2 Task Success：0.738
- 教学 contamination：public=1.000，hidden=0.564

## 你真正要练的科研动作

Benchmark failure → Trace → First Bad Span → Root Cause → 重复确认 → Research Question → Hypothesis → Controlled Experiment → Baseline/Ablation → 统计与成本分析。

## 可选真实 API

`src/optional_real_api/` 只提供适配入口，不是必做。没有 API Key 完全不影响本讲。
