"""读取主实验结果并生成教学图。"""
from __future__ import annotations
import csv
from collections import defaultdict
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib import font_manager

ROOT = Path(__file__).resolve().parents[1]
RESULTS = ROOT / "results"
FIGS = ROOT / "figures"
FIGS.mkdir(parents=True, exist_ok=True)

FONT_PATH = "/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc"
font_manager.fontManager.addfont(FONT_PATH)
CJK_FONT = font_manager.FontProperties(fname=FONT_PATH).get_name()
plt.rcParams["font.family"] = CJK_FONT
plt.rcParams["axes.unicode_minus"] = False


def read_csv(path):
    with open(path, "r", encoding="utf-8-sig") as f:
        return list(csv.DictReader(f))


def save_bar(labels, values, title, ylabel, filename, ylim=None):
    fig, ax = plt.subplots(figsize=(9, 5.2))
    bars = ax.bar(range(len(labels)), values)
    ax.set_xticks(range(len(labels)), labels, rotation=18, ha="right")
    ax.set_ylabel(ylabel)
    ax.set_title(title)
    if ylim:
        ax.set_ylim(*ylim)
    ax.grid(axis="y", alpha=0.25)
    for b, v in zip(bars, values):
        ax.text(b.get_x()+b.get_width()/2, b.get_height()+0.01*(ylim[1] if ylim else max(values)), f"{v:.3f}", ha="center", va="bottom", fontsize=9)
    fig.tight_layout()
    fig.savefig(FIGS / filename, dpi=180)
    plt.close(fig)


def main():
    rows = read_csv(RESULTS / "condition_summary.csv")
    labels = [r["condition"].replace("C1_", "C1\n").replace("C2_", "C2\n").replace("C3_", "C3\n").replace("C4_", "C4\n").replace("C5_", "C5\n").replace("C6_", "C6\n") for r in rows]
    success = [float(r["task_success"]) for r in rows]
    save_bar(labels, success, "同一受控 Agent 在不同 Harness / Environment / Contamination 条件下的 Task Success", "Task Success", "result_success_by_condition.png", (0, 1.08))

    # 只比较前四个配置的多个指标。
    r4 = rows[:4]
    metrics = ["task_success", "completion_rate", "tool_selection_accuracy", "argument_validity"]
    names = ["Task Success", "Completion", "Tool Select Acc.", "Arg Validity"]
    fig, ax = plt.subplots(figsize=(10, 5.6))
    width = 0.18
    x = list(range(len(r4)))
    for j, (m, name) in enumerate(zip(metrics, names)):
        vals = [float(r[m]) for r in r4]
        ax.bar([i + (j-1.5)*width for i in x], vals, width=width, label=name)
    ax.set_xticks(x, [r["condition"] for r in r4], rotation=15, ha="right")
    ax.set_ylim(0, 1.05)
    ax.set_title("不要只看最终成功率：同一条件下多个系统指标可能讲出不同故事")
    ax.legend(ncol=2)
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGS / "result_multi_metric.png", dpi=180)
    plt.close(fig)

    rank = read_csv(RESULTS / "metric_rank_reversal.csv")
    fig, ax = plt.subplots(figsize=(8, 5))
    x = [0, 1]
    w = 0.34
    ts = [float(r["task_success"]) for r in rank]
    cr = [float(r["completion_rate"]) for r in rank]
    ax.bar([i-w/2 for i in x], ts, width=w, label="Task Success")
    ax.bar([i+w/2 for i in x], cr, width=w, label="Completion Rate")
    ax.set_xticks(x, [r["agent"] for r in rank])
    ax.set_ylim(0, 1.02)
    ax.set_title("Metric 改变可能导致系统排序改变")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGS / "result_metric_rank_reversal.png", dpi=180)
    plt.close(fig)

    rc = read_csv(RESULTS / "root_cause_counts.csv")
    wanted = {"C1_strict_env1", "C3_strict_env2", "C4_robust_env2"}
    causes = sorted({r["root_cause"] for r in rc if r["condition"] in wanted and r["root_cause"] != "success_or_undetermined"})
    conds = ["C1_strict_env1", "C3_strict_env2", "C4_robust_env2"]
    fig, ax = plt.subplots(figsize=(10, 5.3))
    w = 0.24
    x = list(range(len(causes)))
    for j, cond in enumerate(conds):
        counts = []
        for cause in causes:
            val = next((int(r["count"]) for r in rc if r["condition"] == cond and r["root_cause"] == cause), 0)
            counts.append(val)
        ax.bar([i + (j-1)*w for i in x], counts, width=w, label=cond)
    ax.set_xticks(x, causes, rotation=18, ha="right")
    ax.set_ylabel("Failure episodes")
    ax.set_title("Trace-level Root Cause：环境漂移会改变失败结构")
    ax.legend()
    ax.grid(axis="y", alpha=0.25)
    fig.tight_layout()
    fig.savefig(FIGS / "result_root_cause.png", dpi=180)
    plt.close(fig)

    # contamination gap 图
    d = {r["condition"]: float(r["task_success"]) for r in rows}
    labels2 = ["公开题 + 泄漏", "隐藏改写题 + 同一泄漏表"]
    vals2 = [d["C5_leaky_public"], d["C6_leaky_hidden"]]
    save_bar(labels2, vals2, "教学模拟：答案泄漏会制造虚高，换成隐藏改写题后优势消失", "Task Success", "result_contamination_gap.png", (0, 1.08))

    print(f"figures written to {FIGS}")


if __name__ == "__main__":
    main()
