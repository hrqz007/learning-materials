"""第32讲主实验：Harness / Environment / Contamination / Metric 敏感性。

运行：
    python src/generate_tasks.py
    python src/benchmark_lab.py

输出：results/*.csv, *.json, traces/*.jsonl

重要：这是受控教学模拟，不代表任何真实模型的性能。
"""
from __future__ import annotations
import csv
import json
from collections import Counter, defaultdict
from pathlib import Path
from typing import Dict, List

from common.benchmark_core import Harness, MiniEnvironment, MockAgent, EpisodeResult, load_tasks, summarize

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RESULTS = ROOT / "results"
TRACES = RESULTS / "traces"


def write_csv(path: Path, rows: List[dict]):
    if not rows:
        return
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        w.writeheader()
        w.writerows(rows)


def write_traces(path: Path, episodes: List[EpisodeResult]):
    with path.open("w", encoding="utf-8") as f:
        for e in episodes:
            obj = e.flat_dict()
            obj["trace"] = [s.__dict__ for s in e.trace]
            f.write(json.dumps(obj, ensure_ascii=False) + "\n")


def run_condition(condition: Dict, tasks, leak_map) -> List[EpisodeResult]:
    agent = MockAgent(
        name=condition["agent_name"],
        tool_error_rate=condition.get("tool_error_rate", 0.08),
        arg_error_rate=condition.get("arg_error_rate", 0.10),
        redundant_rate=condition.get("redundant_rate", 0.05),
        omit_rate=condition.get("omit_rate", 0.04),
        contamination_map=leak_map,
        contamination_enabled=condition.get("contamination", False),
    )
    harness = Harness(
        name=condition["harness_name"],
        normalize_args=condition.get("normalize_args", False),
        adapt_env_version=condition.get("adapt_env_version", False),
        retry_transient=condition.get("retry_transient", False),
        suppress_duplicates=condition.get("suppress_duplicates", False),
    )
    selected = [t for t in tasks if t.split == condition["split"]]
    episodes: List[EpisodeResult] = []

    for rep in range(condition.get("repeats", 20)):
        for task_idx, task in enumerate(selected):
            seed = condition["seed_base"] + rep * 1000 + task_idx
            env_rng_seed = seed + 100000
            import random
            env = MiniEnvironment(
                condition["environment_version"],
                random.Random(env_rng_seed),
                transient_error_rate=condition.get("transient_error_rate", 0.0),
            )
            run_id = f"{condition['name']}-r{rep:02d}-{task.task_id}"
            episodes.append(harness.run_episode(run_id, task, agent, env, seed))
    return episodes


def metric_rank_reversal(tasks, leak_map):
    """受控演示：同一批 1000 个四步任务，Metric 不同会导致排序反转。

    Agent_A：更像“全对或全错”，65% 完整成功；失败时几乎没有有效进展。
    Agent_B：完整成功率较低（55%），但失败时通常完成 3/4 步。
    因而 Task Success 偏好 A，而 Completion Rate 偏好 B。
    这只是教学构造，不代表任何真实 Agent。
    """
    import random
    rng = random.Random(320032)
    stats = {"Agent_A": {"success": [], "completion": []}, "Agent_B": {"success": [], "completion": []}}
    for _ in range(1000):
        a_ok = rng.random() < 0.65
        stats["Agent_A"]["success"].append(1 if a_ok else 0)
        stats["Agent_A"]["completion"].append(1.0 if a_ok else 0.10)

        b_ok = rng.random() < 0.55
        stats["Agent_B"]["success"].append(1 if b_ok else 0)
        stats["Agent_B"]["completion"].append(1.0 if b_ok else 0.75)

    out = []
    for agent in ["Agent_A", "Agent_B"]:
        n = len(stats[agent]["success"])
        out.append({
            "agent": agent,
            "task_success": sum(stats[agent]["success"]) / n,
            "completion_rate": sum(stats[agent]["completion"]) / n,
            "note": "controlled metric-sensitivity teaching simulation"
        })
    return out


def main():
    RESULTS.mkdir(parents=True, exist_ok=True)
    TRACES.mkdir(parents=True, exist_ok=True)
    tasks = load_tasks(str(DATA / "tasks.jsonl"))
    leak_map = json.loads((DATA / "public_answer_leak.json").read_text(encoding="utf-8"))

    conditions = [
        dict(name="C1_strict_env1", agent_name="MockAgent-clean", harness_name="strict", environment_version="v1", split="hidden",
             normalize_args=False, adapt_env_version=False, retry_transient=False, suppress_duplicates=False,
             contamination=False, transient_error_rate=0.02, repeats=30, seed_base=1000),
        dict(name="C2_robust_env1", agent_name="MockAgent-clean", harness_name="robust", environment_version="v1", split="hidden",
             normalize_args=True, adapt_env_version=True, retry_transient=True, suppress_duplicates=True,
             contamination=False, transient_error_rate=0.02, repeats=30, seed_base=1000),
        dict(name="C3_strict_env2", agent_name="MockAgent-clean", harness_name="strict", environment_version="v2", split="hidden",
             normalize_args=False, adapt_env_version=False, retry_transient=False, suppress_duplicates=False,
             contamination=False, transient_error_rate=0.02, repeats=30, seed_base=1000),
        dict(name="C4_robust_env2", agent_name="MockAgent-clean", harness_name="robust", environment_version="v2", split="hidden",
             normalize_args=True, adapt_env_version=True, retry_transient=True, suppress_duplicates=True,
             contamination=False, transient_error_rate=0.02, repeats=30, seed_base=1000),
        dict(name="C5_leaky_public", agent_name="MockAgent-leaky", harness_name="strict", environment_version="v1", split="public",
             normalize_args=False, adapt_env_version=False, retry_transient=False, suppress_duplicates=False,
             contamination=True, transient_error_rate=0.0, repeats=15, seed_base=5000),
        dict(name="C6_leaky_hidden", agent_name="MockAgent-leaky", harness_name="strict", environment_version="v1", split="hidden",
             normalize_args=False, adapt_env_version=False, retry_transient=False, suppress_duplicates=False,
             contamination=True, transient_error_rate=0.0, repeats=15, seed_base=5000),
    ]

    all_episodes: List[EpisodeResult] = []
    summaries = []
    root_causes = []

    for cfg in conditions:
        rs = run_condition(cfg, tasks, leak_map)
        all_episodes.extend(rs)
        s = summarize(rs)
        row = {"condition": cfg["name"], **{k: round(v, 6) if isinstance(v, float) else v for k, v in s.items()}}
        summaries.append(row)
        write_traces(TRACES / f"{cfg['name']}.jsonl", rs)
        c = Counter(r.root_cause or "success_or_undetermined" for r in rs)
        for k, v in c.items():
            root_causes.append({"condition": cfg["name"], "root_cause": k, "count": v})

    write_csv(RESULTS / "episode_results.csv", [e.flat_dict() for e in all_episodes])
    write_csv(RESULTS / "condition_summary.csv", summaries)
    write_csv(RESULTS / "root_cause_counts.csv", root_causes)
    (RESULTS / "condition_summary.json").write_text(json.dumps(summaries, ensure_ascii=False, indent=2), encoding="utf-8")

    rank = metric_rank_reversal(tasks, leak_map)
    write_csv(RESULTS / "metric_rank_reversal.csv", rank)
    (RESULTS / "metric_rank_reversal.json").write_text(json.dumps(rank, ensure_ascii=False, indent=2), encoding="utf-8")

    print("=== Condition summary ===")
    for row in summaries:
        print(row)
    print("=== Metric rank reversal ===")
    for row in rank:
        print(row)
    print(f"episodes: {len(all_episodes)}")


if __name__ == "__main__":
    main()
