"""第32讲：Benchmark 机制教学实验公共模块。

重要：这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型的实际性能。
目标是让学生看清：Task、Environment、Harness、Metric、Trace 如何共同决定 Benchmark 结果。
"""
from __future__ import annotations

from dataclasses import dataclass, field, asdict
from typing import Any, Dict, List, Optional, Tuple
import json
import math
import random
import statistics
import time


TOOL_SCHEMAS_V1 = {
    "get_order": {"required": ["order_id"]},
    "check_policy": {"required": ["order_id", "action"]},
    "update_address": {"required": ["order_id", "new_address"]},
    "issue_refund": {"required": ["order_id", "amount"]},
    "get_inventory": {"required": ["sku"]},
    "reserve_inventory": {"required": ["sku", "qty"]},
}

# 环境 v2 故意引入接口漂移：check_policy -> verify_policy，qty -> quantity。
TOOL_SCHEMAS_V2 = {
    "get_order": {"required": ["order_id"]},
    "verify_policy": {"required": ["order_id", "action"]},
    "update_address": {"required": ["order_id", "new_address"]},
    "issue_refund": {"required": ["order_id", "amount"]},
    "get_inventory": {"required": ["sku"]},
    "reserve_inventory": {"required": ["sku", "quantity"]},
}


@dataclass
class Task:
    task_id: str
    category: str
    difficulty: str
    goal: str
    gold_actions: List[Dict[str, Any]]
    split: str = "public"
    semantic_id: str = ""


@dataclass
class Action:
    tool: str
    args: Dict[str, Any]


@dataclass
class StepTrace:
    step: int
    proposed_tool: str
    proposed_args: Dict[str, Any]
    executed_tool: Optional[str]
    executed_args: Optional[Dict[str, Any]]
    status: str
    error_type: Optional[str]
    retry: bool
    latency_ms: float
    note: str = ""


@dataclass
class EpisodeResult:
    run_id: str
    task_id: str
    semantic_id: str
    split: str
    category: str
    difficulty: str
    agent_name: str
    harness_name: str
    environment_version: str
    seed: int
    task_success: int
    completion_rate: float
    tool_selection_accuracy: float
    argument_validity: float
    step_count: int
    retry_count: int
    recovery_count: int
    redundant_actions: int
    error_count: int
    latency_ms: float
    token_cost_proxy: int
    first_bad_span: Optional[int]
    root_cause: Optional[str]
    failure_propagation_depth: int
    diagnostic_coverage: int
    trace: List[StepTrace] = field(default_factory=list)

    def flat_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d.pop("trace", None)
        return d


class MiniEnvironment:
    """一个极小但有状态的工具环境。

    v1/v2 的业务目标相同，但工具接口略有漂移，用来演示环境版本对 benchmark 的影响。
    """

    def __init__(self, version: str, rng: random.Random, transient_error_rate: float = 0.0):
        if version not in {"v1", "v2"}:
            raise ValueError("version must be v1 or v2")
        self.version = version
        self.schemas = TOOL_SCHEMAS_V1 if version == "v1" else TOOL_SCHEMAS_V2
        self.rng = rng
        self.transient_error_rate = transient_error_rate
        self.completed: List[Tuple[str, Dict[str, Any]]] = []

    def reset(self) -> None:
        self.completed = []

    def execute(self, tool: str, args: Dict[str, Any]) -> Tuple[bool, str, Optional[str], float]:
        # 受控的低毫秒“延迟”，不真正 sleep，以保证实验快速可复现。
        latency_ms = 8.0 + 4.0 * self.rng.random()

        if tool not in self.schemas:
            return False, "unknown_tool", "TOOL_NOT_FOUND", latency_ms

        schema = self.schemas[tool]
        missing = [k for k in schema["required"] if k not in args]
        if missing:
            return False, f"missing_args:{','.join(missing)}", "INVALID_ARGUMENT", latency_ms

        if self.transient_error_rate > 0 and self.rng.random() < self.transient_error_rate:
            return False, "transient_service_error", "TRANSIENT_ERROR", latency_ms

        self.completed.append((tool, dict(args)))
        return True, "ok", None, latency_ms


class MockAgent:
    """受控教学 Agent。

    它从任务的 gold action 出发，然后按固定概率注入错误。目的不是模拟真实 LLM，
    而是产生可复现的 Tool/Argument/Redundancy/Abort 等失败，方便研究 Benchmark 机制。
    """

    def __init__(
        self,
        name: str,
        tool_error_rate: float = 0.08,
        arg_error_rate: float = 0.10,
        redundant_rate: float = 0.05,
        omit_rate: float = 0.04,
        contamination_map: Optional[Dict[str, List[Dict[str, Any]]]] = None,
        contamination_enabled: bool = False,
    ):
        self.name = name
        self.tool_error_rate = tool_error_rate
        self.arg_error_rate = arg_error_rate
        self.redundant_rate = redundant_rate
        self.omit_rate = omit_rate
        self.contamination_map = contamination_map or {}
        self.contamination_enabled = contamination_enabled

    def plan(self, task: Task, rng: random.Random) -> List[Action]:
        # “泄漏”条件：如果公开 task_id 出现在记忆表中，直接输出完美答案。
        # 这只是教学模拟，用于解释 contamination，不代表真实模型。
        if self.contamination_enabled and task.task_id in self.contamination_map:
            return [Action(x["tool"], dict(x["args"])) for x in self.contamination_map[task.task_id]]

        actions: List[Action] = []
        for gold in task.gold_actions:
            if rng.random() < self.omit_rate:
                continue

            tool = gold["tool"]
            args = dict(gold["args"])

            if rng.random() < self.tool_error_rate:
                # 换成一个错误但合法的工具名，制造 tool selection error。
                choices = [k for k in TOOL_SCHEMAS_V1 if k != tool]
                tool = rng.choice(choices)

            if args and rng.random() < self.arg_error_rate:
                key = rng.choice(list(args.keys()))
                value = args.pop(key)
                # 产生常见“近似参数名”错误，robust harness 可以纠正其中一部分。
                aliases = {
                    "order_id": "id",
                    "new_address": "address",
                    "amount": "refund_amount",
                    "qty": "quantity",
                    "sku": "product_sku",
                    "action": "operation",
                }
                args[aliases.get(key, key + "_wrong")] = value

            actions.append(Action(tool, args))

            if rng.random() < self.redundant_rate:
                actions.append(Action(tool, dict(args)))

        return actions


class Harness:
    """执行 Harness：负责解析、参数归一化、环境适配、重试、Trace。"""

    def __init__(self, name: str, normalize_args: bool, adapt_env_version: bool, retry_transient: bool, suppress_duplicates: bool):
        self.name = name
        self.normalize_args = normalize_args
        self.adapt_env_version = adapt_env_version
        self.retry_transient = retry_transient
        self.suppress_duplicates = suppress_duplicates

    @staticmethod
    def _normalize_args(args: Dict[str, Any]) -> Dict[str, Any]:
        reverse = {
            "id": "order_id",
            "address": "new_address",
            "refund_amount": "amount",
            "quantity": "qty",
            "product_sku": "sku",
            "operation": "action",
        }
        out = {}
        for k, v in args.items():
            out[reverse.get(k, k)] = v
        return out

    def _adapt_to_env(self, action: Action, env_version: str) -> Action:
        tool = action.tool
        args = dict(action.args)
        if self.normalize_args:
            args = self._normalize_args(args)

        if self.adapt_env_version and env_version == "v2":
            if tool == "check_policy":
                tool = "verify_policy"
            if tool == "reserve_inventory" and "qty" in args:
                args["quantity"] = args.pop("qty")
        return Action(tool, args)

    def run_episode(self, run_id: str, task: Task, agent: MockAgent, env: MiniEnvironment, seed: int) -> EpisodeResult:
        rng = random.Random(seed)
        env.reset()
        proposed = agent.plan(task, rng)
        trace: List[StepTrace] = []
        retries = 0
        recovered = 0
        redundant = 0
        errors = 0
        first_bad_span = None
        root_cause = None
        last_signature = None

        # gold tool 序列只用于教学指标，真实 benchmark 往往不能直接如此对齐。
        gold_tools = [x["tool"] for x in task.gold_actions]
        completed_gold_steps = 0
        selected_correct = 0
        arg_valid_steps = 0

        for idx, raw_action in enumerate(proposed, start=1):
            signature = (raw_action.tool, json.dumps(raw_action.args, sort_keys=True, ensure_ascii=False))
            if self.suppress_duplicates and signature == last_signature:
                redundant += 1
                trace.append(StepTrace(idx, raw_action.tool, raw_action.args, None, None, "suppressed_duplicate", None, False, 0.0, "Harness 去重"))
                continue
            if signature == last_signature:
                redundant += 1
            last_signature = signature

            action = self._adapt_to_env(raw_action, env.version)

            # 工具选择准确率：按当前 gold 位置进行近似对齐。
            expected_tool = gold_tools[min(completed_gold_steps, len(gold_tools) - 1)] if gold_tools else None
            canonical_tool = action.tool
            if env.version == "v2" and canonical_tool == "verify_policy":
                canonical_tool = "check_policy"
            if canonical_tool == expected_tool:
                selected_correct += 1

            ok, msg, err, latency = env.execute(action.tool, action.args)
            retry_flag = False

            if not ok and err == "TRANSIENT_ERROR" and self.retry_transient:
                retries += 1
                retry_flag = True
                ok2, msg2, err2, latency2 = env.execute(action.tool, action.args)
                latency += latency2
                if ok2:
                    ok, msg, err = ok2, msg2, err2
                    recovered += 1

            if ok:
                arg_valid_steps += 1
                if canonical_tool == expected_tool:
                    completed_gold_steps += 1
            else:
                errors += 1
                if first_bad_span is None:
                    first_bad_span = idx
                    root_cause = {
                        "TOOL_NOT_FOUND": "tool_or_environment_mismatch",
                        "INVALID_ARGUMENT": "argument_schema_mismatch",
                        "TRANSIENT_ERROR": "environment_transient_error",
                    }.get(err, "unknown")

            trace.append(StepTrace(
                step=idx,
                proposed_tool=raw_action.tool,
                proposed_args=dict(raw_action.args),
                executed_tool=action.tool,
                executed_args=dict(action.args),
                status="ok" if ok else "error",
                error_type=err,
                retry=retry_flag,
                latency_ms=round(latency, 3),
                note=msg,
            ))

        # 任务成功 = 依次完成全部 gold steps，且没有多余的错误动作破坏结果。
        # 为教学简化，这里把 completed_gold_steps 作为核心状态。
        task_success = int(completed_gold_steps >= len(task.gold_actions) and errors == 0)
        completion_rate = completed_gold_steps / max(1, len(task.gold_actions))
        tool_acc = selected_correct / max(1, len(proposed))
        arg_validity = arg_valid_steps / max(1, len(proposed))
        latency_total = sum(x.latency_ms for x in trace)
        propagation_depth = 0 if first_bad_span is None else max(0, len(trace) - first_bad_span)
        diagnostic_coverage = int((task_success == 1) or (root_cause is not None))

        return EpisodeResult(
            run_id=run_id,
            task_id=task.task_id,
            semantic_id=task.semantic_id,
            split=task.split,
            category=task.category,
            difficulty=task.difficulty,
            agent_name=agent.name,
            harness_name=self.name,
            environment_version=env.version,
            seed=seed,
            task_success=task_success,
            completion_rate=round(completion_rate, 6),
            tool_selection_accuracy=round(tool_acc, 6),
            argument_validity=round(arg_validity, 6),
            step_count=len(trace),
            retry_count=retries,
            recovery_count=recovered,
            redundant_actions=redundant,
            error_count=errors,
            latency_ms=round(latency_total, 3),
            token_cost_proxy=25 * len(trace),
            first_bad_span=first_bad_span,
            root_cause=root_cause,
            failure_propagation_depth=propagation_depth,
            diagnostic_coverage=diagnostic_coverage,
            trace=trace,
        )


def percentile(values: List[float], q: float) -> float:
    if not values:
        return float("nan")
    xs = sorted(values)
    if len(xs) == 1:
        return xs[0]
    pos = (len(xs) - 1) * q
    lo = math.floor(pos)
    hi = math.ceil(pos)
    if lo == hi:
        return xs[lo]
    frac = pos - lo
    return xs[lo] * (1 - frac) + xs[hi] * frac


def summarize(results: List[EpisodeResult]) -> Dict[str, Any]:
    if not results:
        return {}
    successes = [r.task_success for r in results]
    lat = [r.latency_ms for r in results]
    failures = [r for r in results if not r.task_success]
    diagnosed = [r for r in failures if r.root_cause]
    retry_total = sum(r.retry_count for r in results)
    recovery_total = sum(r.recovery_count for r in results)
    return {
        "episodes": len(results),
        "task_success": sum(successes) / len(successes),
        "completion_rate": statistics.fmean(r.completion_rate for r in results),
        "tool_selection_accuracy": statistics.fmean(r.tool_selection_accuracy for r in results),
        "argument_validity": statistics.fmean(r.argument_validity for r in results),
        "avg_steps": statistics.fmean(r.step_count for r in results),
        "avg_token_cost_proxy": statistics.fmean(r.token_cost_proxy for r in results),
        "avg_latency_ms": statistics.fmean(lat),
        "p95_latency_ms": percentile(lat, 0.95),
        "p99_latency_ms": percentile(lat, 0.99),
        "retry_rate_per_episode": retry_total / len(results),
        "recovery_rate_given_retry": recovery_total / max(1, retry_total),
        "error_rate_per_episode": sum(r.error_count for r in results) / len(results),
        "redundant_actions_per_episode": sum(r.redundant_actions for r in results) / len(results),
        "diagnostic_coverage_on_failures": len(diagnosed) / max(1, len(failures)),
        "failure_count": len(failures),
    }


def load_tasks(path: str) -> List[Task]:
    tasks = []
    with open(path, "r", encoding="utf-8") as f:
        for line in f:
            if line.strip():
                tasks.append(Task(**json.loads(line)))
    return tasks
