"""生成第32讲受控教学 benchmark 的任务文件。"""
from __future__ import annotations
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
OUT = ROOT / "data" / "tasks.jsonl"
LEAK = ROOT / "data" / "public_answer_leak.json"


def make_task(task_id, semantic_id, category, difficulty, goal, actions, split):
    return {
        "task_id": task_id,
        "semantic_id": semantic_id,
        "category": category,
        "difficulty": difficulty,
        "goal": goal,
        "gold_actions": actions,
        "split": split,
    }


def main():
    tasks = []
    order_n = 0
    # 每个语义任务做 public / hidden-paraphrase 两个版本，共 48 个任务。
    for i in range(1, 25):
        order_n += 1
        order_id = f"ORD{1000+i}"
        if i % 3 == 1:
            cat = "address_change"
            diff = "medium"
            actions = [
                {"tool": "get_order", "args": {"order_id": order_id}},
                {"tool": "check_policy", "args": {"order_id": order_id, "action": "change_address"}},
                {"tool": "update_address", "args": {"order_id": order_id, "new_address": f"Road-{i}"}},
            ]
            g1 = f"将订单 {order_id} 的收货地址改为 Road-{i}，并遵守订单修改规则。"
            g2 = f"请先核对规则，再把 {order_id} 的配送地址更新成 Road-{i}。"
        elif i % 3 == 2:
            cat = "refund"
            diff = "hard"
            amount = 10 + i
            actions = [
                {"tool": "get_order", "args": {"order_id": order_id}},
                {"tool": "check_policy", "args": {"order_id": order_id, "action": "refund"}},
                {"tool": "issue_refund", "args": {"order_id": order_id, "amount": amount}},
            ]
            g1 = f"为订单 {order_id} 退款 {amount} 元，先检查退款政策。"
            g2 = f"订单 {order_id} 需要退回 {amount} 元；必须在执行前确认政策允许。"
        else:
            cat = "inventory"
            diff = "easy"
            sku = f"SKU{i:03d}"
            qty = 1 + (i % 4)
            actions = [
                {"tool": "get_inventory", "args": {"sku": sku}},
                {"tool": "reserve_inventory", "args": {"sku": sku, "qty": qty}},
            ]
            g1 = f"检查 {sku} 库存并预留 {qty} 件。"
            g2 = f"确认商品 {sku} 是否可用，然后锁定 {qty} 个库存单位。"

        tasks.append(make_task(f"pub-{i:02d}", f"sem-{i:02d}", cat, diff, g1, actions, "public"))
        tasks.append(make_task(f"hid-{i:02d}", f"sem-{i:02d}", cat, diff, g2, actions, "hidden"))

    OUT.parent.mkdir(parents=True, exist_ok=True)
    with OUT.open("w", encoding="utf-8") as f:
        for t in tasks:
            f.write(json.dumps(t, ensure_ascii=False) + "\n")

    # 模拟“公开 benchmark 答案泄漏”：只泄漏 public task_id，不包含 hidden paraphrase。
    leak = {t["task_id"]: t["gold_actions"] for t in tasks if t["split"] == "public"}
    LEAK.write_text(json.dumps(leak, ensure_ascii=False, indent=2), encoding="utf-8")
    print(f"wrote {len(tasks)} tasks -> {OUT}")
    print(f"wrote {len(leak)} leaked public answers -> {LEAK}")


if __name__ == "__main__":
    main()
