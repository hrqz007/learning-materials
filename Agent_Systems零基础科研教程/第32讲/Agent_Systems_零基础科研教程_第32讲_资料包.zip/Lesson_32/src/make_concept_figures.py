from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib import font_manager

ROOT = Path(__file__).resolve().parents[1]
FIG = ROOT / 'figures'
FIG.mkdir(exist_ok=True)
FONT_PATH='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font_manager.fontManager.addfont(FONT_PATH)
FONT=font_manager.FontProperties(fname=FONT_PATH).get_name()
plt.rcParams['font.family']=FONT
plt.rcParams['axes.unicode_minus']=False

COLORS = {
    'blue':'#DCEEFF', 'blue_edge':'#3A78B7',
    'green':'#E2F4E7', 'green_edge':'#3F8F5A',
    'orange':'#FFF0D8', 'orange_edge':'#C9862D',
    'red':'#FFE1E1', 'red_edge':'#C94A4A',
    'purple':'#EEE3FF', 'purple_edge':'#7851A9',
    'gray':'#EEEEEE', 'gray_edge':'#777777',
}

def box(ax, x,y,w,h,text,face,edge,fs=12):
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.02',facecolor=face,edgecolor=edge,linewidth=1.6)
    ax.add_patch(p); ax.text(x+w/2,y+h/2,text,ha='center',va='center',fontsize=fs,wrap=True)
    return p

def arr(ax,x1,y1,x2,y2,label=None,fs=10):
    a=FancyArrowPatch((x1,y1),(x2,y2),arrowstyle='-|>',mutation_scale=14,linewidth=1.4,color='#555555')
    ax.add_patch(a)
    if label: ax.text((x1+x2)/2,(y1+y2)/2+0.025,label,ha='center',va='bottom',fontsize=fs)

def clean(ax):
    ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')

# 1 benchmark system
fig,ax=plt.subplots(figsize=(12,6.6)); clean(ax)
box(ax,.03,.69,.15,.16,'Dataset / Task Set\n题目与初始状态',COLORS['green'],COLORS['green_edge'])
box(ax,.24,.69,.16,.16,'Agent / Model\n被测系统',COLORS['blue'],COLORS['blue_edge'])
box(ax,.46,.69,.18,.16,'Harness\n提示词/解析/重试/调度',COLORS['orange'],COLORS['orange_edge'])
box(ax,.70,.69,.18,.16,'Environment\n工具/网站/OS/API/状态',COLORS['purple'],COLORS['purple_edge'])
box(ax,.27,.30,.18,.16,'Trajectory / Trace\n全过程证据',COLORS['gray'],COLORS['gray_edge'])
box(ax,.53,.30,.17,.16,'Evaluator + Metric\n判分与指标',COLORS['red'],COLORS['red_edge'])
box(ax,.77,.30,.16,.16,'Aggregation /\nLeaderboard',COLORS['blue'],COLORS['blue_edge'])
arr(ax,.18,.77,.24,.77,'取一个 Task'); arr(ax,.40,.77,.46,.77,'动作计划'); arr(ax,.64,.77,.70,.77,'执行')
arr(ax,.79,.69,.62,.46,'Observation / State'); arr(ax,.55,.69,.38,.46,'记录'); arr(ax,.45,.38,.53,.38,'评分'); arr(ax,.70,.38,.77,.38,'聚合')
ax.text(.5,.93,'Agent Benchmark = 一套“测量系统”，不只是一个 Dataset',ha='center',fontsize=19,fontweight='bold')
ax.text(.5,.08,'关键：Task、Environment、Harness、Metric、版本与预算共同定义了“你到底在测什么”。',ha='center',fontsize=13)
fig.tight_layout(); fig.savefig(FIG/'benchmark_system_architecture.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 2 dataset vs benchmark
fig,ax=plt.subplots(figsize=(11,6)); clean(ax)
box(ax,.05,.62,.35,.23,'Dataset\n一堆“材料/样本”\n例如：问题、图片、代码仓库、任务描述',COLORS['green'],COLORS['green_edge'],13)
box(ax,.60,.62,.35,.23,'Benchmark\n材料 + 任务定义 + 环境 + 运行协议\n+ Metric + 聚合 + 版本控制',COLORS['blue'],COLORS['blue_edge'],13)
arr(ax,.41,.735,.59,.735,'加入“怎么考、怎么判”')
box(ax,.17,.19,.22,.18,'现实比喻\n题库 ≈ Dataset',COLORS['orange'],COLORS['orange_edge'],13)
box(ax,.61,.19,.22,.18,'现实比喻\n整套高考制度 ≈ Benchmark',COLORS['purple'],COLORS['purple_edge'],13)
arr(ax,.39,.28,.61,.28)
ax.text(.5,.93,'Dataset 是原料；Benchmark 是标准化测量协议',ha='center',fontsize=19,fontweight='bold')
fig.tight_layout(); fig.savefig(FIG/'dataset_vs_benchmark.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 3 static vs agent benchmark
fig,ax=plt.subplots(figsize=(12,6.8)); clean(ax)
ax.text(.25,.93,'普通机器学习 Benchmark',ha='center',fontsize=17,fontweight='bold')
box(ax,.07,.68,.16,.13,'输入 x',COLORS['green'],COLORS['green_edge']); box(ax,.30,.68,.16,.13,'模型 f(x)',COLORS['blue'],COLORS['blue_edge']); box(ax,.18,.40,.17,.13,'输出 y_pred',COLORS['orange'],COLORS['orange_edge']); box(ax,.18,.16,.17,.13,'Metric\n一次性比较',COLORS['red'],COLORS['red_edge'])
arr(ax,.23,.745,.30,.745); arr(ax,.38,.68,.28,.53); arr(ax,.265,.40,.265,.29)
ax.text(.75,.93,'Agent Benchmark',ha='center',fontsize=17,fontweight='bold')
box(ax,.57,.69,.15,.13,'Observation',COLORS['green'],COLORS['green_edge']); box(ax,.78,.69,.15,.13,'Agent',COLORS['blue'],COLORS['blue_edge']); box(ax,.78,.43,.15,.13,'Action / Tool',COLORS['orange'],COLORS['orange_edge']); box(ax,.57,.43,.15,.13,'Environment\nState Transition',COLORS['purple'],COLORS['purple_edge']); box(ax,.66,.16,.18,.13,'Trace + Metrics\n全轨迹评估',COLORS['red'],COLORS['red_edge'])
arr(ax,.72,.755,.78,.755); arr(ax,.855,.69,.855,.56); arr(ax,.78,.495,.72,.495); arr(ax,.645,.56,.645,.69); arr(ax,.75,.43,.75,.29)
ax.text(.25,.06,'静态：input → output',ha='center',fontsize=13)
ax.text(.75,.06,'交互式：状态会被动作改变，错误会传播，路径依赖明显',ha='center',fontsize=13)
fig.tight_layout(); fig.savefig(FIG/'ml_vs_agent_benchmark.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 4 version sensitivity
fig,ax=plt.subplots(figsize=(12,6.4)); clean(ax)
box(ax,.40,.72,.20,.15,'同一个“Agent 名字”',COLORS['blue'],COLORS['blue_edge'],14)
items=[(.06,.40,'Model Version\n模型快照/推理配置'),(.27,.40,'Harness\nprompt/解析/重试'),(.52,.40,'Tools\nschema/权限/返回格式'),(.77,.40,'Environment\n网站/API/OS/数据版本')]
for x,y,t in items: box(ax,x,y,.17,.16,t,COLORS['orange'],COLORS['orange_edge'],11); arr(ax,.50,.72,x+.085,y+.16)
box(ax,.31,.12,.38,.15,'Measured Score\n成功率、成本、Latency、Failure 结构',COLORS['red'],COLORS['red_edge'],14)
for x,_,_ in items: arr(ax,x+.085,.40,.50,.27)
ax.text(.5,.94,'为什么 Agent Benchmark 特别依赖版本与 Harness？',ha='center',fontsize=19,fontweight='bold')
fig.tight_layout(); fig.savefig(FIG/'benchmark_version_sensitivity.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 5 contamination taxonomy
fig,ax=plt.subplots(figsize=(12,6.6)); clean(ax)
box(ax,.38,.76,.24,.14,'Benchmark Integrity\n基准完整性',COLORS['blue'],COLORS['blue_edge'],14)
subs=[(.03,.47,'Training contamination\n测试题/答案进入预训练或微调',COLORS['red'],COLORS['red_edge']),(.27,.47,'Prompt / Demo leakage\n测试答案通过示例/配置泄漏',COLORS['orange'],COLORS['orange_edge']),(.51,.47,'Search-time contamination\nAgent 搜索时找到公开题+答案',COLORS['purple'],COLORS['purple_edge']),(.75,.47,'State / Memory leakage\n跨 episode 残留状态或记忆',COLORS['gray'],COLORS['gray_edge'])]
for x,y,t,f,e in subs: box(ax,x,y,.21,.17,t,f,e,10.5); arr(ax,.50,.76,x+.105,y+.17)
box(ax,.18,.15,.25,.15,'Overfitting\n反复针对 Benchmark 习惯调参\n不一定有直接答案泄漏',COLORS['orange'],COLORS['orange_edge'],11)
box(ax,.57,.15,.25,.15,'Data Leakage\n本不该可见的信息进入训练/调参/测试',COLORS['red'],COLORS['red_edge'],11)
arr(ax,.285,.47,.305,.30); arr(ax,.615,.47,.695,.30)
ax.text(.5,.94,'Contamination、Overfitting、Data Leakage 不是完全同义词',ha='center',fontsize=18,fontweight='bold')
fig.tight_layout(); fig.savefig(FIG/'contamination_taxonomy.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 6 failure -> research
fig,ax=plt.subplots(figsize=(13,5.8)); clean(ax)
xs=[.02,.18,.34,.50,.66,.82]
labels=['Benchmark Failure\n失败样本','Trace / First Bad Span\n定位第一处坏点','重复实验\n确认是否稳定','Research Question\n提出可回答问题','Hypothesis\n可证伪假设','Controlled Experiment\nBaseline + Ablation']
faces=[COLORS['red'],COLORS['gray'],COLORS['green'],COLORS['purple'],COLORS['orange'],COLORS['blue']]
edges=[COLORS['red_edge'],COLORS['gray_edge'],COLORS['green_edge'],COLORS['purple_edge'],COLORS['orange_edge'],COLORS['blue_edge']]
for x,t,f,e in zip(xs,labels,faces,edges): box(ax,x,.52,.145,.20,t,f,e,10.5)
for i in range(len(xs)-1): arr(ax,xs[i]+.145,.62,xs[i+1],.62)
box(ax,.34,.16,.32,.16,'统计 + Failure taxonomy + Cost/Compute matched\n→ 判断证据是否支持 Hypothesis',COLORS['purple'],COLORS['purple_edge'],12)
arr(ax,.892,.52,.66,.32)
ax.text(.5,.90,'从 Benchmark 失败中长出科研问题，而不是先发明方法再刷榜',ha='center',fontsize=18,fontweight='bold')
fig.tight_layout(); fig.savefig(FIG/'failure_to_research_pipeline.png',dpi=180,bbox_inches='tight'); plt.close(fig)

# 7 reproducibility card
fig,ax=plt.subplots(figsize=(10.5,7)); clean(ax)
levels=[('Benchmark Release / Task IDs / Split',.78,COLORS['green'],COLORS['green_edge']),('Environment image / website / data / tool schema',.64,COLORS['purple'],COLORS['purple_edge']),('Harness commit / prompt / parser / retry / max steps',.50,COLORS['orange'],COLORS['orange_edge']),('Model exact ID / date / reasoning settings',.36,COLORS['blue'],COLORS['blue_edge']),('Seed / budget / token / time / parallelism',.22,COLORS['gray'],COLORS['gray_edge']),('Trace / raw outputs / evaluator / metric version',.08,COLORS['red'],COLORS['red_edge'])]
for t,y,f,e in levels: box(ax,.13,y,.74,.10,t,f,e,12)
ax.text(.5,.94,'Agent Benchmark 可复现性：需要“整栈锁定”',ha='center',fontsize=19,fontweight='bold')
fig.tight_layout(); fig.savefig(FIG/'reproducibility_stack.png',dpi=180,bbox_inches='tight'); plt.close(fig)

print('concept figures written')
