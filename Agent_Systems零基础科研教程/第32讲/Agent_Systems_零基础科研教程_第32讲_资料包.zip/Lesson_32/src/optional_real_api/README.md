# 可选真实模型实验

本讲必做实验完全不需要 API Key。这个目录只提供“如何把真实模型接入同一 benchmark runner”的最小入口。

截至 2026-09-27，OpenAI 官方文档使用 Responses API。为避免课程绑死模型版本，代码不硬编码具体模型，而要求设置 `OPENAI_MODEL`。

正式科研时请额外固定并记录：

- 精确模型 ID / 快照或发布日期；
- SDK 版本；
- system/developer prompt；
- tool schema；
- reasoning effort / temperature 等推理配置；
- Harness commit；
- Environment release；
- 预算上限、最大步数、超时与重试策略；
- 每个 episode 的完整 Trace。

如果这些不固定，即使“Benchmark 名字相同”，结果也可能不可比。
