"""可选：把真实 OpenAI 模型接入“任务 -> JSON 动作计划”接口。

截至课程制作日（2026-09-27），OpenAI 官方推荐 Responses API。
此文件不是必做实验；没有 API Key 时不要运行。模型名通过 OPENAI_MODEL 环境变量指定，
避免把课程永久绑死到某个型号。

安装：pip install openai
环境变量：OPENAI_API_KEY, OPENAI_MODEL

注意：这个最小适配器只让模型输出动作 JSON，不直接执行真实工具。
正式研究时应把完整 system prompt、tool schema、SDK 版本、模型精确版本与日期写入实验记录。
"""
from __future__ import annotations
import json
import os
from openai import OpenAI


def ask_for_plan(goal: str, tool_schema_text: str) -> dict:
    model = os.environ.get("OPENAI_MODEL")
    if not model:
        raise RuntimeError("请设置 OPENAI_MODEL，例如你当前有权限使用的精确模型 ID。")
    client = OpenAI()
    prompt = f"""
你是一个受控 benchmark agent。请根据目标和工具定义生成动作计划。
只返回 JSON：{{"actions":[{{"tool":"...","args":{{...}}}}]}}
不要解释。

目标：{goal}
工具：{tool_schema_text}
"""
    response = client.responses.create(model=model, input=prompt)
    return json.loads(response.output_text)


if __name__ == "__main__":
    print("这是可选真实 API 适配器。请先设置 OPENAI_API_KEY 与 OPENAI_MODEL。")
