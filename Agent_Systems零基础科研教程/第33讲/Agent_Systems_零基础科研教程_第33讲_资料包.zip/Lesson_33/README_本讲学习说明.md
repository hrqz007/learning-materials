# Agent Systems 零基础科研教程 · 第33讲

## 主题
第33讲：Agent Trajectory Evaluation——从最终结果走向过程级评测、First Bad Span 与 Failure Propagation

## 本讲核心
从 outcome-only evaluation 进入 trajectory/process-level evaluation：读 trace、找 First Bad Span、区分 root cause 与 downstream symptom、计算 recovery / failure propagation / redundancy / cost，并把稳定 failure phenomenon 转成 Research Question。

## 建议学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 在 `src/` 运行实验
4. 看 `results/` 与 `figures/`
5. 填 `04_实验设计书.docx` 的思路
6. 做 `05_练习题.docx`，再看答案
7. 用 `07_术语速查表.docx` 复习

## 必做实验
```bash
cd Lesson_33/src
python trajectory_lab.py
python analyze_trajectories.py
python inspect_one_trace.py C2_recoverer.jsonl
```

## 实验性质
**这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、真实 Agent 系统的实际性能。**
`cost_units` 也是人为教学 proxy，不是美元、真实 token 费用或真实 API 定价。

## 已实际运行
本资料包生成时已运行 `trajectory_lab.py` 和 `analyze_trajectories.py`，生成 2400 个 episode，并把实际结果写入 `results/`。

## 当前资料参考
截至 2026-09-27，课程内容核对了 OpenAI 官方 agent eval / tracing / trace grading 文档、Anthropic 2026 agent eval 工程文档，以及 2024-2026 trajectory/process evaluation 相关论文。
