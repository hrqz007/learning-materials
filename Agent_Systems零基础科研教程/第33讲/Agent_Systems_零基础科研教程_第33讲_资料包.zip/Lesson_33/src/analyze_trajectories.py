"""Analyze lesson 33 trajectories and create summaries/figures.
All results come from the controlled teaching simulator, not real models.
"""
from __future__ import annotations
import csv, json, math
from collections import Counter, defaultdict
from pathlib import Path
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'results'; FIG=ROOT/'figures'
FIG.mkdir(exist_ok=True)


def load_rows():
    with open(RES/'episode_results.csv',encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    ints=['success','step_count','error_count','neutral_count','recovery_count','redundant_actions','total_latency_ms','had_process_error','recovered_episode','propagated_failure']
    floats=['trajectory_quality','total_cost_units']
    for r in rows:
        for k in ints: r[k]=int(r[k])
        for k in floats: r[k]=float(r[k])
        r['first_bad_index']=int(r['first_bad_index']) if r['first_bad_index'] else None
    return rows

def mean(xs): return sum(xs)/len(xs) if xs else 0.0

def wilson(s,n,z=1.96):
    if n==0:return (0,0)
    p=s/n; d=1+z*z/n
    c=(p+z*z/(2*n))/d
    h=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/d
    return max(0,c-h),min(1,c+h)

def main():
    rows=load_rows(); by=defaultdict(list)
    for r in rows: by[r['condition']].append(r)
    summary=[]
    for c,rs in by.items():
        n=len(rs); s=sum(r['success'] for r in rs); lo,hi=wilson(s,n)
        proc=[r for r in rs if r['had_process_error']]
        recover_rate=sum(r['recovery_count'] for r in rs)/sum(r['error_count'] for r in rs) if sum(r['error_count'] for r in rs) else 0
        prop_rate=sum(r['propagated_failure'] for r in proc)/len(proc) if proc else 0
        summary.append({
            'condition':c,'n':n,'success_rate':round(s/n,4),'success_ci_low':round(lo,4),'success_ci_high':round(hi,4),
            'mean_trajectory_quality':round(mean([r['trajectory_quality'] for r in rs]),4),
            'process_error_episode_rate':round(mean([r['had_process_error'] for r in rs]),4),
            'recovery_rate_given_process_error':round(recover_rate,4),
            'propagation_to_failure_given_process_error':round(prop_rate,4),
            'mean_steps':round(mean([r['step_count'] for r in rs]),2),
            'mean_cost_units':round(mean([r['total_cost_units'] for r in rs]),3),
            'mean_latency_ms':round(mean([r['total_latency_ms'] for r in rs]),1),
            'mean_redundant_actions':round(mean([r['redundant_actions'] for r in rs]),3),
        })
    with open(RES/'condition_summary.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(summary[0].keys())); w.writeheader(); w.writerows(summary)
    (RES/'condition_summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')

    # First bad span distribution by condition and overall
    fbs=[]
    for c,rs in by.items():
        cc=Counter(r['first_bad_index'] for r in rs if r['first_bad_index'] is not None)
        total=sum(cc.values())
        for idx,count in sorted(cc.items()):
            fbs.append({'condition':c,'first_bad_index':idx,'count':count,'share':round(count/total,4) if total else 0})
    with open(RES/'first_bad_span_distribution.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(fbs[0].keys())); w.writeheader(); w.writerows(fbs)

    # Propagation conditional on first bad position (all configs)
    prop=[]
    positions=defaultdict(list)
    for r in rows:
        if r['first_bad_index'] is not None: positions[r['first_bad_index']].append(r)
    for idx,rs in sorted(positions.items()):
        prop.append({'first_bad_index':idx,'n':len(rs),'failure_rate':round(1-mean([r['success'] for r in rs]),4),'recovery_success_rate':round(mean([r['success'] for r in rs]),4)})
    with open(RES/'propagation_by_first_bad_position.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(prop[0].keys())); w.writeheader(); w.writerows(prop)

    labels=[s['condition'].replace('C1_','').replace('C2_','').replace('C3_','').replace('C4_','') for s in summary]
    # Figure: success vs trajectory quality
    fig,ax=plt.subplots(figsize=(8.4,5.2))
    for s,l in zip(summary,labels):
        ax.scatter(s['success_rate'],s['mean_trajectory_quality'],s=100)
        ax.annotate(l,(s['success_rate'],s['mean_trajectory_quality']),xytext=(5,5),textcoords='offset points')
    ax.set_xlabel('Task success rate'); ax.set_ylabel('Mean trajectory quality')
    ax.set_title('Outcome and process can tell different stories')
    ax.grid(alpha=.25); fig.tight_layout(); fig.savefig(FIG/'result_success_vs_quality.png',dpi=180); plt.close(fig)

    # Figure: cost-success tradeoff
    fig,ax=plt.subplots(figsize=(8.4,5.2))
    for s,l in zip(summary,labels):
        ax.scatter(s['mean_cost_units'],s['success_rate'],s=100)
        ax.annotate(l,(s['mean_cost_units'],s['success_rate']),xytext=(5,5),textcoords='offset points')
    ax.set_xlabel('Mean cost units (simulated proxy)'); ax.set_ylabel('Task success rate')
    ax.set_title('A higher score may require more process cost')
    ax.grid(alpha=.25); fig.tight_layout(); fig.savefig(FIG/'result_cost_success_tradeoff.png',dpi=180); plt.close(fig)

    # Figure: first bad span histogram for configs with enough errors
    fig,ax=plt.subplots(figsize=(8.6,5.2))
    for c,rs in by.items():
        vals=[r['first_bad_index'] for r in rs if r['first_bad_index'] is not None]
        if vals:
            counts=Counter(vals); xs=sorted(counts); ys=[counts[x]/len(vals) for x in xs]
            ax.plot(xs,ys,marker='o',label=c)
    ax.set_xlabel('First bad span index'); ax.set_ylabel('Share among episodes with process errors')
    ax.set_title('Where does the first process error appear?')
    ax.legend(fontsize=8); ax.grid(alpha=.25); fig.tight_layout(); fig.savefig(FIG/'result_first_bad_span.png',dpi=180); plt.close(fig)

    # Figure: process-error rate and recovery rate
    fig,ax=plt.subplots(figsize=(8.8,5.2))
    x=range(len(summary)); w=.36
    ax.bar([i-w/2 for i in x],[s['process_error_episode_rate'] for s in summary],width=w,label='episodes with process error')
    ax.bar([i+w/2 for i in x],[s['recovery_rate_given_process_error'] for s in summary],width=w,label='recovery success | process error')
    ax.set_xticks(list(x)); ax.set_xticklabels(labels,rotation=15,ha='right')
    ax.set_ylim(0,1); ax.set_ylabel('Rate'); ax.set_title('Errors and recovery are different dimensions')
    ax.legend(fontsize=8); ax.grid(axis='y',alpha=.25); fig.tight_layout(); fig.savefig(FIG/'result_error_recovery.png',dpi=180); plt.close(fig)
    print(json.dumps(summary,ensure_ascii=False,indent=2))

if __name__=='__main__': main()
