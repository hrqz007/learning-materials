"""Lesson 33: Minimal trace schema helpers.
This is a controlled teaching simulator, NOT a real model benchmark.
"""
from dataclasses import dataclass, asdict
from typing import Any, Dict, List, Optional

@dataclass
class Span:
    span_id: str
    kind: str
    label: int  # +1 good, 0 neutral, -1 error (teaching annotation)
    detail: str
    latency_ms: int
    cost_units: float
    recovered: bool = False
    parent_id: Optional[str] = None

    def to_dict(self) -> Dict[str, Any]:
        return asdict(self)

@dataclass
class Episode:
    episode_id: str
    task_id: str
    condition: str
    difficulty: str
    success: bool
    spans: List[Span]
    first_bad_span: Optional[str]
    first_bad_index: Optional[int]
    recovery_count: int
    error_count: int
    redundant_actions: int
    total_latency_ms: int
    total_cost_units: float

    def to_dict(self) -> Dict[str, Any]:
        d = asdict(self)
        d["spans"] = [s.to_dict() for s in self.spans]
        return d
