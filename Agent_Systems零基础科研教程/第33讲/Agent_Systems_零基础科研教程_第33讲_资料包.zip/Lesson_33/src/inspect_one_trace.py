"""Print one trace in a beginner-friendly table-like view."""
import json, sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'results'/'traces'/(sys.argv[1] if len(sys.argv)>1 else 'C2_recoverer.jsonl')
with open(path,encoding='utf-8') as f: ep=json.loads(next(f))
print('episode:',ep['episode_id'],'success=',ep['success'],'first_bad=',ep['first_bad_span'])
print('-'*92)
print(f"{'span':<6} {'kind':<16} {'label':<5} {'recovered':<9} detail")
for s in ep['spans']:
    print(f"{s['span_id']:<6} {s['kind']:<16} {s['label']:<5} {str(s['recovered']):<9} {s['detail']}")
