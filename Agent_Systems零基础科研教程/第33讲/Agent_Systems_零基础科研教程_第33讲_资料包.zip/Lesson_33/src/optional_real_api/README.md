# 可选真实 API 实验

本目录不是本讲必做部分。核心实验完全无需 API Key。

目的：把真实模型/Agent 的模型调用、工具调用、状态变化记录成 trace，再复用本讲的过程级分析思路。

截至 2026-09-27，OpenAI 官方文档已提供 Agents tracing / trace grading；API 与 SDK 会快速变化，因此运行前应以官方文档为准。不要为了本讲学习而强行绑定某个框架。

官方参考：
- https://developers.openai.com/api/docs/guides/agents-api/tracing
- https://developers.openai.com/api/docs/guides/trace-grading
- https://developers.openai.com/api/docs/guides/agent-evals
