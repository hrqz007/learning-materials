"""Optional real-API tracing skeleton (not part of the required lab).

As of 2026-09-27, consult the current OpenAI official Agents/Tracing and evaluation docs
before adapting this file. This skeleton intentionally avoids binding the lesson to a
specific framework or tool schema.

Requires: OPENAI_API_KEY and an installed current `openai` package.
No real call is executed by the lesson's verification script.
"""
import json, os, time
from pathlib import Path


def record_span(trace, kind, input_obj, output_obj, start_t, status='ok'):
    trace.append({
        'kind': kind,
        'input': input_obj,
        'output': output_obj,
        'status': status,
        'latency_ms': round((time.time()-start_t)*1000, 1),
    })


def example_single_model_span(prompt: str, model: str):
    from openai import OpenAI
    client=OpenAI()
    trace=[]
    t=time.time()
    response=client.responses.create(model=model, input=prompt)
    record_span(trace,'MODEL_RESPONSE',{'prompt':prompt},{'text':response.output_text},t)
    return trace


if __name__=='__main__':
    if not os.getenv('OPENAI_API_KEY'):
        raise SystemExit('Set OPENAI_API_KEY first. This optional file is not required for Lesson 33.')
    model=os.environ.get('OPENAI_MODEL')
    if not model:
        raise SystemExit('Set OPENAI_MODEL to a model available in your current account/API. Check official model docs first.')
    trace=example_single_model_span('Return the number 7.',model)
    print(json.dumps(trace,ensure_ascii=False,indent=2))
