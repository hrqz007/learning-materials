"""Lesson 33 controlled teaching simulation.

Purpose:
- Show why outcome-only evaluation can hide process differences.
- Produce trace JSONL for First Bad Span / propagation / recovery analysis.

IMPORTANT: This is a controlled teaching simulator. Its probabilities are manually
chosen for pedagogy. They do NOT represent GPT/Claude/Gemini or any real agent.
"""
from __future__ import annotations
import csv, json, random
from pathlib import Path
from common.trace_schema import Span, Episode

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
RESULTS = ROOT / 'results'
TRACES = RESULTS / 'traces'
RESULTS.mkdir(exist_ok=True); TRACES.mkdir(exist_ok=True)

CONDITIONS = {
    # Clean policy: low error rates, moderate verification.
    'C1_clean': dict(plan=.025, tool=.035, args=.045, execute=.018,
                     verify=True, detect=.86, recover=.72, redundant=.025, lucky=.025),
    # Messier policy: more early mistakes but strong detection/recovery.
    # Intentionally tuned to achieve similar final success to C1 while producing dirtier traces.
    'C2_recoverer': dict(plan=.080, tool=.095, args=.120, execute=.040,
                         verify=True, detect=.93, recover=.86, redundant=.065, lucky=.035),
    # Fast baseline: fewer steps, no verification/recovery.
    'C3_fast_no_verify': dict(plan=.055, tool=.070, args=.085, execute=.030,
                              verify=False, detect=0.0, recover=0.0, redundant=.015, lucky=.055),
    # Over-checking policy: low error + strong recovery, but high redundant action cost.
    'C4_overcheck': dict(plan=.030, tool=.040, args=.050, execute=.020,
                         verify=True, detect=.92, recover=.72, redundant=.32, lucky=.025),
}

DIFF_ADD = {'easy': 0.0, 'medium': .025, 'hard': .055}
STAGES = [('plan','PLAN'), ('tool','TOOL_SELECT'), ('args','ARGUMENT_BUILD'), ('execute','TOOL_EXECUTE')]


def load_tasks():
    with open(DATA/'tasks.jsonl', encoding='utf-8') as f:
        return [json.loads(x) for x in f if x.strip()]


def run_episode(task, condition, seed):
    cfg = CONDITIONS[condition]
    rng = random.Random(seed)
    spans=[]; unresolved=[]; recovery_count=0; redundant_actions=0
    diff = DIFF_ADD[task['difficulty']]

    for idx,(key,kind) in enumerate(STAGES, start=1):
        p_err = min(.45, cfg[key] + diff)
        is_err = rng.random() < p_err
        label = -1 if is_err else 1
        detail = f"{kind}: " + ("injected teaching error" if is_err else "valid step")
        spans.append(Span(f"s{len(spans)+1:02d}", kind, label, detail,
                          latency_ms=rng.randint(15,45), cost_units=round(rng.uniform(.8,1.25),3)))
        if is_err:
            unresolved.append(len(spans)-1)
        # neutral redundant action can occur after a core action
        if rng.random() < cfg['redundant']:
            redundant_actions += 1
            spans.append(Span(f"s{len(spans)+1:02d}", 'REDUNDANT', 0,
                              'neutral/redundant action: not required for task completion',
                              latency_ms=rng.randint(12,35), cost_units=round(rng.uniform(.65,1.05),3)))

    if cfg['verify']:
        spans.append(Span(f"s{len(spans)+1:02d}", 'VERIFY', 1,
                          'verification step inspects current state', rng.randint(18,40), round(rng.uniform(.8,1.2),3)))
        still=[]
        for err_idx in unresolved:
            detected = rng.random() < cfg['detect']
            if detected and rng.random() < cfg['recover']:
                spans[err_idx].recovered=True
                recovery_count += 1
                spans.append(Span(f"s{len(spans)+1:02d}", 'RECOVERY', 1,
                                  f"recovered error from {spans[err_idx].span_id}/{spans[err_idx].kind}",
                                  rng.randint(20,55), round(rng.uniform(1.0,1.5),3), parent_id=spans[err_idx].span_id))
            else:
                still.append(err_idx)
        unresolved=still

    # Outcome: no unresolved critical error -> success; otherwise a small lucky-success chance.
    success = (len(unresolved)==0) or (rng.random() < cfg['lucky'])
    final_label = 1 if success else -1
    spans.append(Span(f"s{len(spans)+1:02d}", 'FINAL', final_label,
                      'final task outcome: ' + ('success' if success else 'failure'),
                      rng.randint(8,18), round(rng.uniform(.25,.45),3)))

    first_bad=None; first_bad_index=None
    for i,s in enumerate(spans, start=1):
        if s.label==-1 and s.kind!='FINAL':
            first_bad=s.span_id; first_bad_index=i; break
    errors=sum(1 for s in spans if s.label==-1 and s.kind!='FINAL')
    return Episode(
        episode_id=f"{condition}__{task['task_id']}__r{seed}", task_id=task['task_id'],
        condition=condition, difficulty=task['difficulty'], success=success, spans=spans,
        first_bad_span=first_bad, first_bad_index=first_bad_index,
        recovery_count=recovery_count, error_count=errors, redundant_actions=redundant_actions,
        total_latency_ms=sum(s.latency_ms for s in spans),
        total_cost_units=round(sum(s.cost_units for s in spans),3),
    )


def main():
    tasks=load_tasks(); rows=[]
    trace_files={c: open(TRACES/f'{c}.jsonl','w',encoding='utf-8') for c in CONDITIONS}
    try:
        for c_idx,condition in enumerate(CONDITIONS):
            for rep in range(5):
                for t_idx,task in enumerate(tasks):
                    seed = 330000 + c_idx*100000 + rep*1000 + t_idx
                    ep=run_episode(task,condition,seed)
                    trace_files[condition].write(json.dumps(ep.to_dict(),ensure_ascii=False)+'\n')
                    good=sum(1 for s in ep.spans if s.label==1 and s.kind!='FINAL')
                    bad=sum(1 for s in ep.spans if s.label==-1 and s.kind!='FINAL')
                    neutral=sum(1 for s in ep.spans if s.label==0)
                    denom=max(1,good+bad+neutral)
                    rows.append({
                        'episode_id':ep.episode_id,'task_id':ep.task_id,'condition':condition,
                        'difficulty':ep.difficulty,'success':int(ep.success),'step_count':len(ep.spans),
                        'error_count':ep.error_count,'neutral_count':neutral,'recovery_count':ep.recovery_count,
                        'redundant_actions':ep.redundant_actions,'first_bad_span':ep.first_bad_span or '',
                        'first_bad_index':ep.first_bad_index or '',
                        'trajectory_quality':round((good - bad)/denom,4),
                        'total_latency_ms':ep.total_latency_ms,'total_cost_units':ep.total_cost_units,
                        'had_process_error':int(ep.error_count>0),
                        'recovered_episode':int(ep.recovery_count>0 and ep.success),
                        'propagated_failure':int(ep.error_count>0 and not ep.success),
                    })
    finally:
        for f in trace_files.values(): f.close()
    with open(RESULTS/'episode_results.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
    print(f'generated {len(rows)} episodes')

if __name__=='__main__': main()
