# Agent Systems 零基础科研教程 · 第34讲

## 主题
第34讲：Agent Reliability & Robustness——从“偶尔成功”到“稳定成功”：Consistency、Perturbation、Recovery 与 Graceful Degradation

## 本讲核心
把“Agent 能否成功一次”升级成“Agent 能否稳定、重复、受扰动、长任务下成功，并在错误后恢复”。重点掌握 Capability vs Reliability、Consistency、pass@k vs pass^k、Robustness、Perturbation、Fault Tolerance、Recovery、Graceful Degradation、Horizon Decay 与 Cost-Matched Baseline。

## 建议学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. `cd Lesson_34/src` 后运行实验
4. 查看 `results/`、`traces/` 与 `figures/`
5. 阅读 `04_实验设计书.docx`
6. 做练习题，再核对答案

## 必做命令
```bash
cd Lesson_34/src
python reliability_lab.py
python analyze_reliability.py
python inspect_failure_trace.py C4_brittle_fast
```

## 已实际运行
生成并分析了 3840 个 episode；结果已写入 CSV/JSON/JSONL。

## 实验性质
**这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、真实 Agent 系统的实际性能。所有故障概率、cost_units 与 latency_ms 都是人为教学参数。**

## 当前资料核对
截至 2026-09-27，本讲核对了 τ-bench（ICLR 2025）、Anthropic 2026 Agent Evals 工程资料、OpenAI 当前 agent workflow evaluation / tracing 文档，以及 2026 年 agent reliability / long-horizon reliability 预印本。预印本在讲义中明确标注，不作为已定论。
