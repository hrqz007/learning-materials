"""Analyze Lesson 34 experiment. Standard library only."""
from __future__ import annotations
import csv, json, math
from collections import defaultdict, Counter
from pathlib import Path
from common.metrics import pass_hat_k, pass_at_k
ROOT=Path(__file__).resolve().parents[1]; RESULTS=ROOT/'results'
rows=[]
with open(RESULTS/'episode_results.csv',encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        r['success']=r['success']=='True'; r['critical_failure']=r['critical_failure']=='True'
        for k in ['horizon','repeat','error_count','detected_count','recovered_count','unresolved_error_count','total_latency_ms']: r[k]=int(r[k])
        r['total_cost_units']=float(r['total_cost_units']); rows.append(r)

def summarize(group):
    n=len(group); succ=sum(x['success'] for x in group); errs=sum(x['error_count'] for x in group); rec=sum(x['recovered_count'] for x in group); det=sum(x['detected_count'] for x in group)
    return {'n':n,'success_rate':succ/n,'mean_errors':sum(x['error_count'] for x in group)/n,'detection_rate_given_error':det/errs if errs else 0.0,'recovery_rate_given_detected':rec/det if det else 0.0,'critical_failure_rate':sum(x['critical_failure'] for x in group)/n,'mean_cost_units':sum(x['total_cost_units'] for x in group)/n,'mean_latency_ms':sum(x['total_latency_ms'] for x in group)/n,'cost_per_success':sum(x['total_cost_units'] for x in group)/succ if succ else float('inf')}

by_cp=defaultdict(list)
for r in rows: by_cp[(r['condition'],r['perturbation'])].append(r)
summary=[]
for (c,p),g in sorted(by_cp.items()):
    s=summarize(g); s.update(condition=c,perturbation=p)
    task_runs=defaultdict(list)
    for x in g: task_runs[x['task_id']].append(x['success'])
    s['pass_hat_4']=sum(pass_hat_k(v) for v in task_runs.values())/len(task_runs)
    s['pass_at_4']=sum(pass_at_k(v) for v in task_runs.values())/len(task_runs)
    summary.append(s)
fields=['condition','perturbation','n','success_rate','pass_hat_4','pass_at_4','mean_errors','detection_rate_given_error','recovery_rate_given_detected','critical_failure_rate','mean_cost_units','mean_latency_ms','cost_per_success']
with open(RESULTS/'condition_perturbation_summary.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(summary)

# horizon curves
hg=defaultdict(list)
for r in rows: hg[(r['condition'],r['perturbation'],r['horizon'])].append(r)
hrows=[]
for (c,p,h),g in sorted(hg.items()):
    s=summarize(g); hrows.append({'condition':c,'perturbation':p,'horizon':h,'n':s['n'],'success_rate':s['success_rate'],'critical_failure_rate':s['critical_failure_rate'],'mean_cost_units':s['mean_cost_units']})
with open(RESULTS/'horizon_curves.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=hrows[0].keys()); w.writeheader(); w.writerows(hrows)

# reliability profile: clean vs stressed mean
profile=[]
for c in sorted({r['condition'] for r in rows}):
    d={s['perturbation']:s for s in summary if s['condition']==c}
    clean=d['clean']['success_rate']; stressed=sum(d[p]['success_rate'] for p in ['tool_noise','schema_drift','mixed'])/3
    clean_p4=d['clean']['pass_hat_4']; stressed_p4=sum(d[p]['pass_hat_4'] for p in ['tool_noise','schema_drift','mixed'])/3
    profile.append({'condition':c,'clean_success':clean,'stressed_success_mean':stressed,'success_drop':clean-stressed,'clean_pass_hat_4':clean_p4,'stressed_pass_hat_4_mean':stressed_p4,'pass_hat_4_drop':clean_p4-stressed_p4,'mean_cost_clean':d['clean']['mean_cost_units'],'mean_cost_stressed':sum(d[p]['mean_cost_units'] for p in ['tool_noise','schema_drift','mixed'])/3})
(RESULTS/'reliability_profile.json').write_text(json.dumps(profile,ensure_ascii=False,indent=2),encoding='utf-8')
with open(RESULTS/'reliability_profile.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=profile[0].keys()); w.writeheader(); w.writerows(profile)

# error severity/type from traces
counts=Counter(); recovered=Counter()
for fp in (RESULTS/'traces').glob('*.jsonl'):
    for line in fp.read_text(encoding='utf-8').splitlines():
        if not line.strip(): continue
        ep=json.loads(line)
        for st in ep['steps']:
            if st['error']:
                counts[(ep['condition'],ep['perturbation'],st['error_type'],st['severity'])]+=1
                if st['recovered']: recovered[(ep['condition'],ep['perturbation'],st['error_type'],st['severity'])]+=1
with open(RESULTS/'failure_type_counts.csv','w',newline='',encoding='utf-8-sig') as f:
    fields=['condition','perturbation','error_type','severity','count','recovered_count']; w=csv.DictWriter(f,fieldnames=fields); w.writeheader()
    for key,n in sorted(counts.items()): w.writerow(dict(zip(fields[:4],key),count=n,recovered_count=recovered[key]))
print(json.dumps(profile,ensure_ascii=False,indent=2))
