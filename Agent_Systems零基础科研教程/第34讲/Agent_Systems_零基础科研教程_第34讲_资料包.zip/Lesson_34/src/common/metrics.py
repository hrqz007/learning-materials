"""Reliability metrics for Lesson 34. Pure standard library."""
from math import prod

def pass_hat_k(outcomes):
    """1.0 only when all k repeated trials succeed; otherwise 0.0 for one task."""
    return 1.0 if outcomes and all(bool(x) for x in outcomes) else 0.0

def pass_at_k(outcomes):
    """1.0 when at least one of k repeated trials succeeds; otherwise 0.0 for one task."""
    return 1.0 if outcomes and any(bool(x) for x in outcomes) else 0.0

def degradation(clean, stressed):
    return clean - stressed

def cost_per_success(total_cost, successes):
    return float('inf') if successes == 0 else total_cost / successes
