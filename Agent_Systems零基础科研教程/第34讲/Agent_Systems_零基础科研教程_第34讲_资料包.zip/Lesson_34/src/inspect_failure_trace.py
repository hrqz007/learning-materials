"""Print one failed trace so a beginner can inspect it."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
condition=sys.argv[1] if len(sys.argv)>1 else 'C4_brittle_fast'
fp=ROOT/'results'/'traces'/f'{condition}.jsonl'
for line in fp.read_text(encoding='utf-8').splitlines():
    ep=json.loads(line)
    if not ep['success'] and ep['perturbation']!='clean':
        print('='*72)
        print('episode:',ep['episode_id'])
        print('task/horizon:',ep['task_id'],ep['horizon'],'perturbation:',ep['perturbation'])
        print('success:',ep['success'],'critical_failure:',ep['critical_failure'])
        print('errors/detected/recovered:',ep['error_count'],ep['detected_count'],ep['recovered_count'])
        for s in ep['steps']:
            flag='ERROR' if s['error'] else 'OK'
            print(f"step={s['step']:02d} {flag:5s} type={s['error_type']} severity={s['severity']} detected={s['detected']} recovered={s['recovered']}")
        break
