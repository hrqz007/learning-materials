"""Regenerate the five result figures for Lesson 34 from saved CSV/JSON files.
Requires matplotlib. It does not rerun the simulator.
"""
from pathlib import Path
import csv, json
import matplotlib.pyplot as plt

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'results'; FIG=ROOT/'figures'
plt.rcParams['font.sans-serif']=['Noto Sans CJK JP','DejaVu Sans']
plt.rcParams['axes.unicode_minus']=False

def rows_csv(name):
    with open(RES/name,encoding='utf-8-sig') as f: return list(csv.DictReader(f))
S=rows_csv('condition_perturbation_summary.csv'); H=rows_csv('horizon_curves.csv'); P=json.loads((RES/'reliability_profile.json').read_text(encoding='utf-8'))
conds=['C1_plain','C2_guarded','C3_redundant','C4_brittle_fast']; perts=['clean','tool_noise','schema_drift','mixed']

def get(c,p,key):
    return float(next(r for r in S if r['condition']==c and r['perturbation']==p)[key])

def save(name):
    plt.tight_layout(); plt.savefig(FIG/name,dpi=180,bbox_inches='tight'); plt.close()

for metric,name,title in [('success_rate','actual_success_heatmap.png','实际运行：Success Rate'),('pass_hat_4','actual_pass4_heatmap.png','实际运行：pass^4（4 次必须全部成功）')]:
    mat=[[get(c,p,metric) for p in perts] for c in conds]
    fig,ax=plt.subplots(figsize=(9.8,5.4)); im=ax.imshow(mat,vmin=0,vmax=1,aspect='auto'); ax.set_xticks(range(4),perts); ax.set_yticks(range(4),conds); ax.set_title(title)
    for i in range(4):
        for j in range(4): ax.text(j,i,f'{mat[i][j]:.2f}',ha='center',va='center')
    fig.colorbar(im,ax=ax,label='score'); save(name)

fig,ax=plt.subplots(figsize=(10,5.6))
for c in conds:
    vals=[]
    for h in [4,8,12,16]: vals.append(float(next(r for r in H if r['condition']==c and r['perturbation']=='mixed' and int(r['horizon'])==h)['success_rate']))
    ax.plot([4,8,12,16],vals,marker='o',label=c)
ax.set_xlabel('Task Horizon'); ax.set_ylabel('Success under mixed stress'); ax.set_ylim(0,1.02); ax.grid(alpha=.25); ax.legend(ncol=2); ax.set_title('实际运行：长任务 + mixed stress 下的可靠性衰减'); save('actual_horizon_curves.png')

fig,ax=plt.subplots(figsize=(9.2,5.5))
for p in P:
    ax.scatter(p['mean_cost_stressed'],p['stressed_success_mean'],s=85); ax.text(p['mean_cost_stressed']+.05,p['stressed_success_mean'],p['condition'],fontsize=9)
ax.set_xlabel('Mean cost_units under stress'); ax.set_ylabel('Mean stressed success'); ax.set_ylim(0,1.02); ax.grid(alpha=.25); ax.set_title('实际运行：Reliability - Cost Trade-off'); save('actual_cost_vs_reliability.png')

fig,ax=plt.subplots(figsize=(9.2,5.3)); vals=[get(c,'mixed','recovery_rate_given_detected') for c in conds]; ax.bar(conds,vals); ax.set_ylim(0,1.02); ax.set_ylabel('Recovery | Detected Error'); ax.set_title('实际运行：检测到错误以后，系统能否恢复？'); ax.tick_params(axis='x',rotation=15); save('actual_recovery_rate.png')
print('Regenerated result figures in',FIG)
