# 可选真实 Agent 实验（非必做）

本讲核心实验完全不需要 API Key。真实 API 版本只用于把本讲指标迁移到你的真实 Agent。

建议记录：模型精确版本/日期、task、perturbation、harness、tool schema、environment snapshot、seed/temperature、完整 trace、success、cost、latency、retry/recovery。

截至 2026-09-27 可参考：
- OpenAI agent workflow evaluation: https://developers.openai.com/api/docs/guides/agent-evals
- OpenAI tracing: https://developers.openai.com/api/docs/guides/agents-api/tracing
- OpenAI deprecations（注意旧 Evals 平台处于迁移/弃用阶段）: https://developers.openai.com/api/docs/deprecations
- Anthropic, Demystifying evals for AI agents: https://www.anthropic.com/engineering/demystifying-evals-for-ai-agents

原则：不要为了跑框架而改变科研问题。先固定 task/environment/harness，再做 perturbation 与 repeated trials。
