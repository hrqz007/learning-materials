"""Lesson 34 controlled teaching simulation.

This is NOT a benchmark of any real model. Probabilities are manually selected so
students can observe capability/reliability divergence, long-horizon decay,
perturbation sensitivity, recovery, and cost trade-offs.
"""
from __future__ import annotations
import csv, hashlib, json, random
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; RESULTS=ROOT/'results'; TRACES=RESULTS/'traces'
RESULTS.mkdir(exist_ok=True); TRACES.mkdir(exist_ok=True)

CFG=json.loads((DATA/'config.json').read_text(encoding='utf-8'))
CONDS=CFG['conditions']; PERT=CFG['perturbations']; REPEATS=CFG['repeats_per_task']
TASKS=[json.loads(x) for x in (DATA/'tasks.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]

def seed_of(*xs):
    s='|'.join(map(str,xs)).encode('utf-8')
    return int(hashlib.sha256(s).hexdigest()[:16],16)%(2**32)

def severity_weights(perturbation):
    if perturbation=='schema_drift': return (['minor','major','critical'],[0.35,0.45,0.20])
    if perturbation=='tool_noise': return (['minor','major','critical'],[0.60,0.32,0.08])
    if perturbation=='mixed': return (['minor','major','critical'],[0.45,0.40,0.15])
    return (['minor','major','critical'],[0.55,0.35,0.10])

def error_type(perturbation,rng):
    if perturbation=='tool_noise': return 'noisy_tool_result'
    if perturbation=='schema_drift': return 'argument_schema_mismatch'
    if perturbation=='mixed': return rng.choice(['noisy_tool_result','argument_schema_mismatch','timeout','decision_error'])
    return rng.choice(['decision_error','tool_selection_error','argument_error'])

def run_episode(task,condition,perturbation,repeat_idx):
    c=CONDS[condition]; rng=random.Random(seed_of(task['task_id'],condition,perturbation,repeat_idx))
    steps=[]; unresolved=[]; errors=detected=recovered=0; total_cost=0.0; total_latency=0
    for i in range(task['horizon']):
        cost=c['base_cost']+c['check_cost']; latency=int(85+25*c['check_cost']+rng.randint(0,35))
        total_cost+=cost; total_latency+=latency
        p_error=c['base_error']+PERT[perturbation]*c['stress_sensitivity']
        has_error=rng.random()<p_error
        rec=False; det=False; sev=None; et=None
        if has_error:
            errors+=1; names,weights=severity_weights(perturbation); sev=rng.choices(names,weights=weights,k=1)[0]; et=error_type(perturbation,rng)
            det=rng.random()<c['detect']
            if det:
                detected+=1; total_cost+=0.18; total_latency+=rng.randint(10,35)
                if rng.random()<c['recover']:
                    rec=True; recovered+=1; total_cost+=0.35; total_latency+=rng.randint(20,55)
                else: unresolved.append(sev)
            else: unresolved.append(sev)
        steps.append({'step':i+1,'error':has_error,'error_type':et,'severity':sev,'detected':det,'recovered':rec,'cost_units':round(cost,3),'latency_ms':latency})
    fail=False; critical_failure=False
    for sev in unresolved:
        pf={'minor':0.35,'major':0.85,'critical':1.0}[sev]
        if rng.random()<pf:
            fail=True
            if sev=='critical': critical_failure=True
    success=not fail
    return {
      'episode_id':f"{task['task_id']}__{condition}__{perturbation}__r{repeat_idx}",
      'task_id':task['task_id'],'domain':task['domain'],'horizon':task['horizon'],
      'condition':condition,'perturbation':perturbation,'repeat':repeat_idx,
      'success':success,'error_count':errors,'detected_count':detected,'recovered_count':recovered,
      'unresolved_error_count':len(unresolved),'critical_failure':critical_failure,
      'total_cost_units':round(total_cost,3),'total_latency_ms':total_latency,'steps':steps}

def main():
    all_rows=[]; files={c:open(TRACES/f'{c}.jsonl','w',encoding='utf-8') for c in CONDS}
    try:
        for condition in CONDS:
            for perturbation in PERT:
                for task in TASKS:
                    for r in range(REPEATS):
                        ep=run_episode(task,condition,perturbation,r); files[condition].write(json.dumps(ep,ensure_ascii=False)+'\n')
                        flat={k:v for k,v in ep.items() if k!='steps'}; all_rows.append(flat)
    finally:
        for f in files.values(): f.close()
    fields=list(all_rows[0].keys())
    with open(RESULTS/'episode_results.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(all_rows)
    print(f'Generated {len(all_rows)} episodes into {RESULTS}')
if __name__=='__main__': main()
