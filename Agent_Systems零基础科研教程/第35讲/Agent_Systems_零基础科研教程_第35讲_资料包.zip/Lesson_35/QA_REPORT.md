# 第35讲交付前 QA 报告

检查日期：2026-09-27

## 1. Python 源码
- `python -m py_compile security_lab.py analyze_security.py inspect_security_trace.py common/metrics.py`：通过。
- 从资料包目录实际运行 `security_lab.py`：通过，生成 3840 个受控教学 episode。
- 实际运行 `analyze_security.py`：通过。
- 实际读取 executed / blocked 两类 JSONL Trace：通过。
- 结果行数：`episode_results.csv` 3840 行数据；4 个 strategy trace 文件各 960 条。

## 2. DOCX 渲染与逐页检查
使用官方 DOCX 渲染脚本重新渲染并逐页检查：
- `01_零基础讲义.docx`：10 页，通过。
- `03_实验指导书.docx`：3 页，通过。
- `04_实验设计书.docx`：3 页，通过。
- `05_练习题.docx`：1 页，通过。
- `06_练习题答案.docx`：2 页，通过。
- `07_术语速查表.docx`：1 页，通过；已消除原先仅剩一行的尾页。

检查项：无文字/图片裁切，无重叠，无缺字；表格行未被不合理拆分；无空白尾页；页脚均为“第35讲”。

## 3. PDF 独立检查
- `02_零基础讲义.pdf` 由最终 DOCX 重新转换，A4，10 页。
- 使用独立 PDF renderer 以 160 DPI 渲染 10 页并逐页检查：通过。
- `pdffonts` 检查：Noto Sans CJK SC 中文字体已嵌入；中文显示正常。

## 4. 题号与结构
- 练习题题号：1-18 连续、无重复。
- 练习题答案题号：1-18 连续、无重复。
- DOCX 页脚检查：全部为第35讲，无第34讲残留。

## 5. 实验性质
实验为完全本地、无 API Key、无 GPU、无真实副作用的受控教学模拟。所有概率和性能数字均为人为教学参数；不代表 GPT / Claude / Gemini 或任何真实 Agent 产品性能。

## 6. 最终结论
交付前检查通过。
