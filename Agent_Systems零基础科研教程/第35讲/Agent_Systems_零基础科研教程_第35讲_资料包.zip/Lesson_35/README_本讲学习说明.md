# Agent Systems 零基础科研教程 · 第35讲

## 主题
第35讲：Agent Safety & Security——Prompt Injection、Tool Abuse、权限边界、Data Leakage 与 Defense in Depth

## 本讲核心
从 Agent Reliability 进一步进入 Safety & Security：重点掌握 Threat Model、Attack Surface、Direct/Indirect Prompt Injection、Least Privilege、Tool Abuse、Authorization、Data Leakage、Memory Poisoning、Defense in Depth，以及如何用 Trace 区分 Attack Adoption → Unsafe Attempt → Block → Recovery → Attack Success。

## 建议学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 进入 `Lesson_35/src` 运行实验
4. 查看 `results/` 与 `results/traces/`
5. 阅读 `04_实验设计书.docx`
6. 做练习题，再核对答案

## 必做命令
```bash
cd Lesson_35/src
python security_lab.py
python analyze_security.py
python inspect_security_trace.py executed S1_naive
python inspect_security_trace.py blocked S4_layered
```

## 已实际运行
本资料包生成并分析了 **3840 个 episode**，完整 CSV/JSON/JSONL 结果已经包含在 `results/`。

## 实验性质
**这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、真实 Agent 产品的实际安全性能。所有攻击采纳概率、防御拦截概率、成本和延迟参数均为人为教学参数；实验中的“高风险工具”只是无真实副作用的字符串标签。**

## 当前资料核对
截至 2026-09-27，本讲核对了 AgentDojo、ToolEmu、Agent Security Bench，以及 OpenAI 当前 Agents SDK Guardrails、Anthropic 2025-2026 prompt-injection / trustworthy-agents / containment 官方资料、MCP 2026-07-28 authorization hardening。讲义中已区分正式会议论文、预印本和工业官方资料。
