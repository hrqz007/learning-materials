"""Analyze Lesson 35 controlled simulation. Standard library only."""
from __future__ import annotations
import csv, json
from collections import defaultdict, Counter
from pathlib import Path
from common.metrics import safe_div
ROOT=Path(__file__).resolve().parents[1]; RESULTS=ROOT/'results'
rows=[]
with open(RESULTS/'episode_results.csv',encoding='utf-8-sig') as f:
    for r in csv.DictReader(f):
        for k in ['attack_present','attack_adopted','unsafe_action_attempt','content_guard_block','authorization_block','confirmation_block','blocked_attack','recovered','false_block','attack_success','policy_violation','task_success']:
            r[k]=r[k]=='True'
        for k in ['repeat','blast_radius_units','propagation_depth','latency_ms']: r[k]=int(r[k])
        r['cost_units']=float(r['cost_units']); rows.append(r)

def summary(group):
    n=len(group); attacks=sum(x['attack_present'] for x in group); adopted=sum(x['attack_adopted'] for x in group); attempts=sum(x['unsafe_action_attempt'] for x in group)
    return {
      'n':n,'task_success_rate':safe_div(sum(x['task_success'] for x in group),n),
      'attack_success_rate':safe_div(sum(x['attack_success'] for x in group),attacks),
      'attack_adoption_rate':safe_div(adopted,attacks),
      'unsafe_attempt_rate':safe_div(attempts,attacks),
      'content_guard_block_rate':safe_div(sum(x['content_guard_block'] for x in group),attacks),
      'blocked_attack_rate_given_attempt':safe_div(sum((x['authorization_block'] or x['confirmation_block']) for x in group),attempts),
      'recovery_rate_given_block':safe_div(sum(x['recovered'] for x in group),sum(x['blocked_attack'] for x in group)),
      'false_block_rate':safe_div(sum(x['false_block'] for x in group),sum(not x['attack_present'] for x in group)),
      'policy_violation_rate':safe_div(sum(x['policy_violation'] for x in group),n),
      'mean_blast_radius':safe_div(sum(x['blast_radius_units'] for x in group),sum(x['attack_success'] for x in group)),
      'mean_cost_units':sum(x['cost_units'] for x in group)/n,'mean_latency_ms':sum(x['latency_ms'] for x in group)/n
    }
by=defaultdict(list)
for r in rows: by[(r['strategy'],r['condition'])].append(r)
out=[]
for (s,c),g in sorted(by.items()):
    z=summary(g); z.update(strategy=s,condition=c); out.append(z)
fields=['strategy','condition','n','task_success_rate','attack_success_rate','attack_adoption_rate','unsafe_attempt_rate','content_guard_block_rate','blocked_attack_rate_given_attempt','recovery_rate_given_block','false_block_rate','policy_violation_rate','mean_blast_radius','mean_cost_units','mean_latency_ms']
with open(RESULTS/'strategy_condition_summary.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(out)

# Aggregate security/utility profile across attack conditions
profiles=[]
for s in sorted({r['strategy'] for r in rows}):
    clean=next(z for z in out if z['strategy']==s and z['condition']=='clean')
    attack=[z for z in out if z['strategy']==s and z['condition']!='clean']
    profiles.append({
      'strategy':s,'clean_task_success':clean['task_success_rate'],
      'attack_task_success_mean':sum(z['task_success_rate'] for z in attack)/len(attack),
      'attack_success_rate_mean':sum(z['attack_success_rate'] for z in attack)/len(attack),
      'unsafe_attempt_rate_mean':sum(z['unsafe_attempt_rate'] for z in attack)/len(attack),
      'blocked_attack_rate_mean':sum(z['blocked_attack_rate_given_attempt'] for z in attack)/len(attack),
      'recovery_rate_mean':sum(z['recovery_rate_given_block'] for z in attack)/len(attack),
      'clean_false_block_rate':clean['false_block_rate'],
      'mean_attack_cost':sum(z['mean_cost_units'] for z in attack)/len(attack)
    })
with open(RESULTS/'security_utility_profile.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=profiles[0].keys()); w.writeheader(); w.writerows(profiles)
(RESULTS/'security_utility_profile.json').write_text(json.dumps(profiles,ensure_ascii=False,indent=2),encoding='utf-8')

# First bad span and propagation
span_counts=Counter(); prop=defaultdict(list)
for r in rows:
    if r['attack_present'] and r['first_bad_span']:
        span_counts[(r['strategy'],r['first_bad_span'])]+=1
    if r['attack_present'] and r['attack_adopted']:
        prop[r['strategy']].append(r['propagation_depth'])
with open(RESULTS/'first_bad_span_counts.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['strategy','first_bad_span','count'])
    for (s,b),n in sorted(span_counts.items()): w.writerow([s,b,n])
with open(RESULTS/'propagation_summary.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.writer(f); w.writerow(['strategy','n_adopted','mean_propagation_depth'])
    for s,v in sorted(prop.items()): w.writerow([s,len(v),sum(v)/len(v) if v else 0])
print(json.dumps(profiles,ensure_ascii=False,indent=2))
