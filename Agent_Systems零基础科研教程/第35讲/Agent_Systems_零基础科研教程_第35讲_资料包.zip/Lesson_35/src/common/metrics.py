"""Lesson 35 metrics. Standard library only."""
def safe_div(a,b):
    return 0.0 if not b else a/b

def security_utility_score(benign_success, attack_success_rate, weight=1.0):
    """Teaching-only combined score. Do NOT use as a universal real-world metric."""
    return benign_success - weight*attack_success_rate
