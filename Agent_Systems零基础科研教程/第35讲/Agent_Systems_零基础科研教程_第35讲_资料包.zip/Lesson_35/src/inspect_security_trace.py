"""Print one successful attack and one blocked attack trace."""
from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
mode=sys.argv[1] if len(sys.argv)>1 else 'executed'
strategy=sys.argv[2] if len(sys.argv)>2 else ('S1_naive' if mode=='executed' else 'S4_layered')
fp=ROOT/'results'/'traces'/f'{strategy}.jsonl'
for line in fp.read_text(encoding='utf-8').splitlines():
    ep=json.loads(line)
    wanted=(mode=='executed' and ep['attack_success']) or (mode=='blocked' and ep['blocked_attack'] and not ep['attack_success'])
    if wanted:
        print('='*78); print('episode:',ep['episode_id']); print('task:',ep['task_id'],'condition:',ep['condition'],'strategy:',ep['strategy'])
        print('task_success:',ep['task_success'],'attack_success:',ep['attack_success'],'blocked:',ep['blocked_attack'],'recovered:',ep['recovered'])
        print('first_bad_span:',ep['first_bad_span'],'propagation_depth:',ep['propagation_depth'],'blast_radius:',ep['blast_radius_units'])
        for s in ep['spans']:
            print(f"span={s['span']:02d} {s['name']:27s} status={s['status']:11s} detail={s['detail']}")
        break
