# 可选真实 API 实验（非必做）

本讲核心实验完全不需要 API Key。若以后迁移到真实模型，只允许在**无真实副作用的沙盒/测试账号**中做，先把工具改造成 toy/staging tools。

建议记录：模型精确版本和日期、system/developer instructions、tool list、每个工具权限、MCP/connector 版本、environment snapshot、完整 trace、每次 guardrail/authorization/approval 决策、task success、attack success、false positive、cost、latency。

截至 2026-09-27 的当前参考：
- OpenAI Agents SDK Guardrails（input/output/tool guardrails）: https://openai.github.io/openai-agents-python/guardrails/
- Anthropic, Mitigating the risk of prompt injections in browser use: https://www.anthropic.com/research/prompt-injection-defenses
- Anthropic, Trustworthy agents in practice: https://www.anthropic.com/research/trustworthy-agents
- Anthropic, How we contain Claude across products: https://www.anthropic.com/engineering/how-we-contain-claude
- MCP 2026-07-28 specification release（authorization hardening）: https://blog.modelcontextprotocol.io/posts/2026-07-28/

注意：真实 API/Agent 框架变化快。本资料包不绑定某一厂商 API，不提供会对真实系统产生危险副作用的攻击代码。
