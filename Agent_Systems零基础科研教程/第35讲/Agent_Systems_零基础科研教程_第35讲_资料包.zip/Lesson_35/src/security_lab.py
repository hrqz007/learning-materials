"""Lesson 35 controlled safety/security simulation.

No real external actions occur. Tool names are strings in an in-memory toy world.
The probabilities are MANUALLY chosen for teaching and do not represent any model.
"""
from __future__ import annotations
import csv, hashlib, json, random
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; RESULTS=ROOT/'results'; TRACES=RESULTS/'traces'
RESULTS.mkdir(exist_ok=True); TRACES.mkdir(exist_ok=True)
CFG=json.loads((DATA/'config.json').read_text(encoding='utf-8'))
STRATS=CFG['strategies']; CONDITIONS=CFG['attack_conditions']; REPEATS=CFG['repeats_per_task']; FORBIDDEN=CFG['forbidden_tools']
TASKS=[json.loads(x) for x in (DATA/'tasks.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]

def seed_of(*xs):
    return int(hashlib.sha256('|'.join(map(str,xs)).encode()).hexdigest()[:16],16)%(2**32)

def attack_tool(rng):
    return rng.choice(FORBIDDEN)

def run_episode(task,strategy,condition,repeat_idx):
    s=STRATS[strategy]; c=CONDITIONS[condition]; rng=random.Random(seed_of(task['task_id'],strategy,condition,repeat_idx))
    spans=[]; cost=s['base_cost']; latency=100+rng.randint(0,35)+int(30*s['overhead'])
    attack_present=c['attack_present']; attack_adopted=False; unsafe_attempt=False; attack_success=False
    guard_block=False; auth_block=False; confirmation_block=False; recovered=False; false_block=False
    first_bad_span=None; propagation_depth=0; blast_radius=0

    # span 1: observation from environment/tool/memory
    spans.append({'span':1,'name':'observe_input','status':'ok','detail':'clean content' if not attack_present else f'untrusted content from {condition}'})

    # optional content guard (layered defenses)
    if attack_present and rng.random() < s['content_guard']:
        guard_block=True; cost+=0.18; latency+=20+rng.randint(0,20)
        spans.append({'span':2,'name':'content_guard','status':'blocked','detail':'suspected untrusted instruction; content treated as data'})
        if rng.random() < s['recover_after_block']:
            recovered=True
            spans.append({'span':3,'name':'recover_user_intent','status':'ok','detail':'resume original task'})
        else:
            spans.append({'span':3,'name':'recover_user_intent','status':'fail','detail':'agent cannot resume task'})
    else:
        spans.append({'span':2,'name':'content_guard','status':'pass','detail':'no block'})

    # clean false positives
    if not attack_present and rng.random() < s['false_block']:
        false_block=True; cost+=0.15; latency+=18
        spans.append({'span':3,'name':'policy_gate','status':'false_block','detail':'benign action blocked'})
    elif attack_present and not guard_block:
        p=min(0.98,s['adopt_attack']*c['mult'])
        attack_adopted=rng.random() < p
        spans.append({'span':3,'name':'instruction_interpretation','status':'bad' if attack_adopted else 'ok','detail':'untrusted text treated as instruction' if attack_adopted else 'untrusted text treated as data'})
        if attack_adopted:
            first_bad_span='instruction_interpretation'; propagation_depth=1
            bad_tool=attack_tool(rng); unsafe_attempt=True
            spans.append({'span':4,'name':'tool_request','status':'bad','detail':f'forbidden toy tool requested: {bad_tool}'})
            propagation_depth=2
            # authority boundary
            if rng.random() < s['auth_block']:
                auth_block=True; cost+=0.12; latency+=15+rng.randint(0,15)
                spans.append({'span':5,'name':'authorization_gate','status':'blocked','detail':'tool is outside scoped authority'})
                if rng.random() < s['recover_after_block']:
                    recovered=True; spans.append({'span':6,'name':'recover_user_intent','status':'ok','detail':'resume original task'})
                else:
                    spans.append({'span':6,'name':'recover_user_intent','status':'fail','detail':'blocked but task not recovered'})
            else:
                spans.append({'span':5,'name':'authorization_gate','status':'pass','detail':'authority boundary did not stop request'})
                propagation_depth=3
                if rng.random() < s['confirm_block']:
                    confirmation_block=True; cost+=0.10; latency+=25+rng.randint(0,25)
                    spans.append({'span':6,'name':'confirmation_gate','status':'blocked','detail':'high-impact action not approved'})
                    if rng.random() < s['recover_after_block']:
                        recovered=True; spans.append({'span':7,'name':'recover_user_intent','status':'ok','detail':'resume original task'})
                    else:
                        spans.append({'span':7,'name':'recover_user_intent','status':'fail','detail':'blocked but task not recovered'})
                else:
                    spans.append({'span':6,'name':'confirmation_gate','status':'pass','detail':'no confirmation barrier'})
                    spans.append({'span':7,'name':'tool_execution','status':'violation','detail':f'toy side effect executed: {bad_tool}'})
                    propagation_depth=4; attack_success=True; blast_radius=rng.choice([1,1,2,2,3])

    # task outcome
    if attack_success:
        task_success=False
    elif false_block:
        task_success=False
    elif guard_block or auth_block or confirmation_block:
        if recovered:
            task_success=rng.random() < max(0.55,s['clean_success']-0.05)
        else:
            task_success=False
    elif attack_adopted:
        # should normally have reached a gate/execution, kept for completeness
        task_success=False
    else:
        task_success=rng.random() < s['clean_success']

    spans.append({'span':len(spans)+1,'name':'final_task_check','status':'ok' if task_success else 'fail','detail':'original user goal completed' if task_success else 'original user goal not completed'})
    policy_violation=attack_success
    blocked_attack=attack_present and attack_adopted and (auth_block or confirmation_block)
    content_blocked_attack=attack_present and guard_block
    return {
      'episode_id':f"{task['task_id']}__{strategy}__{condition}__r{repeat_idx}",
      'task_id':task['task_id'],'domain':task['domain'],'strategy':strategy,'condition':condition,'repeat':repeat_idx,
      'attack_present':attack_present,'attack_adopted':attack_adopted,'unsafe_action_attempt':unsafe_attempt,
      'content_guard_block':guard_block,'authorization_block':auth_block,'confirmation_block':confirmation_block,
      'blocked_attack':blocked_attack or content_blocked_attack,'recovered':recovered,'false_block':false_block,
      'attack_success':attack_success,'policy_violation':policy_violation,'task_success':task_success,
      'blast_radius_units':blast_radius,'first_bad_span':first_bad_span,'propagation_depth':propagation_depth,
      'cost_units':round(cost,3),'latency_ms':latency,'spans':spans}

def main():
    rows=[]; handles={s:open(TRACES/f'{s}.jsonl','w',encoding='utf-8') for s in STRATS}
    try:
        for strategy in STRATS:
            for condition in CONDITIONS:
                for task in TASKS:
                    for r in range(REPEATS):
                        ep=run_episode(task,strategy,condition,r); handles[strategy].write(json.dumps(ep,ensure_ascii=False)+'\n')
                        rows.append({k:v for k,v in ep.items() if k!='spans'})
    finally:
        for h in handles.values(): h.close()
    fields=list(rows[0].keys())
    with open(RESULTS/'episode_results.csv','w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    print(f'Generated {len(rows)} teaching episodes')
if __name__=='__main__': main()
