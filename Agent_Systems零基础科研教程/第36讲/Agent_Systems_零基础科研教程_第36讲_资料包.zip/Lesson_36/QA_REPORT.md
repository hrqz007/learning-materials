# QA REPORT - Lesson 36

Date: 2026-09-27

- Core Python syntax check: PASS (9 `.py` files compiled; optional real-API file syntax-only, not executed).
- Controlled experiment execution: PASS.
- Episode count: 3840; unique episode IDs: 3840.
- JSONL Trace count: 3840.
- Deterministic rerun: PASS (key result file SHA-256 values unchanged after rerun).
- Scaling curve generation: PASS (12 rows: 2 topologies × 6 agent counts).
- Token-matched comparison generation: PASS (4 target strategies).
- DOCX render QA: PASS. Page counts: main=10, lab=3, formal design=3, questions=1, answers=2, glossary=2. All rendered pages visually inspected; no clipping/overlap/missing Chinese glyphs observed.
- PDF independent render QA: PASS. Main PDF=10 pages; all pages visually inspected.
- Chinese font check: PASS (`NotoSansCJKsc` embedded in PDF).
- Figure crop check: PASS.
- Table page-break check: PASS; no table row is visibly split across pages.
- Blank tail-page check: PASS; no completely blank trailing page.
- Exercise numbering: PASS (1-18 exactly once).
- Footer check: PASS (`第36讲`, no stale `第35讲`).
- Safety/epistemic labeling: PASS; all synthetic performance/cost/latency results are labeled as controlled teaching simulation.
- Real API code: NOT RUN by design (requires user key and real cost); current SDK usage example is syntax-checked only.
- ZIP integrity: PASS (final ZIP CRC-tested, extracted, and core experiment rerun from extracted copy).
