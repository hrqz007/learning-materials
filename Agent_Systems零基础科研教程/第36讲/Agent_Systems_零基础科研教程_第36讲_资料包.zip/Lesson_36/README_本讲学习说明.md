# Agent Systems 零基础科研教程 · 第36讲

## 主题
第36讲：Agent Efficiency & Scalability——Cost、Token、Latency、Concurrency 与 Compute-Matched Evaluation

## 本讲核心
本讲从“系统能不能完成任务”进一步进入“系统为了完成任务花了多少资源，以及这些资源是否被有效利用”。核心包括 Cost、Token、Model Calls、Latency、p95/p99、Throughput、Concurrency、Critical Path、Diminishing Returns、Pareto Frontier、Agent-count scaling，以及 Compute/Token/Cost-Matched Baseline。

## 建议学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 进入 `Lesson_36/src` 运行实验
4. 查看 `results/` 与 `results/traces/`
5. 阅读 `04_实验设计书.docx`
6. 做练习题，再核对答案

## 必做命令
```bash
cd Lesson_36/src
python efficiency_lab.py
python analyze_efficiency.py
python scaling_curve.py
python token_matched_baseline.py
python inspect_efficiency_trace.py S3_parallel3 api_jitter hard
```

## 已实际运行
本资料包核心实验生成 **3840 个 episode**，并生成 Agent-count scaling 与 Token-Matched 对照结果。完整 CSV/JSON/JSONL Trace 已包含在 `results/`。

## 实验性质
**这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、真实 Agent 产品的实际性能、成本或延迟。成功概率、Token、服务时延、排队和通信参数均为人为教学参数；它们只用于理解实验设计与系统机制。**

## 可选真实 API
`src/optional_real_api/openai_agents_usage_example.py` 使用 2026-09-27 OpenAI Agents SDK 官方 `result.context_wrapper.usage` 接口示例。资料包只做语法检查，不会自动调用真实 API 或产生费用。

## 当前资料核对
截至 2026-09-27，本讲核对 OpenAI Agents SDK Usage / Tracing 官方文档，并参考 2024-2026 关于 Agent test-time compute、multi-agent scaling、diversity 与效率的公开研究。预印本与 OpenReview 投稿状态均在讲义中明确标注。
