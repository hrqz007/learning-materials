"""Analyze Lesson 36 controlled experiment."""
from __future__ import annotations
import csv,json,statistics
from collections import defaultdict
from pathlib import Path
from common.metrics import safe_div, percentile
ROOT=Path(__file__).resolve().parents[1]; R=ROOT/'results'
rows=list(csv.DictReader(open(R/'episode_results.csv',encoding='utf-8-sig')))
num=['task_success','model_calls','tool_calls','input_tokens','output_tokens','communication_tokens','total_tokens','cost_proxy','latency_ms','max_parallel_width','retry_count','redundant_actions','timed_out','horizon']
for r in rows:
    for k in num: r[k]=float(r[k])

def aggregate(key_fields, out_name):
    g=defaultdict(list)
    for r in rows: g[tuple(r[k] for k in key_fields)].append(r)
    out=[]
    for key,rs in sorted(g.items()):
        succ=sum(x['task_success'] for x in rs)
        rec={k:v for k,v in zip(key_fields,key)}
        rec.update({'n':len(rs),'task_success':succ/len(rs),'mean_total_tokens':statistics.mean(x['total_tokens'] for x in rs),'mean_model_calls':statistics.mean(x['model_calls'] for x in rs),'mean_cost_proxy':statistics.mean(x['cost_proxy'] for x in rs),'mean_latency_ms':statistics.mean(x['latency_ms'] for x in rs),'p50_latency_ms':percentile([x['latency_ms'] for x in rs],0.5),'p95_latency_ms':percentile([x['latency_ms'] for x in rs],0.95),'p99_latency_ms':percentile([x['latency_ms'] for x in rs],0.99),'mean_comm_tokens':statistics.mean(x['communication_tokens'] for x in rs),'tokens_per_success':safe_div(sum(x['total_tokens'] for x in rs),succ),'cost_per_success':safe_div(sum(x['cost_proxy'] for x in rs),succ)})
        out.append(rec)
    fields=list(out[0])
    with open(R/out_name,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(out)
    return out
summ=aggregate(['strategy','condition'],'strategy_condition_summary.csv')
diff=aggregate(['strategy','difficulty'],'strategy_difficulty_summary.csv')
# Overall profile
prof=aggregate(['strategy'],'strategy_profile.csv')
(R/'strategy_profile.json').write_text(json.dumps(prof,ensure_ascii=False,indent=2),encoding='utf-8')
# Latency decomposition from traces would require span parsing; keep summary here.
print('strategy profiles:')
for x in prof:
    print(x['strategy'], 'success',round(x['task_success'],3),'tokens',round(x['mean_total_tokens'],0),'p95ms',round(x['p95_latency_ms'],0),'cost/success',round(x['cost_per_success'],2))
