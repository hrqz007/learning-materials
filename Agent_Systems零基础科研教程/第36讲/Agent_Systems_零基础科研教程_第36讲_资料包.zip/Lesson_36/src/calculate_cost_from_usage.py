"""Convert token usage to a currency cost after YOU fill current official prices.
No provider/model price is hardcoded because prices change.
"""
from __future__ import annotations
import json,sys
from pathlib import Path
root=Path(__file__).resolve().parents[1]
pricing=json.loads((root/'data'/'pricing_template.json').read_text(encoding='utf-8'))
in_tok=int(sys.argv[1]) if len(sys.argv)>1 else 100000
out_tok=int(sys.argv[2]) if len(sys.argv)>2 else 20000
pi=float(pricing['input_price_per_million_tokens']); po=float(pricing['output_price_per_million_tokens'])
cost=in_tok/1_000_000*pi+out_tok/1_000_000*po
print({'input_tokens':in_tok,'output_tokens':out_tok,'estimated_cost':cost,'pricing':pricing})
