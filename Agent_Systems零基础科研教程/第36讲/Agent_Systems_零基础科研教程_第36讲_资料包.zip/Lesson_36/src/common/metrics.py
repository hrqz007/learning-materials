"""Lesson 36 helper metrics. Standard library only."""
from math import ceil

def safe_div(a,b):
    return 0.0 if not b else a/b

def percentile(values,p):
    xs=sorted(values)
    if not xs:
        return 0.0
    if len(xs)==1:
        return float(xs[0])
    k=(len(xs)-1)*p
    lo=int(k); hi=min(lo+1,len(xs)-1); frac=k-lo
    return xs[lo]*(1-frac)+xs[hi]*frac

def cost_per_success(total_resource,successes):
    return safe_div(total_resource,successes)
