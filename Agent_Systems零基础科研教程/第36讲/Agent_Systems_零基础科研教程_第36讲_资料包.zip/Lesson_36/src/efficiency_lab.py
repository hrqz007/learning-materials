"""Lesson 36 controlled Agent efficiency/scalability simulation.

This is a teaching simulator. All quality, token, latency and queue parameters are
manual synthetic values. They DO NOT describe any real model/provider.
"""
from __future__ import annotations
import csv, hashlib, json, math, random
from pathlib import Path

ROOT=Path(__file__).resolve().parents[1]
DATA=ROOT/'data'; RESULTS=ROOT/'results'; TRACES=RESULTS/'traces'
RESULTS.mkdir(exist_ok=True); TRACES.mkdir(exist_ok=True)
CFG=json.loads((DATA/'config.json').read_text(encoding='utf-8'))
TASKS=[json.loads(x) for x in (DATA/'tasks.jsonl').read_text(encoding='utf-8').splitlines() if x.strip()]

BASE_SUCCESS={'easy':0.92,'medium':0.76,'hard':0.56}

def seed_of(*xs):
    return int(hashlib.sha256('|'.join(map(str,xs)).encode()).hexdigest()[:16],16)%(2**32)

def model_duration(rng,out_tokens,cond,width=1):
    base=240+0.55*out_tokens
    jitter=max(0.45,rng.lognormvariate(0,cond['jitter']))
    queue=cond['queue_mult']*width*(65+rng.random()*90)
    # rare tail event under api_jitter
    tail=0
    if cond['jitter']>0.3 and rng.random()<0.06:
        tail=900+rng.random()*1600
    return int(base*cond['model_mult']*jitter+queue+tail)

def tool_duration(rng,cond):
    return int((75+rng.random()*75)*cond['tool_mult'])

def model_tokens(rng,task,step,scale=1.0,context_factor=1.0):
    inp=int((520+task['horizon']*32+step*95+rng.randint(-45,70))*scale*context_factor)
    out=int((130+rng.randint(0,120))*scale)
    return max(inp,120),max(out,50)

def add_span(spans,name,kind,start,duration,input_tokens=0,output_tokens=0,parallel_group=None,detail=''):
    spans.append({'span':len(spans)+1,'name':name,'kind':kind,'start_ms':int(start),'end_ms':int(start+duration),'duration_ms':int(duration),'input_tokens':int(input_tokens),'output_tokens':int(output_tokens),'parallel_group':parallel_group,'detail':detail})

def simulate_mode(task,mode,cond,rng):
    spans=[]; calls=0; input_tokens=0; output_tokens=0; tool_calls=0; comm_tokens=0; retries=0; redundant=0
    t=0; h=task['horizon']; max_width=1
    if mode=='single':
        for step in range(h):
            it,ot=model_tokens(rng,task,step)
            d=model_duration(rng,ot,cond,1); add_span(spans,f'reason_{step+1}','model',t,d,it,ot,detail='sequential agent reasoning'); t+=d; calls+=1; input_tokens+=it; output_tokens+=ot
            if step < task['tool_steps']:
                td=tool_duration(rng,cond); add_span(spans,f'tool_{step+1}','tool',t,td,detail='toy tool'); t+=td; tool_calls+=1
    elif mode=='reflect':
        for step in range(h):
            it,ot=model_tokens(rng,task,step)
            d=model_duration(rng,ot,cond,1); add_span(spans,f'reason_{step+1}','model',t,d,it,ot); t+=d; calls+=1; input_tokens+=it; output_tokens+=ot
            # harder/later steps more likely to trigger reflection
            p=0.24+(0.10 if task['difficulty']=='hard' else 0)+(0.08 if step>h*0.6 else 0)
            if rng.random()<p:
                rit,rot=model_tokens(rng,task,step,scale=0.58,context_factor=1.08)
                rd=model_duration(rng,rot,cond,1); add_span(spans,f'reflect_{step+1}','model',t,rd,rit,rot,detail='selective verification/reflection'); t+=rd; calls+=1; input_tokens+=rit; output_tokens+=rot
            if step < task['tool_steps']:
                td=tool_duration(rng,cond); add_span(spans,f'tool_{step+1}','tool',t,td); t+=td; tool_calls+=1
    elif mode=='parallel3':
        max_width=3
        for step in range(h):
            branch_start=t; ends=[]
            for b in range(3):
                it,ot=model_tokens(rng,task,step,scale=0.78,context_factor=1.0)
                d=model_duration(rng,ot,cond,3); add_span(spans,f'candidate_{step+1}_{b+1}','model',branch_start,d,it,ot,parallel_group=f'step{step+1}',detail='parallel candidate'); ends.append(branch_start+d); calls+=1; input_tokens+=it; output_tokens+=ot
            t=max(ends)
            vit,vot=model_tokens(rng,task,step,scale=0.38,context_factor=1.15)
            vd=model_duration(rng,vot,cond,1); add_span(spans,f'vote_{step+1}','model',t,vd,vit,vot,detail='aggregate candidates'); t+=vd; calls+=1; input_tokens+=vit; output_tokens+=vot
            redundant += 2
            if step < task['tool_steps']:
                td=tool_duration(rng,cond); add_span(spans,f'tool_{step+1}','tool',t,td); t+=td; tool_calls+=1
    elif mode=='multiagent':
        max_width=3
        pit,pot=model_tokens(rng,task,0,scale=1.00,context_factor=1.15)
        pd=model_duration(rng,pot,cond,1); add_span(spans,'planner','model',t,pd,pit,pot,detail='planner decomposes task'); t+=pd; calls+=1; input_tokens+=pit; output_tokens+=pot
        planner_end=t
        worker_ends=[]
        steps_per_worker=math.ceil(h/3)
        for w in range(3):
            wt=planner_end
            for j in range(steps_per_worker):
                global_step=w*steps_per_worker+j
                if global_step>=h: break
                it,ot=model_tokens(rng,task,global_step,scale=0.98,context_factor=1.30)
                d=model_duration(rng,ot,cond,3); add_span(spans,f'worker{w+1}_step{j+1}','model',wt,d,it,ot,parallel_group=f'worker{w+1}',detail='worker branch'); wt+=d; calls+=1; input_tokens+=it; output_tokens+=ot
                if global_step < task['tool_steps']:
                    td=tool_duration(rng,cond); add_span(spans,f'worker{w+1}_tool{j+1}','tool',wt,td,parallel_group=f'worker{w+1}'); wt+=td; tool_calls+=1
            worker_ends.append(wt)
        t=max(worker_ends)
        comm_tokens=int(320*3 + 70*task['horizon'])
        comm_d=int(85+0.18*comm_tokens+cond['queue_mult']*160)
        add_span(spans,'communication_merge','communication',t,comm_d,detail='summaries/messages before aggregation'); t+=comm_d
        ait,aot=model_tokens(rng,task,h,scale=0.95,context_factor=1.35)
        ad=model_duration(rng,aot,cond,1); add_span(spans,'aggregator','model',t,ad,ait,aot,detail='aggregate worker outputs'); t+=ad; calls+=1; input_tokens+=ait; output_tokens+=aot
    else:
        raise ValueError(mode)
    total_tokens=input_tokens+output_tokens+comm_tokens
    return {'spans':spans,'model_calls':calls,'input_tokens':input_tokens,'output_tokens':output_tokens,'communication_tokens':comm_tokens,'total_tokens':total_tokens,'tool_calls':tool_calls,'latency_ms':t,'retry_count':retries,'redundant_actions':redundant,'max_parallel_width':max_width}

def quality_probability(task,mode,cond):
    p=BASE_SUCCESS[task['difficulty']]
    horizon_penalty=max(0,task['horizon']-4)*0.010
    gain={'single':0.0,'reflect':0.055,'parallel3':0.105,'multiagent':0.125}[mode]
    # reflection helps hard tasks more; multiagent has coordination penalty on easy tasks
    if mode=='reflect' and task['difficulty']=='hard': gain+=0.025
    if mode=='multiagent' and task['difficulty']=='easy': gain-=0.035
    if mode=='parallel3' and task['difficulty']=='easy': gain-=0.020
    p=p-horizon_penalty+gain-cond['success_penalty']
    return max(0.05,min(0.97,p))

def routed_mode(task):
    if task['difficulty']=='easy': return 'single'
    if task['difficulty']=='medium': return 'reflect'
    return 'multiagent'

def run_episode(task,strategy,condition,repeat_idx):
    rng=random.Random(seed_of(task['task_id'],strategy,condition,repeat_idx))
    cond=CFG['conditions'][condition]
    mode=CFG['strategies'][strategy]['mode']
    chosen=routed_mode(task) if mode=='router' else mode
    m=simulate_mode(task,chosen,cond,rng)
    p=quality_probability(task,chosen,cond)
    # router has small routing error/overhead but avoids universally expensive strategy
    router_overhead_tokens=0; router_overhead_latency=0
    if mode=='router':
        router_overhead_tokens=220+rng.randint(0,90); router_overhead_latency=120+rng.randint(0,80)
        m['input_tokens']+=router_overhead_tokens; m['total_tokens']+=router_overhead_tokens; m['latency_ms']+=router_overhead_latency; m['model_calls']+=1
        if rng.random()<0.04: p-=0.035
        add_span(m['spans'],'router','model',0,router_overhead_latency,router_overhead_tokens,0,detail=f'routed to {chosen}')
    # under severe tail, timeout can make success lower
    timed_out=m['latency_ms']>22000
    success=(rng.random()<p) and not timed_out
    cost_proxy=(m['input_tokens']*1.0+m['output_tokens']*3.0+m['communication_tokens']*0.25)/1000.0
    return {
      'episode_id':f"{task['task_id']}-{strategy}-{condition}-r{repeat_idx}",
      'task_id':task['task_id'],'difficulty':task['difficulty'],'horizon':task['horizon'],'strategy':strategy,'condition':condition,'routed_to':chosen,
      'task_success':int(success),'model_calls':m['model_calls'],'tool_calls':m['tool_calls'],'input_tokens':m['input_tokens'],'output_tokens':m['output_tokens'],'communication_tokens':m['communication_tokens'],'total_tokens':m['total_tokens'],'cost_proxy':round(cost_proxy,3),'latency_ms':m['latency_ms'],'max_parallel_width':m['max_parallel_width'],'retry_count':m['retry_count'],'redundant_actions':m['redundant_actions'],'timed_out':int(timed_out),'spans':m['spans']
    }

rows=[]
trace_files={s:open(TRACES/f'{s}.jsonl','w',encoding='utf-8') for s in CFG['strategies']}
for task in TASKS:
  for strategy in CFG['strategies']:
    for condition in CFG['conditions']:
      for r in range(CFG['repeats_per_task']):
        ep=run_episode(task,strategy,condition,r); rows.append(ep); trace_files[strategy].write(json.dumps(ep,ensure_ascii=False)+'\n')
for f in trace_files.values(): f.close()
fields=[k for k in rows[0] if k!='spans']
with open(RESULTS/'episode_results.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows([{k:r[k] for k in fields} for r in rows])
print(f'generated {len(rows)} episodes')
