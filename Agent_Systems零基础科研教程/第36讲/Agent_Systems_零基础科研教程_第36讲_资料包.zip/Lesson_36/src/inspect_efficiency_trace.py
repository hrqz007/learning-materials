"""Print one readable trace for a strategy/condition/difficulty."""
from __future__ import annotations
import json,sys
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
strategy=sys.argv[1] if len(sys.argv)>1 else 'S3_parallel3'
condition=sys.argv[2] if len(sys.argv)>2 else 'api_jitter'
difficulty=sys.argv[3] if len(sys.argv)>3 else 'hard'
path=ROOT/'results'/'traces'/f'{strategy}.jsonl'
for line in path.read_text(encoding='utf-8').splitlines():
    ep=json.loads(line)
    if ep['condition']==condition and ep['difficulty']==difficulty:
        print('EPISODE',ep['episode_id'],'success=',ep['task_success'],'tokens=',ep['total_tokens'],'latency_ms=',ep['latency_ms'],'routed_to=',ep['routed_to'])
        for s in sorted(ep['spans'],key=lambda x:(x['start_ms'],x['end_ms'],x['span'])):
            print(f"[{s['start_ms']:>6}-{s['end_ms']:<6} ms] {s['kind']:<13} {s['name']:<24} in={s['input_tokens']:<5} out={s['output_tokens']:<4} group={s['parallel_group'] or '-'}")
        break
else:
    print('no matching trace')
