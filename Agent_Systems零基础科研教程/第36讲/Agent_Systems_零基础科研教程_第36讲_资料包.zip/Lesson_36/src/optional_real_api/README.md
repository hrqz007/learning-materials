# 可选真实 API 实验

该目录不是必做。`openai_agents_usage_example.py` 按 2026-09-27 官方 OpenAI Agents SDK 文档的 usage 接口编写。

1. `pip install openai-agents`
2. 设置 `OPENAI_API_KEY`。
3. 可选设置 `OPENAI_MODEL` 为你要固定测试的精确模型版本。
4. 运行脚本并记录 requests / input_tokens / output_tokens / total_tokens。

不要把教学模拟的 cost_proxy 换算成真实美元。若要算真实成本，必须按实验当天官方价格填写 `data/pricing_template.json`。
