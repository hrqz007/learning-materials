"""OPTIONAL real-API example using the current OpenAI Agents SDK usage object.

Requirements:
  pip install openai-agents
  set OPENAI_API_KEY
Optionally set OPENAI_MODEL to the exact model version you want to test.

This file is syntax-checked in the course package but is NOT executed during package QA,
because doing so would require a user's API key and incur real cost.
"""
import asyncio, os
from agents import Agent, Runner

async def main():
    kwargs={}
    if os.getenv('OPENAI_MODEL'):
        kwargs['model']=os.environ['OPENAI_MODEL']
    agent=Agent(name='EfficiencyLabAgent',instructions='Answer concisely. Do not use external tools.',**kwargs)
    result=await Runner.run(agent,'Explain in two sentences why p95 latency matters for an Agent system.')
    usage=result.context_wrapper.usage
    print(result.final_output)
    print({'requests':usage.requests,'input_tokens':usage.input_tokens,'output_tokens':usage.output_tokens,'total_tokens':usage.total_tokens})
    for i,u in enumerate(usage.request_usage_entries,1):
        print('request',i,'in=',u.input_tokens,'out=',u.output_tokens)

if __name__=='__main__':
    asyncio.run(main())
