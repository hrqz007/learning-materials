"""Generate a synthetic scaling curve for homogeneous agents and communication topologies."""
from __future__ import annotations
import csv, hashlib, random, math
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; R=ROOT/'results'; R.mkdir(exist_ok=True)
counts=[1,2,4,8,16,32]
rows=[]
for topo in ['sparse','full_mesh']:
  for n in counts:
    rng=random.Random(int(hashlib.sha256(f'{topo}-{n}'.encode()).hexdigest()[:8],16))
    trials=1200; succ=0; lat=[]
    # synthetic: correlated homogeneous agents have diminishing effective diversity
    eff=1+2.8*(1-math.exp(-(n-1)/4.0))
    p=0.58+0.085*math.log2(eff)
    if n>12: p-=0.008*math.log2(n/12)
    p=max(0.05,min(0.89,p))
    edges=(n-1) if topo=='sparse' else n*(n-1)//2
    comm_tokens=edges*140
    total_tokens=n*3200+comm_tokens
    for _ in range(trials):
      succ += rng.random()<p
      branch=[rng.lognormvariate(math.log(2200),0.24) for _ in range(n)]
      l=max(branch)+260+edges*(10 if topo=='sparse' else 4)
      lat.append(l)
    lat.sort(); p95=lat[int(0.95*(len(lat)-1))]
    rows.append({'topology':topo,'agent_count':n,'success_rate':succ/trials,'mean_total_tokens':total_tokens,'communication_tokens':comm_tokens,'communication_edges':edges,'p95_latency_ms':p95,'marginal_success_per_1k_tokens':''})
# fill marginal within topology
for topo in ['sparse','full_mesh']:
    xs=[r for r in rows if r['topology']==topo]
    prev=None
    for r in xs:
        if prev is not None:
            ds=r['success_rate']-prev['success_rate']; dt=(r['mean_total_tokens']-prev['mean_total_tokens'])/1000
            r['marginal_success_per_1k_tokens']=ds/dt if dt else 0
        prev=r
with open(R/'scaling_curve.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print('scaling rows',len(rows))
