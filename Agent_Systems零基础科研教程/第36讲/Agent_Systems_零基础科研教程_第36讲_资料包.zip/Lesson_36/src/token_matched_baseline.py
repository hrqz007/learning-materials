"""Build a teaching-only token-matched comparison.
It compares expensive strategies to repeated single-agent samples under a similar token budget.
"""
from __future__ import annotations
import csv,random,hashlib,math,statistics
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]; R=ROOT/'results'
prof=list(csv.DictReader(open(R/'strategy_profile.csv',encoding='utf-8-sig')))
p={r['strategy']:r for r in prof}
base_tokens=float(p['S1_single']['mean_total_tokens']); base_success=float(p['S1_single']['task_success'])
rows=[]
for target in ['S2_reflect','S3_parallel3','S4_multiagent','S5_router']:
    target_tokens=float(p[target]['mean_total_tokens']); target_success=float(p[target]['task_success'])
    k=max(1,math.ceil(target_tokens/base_tokens))
    # majority/selection-like repeated-single baseline, with correlated errors so gain is not unrealistically huge
    rng=random.Random(int(hashlib.sha256(target.encode()).hexdigest()[:8],16)); trials=8000; s=0
    effective_k=1+0.55*(k-1)
    p_match=1-(1-base_success)**effective_k
    # penalty for needing a selector/verifier and correlation among samples
    p_match=min(0.94,p_match-0.025*max(0,k-1))
    for _ in range(trials): s += rng.random()<p_match
    rows.append({'target_strategy':target,'target_success':target_success,'target_mean_tokens':target_tokens,'matched_single_repeats':k,'matched_single_success':s/trials,'matched_budget_tokens':k*base_tokens,'raw_success_gap_vs_single':target_success-base_success,'matched_success_gap':target_success-s/trials})
with open(R/'token_matched_comparison.csv','w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0])); w.writeheader(); w.writerows(rows)
print('matched rows',len(rows))
