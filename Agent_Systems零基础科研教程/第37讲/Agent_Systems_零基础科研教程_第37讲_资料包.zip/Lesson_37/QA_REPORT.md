# QA REPORT - Lesson 37

Date: 2026-09-27

- Core Python syntax check: PASS (7 `.py` files compiled; all experiments are local/offline and require no API key).
- Rule-based reading-audit execution: PASS.
- Claim-Evidence Audit: PASS (3 sample notes; scores 28.6, 64.8, 100.0; these are explicitly labeled human-defined teaching completeness scores, NOT paper-quality scores).
- Paper card comparison: PASS (7 representative Agent Systems papers/projects).
- Reading audit trace: PASS (8 ordered steps in JSONL, plus human-readable trace text).
- Deterministic rerun: PASS (key result file SHA-256 values unchanged after full rerun).
- Research-method boundary: PASS; teaching examples and hypotheses are explicitly separated from claims about real papers/models.
- Current-source/version check: PASS as of 2026-09-27. Official sources were rechecked for OSWorld version drift (OSWorld 2.0 announced 2026-06-26), SWE-agent project evolution (superseded by mini-swe-agent; maintenance-only), TUA-Bench 2026, and τ-bench ICLR 2025.
- DOCX open/ZIP-structure check: PASS for all 6 DOCX files.
- DOCX render QA: PASS. Final page counts: main=11, lab=2, formal design=2, questions=2, answers=2, glossary=2. All rendered pages were visually inspected; no clipping/overlap/missing Chinese glyphs observed.
- PDF independent render QA: PASS. Main PDF=11 pages; all pages independently rendered and visually inspected.
- Chinese font check: PASS (`NotoSansCJKsc` embedded in PDF).
- Figure crop check: PASS; diagrams and captions are fully visible.
- Table page-break check: PASS; no table row is visibly split across pages.
- Blank tail-page check: PASS; no completely blank trailing page.
- Exercise numbering: PASS (1-18 exactly once in the exercise document).
- Header/footer check: PASS (`第37讲`, with no stale `第34讲/第35讲/第36讲` in deliverable DOCX content/header/footer XML).
- Next-lesson continuity: PASS; Lesson 38 is identified as system-architecture reconstruction (Module / Control Flow / Data Flow / State / Boundary).
- ZIP integrity: PASS after CRC test; extracted-copy experiment rerun performed before delivery.
