# Agent Systems 零基础科研教程 · 第37讲

## 主题
第37讲：怎么精读一篇 Agent Systems 论文——从 Abstract、系统图、实验协议，到 Claim-Evidence Map 与 Research Question

## 本讲核心
本讲正式从“Agent 系统知识”转向“Agent Systems 科研阅读能力”。核心不是逐字翻译论文，而是重建 `Question → System → Experiment → Evidence → Claim`，并从 Failure / Trace / Ablation 中提取可验证研究现象。

## 建议学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 进入 `Lesson_37/src` 运行 5 个离线脚本
4. 查看 `results/claim_evidence_audit.csv` 与 `results/reading_audit_trace.jsonl`
5. 阅读 `04_实验设计书.docx`
6. 做练习题，再核对答案

## 必做命令
```bash
cd Lesson_37/src
python audit_paper_notes.py
python compare_papers.py
python build_reading_trace.py
python inspect_reading_trace.py
python make_blank_note.py
```

## 实验性质
本讲代码是**规则化科研阅读训练工具**。`completeness score` 是人为设置的教学检查分，不是论文质量评分、模型性能指标或学术界标准。

## 当前资料核对
截至 2026-09-27，本讲使用一手来源核对了 ReAct、AgentBench、WebArena、SWE-agent、tau-bench、OSWorld 和 TUA-Bench。特别用 OSWorld 2.0 与 SWE-agent 当前项目演化说明：Agent 论文复现必须锁定 paper/code/model/benchmark/harness/environment/run protocol 的具体版本。

## 下一讲
第38讲：《怎么看懂并重建 Agent 系统架构图：Module、Control Flow、Data Flow、State 与 Boundary》
