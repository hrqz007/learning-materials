from pathlib import Path
import json, csv
from common.audit import audit_note
ROOT = Path(__file__).resolve().parents[1]
notes = json.loads((ROOT/'data/sample_notes.json').read_text(encoding='utf-8'))
rows = [audit_note(n) for n in notes]
out = ROOT/'results/claim_evidence_audit.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
    fieldnames = list(rows[0].keys())
    w=csv.DictWriter(f,fieldnames=fieldnames); w.writeheader(); w.writerows(rows)
(ROOT/'results/claim_evidence_audit.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print('Wrote', out)
for r in rows:
    print(r['note_id'], 'score=', r['score'], 'missing=', r['missing_count'])
