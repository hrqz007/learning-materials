from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
paper='webarena2024'
steps=[
 ('triage','Read title/abstract/figures; classify paper type and main question.'),
 ('system','Reconstruct Agent -> Environment -> Observation -> Action loop.'),
 ('protocol','Record benchmark version, task count, model, harness, environment and evaluator.'),
 ('baselines','Check whether compared systems use matched models/compute/tools and identical tasks.'),
 ('evidence','Map each main claim to tables, ablations, traces or validators that support it.'),
 ('failure','Read failures, appendix and negative results; mark first unexplained phenomenon.'),
 ('reproduction','Pin code commit/environment and write minimum rerun plan.'),
 ('rq_mining','Convert a stable failure pattern into RQ -> hypothesis -> controlled experiment.')
]
out=ROOT/'results/reading_audit_trace.jsonl'
with out.open('w',encoding='utf-8') as f:
    for i,(stage,action) in enumerate(steps,1):
        f.write(json.dumps({'paper_id':paper,'step':i,'stage':stage,'action':action},ensure_ascii=False)+'\n')
print('Wrote',out,'steps=',len(steps))
