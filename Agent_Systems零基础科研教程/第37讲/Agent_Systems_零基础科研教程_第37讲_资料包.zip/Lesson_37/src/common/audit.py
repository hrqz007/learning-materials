FIELDS = [
    "research_question","agent_architecture","benchmark_version","model","runtime_or_harness",
    "baseline","matched_baseline","metric","repetitions","cost_latency","ablation",
    "failure_cases","limitations","code_commit","primary_claim","claim_evidence_links","open_question"
]
WEIGHTS = {
    "research_question":8,"agent_architecture":7,"benchmark_version":7,"model":5,"runtime_or_harness":7,
    "baseline":7,"matched_baseline":5,"metric":7,"repetitions":6,"cost_latency":4,"ablation":6,
    "failure_cases":6,"limitations":6,"code_commit":5,"primary_claim":8,"claim_evidence_links":8,"open_question":3
}

def audit_note(note):
    present = {}
    for f in FIELDS:
        v = note.get(f, "")
        present[f] = bool(str(v).strip())
    total = sum(WEIGHTS.values())
    got = sum(WEIGHTS[f] for f in FIELDS if present[f])
    missing = [f for f in FIELDS if not present[f]]
    return {
        "note_id": note.get("note_id",""),
        "paper_id": note.get("paper_id",""),
        "score": round(100*got/total,1),
        "missing_count": len(missing),
        "missing_fields": missing,
        **{f"has_{f}": int(present[f]) for f in FIELDS}
    }
