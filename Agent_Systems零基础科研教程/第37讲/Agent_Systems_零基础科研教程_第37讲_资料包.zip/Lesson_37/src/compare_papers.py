from pathlib import Path
import json, csv
ROOT=Path(__file__).resolve().parents[1]
papers=json.loads((ROOT/'data/paper_cards.json').read_text(encoding='utf-8'))
rows=[]
for p in papers:
    rows.append({
        'id':p['id'],'year':p['year'],'type':p['type'],'venue':p['venue'],'title':p['title'],
        'read_first':' > '.join(p['reading_priority'][:3]),
        'repro_risk':p['current_repro_note']
    })
out=ROOT/'results/paper_type_comparison.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print('Wrote',out,'rows=',len(rows))
