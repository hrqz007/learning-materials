from pathlib import Path
import json, sys
ROOT=Path(__file__).resolve().parents[1]
path=ROOT/'results/reading_audit_trace.jsonl'
for line in path.read_text(encoding='utf-8').splitlines():
    x=json.loads(line)
    print(f"{x['step']:02d}. [{x['stage']}] {x['action']}")
