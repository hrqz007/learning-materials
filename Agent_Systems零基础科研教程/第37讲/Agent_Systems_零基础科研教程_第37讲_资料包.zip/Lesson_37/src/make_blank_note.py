from pathlib import Path
import json
ROOT=Path(__file__).resolve().parents[1]
schema=json.loads((ROOT/'data/paper_reading_schema.json').read_text(encoding='utf-8'))
note={}
for group, fields in schema.items():
    note[group]={k:"" for k in fields}
out=ROOT/'results/blank_research_note.json'
out.write_text(json.dumps(note,ensure_ascii=False,indent=2),encoding='utf-8')
print('Wrote',out)
