# QA REPORT - Lesson 38

Date: 2026-09-27

- Core Python syntax check: PASS (8 `.py` files; required experiment uses only Python standard library and no API key/GPU).
- Architecture experiment execution: PASS (60 tasks × 5 conditions × 3 architectures × 4 repeats = 3600 episodes).
- Paired fault schedule: PASS; fault decisions depend only on `task_id | condition | repeat`, so all three architectures receive the same deterministic fault schedule.
- JSONL Trace generation: PASS (3600 episode traces).
- Architecture reconstruction from Trace: PASS; clean traces were converted to `source -> target` edge counts and `inferred_architecture.json` for all 3 architectures.
- Interface-contract test: PASS (valid plan/lookup accepted; missing field, wrong type, and checksum corruption rejected as designed).
- Deterministic rerun: PASS; SHA-256 values of all key result files were identical after a full rerun.
- Teaching-simulation boundary: PASS; fault probability, checksum, recovery rules and simulated latency are explicitly labeled as human-designed teaching mechanisms, not evidence about GPT/Claude/Gemini or any real agent product.
- DOCX open/structure check: PASS for all 6 DOCX files.
- DOCX render QA: PASS. Final page counts: main=14, lab=3, formal design=3, questions=2, answers=2, glossary=2. All rendered pages were visually inspected; no clipping, overlap, missing Chinese glyphs, or stale footer observed.
- PDF independent render QA: PASS. Main PDF=14 pages; all pages independently rendered and visually inspected.
- Chinese font check: PASS (`NotoSansCJKsc-Regular` and `NotoSansCJKsc-Bold` embedded in PDF).
- Figure crop/readability check: PASS for 11 figures; diagrams and result plots remain inside page boundaries.
- Table page-break check: PASS; table rows use `cantSplit` and no visible row split was found in rendered pages.
- Blank tail-page check: PASS; no completely blank or nearly empty trailing page in the main lecture.
- Exercise numbering: PASS (1-20 exactly once); answer numbering 1-20 exactly once.
- Header/footer check: PASS (`第38讲`; no stale `第34讲/第35讲/第36讲/第37讲` in header/footer XML).
- ZIP integrity: PASS after final CRC test; an extracted-copy experiment rerun was performed before delivery.
