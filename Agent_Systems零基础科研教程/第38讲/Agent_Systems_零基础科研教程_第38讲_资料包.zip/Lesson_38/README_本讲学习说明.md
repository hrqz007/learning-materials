# Agent Systems 零基础科研教程 · 第38讲

## 主题
《怎么看懂并重建 Agent 系统架构图——Module、Control Flow、Data Flow、State 与 Boundary》

## 本讲核心
本讲从“看懂论文系统图”继续推进到“能够自己重建运行系统”。核心产物不是记住框架名，而是能够画清：

- Module / Component
- Control Flow
- Data Flow
- State Ownership / Lifetime
- Boundary / Contract
- Sequence / Trace
- Failure Propagation

## 建议学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 在 `src/` 下运行实验
4. 重点查看 `results/architecture_traces.jsonl` 与 `results/inferred_architecture.json`
5. 阅读 `04_实验设计书.docx`
6. 独立完成练习题，再看答案

## 必做命令
```bash
cd Lesson_38/src
python validate_contracts.py
python run_architecture_lab.py
python analyze_architecture_lab.py
python reconstruct_architecture.py
python inspect_trace.py --architecture typed_recovery --condition tool_result_fault --fault-only
```

## 实验规模
实际运行：60 tasks × 5 conditions × 3 architectures × 4 repeats = **3600 episodes**。

## 重要说明
**这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、框架、产品的实际性能。**

Fault injection probability、checksum、recovery rule 与 simulated latency units 都是教学设计，只服务于机制理解。

## 下一讲
第39讲：《怎么看 Agent 代码：入口、Config、Runner、Agent Loop、Tool Adapter 与 Trace 的最小源码阅读法》
