from pathlib import Path
import csv, json
from collections import defaultdict
ROOT=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((ROOT/'results/episodes.csv').open(encoding='utf-8-sig')))

def mean(xs): return sum(xs)/len(xs) if xs else 0.0

groups=defaultdict(list)
for r in rows: groups[(r['architecture'],r['condition'])].append(r)
summary=[]
for (arch,cond),g in sorted(groups.items()):
    injected=[x for x in g if int(x['fault_injected'])==1]
    summary.append({
      'architecture':arch,'condition':cond,'n':len(g),'fault_injected_n':len(injected),
      'task_success':round(mean([int(x['task_success']) for x in g]),4),
      'diagnostic_coverage_on_injected':round(mean([int(x['diagnosed_correct']) for x in injected]),4) if injected else '',
      'boundary_detection_on_injected':round(mean([int(x['boundary_detected']) for x in injected]),4) if injected else '',
      'mean_propagation_depth_on_injected':round(mean([int(x['propagation_depth']) for x in injected]),3) if injected else '',
      'mean_retries':round(mean([int(x['retries']) for x in g]),3),
      'mean_steps':round(mean([int(x['step_count']) for x in g]),3),
      'mean_latency_units':round(mean([float(x['latency_units']) for x in g]),3),
    })
out=ROOT/'results/summary_by_architecture_condition.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=summary[0].keys()); w.writeheader(); w.writerows(summary)
(ROOT/'results/summary_by_architecture_condition.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')

# overall injected-fault summary excluding clean
by_arch=defaultdict(list)
for r in rows:
    if r['condition']!='clean' and int(r['fault_injected'])==1: by_arch[r['architecture']].append(r)
overall=[]
for arch,g in sorted(by_arch.items()):
    overall.append({
      'architecture':arch,'injected_fault_episodes':len(g),
      'task_success_under_fault':round(mean([int(x['task_success']) for x in g]),4),
      'diagnostic_coverage':round(mean([int(x['diagnosed_correct']) for x in g]),4),
      'boundary_detection':round(mean([int(x['boundary_detected']) for x in g]),4),
      'mean_propagation_depth':round(mean([int(x['propagation_depth']) for x in g]),3),
      'mean_retries':round(mean([int(x['retries']) for x in g]),3),
      'mean_latency_units':round(mean([float(x['latency_units']) for x in g]),3),
    })
out2=ROOT/'results/overall_fault_summary.csv'
with out2.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=overall[0].keys()); w.writeheader(); w.writerows(overall)
print('wrote',out)
print('wrote',out2)
for x in overall: print(x)
