import hashlib

REQUIRED = {
    "PlanMessage": {"task_id": str, "key": str, "multiplier": int, "offset": int},
    "LookupResult": {"task_id": str, "key": str, "value": int, "checksum": str},
    "CalcResult": {"task_id": str, "value": int, "expression": str},
}

def checksum_for(key, value):
    raw = f"{key}:{value}".encode("utf-8")
    return hashlib.sha256(raw).hexdigest()[:12]

def validate_message(kind, message):
    """Return (ok, reason). This is deliberately simple and readable."""
    schema = REQUIRED[kind]
    if not isinstance(message, dict):
        return False, f"{kind} must be dict"
    for field, tp in schema.items():
        if field not in message:
            return False, f"missing field: {field}"
        if not isinstance(message[field], tp):
            return False, f"wrong type: {field}"
    if kind == "LookupResult":
        expected = checksum_for(message["key"], message["value"])
        if message["checksum"] != expected:
            return False, "checksum mismatch"
    return True, "ok"
