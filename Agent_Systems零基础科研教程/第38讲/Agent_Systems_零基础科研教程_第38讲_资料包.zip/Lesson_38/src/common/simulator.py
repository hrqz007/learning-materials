from dataclasses import dataclass, asdict
import hashlib, random
from .contracts import checksum_for, validate_message

MODULE_ORDER = ["Input","Planner","Router","LookupTool","Calculator","Verifier","Finalizer"]

@dataclass
class Event:
    step: int
    source: str
    target: str
    event_type: str
    payload: dict

class EventLog:
    def __init__(self, architecture, condition, inject_fault):
        self.architecture = architecture
        self.condition = condition
        self.inject_fault = inject_fault
        self.events=[]
        self.next_step=1
        self.trace_gap_used=False
    def emit(self, source, target, event_type, payload=None, allow_gap=False):
        payload = payload or {}
        # trace_gap_fault intentionally drops one ordinary event.
        if allow_gap and self.condition=="trace_gap_fault" and self.inject_fault and not self.trace_gap_used:
            self.trace_gap_used=True
            self.next_step += 1
            return
        self.events.append(Event(self.next_step,source,target,event_type,payload))
        self.next_step += 1
    def serializable(self):
        return [asdict(e) for e in self.events]


def paired_fault_decision(task_id, condition, repeat, probability):
    if condition == "clean":
        return False
    token=f"{task_id}|{condition}|{repeat}".encode("utf-8")
    n=int(hashlib.sha256(token).hexdigest()[:16],16)
    rng=random.Random(n)
    return rng.random() < probability


def diagnose(events):
    """Rule-based diagnoser using only observable trace events, not hidden fault labels."""
    for e in events:
        t=e.event_type
        if t=="boundary_reject_plan": return "plan_schema_fault"
        if t=="boundary_reject_lookup": return "tool_result_fault"
        if t=="state_write_blocked": return "shared_state_fault"
        if t=="trace_gap_detected": return "trace_gap_fault"
    # A final mismatch says something failed but does not locate the root cause.
    return "unknown"


def propagation_depth(events, fault_step):
    if fault_step is None:
        return 0
    detect_types={"boundary_reject_plan","boundary_reject_lookup","state_write_blocked","trace_gap_detected"}
    for e in events:
        if e.step>=fault_step and e.event_type in detect_types:
            return max(0,e.step-fault_step)
    # If not detected, count how far execution continued after the hidden fault.
    last=max([e.step for e in events], default=fault_step)
    return max(0,last-fault_step)


def _lookup(task, corrupt=False):
    value=task['base']
    checksum=checksum_for(task['key'],value)
    if corrupt:
        value=value+7
        # checksum intentionally remains the checksum of the original value.
    return {'task_id':task['task_id'],'key':task['key'],'value':value,'checksum':checksum}


def _calc(task_id, base, multiplier, offset):
    v=base*multiplier+offset
    return {'task_id':task_id,'value':v,'expression':f'{base}*{multiplier}+{offset}'}


def run_shared_state(task, condition, inject_fault):
    log=EventLog('shared_state',condition,inject_fault)
    state={'task_id':task['task_id'],'instruction':task['instruction']}
    fault_step=None; retries=0; boundary_checks=0; blocked=0
    log.emit('Input','SharedState','write_instruction',{'task_id':task['task_id']})
    # Planner writes directly into shared mutable state.
    state['key']=task['key']; state['multiplier']=task['multiplier']; state['offset']=task['offset']
    if condition=='plan_schema_fault' and inject_fault:
        # Simulate a malformed field name; downstream code silently defaults.
        state['mult']=state.pop('multiplier')
        fault_step=log.next_step
        log.emit('Planner','SharedState','write_plan',{'fields':sorted(state.keys())},allow_gap=True)
    else:
        log.emit('Planner','SharedState','write_plan',{'fields':['key','multiplier','offset']},allow_gap=True)
    # Router reads shared state; missing multiplier falls back to 1 (bad implicit contract).
    mult=state.get('multiplier',1)
    log.emit('SharedState','Router','read_plan',{'key':state.get('key'),'multiplier':mult})
    corrupt=(condition=='tool_result_fault' and inject_fault)
    lookup=_lookup(task,corrupt=corrupt)
    if corrupt and fault_step is None: fault_step=log.next_step
    state['base']=lookup['value']; state['lookup_checksum']=lookup['checksum']
    log.emit('LookupTool','SharedState','write_lookup',{'value':lookup['value'],'checksum':lookup['checksum']})
    if condition=='shared_state_fault' and inject_fault:
        if fault_step is None: fault_step=log.next_step
        state['base']=state['base']-3
        log.emit('Memory','SharedState','overwrite_base',{'new_base':state['base']})
    calc=_calc(task['task_id'],state['base'],mult,state['offset'])
    state['answer']=calc['value']
    log.emit('SharedState','Calculator','read_state',{'base':state['base'],'multiplier':mult,'offset':state['offset']})
    log.emit('Calculator','SharedState','write_answer',{'answer':state['answer']})
    # Verifier only checks internal consistency against the same shared state.
    internal=_calc(task['task_id'],state['base'],mult,state['offset'])['value']
    log.emit('SharedState','Verifier','read_for_verify',{'answer':state['answer'],'recomputed':internal})
    log.emit('Verifier','Finalizer','verify_pass' if internal==state['answer'] else 'verify_fail',{})
    task_success=(state['answer']==task['expected_answer'])
    log.emit('Finalizer','Evaluator','task_success' if task_success else 'task_failure',{'expected':task['expected_answer'],'observed':state['answer']})
    if condition=='trace_gap_fault' and inject_fault:
        # shared logger does not know an event was dropped
        fault_step = fault_step or 2
    diagnosis=diagnose(log.events)
    return _result(task,condition,inject_fault,'shared_state',log,fault_step,retries,boundary_checks,blocked,task_success,diagnosis)


def run_typed(task, condition, inject_fault, recovery=False):
    arch='typed_recovery' if recovery else 'typed_boundaries'
    log=EventLog(arch,condition,inject_fault)
    fault_step=None; retries=0; boundary_checks=0; blocked=0
    log.emit('Input','Planner','task_request',{'task_id':task['task_id']})
    plan={'task_id':task['task_id'],'key':task['key'],'multiplier':task['multiplier'],'offset':task['offset']}
    if condition=='plan_schema_fault' and inject_fault:
        plan={'task_id':task['task_id'],'key':task['key'],'mult':task['multiplier'],'offset':task['offset']}
        fault_step=log.next_step
    log.emit('Planner','Router','plan_message',{'fields':sorted(plan.keys())},allow_gap=True)
    if condition=='trace_gap_fault' and inject_fault and log.trace_gap_used:
        # Detect the missing sequence immediately at the observability boundary.
        fault_step = fault_step or 2
        log.emit('TraceMonitor','Observability','trace_gap_detected',{'message':'sequence discontinuity detected'})
    boundary_checks += 1
    ok,reason=validate_message('PlanMessage',plan)
    if not ok:
        log.emit('Router','Planner','boundary_reject_plan',{'reason':reason})
        if recovery:
            retries += 1
            plan={'task_id':task['task_id'],'key':task['key'],'multiplier':task['multiplier'],'offset':task['offset']}
            log.emit('Planner','Router','retry_plan_message',{'fields':sorted(plan.keys())})
            boundary_checks += 1
            ok,_=validate_message('PlanMessage',plan)
        if not ok:
            log.emit('Router','Finalizer','safe_stop',{'stage':'plan'})
            log.emit('Finalizer','Evaluator','task_failure',{'expected':task['expected_answer'],'observed':None})
            return _result(task,condition,inject_fault,arch,log,fault_step,retries,boundary_checks,blocked,False,diagnose(log.events))
    # State isolation demonstration: an external shared-memory write is blocked/ignored.
    if condition=='shared_state_fault' and inject_fault:
        fault_step=log.next_step
        blocked += 1
        log.emit('Memory','StateBoundary','state_write_blocked',{'field':'base','attempted_delta':-3})
    corrupt=(condition=='tool_result_fault' and inject_fault)
    lookup=_lookup(task,corrupt=corrupt)
    if corrupt and fault_step is None: fault_step=log.next_step
    log.emit('LookupTool','Router','lookup_result',{'value':lookup['value'],'checksum':lookup['checksum']})
    boundary_checks += 1
    ok,reason=validate_message('LookupResult',lookup)
    if not ok:
        log.emit('Router','LookupTool','boundary_reject_lookup',{'reason':reason})
        if recovery:
            retries += 1
            lookup=_lookup(task,corrupt=False)
            log.emit('LookupTool','Router','retry_lookup_result',{'value':lookup['value'],'checksum':lookup['checksum']})
            boundary_checks += 1
            ok,_=validate_message('LookupResult',lookup)
        if not ok:
            log.emit('Router','Finalizer','safe_stop',{'stage':'lookup'})
            log.emit('Finalizer','Evaluator','task_failure',{'expected':task['expected_answer'],'observed':None})
            return _result(task,condition,inject_fault,arch,log,fault_step,retries,boundary_checks,blocked,False,diagnose(log.events))
    calc=_calc(task['task_id'],lookup['value'],plan['multiplier'],plan['offset'])
    log.emit('Router','Calculator','calc_request',{'base':lookup['value'],'multiplier':plan['multiplier'],'offset':plan['offset']})
    log.emit('Calculator','Verifier','calc_result',{'value':calc['value'],'expression':calc['expression']})
    boundary_checks += 1
    ok,_=validate_message('CalcResult',calc)
    if not ok:
        log.emit('Verifier','Finalizer','safe_stop',{'stage':'calc'})
        log.emit('Finalizer','Evaluator','task_failure',{'expected':task['expected_answer'],'observed':None})
        return _result(task,condition,inject_fault,arch,log,fault_step,retries,boundary_checks,blocked,False,diagnose(log.events))
    log.emit('Verifier','Finalizer','verify_pass',{'answer':calc['value']})
    task_success=(calc['value']==task['expected_answer'])
    log.emit('Finalizer','Evaluator','task_success' if task_success else 'task_failure',{'expected':task['expected_answer'],'observed':calc['value']})
    return _result(task,condition,inject_fault,arch,log,fault_step,retries,boundary_checks,blocked,task_success,diagnose(log.events))


def _result(task,condition,inject_fault,arch,log,fault_step,retries,boundary_checks,blocked,task_success,diagnosis):
    true_root = condition if inject_fault and condition!='clean' else 'none'
    diagnosed_correct = int(true_root!='none' and diagnosis==true_root)
    detected = int(any(e.event_type in {"boundary_reject_plan","boundary_reject_lookup","state_write_blocked","trace_gap_detected"} for e in log.events))
    prop=propagation_depth(log.events,fault_step)
    # latency_units are deliberately simulated, not wall-clock latency.
    latency_units = len(log.events) + 1.5*retries + 0.25*boundary_checks
    return {
        'task_id':task['task_id'],'architecture':arch,'condition':condition,'fault_injected':int(inject_fault),
        'true_root':true_root,'diagnosis':diagnosis,'diagnosed_correct':diagnosed_correct,
        'task_success':int(task_success),'boundary_detected':detected,'propagation_depth':prop,
        'retries':retries,'boundary_checks':boundary_checks,'blocked_writes':blocked,
        'step_count':len(log.events),'latency_units':round(latency_units,2),
        'trace':log.serializable()
    }


def run_episode(task, architecture, condition, repeat, probability):
    inject=paired_fault_decision(task['task_id'],condition,repeat,probability)
    if architecture=='shared_state':
        return run_shared_state(task,condition,inject)
    if architecture=='typed_boundaries':
        return run_typed(task,condition,inject,recovery=False)
    if architecture=='typed_recovery':
        return run_typed(task,condition,inject,recovery=True)
    raise ValueError(architecture)
