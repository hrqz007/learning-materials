from pathlib import Path
import json, argparse
ROOT=Path(__file__).resolve().parents[1]
p=argparse.ArgumentParser()
p.add_argument('--architecture',default='typed_recovery')
p.add_argument('--condition',default='tool_result_fault')
p.add_argument('--fault-only',action='store_true')
args=p.parse_args()
for line in (ROOT/'results/architecture_traces.jsonl').read_text(encoding='utf-8').splitlines():
    x=json.loads(line); ep=x['episode']
    if ep['architecture']!=args.architecture or ep['condition']!=args.condition: continue
    if args.fault_only and int(ep['fault_injected'])!=1: continue
    print('EPISODE', {k:ep[k] for k in ['task_id','architecture','condition','fault_injected','task_success','true_root','diagnosis','propagation_depth','retries']})
    for e in x['trace']:
        print(f"{e['step']:02d} {e['source']:>12} -> {e['target']:<12} | {e['event_type']:<24} | {e['payload']}")
    break
