from pathlib import Path
import json, csv
from collections import Counter, defaultdict
ROOT=Path(__file__).resolve().parents[1]
edge_counts=Counter()
node_counts=Counter()
examples={}
for line in (ROOT/'results/architecture_traces.jsonl').read_text(encoding='utf-8').splitlines():
    x=json.loads(line); ep=x['episode']
    if ep['condition']!='clean' or ep['repeat']!=0: continue
    arch=ep['architecture']
    for e in x['trace']:
        edge_counts[(arch,e['source'],e['target'],e['event_type'])]+=1
        node_counts[(arch,e['source'])]+=1; node_counts[(arch,e['target'])]+=1
rows=[]
for (arch,s,t,typ),count in sorted(edge_counts.items()):
    rows.append({'architecture':arch,'source':s,'target':t,'event_type':typ,'count':count})
out=ROOT/'results/module_edge_counts.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
result={}
for arch in sorted({x[0] for x in edge_counts}):
    nodes=sorted({s for (a,s,t,typ) in edge_counts if a==arch}|{t for (a,s,t,typ) in edge_counts if a==arch})
    edges=[{'source':s,'target':t,'event_type':typ,'count':c} for (a,s,t,typ),c in edge_counts.items() if a==arch]
    result[arch]={'nodes':nodes,'edges':sorted(edges,key=lambda x:(x['source'],x['target'],x['event_type']))}
(ROOT/'results/inferred_architecture.json').write_text(json.dumps(result,ensure_ascii=False,indent=2),encoding='utf-8')
print('wrote',out,'edges=',len(rows))
print('architectures=',','.join(result.keys()))
