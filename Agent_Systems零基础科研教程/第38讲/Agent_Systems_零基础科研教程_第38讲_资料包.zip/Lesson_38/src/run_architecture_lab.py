from pathlib import Path
import json, csv, sys
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common.simulator import run_episode

tasks=json.loads((ROOT/'data/tasks.json').read_text(encoding='utf-8'))
config=json.loads((ROOT/'data/experiment_config.json').read_text(encoding='utf-8'))
rows=[]
trace_path=ROOT/'results/architecture_traces.jsonl'
with trace_path.open('w',encoding='utf-8') as tf:
    for condition in config['conditions']:
        for architecture in config['architectures']:
            for repeat in range(config['repeats_per_task_condition']):
                for task in tasks:
                    r=run_episode(task,architecture,condition,repeat,config['fault_injection_probability'])
                    trace=r.pop('trace')
                    r['repeat']=repeat
                    rows.append(r)
                    tf.write(json.dumps({'episode':r,'trace':trace},ensure_ascii=False)+'\n')
out=ROOT/'results/episodes.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
meta={'episodes':len(rows),'tasks':len(tasks),'architectures':config['architectures'],'conditions':config['conditions'],'warning':config['warning_cn']}
(ROOT/'results/run_metadata.json').write_text(json.dumps(meta,ensure_ascii=False,indent=2),encoding='utf-8')
print('episodes=',len(rows))
print('wrote',out)
print('wrote',trace_path)
