from pathlib import Path
import csv, sys
sys.path.insert(0,str(Path(__file__).resolve().parent))
from common.contracts import validate_message, checksum_for
ROOT=Path(__file__).resolve().parents[1]
cases=[
 ('valid_plan','PlanMessage',{'task_id':'T001','key':'K001','multiplier':3,'offset':2}),
 ('missing_multiplier','PlanMessage',{'task_id':'T001','key':'K001','offset':2}),
 ('wrong_type','PlanMessage',{'task_id':'T001','key':'K001','multiplier':'3','offset':2}),
 ('valid_lookup','LookupResult',{'task_id':'T001','key':'K001','value':27,'checksum':checksum_for('K001',27)}),
 ('corrupt_lookup','LookupResult',{'task_id':'T001','key':'K001','value':34,'checksum':checksum_for('K001',27)}),
]
rows=[]
for name,kind,msg in cases:
    ok,reason=validate_message(kind,msg); rows.append({'case':name,'kind':kind,'valid':int(ok),'reason':reason})
out=ROOT/'results/interface_validation_cases.csv'
with out.open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
print('wrote',out)
for r in rows: print(r)
