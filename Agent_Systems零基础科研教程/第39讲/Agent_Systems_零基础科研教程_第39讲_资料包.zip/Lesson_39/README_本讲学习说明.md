# Agent Systems 零基础科研教程 · 第39讲

## 主题
《怎么看 Agent 代码——Entrypoint、Config、Runner、Agent Loop、Tool Adapter 与 Trace 的最小源码阅读法》

## 核心目标
拿到陌生 Agent 仓库后，不从头到尾读全部代码，而是沿着：

Entrypoint → Config → Runner → Agent Loop → Tool Adapter → Trace → Evaluator

完成最小源码理解闭环。

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 进入 `src/` 运行：
   - `python repo_map.py`
   - `python find_entrypoints.py`
   - `python static_callgraph.py`
   - `python run_code_reading_lab.py`
   - `python analyze_code_reading_lab.py`
   - `python trace_to_source.py`
   - `python inspect_trace.py --variant hidden_retry --condition tool_timeout`
4. 阅读 `04_实验设计书.docx`
5. 独立做练习，再看答案

## 实际运行规模
60 tasks × 4 conditions × 4 variants × 4 repeats = **3840 episodes**。

## 重要声明
**这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、框架或产品的实际性能。**

## 当前真实框架对照
`optional_openai_agents_sdk.py` 按 2026-09-27 的 OpenAI Agents SDK 官方文档编写，但构建资料包时没有调用真实 API。

## 下一讲
第40讲：《复现一篇 Agent 论文——先做 Minimum Reproduction：从 Paper Protocol 到可复现实验闭环》
