# 当前框架对照说明（核对日期：2026-09-27）

本讲核心阅读方法不依赖某个框架。为了把抽象概念映射到现实代码，讲义使用 OpenAI Agents SDK 作为当前例子。

官方资料：
- https://openai.github.io/openai-agents-python/
- https://openai.github.io/openai-agents-python/running_agents/
- https://openai.github.io/openai-agents-python/tools/
- https://openai.github.io/openai-agents-python/tracing/
- https://github.com/openai/openai-agents-python

本资料包没有执行真实 OpenAI API 调用。`src/optional_openai_agents_sdk.py` 仅作为可选实验。
