from pathlib import Path
import csv, json
from collections import defaultdict, Counter
ROOT=Path(__file__).resolve().parents[1]
rows=list(csv.DictReader((ROOT/'results/episodes.csv').open(encoding='utf-8-sig')))
def avg(xs): return sum(xs)/len(xs) if xs else 0.0
G=defaultdict(list)
for r in rows: G[(r['variant'],r['condition'])].append(r)
summary=[]
for (v,c),g in sorted(G.items()):
    faults=[x for x in g if x['root_cause']!='none']
    summary.append({
      'variant':v,'condition':c,'n':len(g),
      'task_success':round(avg([int(x['task_success']) for x in g]),4),
      'mean_actual_tool_attempts':round(avg([int(x['actual_tool_attempts']) for x in g]),3),
      'mean_observed_tool_attempts':round(avg([int(x['observed_tool_attempts']) for x in g]),3),
      'mean_hidden_call_gap':round(avg([int(x['hidden_call_gap']) for x in g]),3),
      'diagnostic_coverage_on_faults':round(avg([int(x['diagnosis_correct']) for x in faults]),4) if faults else '',
      'mean_trace_events':round(avg([int(x['trace_events']) for x in g]),3),
      'mean_source_mapping_coverage':round(avg([float(x['source_mapping_coverage']) for x in g]),4),
      'config_shadow_rate':round(avg([1 if int(x['effective_max_steps'])<8 else 0 for x in g]),4),
    })
with (ROOT/'results/summary.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=summary[0].keys()); w.writeheader(); w.writerows(summary)
(ROOT/'results/summary.json').write_text(json.dumps(summary,ensure_ascii=False,indent=2),encoding='utf-8')
fb=Counter(r['first_bad_span'] for r in rows if r['first_bad_span']!='none')
(ROOT/'results/first_bad_span_counts.json').write_text(json.dumps(fb,ensure_ascii=False,indent=2),encoding='utf-8')
for x in summary: print(x)
