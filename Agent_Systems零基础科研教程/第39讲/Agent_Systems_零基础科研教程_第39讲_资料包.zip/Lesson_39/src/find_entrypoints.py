from pathlib import Path
import re,json
ROOT=Path(__file__).resolve().parents[1]
hits=[]
for p in sorted((Path(__file__).resolve().parent).rglob('*.py')):
    if '__pycache__' in str(p): continue
    txt=p.read_text(encoding='utf-8')
    patterns=[]
    if 'if __name__' in txt: patterns.append('__main__ guard')
    if re.search(r'Runner\(\)\.run|Runner\.run',txt): patterns.append('Runner invocation')
    if 'argparse' in txt: patterns.append('CLI parser')
    if patterns: hits.append({'file':str(p.relative_to(Path(__file__).resolve().parent)),'signals':patterns})
(ROOT/'results/entrypoint_candidates.json').write_text(json.dumps(hits,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(hits,ensure_ascii=False,indent=2))
