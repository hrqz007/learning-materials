from pathlib import Path
import json,argparse
ROOT=Path(__file__).resolve().parents[1]
ap=argparse.ArgumentParser(); ap.add_argument('--variant',default='hidden_retry'); ap.add_argument('--condition',default='tool_timeout'); ap.add_argument('--failure-only',action='store_true')
a=ap.parse_args()
for line in (ROOT/'results/runtime_traces.jsonl').read_text(encoding='utf-8').splitlines():
    x=json.loads(line); ep=x['episode']
    if ep['variant']!=a.variant or ep['condition']!=a.condition: continue
    if a.condition!='clean' and ep.get('effective_condition')!=a.condition: continue
    if a.failure_only and ep['task_success']==1: continue
    print(json.dumps(ep,ensure_ascii=False,indent=2))
    for e in x['trace']:
        print(f"{e['step']:02d} {e['component']:<12} {e['event_type']:<22} {e['source_file']}:{e['source_line']}::{e['function']} {e['detail']}")
    break
