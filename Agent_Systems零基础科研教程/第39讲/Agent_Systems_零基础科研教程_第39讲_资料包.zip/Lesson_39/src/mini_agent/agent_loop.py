class StepLimitExceeded(RuntimeError): pass

class AgentLoop:
    def __init__(self, policy, adapter, config, trace):
        self.policy=policy; self.adapter=adapter; self.config=config; self.trace=trace
    def run(self, task, condition):
        self.trace.emit('AgentLoop','episode_start',{'task_id':task['task_id'],'max_steps':self.config.max_steps})
        plan=self.policy.make_plan(task)
        self.trace.emit('Policy','plan_created',{'plan':plan})
        # Simulate long-horizon overhead before the useful tool call.
        warmup=max(0,task['logical_steps']-3) if condition=='long_horizon' else 0
        used=2
        for i in range(warmup):
            used += 1
            self.trace.emit('AgentLoop','reasoning_step',{'index':i+1})
            if used >= self.config.max_steps:
                raise StepLimitExceeded(f'max_steps={self.config.max_steps}')
        timeout_once=(condition=='tool_timeout')
        schema_fault=(condition=='schema_fault')
        used += 1
        if used > self.config.max_steps: raise StepLimitExceeded('before tool')
        result=self.adapter.lookup_value(task['key'],timeout_once=timeout_once,schema_fault=schema_fault)
        base=result.get('value')
        if base is None:
            self.trace.emit('Policy','cannot_calculate',{'reason':'missing value'})
            return None
        used += 1
        if used > self.config.max_steps: raise StepLimitExceeded('before calculate')
        answer=self.policy.calculate(base,task)
        self.trace.emit('Policy','calculated',{'answer':answer})
        used += 1
        if used > self.config.max_steps: raise StepLimitExceeded('before final')
        self.trace.emit('AgentLoop','episode_end',{'answer':answer})
        return answer
