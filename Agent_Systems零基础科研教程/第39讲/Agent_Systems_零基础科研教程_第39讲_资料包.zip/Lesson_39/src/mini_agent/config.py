from dataclasses import dataclass

@dataclass(frozen=True)
class AgentConfig:
    max_steps: int = 8
    max_retries: int = 1
    trace_tool_attempts: bool = True
    strict_tool_schema: bool = True
    swallow_tool_exceptions: bool = False


def build_config(variant: str, condition: str) -> AgentConfig:
    """Central place where the experiment translates names into runtime behavior."""
    if variant == "transparent":
        return AgentConfig()
    if variant == "hidden_retry":
        # Same retry budget, but the retry attempt is deliberately omitted from the public trace.
        return AgentConfig(trace_tool_attempts=False)
    if variant == "config_shadow":
        # Simulates a local/env override that shadows the documented max_steps only on long tasks.
        if condition == "long_horizon":
            return AgentConfig(max_steps=4)
        return AgentConfig()
    if variant == "exception_swallow":
        return AgentConfig(swallow_tool_exceptions=True, strict_tool_schema=False)
    raise ValueError(f"unknown variant: {variant}")
