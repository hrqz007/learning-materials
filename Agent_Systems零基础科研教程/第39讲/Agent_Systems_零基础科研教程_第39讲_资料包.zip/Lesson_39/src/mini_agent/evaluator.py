def diagnose_from_trace(trace):
    """Diagnose only from what a normal observer sees in the trace."""
    for e in trace:
        typ=e['event_type']; d=e['detail']
        if typ=='tool_error': return d.get('type','tool_error')
        if typ=='exception_swallowed': return 'swallowed_exception'
        if typ=='episode_exception': return d.get('type','episode_exception')
    # If result failed but trace gives no cause, observer cannot localize it.
    return 'unknown'

def observed_tool_attempts(trace):
    return sum(1 for e in trace if e['event_type']=='tool_attempt')

def source_mapping_coverage(trace):
    if not trace: return 0.0
    ok=sum(1 for e in trace if e.get('source_file') and e.get('function') and e.get('source_line'))
    return ok/len(trace)
