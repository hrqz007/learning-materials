class RulePolicy:
    """A deterministic stand-in for an LLM policy, so this lab needs no API key."""
    def make_plan(self, task):
        return ['lookup','calculate','finalize']
    def calculate(self, base, task):
        return base*task['multiplier']+task['addend']
