from .config import build_config
from .tracing import TraceRecorder
from .tools import LocalKeyValueTool
from .tool_adapter import ToolAdapter
from .policy import RulePolicy
from .agent_loop import AgentLoop, StepLimitExceeded

class Runner:
    """The orchestration layer: config -> components -> loop -> result."""
    def run(self, task, variant, condition):
        trace=TraceRecorder()
        config=build_config(variant,condition)
        trace.emit('Runner','config_loaded',{
            'max_steps':config.max_steps,'max_retries':config.max_retries,
            'trace_tool_attempts':config.trace_tool_attempts,
            'strict_tool_schema':config.strict_tool_schema,
            'swallow_tool_exceptions':config.swallow_tool_exceptions,
        })
        tool=LocalKeyValueTool(task)
        adapter=ToolAdapter(tool,config,trace)
        loop=AgentLoop(RulePolicy(),adapter,config,trace)
        error=None
        try:
            answer=loop.run(task,condition)
        except Exception as e:
            answer=None; error=type(e).__name__
            trace.emit('Runner','episode_exception',{'type':error,'message':str(e)})
        trace.emit('Runner','evaluation',{'expected':task['expected'],'answer':answer})
        return {
            'answer':answer,'error':error,'task_success':int(answer==task['expected']),
            'actual_tool_attempts':tool.actual_attempts,'trace':trace.to_list(),
            'effective_config':config.__dict__
        }
