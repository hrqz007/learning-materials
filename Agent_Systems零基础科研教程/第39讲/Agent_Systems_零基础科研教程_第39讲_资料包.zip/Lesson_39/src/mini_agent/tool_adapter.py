from .tools import ToolTimeout, ToolSchemaError

class ToolAdapter:
    def __init__(self, tool, config, trace):
        self.tool=tool; self.config=config; self.trace=trace
    def lookup_value(self, key, *, timeout_once=False, schema_fault=False):
        last=None
        for attempt in range(self.config.max_retries+1):
            try:
                if self.config.trace_tool_attempts:
                    self.trace.emit('ToolAdapter','tool_attempt',{'attempt':attempt+1,'key':key})
                result=self.tool.lookup(key,timeout_once=timeout_once,schema_fault=schema_fault)
                if self.config.strict_tool_schema:
                    if not isinstance(result,dict) or 'value' not in result or not isinstance(result['value'],int):
                        raise ToolSchemaError('expected {key:str, value:int}')
                self.trace.emit('ToolAdapter','tool_result',{'keys':sorted(result.keys())})
                return result
            except (ToolTimeout, ToolSchemaError) as e:
                last=e
                if self.config.trace_tool_attempts:
                    self.trace.emit('ToolAdapter','tool_error',{'type':type(e).__name__,'attempt':attempt+1})
                if attempt >= self.config.max_retries:
                    if self.config.swallow_tool_exceptions:
                        self.trace.emit('ToolAdapter','exception_swallowed',{'type':type(e).__name__})
                        return {'key':key,'value':None}
                    raise
        raise last
