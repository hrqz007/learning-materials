class ToolTimeout(RuntimeError): pass
class ToolSchemaError(RuntimeError): pass

class LocalKeyValueTool:
    """Deterministic local tool. No network/API is used."""
    def __init__(self, task):
        self.task=task
        self.actual_attempts=0
    def lookup(self, key: str, *, timeout_once=False, schema_fault=False):
        self.actual_attempts += 1
        if timeout_once and self.actual_attempts == 1:
            raise ToolTimeout("simulated timeout on first attempt")
        if key != self.task['key']:
            raise KeyError(key)
        if schema_fault:
            return {'key':key,'val':self.task['base']}   # wrong field name on purpose
        return {'key':key,'value':self.task['base']}
