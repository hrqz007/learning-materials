from dataclasses import dataclass, asdict
import inspect

@dataclass
class TraceEvent:
    step: int
    component: str
    event_type: str
    detail: dict
    source_file: str
    function: str
    source_line: int

class TraceRecorder:
    def __init__(self):
        self.events=[]
        self._step=0
    def emit(self, component: str, event_type: str, detail=None, stack_depth: int=1):
        self._step += 1
        frame=inspect.currentframe()
        for _ in range(stack_depth):
            frame=frame.f_back
        info=inspect.getframeinfo(frame)
        self.events.append(TraceEvent(
            step=self._step, component=component, event_type=event_type, detail=detail or {},
            source_file=info.filename.split('/')[-1], function=info.function, source_line=info.lineno
        ))
    def to_list(self):
        return [asdict(x) for x in self.events]
