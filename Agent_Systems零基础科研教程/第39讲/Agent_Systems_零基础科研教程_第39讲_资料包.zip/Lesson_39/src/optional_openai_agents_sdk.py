"""Optional REAL API example. Not executed during package build.
Requires: pip install openai-agents ; set OPENAI_API_KEY.
The SDK API was checked against official OpenAI Agents SDK docs on 2026-09-27.
"""
import asyncio
from agents import Agent, Runner
from agents.decorators import tool

@tool
def lookup_number(key: str) -> int:
    """Return a tiny local number for a key."""
    table={"A":12,"B":7}
    return table[key]

agent=Agent(
    name="CodeReadingDemo",
    instructions="Use lookup_number when the user asks for a stored number, then answer concisely.",
    tools=[lookup_number],
)

async def main():
    result=await Runner.run(agent,"What is the stored number for A? Use the tool.")
    print(result.final_output)

if __name__=='__main__':
    asyncio.run(main())
