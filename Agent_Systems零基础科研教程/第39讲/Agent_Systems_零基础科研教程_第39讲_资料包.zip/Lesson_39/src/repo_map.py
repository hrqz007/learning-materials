from pathlib import Path
import ast,json
ROOT=Path(__file__).resolve().parents[1]
SRC=Path(__file__).resolve().parent/'mini_agent'
items=[]
for p in sorted(SRC.glob('*.py')):
    tree=ast.parse(p.read_text(encoding='utf-8'))
    funcs=[n.name for n in tree.body if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef))]
    classes=[]
    for n in tree.body:
        if isinstance(n,ast.ClassDef):
            methods=[m.name for m in n.body if isinstance(m,(ast.FunctionDef,ast.AsyncFunctionDef))]
            classes.append({'name':n.name,'methods':methods})
    items.append({'file':p.name,'functions':funcs,'classes':classes})
(ROOT/'results/repo_map.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(items,ensure_ascii=False,indent=2))
