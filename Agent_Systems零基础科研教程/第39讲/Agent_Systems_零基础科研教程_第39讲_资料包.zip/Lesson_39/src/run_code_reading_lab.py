from pathlib import Path
import sys, json, csv, hashlib, random
ROOT=Path(__file__).resolve().parents[1]
sys.path.insert(0,str(Path(__file__).resolve().parent))
from mini_agent.runner import Runner
from mini_agent.evaluator import diagnose_from_trace, observed_tool_attempts, source_mapping_coverage

tasks=json.loads((ROOT/'data/tasks.json').read_text(encoding='utf-8'))
cfg=json.loads((ROOT/'data/experiment_config.json').read_text(encoding='utf-8'))

def paired_inject(task_id,condition,repeat,p):
    raw=f'{task_id}|{condition}|{repeat}'.encode()
    rng=random.Random(int(hashlib.sha256(raw).hexdigest()[:16],16))
    return rng.random()<p

rows=[]
tracef=(ROOT/'results/runtime_traces.jsonl').open('w',encoding='utf-8')
for condition in cfg['conditions']:
  for variant in cfg['variants']:
    for repeat in range(cfg['repeats']):
      for task0 in tasks:
        task=dict(task0)
        effective_condition=condition
        # Pair whether the timeout/schema fault actually fires across all variants.
        if condition=='tool_timeout' and not paired_inject(task['task_id'],condition,repeat,cfg['timeout_injection_probability']):
            effective_condition='clean'
        if condition=='schema_fault' and not paired_inject(task['task_id'],condition,repeat,cfg['schema_fault_probability']):
            effective_condition='clean'
        out=Runner().run(task,variant,effective_condition)
        tr=out.pop('trace')
        diagnosis=diagnose_from_trace(tr)
        obs_attempts=observed_tool_attempts(tr)
        hidden_gap=out['actual_tool_attempts']-obs_attempts
        first_bad='none'
        if condition=='tool_timeout' and effective_condition=='tool_timeout' and out['actual_tool_attempts']>=1: first_bad='ToolAdapter/tool'
        elif condition=='schema_fault' and effective_condition=='schema_fault': first_bad='ToolAdapter/schema'
        elif condition=='long_horizon' and variant=='config_shadow' and not out['task_success']: first_bad='Config/max_steps'
        root='none'
        if condition=='tool_timeout' and effective_condition=='tool_timeout': root='ToolTimeout'
        elif condition=='schema_fault' and effective_condition=='schema_fault': root='ToolSchema'
        elif condition=='long_horizon' and variant=='config_shadow' and not out['task_success']: root='ConfigShadow'
        diag_correct=int(root!='none' and (
            (root=='ToolTimeout' and diagnosis=='ToolTimeout') or
            (root=='ToolSchema' and diagnosis in {'ToolSchemaError','swallowed_exception'}) or
            (root=='ConfigShadow' and diagnosis=='StepLimitExceeded')
        ))
        row={
          'task_id':task['task_id'],'variant':variant,'condition':condition,'effective_condition':effective_condition,'repeat':repeat,
          'task_success':out['task_success'],'error':out['error'] or '',
          'actual_tool_attempts':out['actual_tool_attempts'],'observed_tool_attempts':obs_attempts,'hidden_call_gap':hidden_gap,
          'trace_events':len(tr),'source_mapping_coverage':round(source_mapping_coverage(tr),4),
          'root_cause':root,'diagnosis':diagnosis,'diagnosis_correct':diag_correct,'first_bad_span':first_bad,
          'effective_max_steps':out['effective_config']['max_steps']
        }
        rows.append(row)
        tracef.write(json.dumps({'episode':row,'trace':tr},ensure_ascii=False)+'\n')
tracef.close()
with (ROOT/'results/episodes.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
(ROOT/'results/run_metadata.json').write_text(json.dumps({'episodes':len(rows),'warning':cfg['warning_cn']},ensure_ascii=False,indent=2),encoding='utf-8')
print('episodes=',len(rows))
print('wrote',ROOT/'results/episodes.csv')
print('wrote',ROOT/'results/runtime_traces.jsonl')
