from pathlib import Path
import ast,json
ROOT=Path(__file__).resolve().parents[1]
SRC=Path(__file__).resolve().parent/'mini_agent'
edges=[]
for p in sorted(SRC.glob('*.py')):
    tree=ast.parse(p.read_text(encoding='utf-8'))
    class V(ast.NodeVisitor):
        def __init__(self): self.scope=[]
        def visit_ClassDef(self,node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        def visit_FunctionDef(self,node):
            self.scope.append(node.name); self.generic_visit(node); self.scope.pop()
        visit_AsyncFunctionDef=visit_FunctionDef
        def visit_Call(self,node):
            if self.scope:
                target=None
                if isinstance(node.func,ast.Name): target=node.func.id
                elif isinstance(node.func,ast.Attribute): target=node.func.attr
                if target: edges.append({'file':p.name,'caller':'/'.join(self.scope),'callee':target,'line':node.lineno})
            self.generic_visit(node)
    V().visit(tree)
(ROOT/'results/static_callgraph.json').write_text(json.dumps(edges,ensure_ascii=False,indent=2),encoding='utf-8')
print('edges=',len(edges))
for e in edges[:40]: print(e)
