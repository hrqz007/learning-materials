from pathlib import Path
import json,collections
ROOT=Path(__file__).resolve().parents[1]
ctr=collections.Counter()
for line in (ROOT/'results/runtime_traces.jsonl').read_text(encoding='utf-8').splitlines():
    x=json.loads(line)
    ep=x['episode']
    if ep['variant']=='transparent' and ep['condition']=='clean' and ep['repeat']==0:
        for e in x['trace']:
            ctr[(e['source_file'],e['function'],e['source_line'],e['component'],e['event_type'])]+=1
rows=[{'source_file':k[0],'function':k[1],'source_line':k[2],'component':k[3],'event_type':k[4],'count':v} for k,v in ctr.items()]
(ROOT/'results/runtime_source_map.json').write_text(json.dumps(rows,ensure_ascii=False,indent=2),encoding='utf-8')
print(json.dumps(rows,ensure_ascii=False,indent=2))
