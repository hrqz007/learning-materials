# Agent Systems 零基础科研教程 · 第40讲

## 主题
《复现一篇 Agent 论文——Minimum Reproduction：从 Paper Protocol 到可复现实验闭环》

## 推荐学习顺序
1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `data/teaching_paper_protocol.md`
3. `03_实验指导书.docx`
4. 按顺序运行 `src/` 中实验
5. 阅读 `04_实验设计书.docx`
6. 独立完成练习题后再看答案

## 受控实验规模
Reference：60 tasks × 3 conditions × 2 methods × 5 repeats = **1800 episodes**。
五种 reproduction profile 合计 **8280 episodes**；加 reference 共 **10080 episodes**。

## 核心教学现象
Reference stressed effect = **0.2017**。
Independent replication（只换 seed）effect = **0.1900**；Harness drift（关闭 retry 等）effect = **0.0083**。

**这些数值全部来自教学模拟，不代表任何真实模型、Benchmark、框架或产品性能。**

## 下一讲
第41讲将继续从“复现”推进到真正的 Controlled Experiment：如何从一个观察到的 Agent failure/phenomenon 构造 Research Question、Hypothesis、Baseline 与 Ablation。
