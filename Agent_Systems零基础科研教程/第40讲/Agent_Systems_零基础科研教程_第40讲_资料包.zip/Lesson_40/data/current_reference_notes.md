# 第40讲：当前真实生态对照（核对日期：2026-09-28）

这些资料只用于说明“真实 Agent benchmark 为什么必须冻结 Harness / Environment / Run ID”，本讲实验本身完全离线。

1. SWE-bench Evaluation Harness Reference
   - https://github.com/SWE-bench/SWE-bench/blob/main/docs/reference/harness.md
   - 当前文档明确说明其 Docker-based harness 用于建立一致的评测环境。
   - 文档还特别提醒：evaluation result cache 以 `run_id` + `instance_id` 为键；如果 prediction 已变但仍复用相同 run_id，可能直接拿到缓存结果。这是非常典型的“实验基础设施细节会污染科研结论”的现实案例。

2. SWE-bench Quick Start / Evaluation
   - https://github.com/SWE-bench/SWE-bench/blob/main/docs/guides/quickstart.md
   - https://www.swebench.com/SWE-bench/guides/evaluation/
   - 官方建议先用 gold patch 验证 evaluation setup，这是“先验证 Evaluator/Harness，再评模型”的现实做法。

3. OpenAI Agents SDK Tracing
   - https://openai.github.io/openai-agents-js/guides/tracing/
   - 当前 SDK 文档把 LLM generations、tool calls、handoffs、guardrails 等纳入 trace。对论文复现而言，完整 trace 能帮助定位“结果没复现”的第一次运行分叉。

注意：这些项目会持续更新，所以真实复现必须记录 commit/tag、文档日期和依赖版本。
