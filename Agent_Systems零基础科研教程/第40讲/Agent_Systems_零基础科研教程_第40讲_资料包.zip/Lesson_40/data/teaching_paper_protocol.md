# 教学 Paper Protocol Card（虚构，用于复现实训）

> **重要：这是受控教学材料，不是真实发表论文，不代表 GPT / Claude / Gemini 或任何真实模型性能。**

## 教学“论文”题目
Verifier-Aware Recovery for Robust Tool-Using Agents

## 目标 Claim
在固定模型、固定任务集、固定 Harness 和严格 Evaluator 下，`verifier_retry` 在 `schema_noise` 与 `tool_timeout` 两类扰动上的平均 Task Success 高于 `baseline`；代价是更多 model calls、token 与 latency。

## Protocol
- Dataset: `tasks.json`, split=`test_v1`
- 60 tasks，难度 easy/medium/hard 各20个
- Methods: `baseline`, `verifier_retry`
- Conditions: `clean`, `schema_noise`, `tool_timeout`
- Repeats per task-condition-method: 5
- Model snapshot: `TeachingMock-2026-09-01`
- Prompt version: `p3`
- Harness: `harness-1.0`
- Evaluator: `strict-v1`
- `max_steps=8`, `retry_limit=1`, `tool_timeout_ms=1200`, `temperature=0.2`
- Seed base: 40000
- Main metric: Task Success
- Secondary metrics: token, latency, cost_units, recovery_rate

## 最小复现目标
先复现“受扰动条件下 verifier_retry - baseline 的 Task Success 差值方向与量级”，而不是一次复现全部表格。
