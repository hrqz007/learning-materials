"""把参考结果与 5 种复现实验做统一比较。"""
import csv, json
from common import RESULTS, read_json, write_json

ref=read_json(RESULTS/'reference'/'summary.json')
profiles=['exact_replay','independent_replication','evaluator_drift','harness_drift','split_mismatch']
rows=[]
for p in profiles:
    s=read_json(RESULTS/'reproductions'/p/'summary.json')
    diff=read_json(RESULTS/'protocol_diffs'/f'{p}.json')
    changed={d['field'] for d in diff['diffs']}
    allowed_changed = changed <= ({'seed_base'} if p=='independent_replication' else set())
    effect_gap=round(s['stressed_effect']-ref['stressed_effect'],4)
    direction_match=(s['stressed_effect']>0)==(ref['stressed_effect']>0)
    # 教学验收规则：效应方向一致、效应差 <= 0.05，且除“独立复现允许换 seed”外没有未批准协议漂移。
    acceptance=(abs(effect_gap)<=0.05 and direction_match and allowed_changed)
    rows.append({
        'profile':p,
        'baseline_success':s['overall']['baseline']['success_rate'],
        'verifier_success':s['overall']['verifier_retry']['success_rate'],
        'stressed_effect':s['stressed_effect'],
        'effect_gap_vs_reference':effect_gap,
        'protocol_diff_count':diff['diff_count'],
        'changed_fields':','.join(sorted(changed)) if changed else 'none',
        'direction_match':int(direction_match),
        'protocol_compatible':int(allowed_changed),
        'meets_teaching_acceptance':int(acceptance),
    })
write_json(RESULTS/'reproduction_comparison.json', {
  'reference_stressed_effect':ref['stressed_effect'],
  'teaching_acceptance_rule':'same direction AND abs(effect_gap)<=0.05 AND no unapproved protocol drift; independent replication may change seed_base',
  'rows':rows})
with (RESULTS/'reproduction_comparison.csv').open('w',encoding='utf-8-sig',newline='') as f:
    w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)
print(json.dumps(rows,ensure_ascii=False,indent=2))
