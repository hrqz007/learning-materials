"""第40讲：Minimum Reproduction 受控教学实验公共模块。

重要：这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型的性能。
只使用 Python 标准库，便于零基础学习者复现。
"""
from __future__ import annotations
import csv, hashlib, json, math, random
from pathlib import Path
from typing import Dict, Iterable, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / "data"
RESULTS = ROOT / "results"


def read_json(path: Path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def write_json(path: Path, obj) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open("w", encoding="utf-8") as f:
        json.dump(obj, f, ensure_ascii=False, indent=2)


def stable_hash(obj) -> str:
    data = json.dumps(obj, ensure_ascii=False, sort_keys=True, separators=(",", ":")).encode("utf-8")
    return hashlib.sha256(data).hexdigest()


def wilson_interval(successes: int, n: int, z: float = 1.96) -> Tuple[float, float]:
    if n == 0:
        return (0.0, 0.0)
    p = successes / n
    den = 1 + z * z / n
    center = (p + z * z / (2*n)) / den
    half = z * math.sqrt((p*(1-p) + z*z/(4*n))/n) / den
    return max(0.0, center-half), min(1.0, center+half)


def load_tasks(split: str) -> List[dict]:
    tasks = read_json(DATA / "tasks.json")
    selected = [t for t in tasks if t["split"] == split]
    if not selected:
        raise ValueError(f"未知 split: {split}")
    return selected


def effective_probability(task: dict, method: str, condition: str, profile: dict) -> float:
    """构造受控成功概率。数值只服务教学机制演示。"""
    diff_penalty = {"easy": 0.04, "medium": 0.13, "hard": 0.23}[task["difficulty"]]
    condition_penalty = {"clean": 0.00, "schema_noise": 0.14, "tool_timeout": 0.18}[condition]

    # 模拟“模型快照漂移”：不是任何真实模型。
    model_shift = profile.get("model_quality_shift", 0.0)
    p = 0.90 - diff_penalty - condition_penalty + model_shift

    if method == "verifier_retry":
        # clean 条件下只小幅收益；受扰动环境中通过验证+一次恢复得到更明显收益。
        p += 0.025 if condition == "clean" else 0.105
        if profile.get("retry_limit", 1) <= 0:
            # Harness 漂移：论文方法名没变，但恢复语义被关闭。
            p -= 0.075 if condition != "clean" else 0.010
    elif method != "baseline":
        raise ValueError(method)

    # 提示词/运行时版本漂移可统一轻微改变结果。
    if profile.get("prompt_version") != "p3":
        p -= 0.025
    if profile.get("harness_version") != "harness-1.0":
        p -= 0.010
    return max(0.05, min(0.97, p))


def run_episode(task: dict, method: str, condition: str, repeat: int, profile: dict, seed_base: int) -> Tuple[dict, List[dict]]:
    seed = seed_base + task["numeric_id"] * 1009 + repeat * 131 + {"clean": 1, "schema_noise": 2, "tool_timeout": 3}[condition] * 17 + (0 if method == "baseline" else 500_000)
    rng = random.Random(seed)
    p = effective_probability(task, method, condition, profile)

    # 先模拟失败来源，再允许 verifier_retry 在特定失败上恢复。
    fail_draw = rng.random() > p
    failure_type = None
    if fail_draw:
        candidates = ["planning_error", "tool_error", "schema_error", "step_limit"]
        weights = [0.36, 0.30, 0.22, 0.12]
        r = rng.random()
        acc = 0
        for c, w in zip(candidates, weights):
            acc += w
            if r <= acc:
                failure_type = c
                break

    recovered = False
    retry_used = 0
    if method == "verifier_retry" and failure_type in {"tool_error", "schema_error"} and profile.get("retry_limit", 1) > 0:
        # 真实系统的恢复概率取决于模型/工具/错误类型；这里是人为设置的教学参数。
        recovery_p = 0.58 if condition != "clean" else 0.42
        if rng.random() < recovery_p:
            recovered = True
            retry_used = 1
            failure_type = None

    semantic_success = failure_type is None

    # evaluator 漂移：lenient-v2 会把一部分近似正确的失败判为成功。
    evaluator = profile.get("evaluator_version", "strict-v1")
    judged_success = semantic_success
    evaluator_flip = False
    if evaluator == "lenient-v2" and not semantic_success and failure_type in {"schema_error", "step_limit"}:
        if rng.random() < 0.42:
            judged_success = True
            evaluator_flip = True

    base_steps = task["expected_steps"] + rng.choice([-1, 0, 0, 0, 1])
    max_steps = profile.get("max_steps", 8)
    steps = max(2, min(max_steps + 1, base_steps + retry_used))
    model_calls = steps + (1 if method == "verifier_retry" else 0) + retry_used
    tokens = int(520 + 165 * model_calls + task["expected_steps"] * 65 + rng.randint(-60, 90))
    latency_ms = int(600 + model_calls * 185 + (350 if condition == "tool_timeout" else 0) + rng.randint(-80, 120))
    cost_units = round(tokens / 1000 + model_calls * 0.12, 3)

    episode_id = f"{profile['name']}::{task['task_id']}::{condition}::{method}::r{repeat}"
    trace = []
    def add(span, status="ok", **kw):
        trace.append({"episode_id": episode_id, "span_index": len(trace), "span": span, "status": status, **kw})

    add("task_load", split=profile["split"], task_id=task["task_id"], difficulty=task["difficulty"])
    add("agent_plan", status="error" if failure_type == "planning_error" else "ok", prompt_version=profile.get("prompt_version"), model_snapshot=profile.get("model_snapshot"))
    tool_status = "error" if failure_type == "tool_error" else "ok"
    add("tool_call", status=tool_status, condition=condition, timeout_ms=profile.get("tool_timeout_ms"), harness_version=profile.get("harness_version"))
    if method == "verifier_retry":
        add("verify", status="flagged" if retry_used else "ok", retry_limit=profile.get("retry_limit", 1))
        if retry_used:
            add("retry", status="recovered" if recovered else "failed")
    if failure_type == "schema_error":
        add("schema_validate", status="error")
    if failure_type == "step_limit":
        add("step_budget", status="error", max_steps=max_steps)
    add("evaluate", status="pass" if judged_success else "fail", evaluator_version=evaluator, semantic_success=semantic_success, evaluator_flip=evaluator_flip)

    row = {
        "episode_id": episode_id,
        "profile": profile["name"],
        "task_id": task["task_id"],
        "difficulty": task["difficulty"],
        "split": profile["split"],
        "condition": condition,
        "method": method,
        "repeat": repeat,
        "seed": seed,
        "success": int(judged_success),
        "semantic_success": int(semantic_success),
        "evaluator_flip": int(evaluator_flip),
        "failure_type": failure_type or "none",
        "recovered": int(recovered),
        "retry_used": retry_used,
        "steps": steps,
        "model_calls": model_calls,
        "tokens": tokens,
        "latency_ms": latency_ms,
        "cost_units": cost_units,
        "protocol_hash": stable_hash({k:v for k,v in profile.items() if k != "name"}),
    }
    return row, trace


def run_profile(profile: dict, output_dir: Path) -> dict:
    output_dir.mkdir(parents=True, exist_ok=True)
    tasks = load_tasks(profile["split"])
    methods = profile["methods"]
    conditions = profile["conditions"]
    repeats = profile["repeats"]
    rows: List[dict] = []
    traces: List[dict] = []
    for task in tasks:
        for condition in conditions:
            for method in methods:
                for repeat in range(repeats):
                    row, tr = run_episode(task, method, condition, repeat, profile, profile["seed_base"])
                    rows.append(row); traces.extend(tr)

    fields = list(rows[0].keys())
    with (output_dir / "episodes.csv").open("w", encoding="utf-8-sig", newline="") as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(rows)
    with (output_dir / "traces.jsonl").open("w", encoding="utf-8") as f:
        for x in traces:
            f.write(json.dumps(x, ensure_ascii=False)+"\n")

    summary = summarize(rows)
    write_json(output_dir / "summary.json", summary)
    with (output_dir / "summary.csv").open("w", encoding="utf-8-sig", newline="") as f:
        fields2=["condition","method","n","successes","success_rate","ci_low","ci_high","avg_tokens","avg_latency_ms","avg_cost_units","recovery_rate"]
        w=csv.DictWriter(f, fieldnames=fields2); w.writeheader(); w.writerows(summary["cells"])
    write_json(output_dir / "protocol_effective.json", profile)
    return {"rows":len(rows), "trace_spans":len(traces), "summary":summary}


def summarize(rows: List[dict]) -> dict:
    cells=[]
    for condition in sorted({r["condition"] for r in rows}):
        for method in sorted({r["method"] for r in rows}):
            sub=[r for r in rows if r["condition"]==condition and r["method"]==method]
            s=sum(int(r["success"]) for r in sub); n=len(sub); lo,hi=wilson_interval(s,n)
            recovered=sum(int(r["recovered"]) for r in sub)
            failures_or_recovered=sum(1 for r in sub if r["failure_type"]!="none" or int(r["recovered"]))
            cells.append({
                "condition":condition,"method":method,"n":n,"successes":s,
                "success_rate":round(s/n,4),"ci_low":round(lo,4),"ci_high":round(hi,4),
                "avg_tokens":round(sum(int(r["tokens"]) for r in sub)/n,1),
                "avg_latency_ms":round(sum(int(r["latency_ms"]) for r in sub)/n,1),
                "avg_cost_units":round(sum(float(r["cost_units"]) for r in sub)/n,3),
                "recovery_rate":round(recovered/max(1,failures_or_recovered),4),
            })
    # overall per method
    overall={}
    for method in sorted({r["method"] for r in rows}):
        sub=[r for r in rows if r["method"]==method]
        overall[method]={"n":len(sub),"success_rate":round(sum(int(r["success"]) for r in sub)/len(sub),4),"avg_cost_units":round(sum(float(r["cost_units"]) for r in sub)/len(sub),3)}
    stressed={}
    for method in sorted({r["method"] for r in rows}):
        sub=[r for r in rows if r["method"]==method and r["condition"]!="clean"]
        stressed[method]=round(sum(int(r["success"]) for r in sub)/len(sub),4)
    effect=round(stressed["verifier_retry"]-stressed["baseline"],4)
    return {"cells":cells,"overall":overall,"stressed_success":stressed,"stressed_effect":effect}
