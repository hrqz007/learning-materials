"""比较参考协议与复现实验协议，找出发生漂移的字段。"""
import argparse, json
from pathlib import Path
from common import DATA, read_json, write_json

parser=argparse.ArgumentParser(); parser.add_argument("--profile", required=True); args=parser.parse_args()
ref=read_json(DATA/"reference_protocol.json"); profiles=read_json(DATA/"reproduction_profiles.json"); cur=profiles[args.profile]
keys=sorted(set(ref)|set(cur)); diffs=[]
for k in keys:
    if k=="name": continue
    if ref.get(k)!=cur.get(k): diffs.append({"field":k,"reference":ref.get(k),"reproduction":cur.get(k)})
out=Path(__file__).resolve().parents[1]/"results"/"protocol_diffs"/f"{args.profile}.json"
write_json(out,{"profile":args.profile,"diff_count":len(diffs),"diffs":diffs})
print(json.dumps({"profile":args.profile,"diff_count":len(diffs),"diffs":diffs},ensure_ascii=False,indent=2))
