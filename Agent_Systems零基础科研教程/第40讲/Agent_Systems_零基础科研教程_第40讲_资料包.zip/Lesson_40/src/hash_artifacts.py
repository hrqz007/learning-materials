"""计算关键输入的 SHA-256，用于证明“我跑的到底是哪一份实验材料”。"""
from pathlib import Path
import hashlib, json
ROOT=Path(__file__).resolve().parents[1]
items=[]
for rel in ['data/tasks.json','data/reference_protocol.json','data/reproduction_profiles.json','data/teaching_paper_protocol.md']:
    p=ROOT/rel; items.append({'file':rel,'sha256':hashlib.sha256(p.read_bytes()).hexdigest(),'bytes':p.stat().st_size})
print(json.dumps(items,ensure_ascii=False,indent=2))
(ROOT/'results'/'input_hashes.json').write_text(json.dumps(items,ensure_ascii=False,indent=2),encoding='utf-8')
