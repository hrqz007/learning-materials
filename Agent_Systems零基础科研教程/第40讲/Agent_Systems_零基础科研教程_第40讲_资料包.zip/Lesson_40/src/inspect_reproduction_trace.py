"""查看某个复现实验中的一个 episode Trace，帮助找“第一次分叉”。"""
import argparse, json
from pathlib import Path
from common import RESULTS
p=argparse.ArgumentParser();p.add_argument('--profile',default='harness_drift');p.add_argument('--contains',default='tool_timeout::verifier_retry');args=p.parse_args()
path=RESULTS/'reproductions'/args.profile/'traces.jsonl'
selected=None; events=[]
with path.open(encoding='utf-8') as f:
    for line in f:
        x=json.loads(line)
        if selected is None and args.contains in x['episode_id']:
            selected=x['episode_id']
        if selected and x['episode_id']==selected:
            events.append(x)
        elif selected and events:
            break
print('episode:',selected)
for e in events:
    print(f"{e['span_index']:02d} {e['span']:<16} {e['status']:<10} {json.dumps({k:v for k,v in e.items() if k not in {'episode_id','span_index','span','status'}},ensure_ascii=False)}")
