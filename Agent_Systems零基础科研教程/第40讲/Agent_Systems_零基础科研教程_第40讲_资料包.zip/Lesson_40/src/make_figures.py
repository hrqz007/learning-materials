"""生成第40讲所有教学图。"""
from pathlib import Path
import csv, json
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from matplotlib import font_manager

ROOT=Path(__file__).resolve().parents[1]; FIG=ROOT/'figures'; RES=ROOT/'results'
FIG.mkdir(exist_ok=True)
font_path='/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc'
font_manager.fontManager.addfont(font_path)
_cjk=font_manager.FontProperties(fname=font_path).get_name()
plt.rcParams['font.family']=_cjk
plt.rcParams['font.sans-serif']=[_cjk]
plt.rcParams['axes.unicode_minus']=False

def save(name):
    plt.tight_layout(); plt.savefig(FIG/name,dpi=180,bbox_inches='tight'); plt.close()

# 1. Minimum Reproduction 阶梯
fig,ax=plt.subplots(figsize=(11,4.8)); ax.axis('off')
steps=[('0','选一个 Claim'),('1','Smoke Test'),('2','1 个 Task'),('3','小批量 Slice'),('4','目标表格/趋势'),('5','全 Benchmark')]
for i,(n,label) in enumerate(steps):
    x=0.03+i*0.16; y=0.15+i*0.10
    box=FancyBboxPatch((x,y),0.14,0.20,boxstyle='round,pad=0.02',fc='white',ec='0.25',lw=1.5)
    ax.add_patch(box); ax.text(x+0.07,y+0.125,f'{n}. {label}',ha='center',va='center',fontsize=12,fontweight='bold')
    if i<len(steps)-1:
        ax.add_patch(FancyArrowPatch((x+0.14,y+0.10),(x+0.18,y+0.20),arrowstyle='->',mutation_scale=15,lw=1.5))
ax.text(0.5,0.94,'Minimum Reproduction：先验证最小证据链，再扩大规模',ha='center',fontsize=16,fontweight='bold')
ax.text(0.5,0.03,'失败时停在当前层定位原因；不要一开始就把全部 Benchmark、全部 Baseline、全部 Ablation 一起跑。',ha='center',fontsize=11)
save('minimum_reproduction_ladder.png')

# 2. protocol manifest layers
fig,ax=plt.subplots(figsize=(10.5,6)); ax.axis('off')
layers=[('Claim / Acceptance','要复现什么？什么算复现成功？'),('Task / Split / Dataset','哪些任务？哪一版数据？'),('Agent / Model / Prompt','系统与模型的精确身份'),('Harness / Tool / Environment','运行时、工具、Sandbox、网络与权限'),('Evaluator / Metric','谁判定成功？如何聚合？'),('Randomness / Budget','Seed、重复次数、Step/Token/Cost/Time Budget'),('Artifact Identity','commit、lockfile、Docker/image、hash、日期')]
y=0.87
for title,desc in layers:
    box=FancyBboxPatch((0.1,y-0.075),0.80,0.10,boxstyle='round,pad=0.015',fc='white',ec='0.3',lw=1.2)
    ax.add_patch(box); ax.text(0.13,y-0.025,title,fontsize=12,fontweight='bold',va='center'); ax.text(0.48,y-0.025,desc,fontsize=11,va='center')
    y-=0.12
ax.text(0.5,0.97,'Protocol Manifest：复现的“合同”',ha='center',fontsize=16,fontweight='bold')
save('protocol_manifest_layers.png')

# 3. result effect comparison
comp=json.loads((RES/'reproduction_comparison.json').read_text(encoding='utf-8'))
labels=['Reference']+[r['profile'] for r in comp['rows']]
vals=[comp['reference_stressed_effect']]+[r['stressed_effect'] for r in comp['rows']]
fig,ax=plt.subplots(figsize=(11,5.2)); bars=ax.bar(range(len(vals)),vals)
ax.axhline(comp['reference_stressed_effect'],ls='--',lw=1,label='Reference effect')
ax.set_ylabel('受扰动条件下 Success 差值\n(verifier_retry - baseline)'); ax.set_xticks(range(len(vals))); ax.set_xticklabels(labels,rotation=22,ha='right'); ax.set_title('同一个“方法名”，协议漂移会改变可复现的效应量')
for b,v in zip(bars,vals): ax.text(b.get_x()+b.get_width()/2,v+0.006,f'{v:.3f}',ha='center',fontsize=9)
ax.legend(); save('result_effect_comparison.png')

# 4 overall success comparison
names=['Reference','independent_replication','evaluator_drift','harness_drift','split_mismatch']
base=[]; ver=[]
ref=json.loads((RES/'reference'/'summary.json').read_text())
base.append(ref['overall']['baseline']['success_rate']); ver.append(ref['overall']['verifier_retry']['success_rate'])
for n in names[1:]:
    s=json.loads((RES/'reproductions'/n/'summary.json').read_text())
    base.append(s['overall']['baseline']['success_rate']); ver.append(s['overall']['verifier_retry']['success_rate'])
fig,ax=plt.subplots(figsize=(10.5,5.2)); import numpy as np
x=np.arange(len(names)); w=.36
ax.bar(x-w/2,base,w,label='baseline'); ax.bar(x+w/2,ver,w,label='verifier_retry')
ax.set_ylim(0,1);ax.set_ylabel('Task Success');ax.set_xticks(x);ax.set_xticklabels(names,rotation=18,ha='right');ax.set_title('只看最终分数，可能误把协议变化当成方法变化');ax.legend();save('result_overall_success.png')

# 5 reproduction gap diagnosis flow
fig,ax=plt.subplots(figsize=(11,6)); ax.axis('off')
nodes=[(0.08,0.78,'结果没复现'),(0.35,0.78,'先比 Protocol'),(0.67,0.78,'协议一致？'),(0.67,0.50,'否：先修协议漂移'),(0.35,0.50,'是：看随机波动/CI'),(0.08,0.50,'仍超出预设容差？'),(0.08,0.22,'看 Trace 第一次分叉'),(0.40,0.22,'定位 Model / Tool / Runtime'),(0.72,0.22,'再决定是否扩大实验')]
for x,y,t in nodes:
    box=FancyBboxPatch((x,y),0.20,0.10,boxstyle='round,pad=0.015',fc='white',ec='0.3');ax.add_patch(box);ax.text(x+0.1,y+0.05,t,ha='center',va='center',fontsize=10)
arrows=[((.28,.83),(.35,.83)),((.55,.83),(.67,.83)),((.77,.78),(.77,.60)),((.67,.55),(.55,.55)),((.35,.55),(.28,.55)),((.18,.50),(.18,.32)),((.28,.27),(.40,.27)),((.60,.27),(.72,.27))]
for a,b in arrows: ax.add_patch(FancyArrowPatch(a,b,arrowstyle='->',mutation_scale=14,lw=1.3))
ax.text(.5,.96,'Reproduction Gap：先排除“协议没对齐”，再讨论科学差异',ha='center',fontsize=16,fontweight='bold')
save('reproduction_gap_diagnosis.png')

# 6 Agent-specific drift sources
fig,ax=plt.subplots(figsize=(11,6)); ax.axis('off')
center=(.5,.5); ax.add_patch(FancyBboxPatch((.38,.43),.24,.14,boxstyle='round,pad=.02',fc='white',ec='0.2',lw=1.5));ax.text(.5,.50,'Agent Experiment\nObserved Result',ha='center',va='center',fontsize=13,fontweight='bold')
items=[(.08,.76,'Model/API\nSnapshot'),(.38,.80,'Prompt / Context'),(.72,.76,'Harness / Retry'),(.08,.44,'Tool / Sandbox'),(.72,.44,'External State\nNetwork / Web'),(.08,.12,'Dataset / Split'),(.38,.10,'Evaluator / Cache'),(.72,.12,'Seed / Concurrency')]
for x,y,t in items:
    ax.add_patch(FancyBboxPatch((x,y),.18,.11,boxstyle='round,pad=.015',fc='white',ec='0.35'));ax.text(x+.09,y+.055,t,ha='center',va='center',fontsize=10)
    ax.add_patch(FancyArrowPatch((x+.09,y+.055),center,arrowstyle='->',mutation_scale=12,lw=1,alpha=.8))
ax.text(.5,.96,'Agent 复现比普通静态模型评测多出一整层“系统运行时漂移”',ha='center',fontsize=15,fontweight='bold')
save('agent_reproduction_drift_sources.png')

# 7 protocol diff counts
rows=comp['rows'][1:]  # exclude exact? include all nonexact perhaps
fig,ax=plt.subplots(figsize=(9.5,4.8)); labs=[r['profile'] for r in comp['rows']]; counts=[r['protocol_diff_count'] for r in comp['rows']]
ax.bar(labs,counts);ax.set_ylabel('与参考协议不同的字段数');ax.set_title('先数“协议差异”，再解释“性能差异”');ax.tick_params(axis='x',rotation=20)
for i,v in enumerate(counts):ax.text(i,v+.05,str(v),ha='center')
save('protocol_diff_counts.png')
