"""真实论文复现前的交互式清单（不调用 API、不下载数据、不执行外部代码）。"""
FIELDS=[
('claim','要复现的具体 claim / 表格行 / 图中趋势'),
('code_commit','作者代码 commit/tag'),
('dataset','数据集名称、版本、split、hash'),
('model','模型精确快照/API版本'),
('prompt','prompt/template/version'),
('harness','Harness/Runner/Tool Adapter 版本'),
('tools','工具、sandbox、权限与外部依赖版本'),
('evaluator','Evaluator与metric实现'),
('randomness','seed、temperature、重复次数'),
('budget','max_steps/token/cost/time budget'),
('environment','OS/Python/CUDA/Docker/依赖锁定'),
('acceptance','开始实验前写好的复现验收标准'),
]
print('真实 Agent 论文 Minimum Reproduction 清单')
for i,(k,desc) in enumerate(FIELDS,1):
    print(f'{i:02d}. {k:<12} - {desc}')
