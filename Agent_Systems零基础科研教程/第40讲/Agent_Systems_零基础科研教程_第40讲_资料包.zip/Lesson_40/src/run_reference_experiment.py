from pathlib import Path
from common import DATA, RESULTS, read_json, run_profile, write_json, stable_hash

profile = read_json(DATA / "reference_protocol.json")
out = RESULTS / "reference"
result = run_profile(profile, out)
metadata = {"kind":"reference_author_run","profile":profile["name"],"protocol_hash":stable_hash({k:v for k,v in profile.items() if k != "name"}),"episodes":result["rows"],"trace_spans":result["trace_spans"]}
write_json(out / "run_metadata.json", metadata)
print(f"reference episodes={result['rows']}, trace_spans={result['trace_spans']}")
print("stressed_effect=", result["summary"]["stressed_effect"])
