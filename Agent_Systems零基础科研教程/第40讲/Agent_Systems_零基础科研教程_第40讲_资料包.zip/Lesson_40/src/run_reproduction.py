"""按指定 profile 运行一次 Minimum Reproduction。"""
import argparse
from common import DATA, RESULTS, read_json, run_profile

parser=argparse.ArgumentParser()
parser.add_argument("--profile", required=True, choices=["exact_replay","independent_replication","evaluator_drift","harness_drift","split_mismatch"])
args=parser.parse_args()
profiles=read_json(DATA / "reproduction_profiles.json")
profile=profiles[args.profile]
res=run_profile(profile, RESULTS / "reproductions" / args.profile)
print(f"{args.profile}: episodes={res['rows']}, trace_spans={res['trace_spans']}, stressed_effect={res['summary']['stressed_effect']}")
