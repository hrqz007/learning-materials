# Agent Systems 零基础科研教程 · 第41讲

## 主题
从 Observation / Failure 到 Research Question、Hypothesis、Baseline、Controlled Experiment 与 Ablation。

## 本讲最低闭环
Observation → 稳定性确认 → Fact/Inference 分离 → RQ → 文献检索闸门 → Hypothesis + Falsifier → Baseline/Ablation → Controlled Experiment → Evidence。

## 建议学习顺序
1. 阅读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 按 `03_实验指导书.docx` 运行 3280 条受控模拟。
3. 阅读 `results/sample_trace.txt` 和 CSV。
4. 独立填写 RQ/Hypothesis/Baseline/Ablation，再看 `results/research_card.md`。
5. 完成 `05_练习题.docx` 后再看答案。

## 一键运行
```bash
python src/run_experiment.py
python src/analyze_experiment.py
python src/make_figures.py
python src/build_research_card.py
```

## 教学模拟声明
所有实验数值均由受控概率模型生成，不代表 GPT / Claude / Gemini 或任何真实 Agent 的性能，也不能作为真实论文结论。

## 真实科研迁移
以后把 `results/traces.jsonl` 替换为自己的真实 Agent Trace；`src/real_trace_adapter.py` 给出框架无关的字段归一化模板。真正研究时仍必须检索已有论文、固定模型/任务/环境/评测版本，并设计配对与资源匹配对照。
