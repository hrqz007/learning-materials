# Lesson 41 Research Card

> 受控教学模拟，不代表真实模型性能。

## Observation
在受控教学模拟中，任务越长，no_verifier 的成功率下降更明显；更早发现错误的策略通常具有更高恢复率，但成本更高。

## Research Question
在固定基础能力、任务分布和计算预算约束下，错误检测延迟是否系统性影响长任务 Agent 的恢复率与错误传播深度？

## Hypotheses

- **H1**: 在控制 horizon、fault position 和 task difficulty 后，Detection Delay 增大将伴随更低 Recovery Rate。
  - Falsifier: 如果较大的 Detection Delay 并不对应更低恢复率，或方向在大多数任务切片中不稳定，则不支持 H1。
  - Teaching check: consistent

- **H2**: 更早检测可降低 Failure Propagation Depth，且该效应在长 horizon 任务上更明显。
  - Falsifier: 如果早检测与传播深度没有稳定关系，或仅由额外计算量解释，则不支持 H2。
  - Teaching check: consistent

- **H3**: Periodic Verifier 在部分 horizon 上可接近 Step Verifier 的成功率，但以更低成本实现，从而形成更好的 cost-reliability trade-off。
  - Falsifier: 如果 Periodic Verifier 始终显著更差，或成本优势不足，则不支持 H3。
  - Teaching check: not_consistent

## Baselines
- Weak: no_verifier
- Strong: final_verifier
- Resource-matched: token_matched_retries

## Ablations
- minus_checkpoint
- minus_retry
- minus_state_reset

## Interpretation Boundary
描述性结果只能说明本模拟中的关系；若要声称因果机制，需要进一步控制混杂变量、做配对/干预实验并在真实系统中复核。
