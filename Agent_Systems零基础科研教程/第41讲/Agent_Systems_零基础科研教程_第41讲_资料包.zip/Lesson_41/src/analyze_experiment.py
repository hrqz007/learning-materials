from __future__ import annotations
import csv, json, math, statistics
from collections import defaultdict
from common import RESULTS, dump_json, wilson_interval


def read_csv(path):
    with path.open(encoding='utf-8-sig') as f: return list(csv.DictReader(f))

def fnum(x):
    try:return float(x)
    except:return math.nan

def summary_group(rows, keys):
    groups=defaultdict(list)
    for r in rows: groups[tuple(r[k] for k in keys)].append(r)
    out=[]
    for key,rs in sorted(groups.items()):
        n=len(rs); succ=sum(int(r['task_success']) for r in rs); lo,hi=wilson_interval(succ,n)
        fault=[r for r in rs if int(r['fault_occurred'])]
        detected=[r for r in fault if int(r['detected'])]
        rec=sum(int(r['recovered']) for r in detected)
        delays=[fnum(r['detection_delay']) for r in detected if r['detection_delay']!='']
        out.append({**dict(zip(keys,key)),'n':n,'success_rate':succ/n,'ci_low':lo,'ci_high':hi,
                    'fault_n':len(fault),'detected_n':len(detected),'recovery_rate_detected':(rec/len(detected) if detected else None),
                    'avg_detection_delay':(statistics.mean(delays) if delays else None),
                    'avg_propagation_depth':statistics.mean(fnum(r['propagation_depth']) for r in rs),
                    'avg_cost_units':statistics.mean(fnum(r['cost_units']) for r in rs)})
    return out

def write_csv(path, rows):
    if not rows:return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

rows=read_csv(RESULTS/'episodes.csv'); abl=read_csv(RESULTS/'ablation_episodes.csv')
overall=summary_group(rows,['strategy'])
by_h=summary_group(rows,['horizon','strategy'])
abl_sum=summary_group(abl,['ablation'])
write_csv(RESULTS/'summary_overall.csv',overall); write_csv(RESULTS/'summary_by_horizon.csv',by_h); write_csv(RESULTS/'ablation_summary.csv',abl_sum)

# Detection delay bins across verifier strategies only.
bins=defaultdict(list)
for r in rows:
    if r['detection_delay']=='': continue
    d=int(float(r['detection_delay']))
    label='1' if d==1 else ('2-3' if d<=3 else ('4-6' if d<=6 else '7+'))
    bins[label].append(r)
delay_rows=[]
for label in ['1','2-3','4-6','7+']:
    rs=bins.get(label,[])
    if not rs: continue
    delay_rows.append({'delay_bin':label,'n':len(rs),'recovery_rate':sum(int(r['recovered']) for r in rs)/len(rs),
                       'avg_propagation_depth':statistics.mean(fnum(r['propagation_depth']) for r in rs)})
write_csv(RESULTS/'detection_delay_slices.csv',delay_rows)

# Teaching hypothesis checks are descriptive checks, not statistical proof.
lookup={(r['horizon'],r['strategy']):r for r in by_h}
checks=[]
# H1 monotonic recovery by delay bins (rough descriptive)
recvals=[r['recovery_rate'] for r in delay_rows]
mono=all(recvals[i]>=recvals[i+1]-0.02 for i in range(len(recvals)-1)) if len(recvals)>1 else False
checks.append({'hypothesis':'H1','descriptive_check':'Recovery rate is non-increasing across delay bins (2pp tolerance)','observed':str(mono),'status':'consistent' if mono else 'not_consistent'})
# H2: propagation larger for delay 7+ than 1
if len(delay_rows)>=2:
    first=next((r for r in delay_rows if r['delay_bin']=='1'),None); last=next((r for r in delay_rows if r['delay_bin']=='7+'),None)
    ok=bool(first and last and last['avg_propagation_depth']>first['avg_propagation_depth'])
else: ok=False
checks.append({'hypothesis':'H2','descriptive_check':'Propagation depth at delay 7+ exceeds delay 1','observed':str(ok),'status':'consistent' if ok else 'not_consistent'})
# H3: periodic within 5pp of step at some long horizon and cheaper everywhere.
qual=[]
for h in ['8','12','16']:
    p=lookup[(h,'periodic_verifier')]; s=lookup[(h,'step_verifier')]
    qual.append((s['success_rate']-p['success_rate']<=0.05) and (p['avg_cost_units']<s['avg_cost_units']))
ok=any(qual)
checks.append({'hypothesis':'H3','descriptive_check':'At least one long horizon: periodic within 5pp of step and lower cost','observed':str(ok),'status':'consistent' if ok else 'not_consistent'})
write_csv(RESULTS/'hypothesis_checks.csv',checks)

summary={'overall':overall,'by_horizon':by_h,'detection_delay_slices':delay_rows,'ablation':abl_sum,'hypothesis_checks':checks,
         'disclaimer':'受控教学模拟，不代表任何真实模型或Agent系统性能；hypothesis checks仅为描述性教学检查。'}
dump_json(RESULTS/'summary.json',summary)
print(json.dumps(summary,ensure_ascii=False,indent=2))
