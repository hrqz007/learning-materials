from __future__ import annotations
import json, csv
from common import DATA, RESULTS
reg=json.loads((DATA/'hypothesis_registry.json').read_text(encoding='utf-8'))
with (RESULTS/'hypothesis_checks.csv').open(encoding='utf-8-sig') as f: checks=list(csv.DictReader(f))
out=[]
out.append('# Lesson 41 Research Card\n')
out.append('> 受控教学模拟，不代表真实模型性能。\n')
out.append('## Observation\n'+reg['observation']+'\n')
out.append('## Research Question\n'+reg['research_question']+'\n')
out.append('## Hypotheses\n')
for h in reg['hypotheses']:
    c=next((x for x in checks if x['hypothesis']==h['id']),None)
    out.append(f"- **{h['id']}**: {h['statement']}\n  - Falsifier: {h['falsifier']}\n  - Teaching check: {c['status'] if c else 'N/A'}\n")
out.append('## Baselines\n- Weak: no_verifier\n- Strong: final_verifier\n- Resource-matched: token_matched_retries\n')
out.append('## Ablations\n- minus_checkpoint\n- minus_retry\n- minus_state_reset\n')
out.append('## Interpretation Boundary\n描述性结果只能说明本模拟中的关系；若要声称因果机制，需要进一步控制混杂变量、做配对/干预实验并在真实系统中复核。\n')
(RESULTS/'research_card.md').write_text('\n'.join(out),encoding='utf-8')
print(RESULTS/'research_card.md')
