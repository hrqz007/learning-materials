from __future__ import annotations
import json, math, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
RESULTS = ROOT / 'results'
FIG = ROOT / 'figures'


def stable_int(*parts: object) -> int:
    s = '||'.join(map(str, parts)).encode('utf-8')
    return int(hashlib.sha256(s).hexdigest()[:16], 16)


def load_json(path: Path):
    return json.loads(path.read_text(encoding='utf-8'))


def dump_json(path: Path, obj):
    path.parent.mkdir(parents=True, exist_ok=True)
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding='utf-8')


def wilson_interval(successes: int, n: int, z: float = 1.96):
    if n == 0:
        return (math.nan, math.nan)
    p = successes / n
    denom = 1 + z*z/n
    center = (p + z*z/(2*n))/denom
    half = z * math.sqrt((p*(1-p)/n) + z*z/(4*n*n))/denom
    return max(0.0, center-half), min(1.0, center+half)
