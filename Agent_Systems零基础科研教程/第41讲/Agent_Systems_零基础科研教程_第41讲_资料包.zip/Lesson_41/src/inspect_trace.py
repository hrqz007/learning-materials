from __future__ import annotations
import argparse, json
from common import RESULTS
p=argparse.ArgumentParser(); p.add_argument('--task-id',default='h16_t00'); p.add_argument('--strategy',default='periodic_verifier'); p.add_argument('--repeat',type=int,default=0)
a=p.parse_args()
for line in (RESULTS/'traces.jsonl').open(encoding='utf-8'):
    tr=json.loads(line); ep=tr['episode']
    if ep['task_id']==a.task_id and ep['strategy']==a.strategy and int(ep['repeat'])==a.repeat:
        print(json.dumps(tr,ensure_ascii=False,indent=2)); break
else: print('Trace not found')
