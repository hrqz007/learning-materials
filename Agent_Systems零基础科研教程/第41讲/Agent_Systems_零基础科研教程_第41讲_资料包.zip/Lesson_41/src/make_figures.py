from __future__ import annotations
import csv, json, math
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from common import RESULTS, FIG

plt.rcParams['font.family']='Noto Sans CJK JP'
plt.rcParams['font.sans-serif']=['Noto Sans CJK JP']
plt.rcParams['axes.unicode_minus']=False
FIG.mkdir(exist_ok=True)

def load_csv(name):
    with (RESULTS/name).open(encoding='utf-8-sig') as f:return list(csv.DictReader(f))

def save(fig,name):
    fig.tight_layout(); fig.savefig(FIG/name,dpi=180,bbox_inches='tight'); plt.close(fig)

# 1 research flow
fig,ax=plt.subplots(figsize=(11,4.6)); ax.axis('off')
labels=['Observation\n观察到异常','Stability Check\n确认现象稳定','Research Question\n提出研究问题','Literature Gate\n检索已有研究','Hypothesis\n可证伪假设','Controlled Experiment\n对照实验','Evidence\n证据判断']
xs=[0.02,0.165,0.31,0.455,0.60,0.745,0.89]
for i,(x,l) in enumerate(zip(xs,labels)):
    w=0.105 if i<6 else 0.09
    box=FancyBboxPatch((x,0.42),w,0.28,boxstyle='round,pad=0.015',linewidth=1.3,facecolor='white',edgecolor='black')
    ax.add_patch(box); ax.text(x+w/2,0.56,l,ha='center',va='center',fontsize=11)
    if i<len(labels)-1:
        nx=xs[i+1]
        ax.add_patch(FancyArrowPatch((x+w,0.56),(nx,0.56),arrowstyle='->',mutation_scale=16,linewidth=1.2))
ax.text(0.5,0.18,'研究不是“先想方法再刷分”，而是让问题、假设与证据链逐步收紧。',ha='center',fontsize=12,fontweight='bold')
save(fig,'research_flow.png')

# 2 observation-fact-inference-hypothesis boundary
fig,ax=plt.subplots(figsize=(10.5,5.2)); ax.axis('off')
items=[
('事实 Fact','periodic_verifier 在本模拟中 success=0.56；step_verifier=0.7075。','可直接从数据计算'),
('观察 Observation','长 horizon 下 no_verifier 的成功率下降更明显。','需要重复和切片确认'),
('推断 Inference','更早发现错误“可能”减少错误传播。','仍可能受混杂因素影响'),
('假设 Hypothesis','控制 horizon/难度后，Detection Delay 增大将降低 Recovery Rate。','必须能被实验推翻')]
ys=[0.78,0.58,0.38,0.18]
for (title,ex,bound),y in zip(items,ys):
    ax.add_patch(FancyBboxPatch((0.04,y-0.08),0.92,0.14,boxstyle='round,pad=0.012',facecolor='white',edgecolor='black'))
    ax.text(0.07,y,title,fontsize=12,fontweight='bold',va='center')
    ax.text(0.31,y+0.025,ex,fontsize=10.5,va='center')
    ax.text(0.31,y-0.035,'边界：'+bound,fontsize=9.5,va='center')
save(fig,'fact_observation_inference_hypothesis.png')

# 3 baseline & ablation matrix
fig,ax=plt.subplots(figsize=(10.5,5.4)); ax.axis('off')
cols=['问题','对照类型','本讲示例','它排除什么解释']
rows=[
['方法比“不做”好吗？','Weak Baseline','no_verifier','排除“任何处理都有效”'],
['比已有合理策略好吗？','Strong Baseline','final_verifier','排除“只挑弱对手”'],
['多算力才变好吗？','Token/Cost-Matched','token_matched_retries','排除“只是多花计算”'],
['哪个模块产生作用？','Ablation','-checkpoint / -retry / -state_reset','定位机制贡献']]
from matplotlib.table import Table
tab=ax.table(cellText=rows,colLabels=cols,cellLoc='left',loc='center',colWidths=[0.22,0.18,0.27,0.33]); tab.auto_set_font_size(False); tab.set_fontsize(10); tab.scale(1,2.0)
ax.set_title('Baseline 与 Ablation 解决的是不同问题',fontsize=15,pad=18,fontweight='bold')
save(fig,'baseline_ablation_grid.png')

# data plots
by=load_csv('summary_by_horizon.csv'); overall=load_csv('summary_overall.csv'); delay=load_csv('detection_delay_slices.csv'); abl=load_csv('ablation_summary.csv')
strategies=['no_verifier','final_verifier','periodic_verifier','step_verifier','token_matched_retries']
# success by horizon
fig,ax=plt.subplots(figsize=(9,5.3))
for s in strategies:
    rs=[r for r in by if r['strategy']==s]
    rs=sorted(rs,key=lambda r:int(r['horizon']))
    ax.plot([int(r['horizon']) for r in rs],[float(r['success_rate']) for r in rs],marker='o',label=s)
ax.set_xlabel('Task Horizon（步骤数）'); ax.set_ylabel('Task Success'); ax.set_ylim(0,1); ax.grid(alpha=.25); ax.legend(fontsize=8)
ax.set_title('受控教学模拟：任务越长，策略差异被放大')
save(fig,'success_by_horizon.png')

# recovery by delay
fig,ax=plt.subplots(figsize=(8,4.8))
ax.bar([r['delay_bin'] for r in delay],[float(r['recovery_rate']) for r in delay])
ax.set_ylim(0,1); ax.set_xlabel('Detection Delay'); ax.set_ylabel('Recovery Rate'); ax.set_title('观察：检测越晚，恢复率越低（教学模拟）'); ax.grid(axis='y',alpha=.2)
save(fig,'recovery_by_detection_delay.png')

# propagation
fig,ax=plt.subplots(figsize=(8,4.8))
ax.bar([r['delay_bin'] for r in delay],[float(r['avg_propagation_depth']) for r in delay])
ax.set_xlabel('Detection Delay'); ax.set_ylabel('Avg Failure Propagation Depth'); ax.set_title('观察：检测延迟与错误传播深度同时上升（教学模拟）'); ax.grid(axis='y',alpha=.2)
save(fig,'propagation_by_detection_delay.png')

# cost success tradeoff
fig,ax=plt.subplots(figsize=(8,5.2))
for r in overall:
    x=float(r['avg_cost_units']); y=float(r['success_rate']); ax.scatter([x],[y],s=60); ax.annotate(r['strategy'],(x,y),xytext=(5,5),textcoords='offset points',fontsize=8)
ax.set_xlabel('Average Cost Units'); ax.set_ylabel('Task Success'); ax.set_ylim(0,1); ax.grid(alpha=.25); ax.set_title('不要只问“谁分数高”：同时看成本-可靠性权衡')
save(fig,'cost_success_tradeoff.png')

# ablation
fig,ax=plt.subplots(figsize=(8.5,4.8))
labels=[r['ablation'] for r in abl]; vals=[float(r['success_rate']) for r in abl]
ax.bar(labels,vals); ax.set_ylim(0,0.75); ax.set_ylabel('Task Success'); ax.set_title('Ablation：删掉模块后，系统到底发生什么？'); ax.tick_params(axis='x',rotation=15); ax.grid(axis='y',alpha=.2)
save(fig,'ablation_success.png')
print('figures generated',len(list(FIG.glob('*.png'))))
