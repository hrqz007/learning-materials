"""Framework-agnostic trace adapter template.

Purpose: map a REAL Agent trace into the same conceptual fields used in Lesson 41.
This script does not call any API and does not claim compatibility with a vendor SDK.
Edit `normalize_span` for your own trace schema.
"""
from __future__ import annotations
import json, sys

def normalize_span(span: dict) -> dict:
    return {
        'step': span.get('step'),
        'event_type': span.get('event_type') or span.get('type'),
        'error': bool(span.get('error', False)),
        'detected': bool(span.get('detected', False)),
        'recovered': bool(span.get('recovered', False)),
        'latency_ms': span.get('latency_ms'),
        'token_count': span.get('token_count')
    }

def main(path):
    with open(path,encoding='utf-8') as f:
        for line in f:
            obj=json.loads(line)
            spans=obj.get('spans', obj.get('trace', []))
            print(json.dumps([normalize_span(s) for s in spans],ensure_ascii=False))

if __name__=='__main__':
    if len(sys.argv)!=2:
        raise SystemExit('Usage: python src/real_trace_adapter.py your_trace.jsonl')
    main(sys.argv[1])
