from __future__ import annotations
import csv, json, math, random
from pathlib import Path
from common import ROOT, DATA, RESULTS, load_json, dump_json, stable_int

CFG = load_json(DATA/'experiment_config.json')


def make_tasks():
    tasks=[]
    for h in CFG['horizons']:
        for i in range(CFG['tasks_per_horizon']):
            rng=random.Random(stable_int('task', h, i))
            difficulty=round(0.28 + 0.58*rng.random(), 3)
            faultiness=round(0.45 + 0.35*rng.random(), 3)
            tasks.append({'task_id':f'h{h}_t{i:02d}','horizon':h,'difficulty':difficulty,'faultiness':faultiness})
    dump_json(DATA/'tasks.json',tasks)
    return tasks


def maybe_fault(rng, task, step):
    # per-step hazard grows mildly with difficulty; kept low enough to yield a spread of outcomes.
    base = 0.035 + 0.040*task['difficulty'] + 0.018*task['faultiness']
    # later steps are slightly more fragile because state is longer.
    p = min(0.17, base * (1 + 0.018*(step-1)))
    return rng.random() < p


def recovery_prob(delay, task, checkpoint=True, retry=True, state_reset=True):
    if not retry:
        return 0.02
    p = 0.88 * math.exp(-0.18*max(0, delay-1))
    p *= (1 - 0.18*task['difficulty'])
    if not checkpoint:
        p *= 0.70
    if not state_reset:
        p *= 0.76
    return max(0.03, min(0.95, p))


def run_episode(task, strategy_name, repeat, ablation=None):
    s=CFG['strategies'][strategy_name]
    rng=random.Random(stable_int(CFG['seed_base'], task['task_id'], strategy_name, repeat, ablation or 'main'))
    active_error=False
    first_fault_global=None
    current_fault_start=None
    detected_at=None
    first_detection_delay=None
    recovered=False
    retries_used=0
    propagation_depth=0
    spans=[]
    checkpoint=True; retry=True; state_reset=True
    if ablation:
        av=CFG['ablation_variants'][ablation]
        checkpoint=av['checkpoint']; retry=av['retry']; state_reset=av['state_reset']

    for step in range(1, task['horizon']+1):
        fault_now=False
        if not active_error and maybe_fault(rng,task,step):
            active_error=True; fault_now=True; current_fault_start=step
            if first_fault_global is None: first_fault_global=step
        elif active_error:
            propagation_depth += 1

        check=False
        if strategy_name=='final_verifier':
            check = step==task['horizon']
        elif s['check_every'] and s['check_every']<999:
            check = (step % s['check_every']==0) or step==task['horizon']

        detected=False; recovered_now=False
        if active_error and check and rng.random()<s['detect_prob']:
            detected=True
            if detected_at is None:
                detected_at=step
                first_detection_delay=step-current_fault_start+1
            delay=step-current_fault_start+1
            if retries_used < s['retry_budget'] and rng.random()<recovery_prob(delay,task,checkpoint,retry,state_reset):
                recovered_now=True; recovered=True; retries_used += 1
                active_error=False
                if state_reset:
                    propagation_depth=max(0, propagation_depth-1)
        # token-matched strategy spends compute on blind retries, not targeted detection.
        blind_retry=False
        if strategy_name=='token_matched_retries' and rng.random() < min(0.22, 0.04*s['retry_budget']):
            blind_retry=True; retries_used += 1
            if active_error and rng.random() < 0.20:
                active_error=False; recovered=True; recovered_now=True

        spans.append({
            'step':step,'fault_now':fault_now,'active_error_after_step':active_error,
            'check':check,'detected':detected,'recovered_now':recovered_now,'blind_retry':blind_retry
        })

    # natural task failure independent of injected persistent fault
    natural_success_p=max(0.58, 0.965 - 0.018*task['horizon'] - 0.12*task['difficulty'])
    natural_success = rng.random() < natural_success_p
    task_success = (not active_error) and natural_success
    detection_delay = first_detection_delay
    cost = s['base_cost']*task['horizon'] + 0.24*retries_used
    if ablation:
        if checkpoint: cost += 0.04*task['horizon']
        if state_reset: cost += 0.02*task['horizon']
    episode={
        'task_id':task['task_id'],'horizon':task['horizon'],'difficulty':task['difficulty'],
        'strategy':strategy_name,'repeat':repeat,'ablation':ablation or '',
        'fault_occurred':int(first_fault_global is not None),'first_fault_step':first_fault_global or '',
        'detected':int(detected_at is not None),'detected_step':detected_at or '',
        'detection_delay':detection_delay if detection_delay is not None else '',
        'recovered':int(recovered),'propagation_depth':propagation_depth,
        'retries_used':retries_used,'task_success':int(task_success),'cost_units':round(cost,3)
    }
    trace={'episode':episode,'spans':spans}
    return episode,trace


def write_csv(path, rows):
    if not rows: return
    with path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)


def main():
    tasks=make_tasks(); RESULTS.mkdir(exist_ok=True)
    episodes=[]; traces=[]
    for task in tasks:
        for strategy in CFG['strategies']:
            for repeat in range(CFG['repeats']):
                ep,tr=run_episode(task,strategy,repeat)
                episodes.append(ep); traces.append(tr)
    # Ablation on periodic verifier only, four repeats to control total budget.
    abl=[]; abl_tr=[]
    for task in tasks:
        for variant in CFG['ablation_variants']:
            for repeat in range(4):
                ep,tr=run_episode(task,'periodic_verifier',repeat,variant)
                abl.append(ep); abl_tr.append(tr)
    write_csv(RESULTS/'episodes.csv',episodes)
    write_csv(RESULTS/'ablation_episodes.csv',abl)
    with (RESULTS/'traces.jsonl').open('w',encoding='utf-8') as f:
        for tr in traces: f.write(json.dumps(tr,ensure_ascii=False)+'\n')
    with (RESULTS/'ablation_traces.jsonl').open('w',encoding='utf-8') as f:
        for tr in abl_tr: f.write(json.dumps(tr,ensure_ascii=False)+'\n')
    print(f'main episodes={len(episodes)}')
    print(f'ablation episodes={len(abl)}')
    print(f'total={len(episodes)+len(abl)}')

if __name__=='__main__': main()
