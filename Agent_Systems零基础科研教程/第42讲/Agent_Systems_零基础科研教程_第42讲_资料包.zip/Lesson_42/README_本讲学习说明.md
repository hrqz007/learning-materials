# Agent Systems 零基础科研教程 · 第42讲

## 主题
Agent 实验的统计推断：Effect Size、Confidence Interval、P-value、Multiple Comparisons、SESOI、Power 与 Pseudoreplication。

## 本讲最低闭环
Research Question / Hypothesis → Analysis Plan → Paired Runs → 确定 Task-level 独立单位 → Effect Size → Task-cluster CI → Paired Test → Multiple-comparison Correction → Practical Significance → Trace / Slice Evidence。

## 建议学习顺序
1. 先读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 再按 `03_实验指导书.docx` 运行 3600 条主实验 episode。
3. 打开 `results/pseudoreplication_summary.csv`，理解“CSV 行数 ≠ 独立样本数”。
4. 阅读 `04_实验设计书.docx`，把 Statistical Analysis Plan 当作未来论文实验模板。
5. 完成 `05_练习题.docx`，最后再看答案。

## 一键运行
```bash
python src/run_experiment.py
python src/analyze_statistics.py
python src/make_figures.py
python src/inspect_pair.py --task-id h16_t00 --repeat 0
```

## 实际生成的数据
- 主实验：100 Tasks × 6 Systems × 6 Repeats = 3600 episodes。
- Pseudoreplication 教学实验：60 Tasks × 25 Repeats = 1500 rows。
- 保存 episode-level CSV、完整 JSONL Trace、cluster-bootstrap CI、多重比较结果和 Power planning simulation。

## 教学模拟声明
所有实验数字均由受控概率模型生成，不代表 GPT、Claude、Gemini、任何真实 Agent、框架或 Benchmark 的实际性能，也不能作为真实科研结论。

## 真实科研迁移
未来把 `results/episodes.csv` 替换成真实 Agent episode 记录，并保证至少包含 `task_id / repeat / system / success / cost / tokens / latency` 等字段。`src/real_result_adapter.py` 给出了框架无关的最小字段模板。真实论文应根据自己的任务异质性重新设计任务数、重复次数、SESOI、统计检验和 Power，而不是照搬本讲数字。
