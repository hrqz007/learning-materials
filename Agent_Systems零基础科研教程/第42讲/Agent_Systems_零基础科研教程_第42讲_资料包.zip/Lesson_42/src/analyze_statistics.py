from __future__ import annotations
import csv, json, math, random, statistics
from collections import defaultdict
from common import DATA, RESULTS, SYSTEMS, LABELS, rng_for

PLAN=json.loads((DATA/'analysis_plan.json').read_text(encoding='utf-8'))

# ---------- helpers ----------
def mean(xs): return sum(xs)/len(xs) if xs else float('nan')
def percentile(xs,q):
    ys=sorted(xs)
    if not ys: return float('nan')
    pos=(len(ys)-1)*q
    lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi: return ys[lo]
    return ys[lo]*(hi-pos)+ys[hi]*(pos-lo)

def cluster_bootstrap_diff(task_values_a, task_values_b, seed=42, B=5000):
    tasks=sorted(set(task_values_a)&set(task_values_b))
    rng=random.Random(seed)
    obs=mean([task_values_b[t]-task_values_a[t] for t in tasks])
    sims=[]
    for _ in range(B):
        samp=[rng.choice(tasks) for _ in tasks]
        sims.append(mean([task_values_b[t]-task_values_a[t] for t in samp]))
    return obs, percentile(sims,.025), percentile(sims,.975)

def naive_bootstrap_diff(vals_a, vals_b, seed=43, B=5000):
    # Deliberately wrong for nested data: resamples runs as if independent.
    rng=random.Random(seed); n=min(len(vals_a),len(vals_b))
    diffs=[vals_b[i]-vals_a[i] for i in range(n)]
    obs=mean(diffs); sims=[]
    for _ in range(B): sims.append(mean([rng.choice(diffs) for _ in range(n)]))
    return obs, percentile(sims,.025), percentile(sims,.975)

def paired_permutation_p(task_values_a, task_values_b, seed=44, B=20000):
    tasks=sorted(set(task_values_a)&set(task_values_b))
    ds=[task_values_b[t]-task_values_a[t] for t in tasks]
    obs=abs(mean(ds)); rng=random.Random(seed); ge=0
    for _ in range(B):
        v=abs(mean([d if rng.random()<0.5 else -d for d in ds]))
        ge += (v>=obs-1e-15)
    return (ge+1)/(B+1)

def holm_adjust(pairs):
    # pairs: [(name,p)]
    ordered=sorted(enumerate(pairs), key=lambda x:x[1][1])
    m=len(pairs); adjusted=[0.0]*m; prev=0.0
    for rank,(orig,(name,p)) in enumerate(ordered):
        adj=min(1.0,(m-rank)*p); adj=max(adj,prev); prev=adj; adjusted[orig]=adj
    return [(pairs[i][0],pairs[i][1],adjusted[i]) for i in range(m)]

def task_metric(rows,system,metric):
    by=defaultdict(list)
    for r in rows:
        if r['system']==system: by[r['task_id']].append(float(r[metric]))
    return {t:mean(vs) for t,vs in by.items()}

def group_mean(rows,system,field):
    return mean([float(r[field]) for r in rows if r['system']==system])

with (RESULTS/'episodes.csv').open(encoding='utf-8-sig') as f:
    rows=list(csv.DictReader(f))
for r in rows:
    r['success']=int(r['success']); r['horizon']=int(r['horizon']); r['repeat']=int(r['repeat'])

# Overall system summary
summary=[]
for s in SYSTEMS:
    rs=[r for r in rows if r['system']==s]
    failures=[r for r in rs if not r['success']]
    summary.append({
        'system':s,'label':LABELS[s],'n':len(rs),
        'success_rate':mean([r['success'] for r in rs]),
        'avg_cost':mean([float(r['cost_units']) for r in rs]),
        'avg_tokens':mean([float(r['tokens']) for r in rs]),
        'avg_latency_ms':mean([float(r['latency_ms']) for r in rs]),
        'p95_latency_ms':percentile([float(r['latency_ms']) for r in rs],.95),
        'avg_quality':mean([float(r['trajectory_quality']) for r in rs]),
        'avg_propagation_if_failed':mean([float(r['propagation_depth']) for r in failures]) if failures else 0.0,
    })

# Pairwise vs baseline with task as resampling/testing unit.
comparisons=[]; raw_p=[]
base_task_success=task_metric(rows,'baseline','success')
base_task_cost=task_metric(rows,'baseline','cost_units')
for i,s in enumerate(SYSTEMS):
    if s=='baseline': continue
    st=task_metric(rows,s,'success'); ct=task_metric(rows,s,'cost_units')
    diff,lo,hi=cluster_bootstrap_diff(base_task_success,st,seed=100+i)
    cdiff,clo,chi=cluster_bootstrap_diff(base_task_cost,ct,seed=200+i)
    p=paired_permutation_p(base_task_success,st,seed=300+i)
    comparisons.append({'system':s,'label':LABELS[s],'success_diff_pp':100*diff,'ci95_low_pp':100*lo,'ci95_high_pp':100*hi,'paired_perm_p':p,'cost_diff_units':cdiff,'cost_ci_low':clo,'cost_ci_high':chi})
    raw_p.append((s,p))
for name,p,padj in holm_adjust(raw_p):
    for c in comparisons:
        if c['system']==name: c['holm_p']=padj

# Primary comparison practical significance gate.
primary=next(c for c in comparisons if c['system']==PLAN['primary_comparison']['system_b'])
primary_summary={
    'comparison':PLAN['primary_comparison'],
    'success_diff_pp':primary['success_diff_pp'],
    'ci95_pp':[primary['ci95_low_pp'],primary['ci95_high_pp']],
    'paired_permutation_p':primary['paired_perm_p'],
    'holm_p':primary['holm_p'],
    'sesoi_success_pp':PLAN['sesoi']['min_success_gain_pp'],
    'max_cost_increase_pct':PLAN['sesoi']['max_cost_increase_pct'],
}
base_cost=next(x['avg_cost'] for x in summary if x['system']=='baseline')
early_cost=next(x['avg_cost'] for x in summary if x['system']=='early_verify')
primary_summary['cost_increase_pct']=100*(early_cost-base_cost)/base_cost
primary_summary['meets_practical_gate']=(primary['success_diff_pp']>=PLAN['sesoi']['min_success_gain_pp'] and primary_summary['cost_increase_pct']<=PLAN['sesoi']['max_cost_increase_pct'])

# Horizon subgroup summary
horizon_rows=[]
for h in sorted(set(r['horizon'] for r in rows)):
    for s in SYSTEMS:
        rr=[r for r in rows if r['horizon']==h and r['system']==s]
        horizon_rows.append({'horizon':h,'system':s,'label':LABELS[s],'n':len(rr),'success_rate':mean([r['success'] for r in rr]),'avg_cost':mean([float(r['cost_units']) for r in rr])})

# Pseudoreplication demo
with (RESULTS/'pseudoreplication_runs.csv').open(encoding='utf-8-sig') as f:
    pr=list(csv.DictReader(f))
pr_by_task=defaultdict(list)
for r in pr: pr_by_task[r['task_id']].append(float(r['delta_quality']))
task_means={t:mean(v) for t,v in pr_by_task.items()}
# Naive CI: bootstrap individual run deltas. Cluster CI: bootstrap task means.
all_d=[float(r['delta_quality']) for r in pr]
rng=random.Random(909)
naive_sims=[mean([rng.choice(all_d) for _ in all_d]) for _ in range(5000)]
rng2=random.Random(910); task_ids=list(task_means)
cluster_sims=[mean([task_means[rng2.choice(task_ids)] for _ in task_ids]) for _ in range(5000)]
pseudo_summary={
    'run_count':len(all_d),'task_count':len(task_ids),'repeats_per_task':len(all_d)//len(task_ids),
    'mean_delta':mean(all_d),'naive_ci':[percentile(naive_sims,.025),percentile(naive_sims,.975)],
    'cluster_ci':[percentile(cluster_sims,.025),percentile(cluster_sims,.975)],
}

# Simple planning simulation: probability that cluster-bootstrap-like normal task-level CI excludes 0.
# This is a teaching aid, not a universal power formula.
power=[]
for effect_pp in [2,4,6]:
    for ntasks in [20,40,60,80,100,140]:
        rng=random.Random(10000+effect_pp*100+ntasks); detected=0; sims=600
        for _ in range(sims):
            # task-level success-rate differences in pp with realistic heterogeneity
            ds=[rng.gauss(effect_pp,13.0) for _ in range(ntasks)]
            m=mean(ds); sd=statistics.stdev(ds); se=sd/math.sqrt(ntasks)
            lo=m-1.96*se; hi=m+1.96*se
            if lo>0 or hi<0: detected+=1
        power.append({'effect_pp':effect_pp,'n_tasks':ntasks,'estimated_detection_rate':detected/sims,'simulations':sims})

# Save tables
def write_csv(name,items):
    with (RESULTS/name).open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=list(items[0].keys())); w.writeheader(); w.writerows(items)
write_csv('summary_overall.csv',summary)
write_csv('comparisons_vs_baseline.csv',comparisons)
write_csv('summary_by_horizon.csv',horizon_rows)
write_csv('power_curve.csv',power)
write_csv('pseudoreplication_summary.csv',[pseudo_summary])

report={'teaching_simulation':True,'overall':summary,'comparisons':comparisons,'primary':primary_summary,'pseudoreplication':pseudo_summary,'power':power}
(RESULTS/'analysis_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')

print('Primary comparison:', primary_summary)
print('Pseudoreplication demo:', pseudo_summary)
print('Multiple comparisons (raw p -> Holm p):')
for c in comparisons: print(c['system'], round(c['success_diff_pp'],3), round(c['paired_perm_p'],5), round(c['holm_p'],5))
print('TEACHING SIMULATION ONLY.')
