from __future__ import annotations
import math, random, hashlib
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
RESULTS = ROOT / 'results'
FIGURES = ROOT / 'figures'

SYSTEMS = [
    'baseline',
    'early_verify',
    'retry_only',
    'aggressive_verify',
    'specialist_long',
    'clustered_gain',
]

LABELS = {
    'baseline':'Baseline',
    'early_verify':'Early Verify',
    'retry_only':'Retry Only',
    'aggressive_verify':'Aggressive Verify',
    'specialist_long':'Long-task Specialist',
    'clustered_gain':'Clustered Gain',
}

SPECIAL_TASKS = {'h04_t03','h12_t07','h20_t11'}

def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))

def stable_seed(*parts) -> int:
    text='|'.join(map(str,parts)).encode('utf-8')
    return int(hashlib.sha256(text).hexdigest()[:16],16) & 0x7fffffff

def rng_for(*parts) -> random.Random:
    return random.Random(stable_seed(*parts))

def clamp(x, lo, hi):
    return max(lo, min(hi, x))

def base_logit(task):
    # Deliberately simple teaching model: task difficulty and horizon lower success.
    return 1.65 - 1.20*task['difficulty'] - 0.058*task['horizon'] - 0.20*task['tool_risk']

def system_logit_bonus(system: str, task: dict) -> float:
    h=task['horizon']
    if system=='baseline': return 0.0
    if system=='early_verify': return 0.20 + 0.006*h
    if system=='retry_only': return 0.075
    if system=='aggressive_verify': return 0.37 + 0.008*h
    if system=='specialist_long': return 0.50 if h>=12 else -0.02
    if system=='clustered_gain': return 2.40 if task['task_id'] in SPECIAL_TASKS else 0.0
    raise KeyError(system)

def cost_multiplier(system: str) -> float:
    return {
        'baseline':1.00,
        'early_verify':1.23,
        'retry_only':1.22,
        'aggressive_verify':1.58,
        'specialist_long':1.30,
        'clustered_gain':1.06,
    }[system]

def recovery_probability(system: str, task: dict) -> float:
    base={
        'baseline':0.08,
        'early_verify':0.48,
        'retry_only':0.20,
        'aggressive_verify':0.62,
        'specialist_long':0.35 if task['horizon']>=12 else 0.10,
        'clustered_gain':0.10,
    }[system]
    return clamp(base - 0.16*task['tool_risk'], 0.02, 0.90)
