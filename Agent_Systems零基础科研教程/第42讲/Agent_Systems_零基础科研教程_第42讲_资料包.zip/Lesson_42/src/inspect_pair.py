import argparse,csv,json
from pathlib import Path
from common import RESULTS
p=argparse.ArgumentParser(); p.add_argument('--task-id',default='h16_t00'); p.add_argument('--repeat',type=int,default=0); args=p.parse_args()
with (RESULTS/'episodes.csv').open(encoding='utf-8-sig') as f: rows=[r for r in csv.DictReader(f) if r['task_id']==args.task_id and int(r['repeat'])==args.repeat]
print(f'Paired comparison for task={args.task_id}, repeat={args.repeat}')
for r in rows:
    print(f"{r['system']:18s} success={r['success']} cost={r['cost_units']} tokens={r['tokens']} latency={r['latency_ms']} quality={r['trajectory_quality']}")
