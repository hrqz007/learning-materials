from __future__ import annotations
import csv, json, math, warnings
from pathlib import Path
import matplotlib.pyplot as plt
from matplotlib import font_manager
from common import RESULTS, FIGURES, SYSTEMS, LABELS

FIGURES.mkdir(exist_ok=True)
font_candidates=['Noto Sans CJK SC','Noto Sans CJK JP','DejaVu Sans']
for f in font_candidates:
    if any(x.name==f for x in font_manager.fontManager.ttflist):
        plt.rcParams['font.family']=f; break
plt.rcParams['axes.unicode_minus']=False

with (RESULTS/'analysis_report.json').open(encoding='utf-8') as f: report=json.load(f)

def save(name):
    plt.tight_layout(); plt.savefig(FIGURES/name,dpi=180,bbox_inches='tight'); plt.close()

# 1 statistical pipeline diagram
fig,ax=plt.subplots(figsize=(10,4.6)); ax.axis('off')
boxes=[('RQ / Hypothesis',.08,.72),('Analysis Plan',.28,.72),('Paired Runs',.48,.72),('Task-level Unit',.68,.72),('Effect + CI',.88,.72),('Multiple\nCorrection',.28,.30),('Practical\nSignificance',.50,.30),('Trace / Slice\nEvidence',.72,.30)]
for txt,x,y in boxes:
    ax.text(x,y,txt,ha='center',va='center',fontsize=11,bbox=dict(boxstyle='round,pad=.5',fc='white',ec='black'))
for a,b in [((.13,.72),(.23,.72)),((.33,.72),(.43,.72)),((.53,.72),(.63,.72)),((.73,.72),(.83,.72)),((.88,.64),(.72,.38)),((.68,.30),(.56,.30)),((.44,.30),(.34,.30))]:
    ax.annotate('',xy=b,xytext=a,arrowprops=dict(arrowstyle='->'))
ax.text(.5,.05,'核心：先定义“独立证据单位”，再谈 p-value。',ha='center',fontsize=12)
save('statistical_pipeline.png')

# 2 nested data diagram
fig,ax=plt.subplots(figsize=(9,5)); ax.axis('off')
ax.text(.5,.92,'同一 Task 下的多个 Repeat 不是“100%独立的新任务”',ha='center',fontsize=14,weight='bold')
for i,x in enumerate([.18,.5,.82]):
    ax.text(x,.72,f'Task {i+1}',ha='center',va='center',bbox=dict(boxstyle='round',fc='white',ec='black'))
    for j,dx in enumerate([-.07,0,.07]):
        ax.text(x+dx,.48,f'Run {j+1}',ha='center',va='center',fontsize=9,bbox=dict(boxstyle='circle',fc='white',ec='gray'))
        ax.annotate('',xy=(x+dx,.53),xytext=(x,.67),arrowprops=dict(arrowstyle='->',lw=1))
ax.text(.5,.18,'Resampling / inference unit：Task（cluster）\nWithin-task repeats：估计随机波动',ha='center',fontsize=12,bbox=dict(boxstyle='round,pad=.6',fc='white',ec='black'))
save('unit_of_analysis.png')

# 3 effect CI vs baseline
comps=report['comparisons']; names=[c['label'] for c in comps]; eff=[c['success_diff_pp'] for c in comps]
lo=[c['success_diff_pp']-c['ci95_low_pp'] for c in comps]; hi=[c['ci95_high_pp']-c['success_diff_pp'] for c in comps]
fig,ax=plt.subplots(figsize=(9,5.2)); y=list(range(len(names)))
ax.errorbar(eff,y,xerr=[lo,hi],fmt='o',capsize=4)
ax.axvline(0,ls='--',lw=1); ax.axvline(3,ls=':',lw=1)
ax.set_yticks(y,names); ax.set_xlabel('Task Success difference vs Baseline (percentage points)'); ax.set_title('Effect size + task-cluster 95% CI')
ax.invert_yaxis(); save('effect_ci.png')

# 4 pseudoreplication
p=report['pseudoreplication']; fig,ax=plt.subplots(figsize=(8.5,4.6))
y=[1,0]; means=[100*p['mean_delta']]*2
lows=[100*(p['mean_delta']-p['naive_ci'][0]),100*(p['mean_delta']-p['cluster_ci'][0])]
highs=[100*(p['naive_ci'][1]-p['mean_delta']),100*(p['cluster_ci'][1]-p['mean_delta'])]
ax.errorbar(means,y,xerr=[lows,highs],fmt='o',capsize=5); ax.axvline(0,ls='--',lw=1)
ax.set_yticks(y,['错误：把1500 runs当独立','正确：按60 tasks聚类']); ax.set_xlabel('Trajectory Quality difference (percentage points)'); ax.set_title('Pseudoreplication 会制造过窄的不确定区间'); save('pseudoreplication.png')

# 5 raw vs Holm p
fig,ax=plt.subplots(figsize=(9,5)); x=range(len(comps)); raw=[max(c['paired_perm_p'],1e-5) for c in comps]; adj=[max(c['holm_p'],1e-5) for c in comps]
ax.scatter(x,[-math.log10(v) for v in raw],label='Raw p'); ax.scatter(x,[-math.log10(v) for v in adj],marker='x',label='Holm-adjusted p')
ax.axhline(-math.log10(.05),ls='--',lw=1); ax.set_xticks(list(x),[c['label'] for c in comps],rotation=25,ha='right'); ax.set_ylabel('-log10(p)'); ax.set_title('多重比较：校正后证据门槛更严格'); ax.legend(); save('multiple_comparisons.png')

# 6 power planning
with (RESULTS/'power_curve.csv').open(encoding='utf-8-sig') as f: power=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(8.8,5.2))
for e in sorted(set(int(r['effect_pp']) for r in power)):
    rr=[r for r in power if int(r['effect_pp'])==e]
    ax.plot([int(r['n_tasks']) for r in rr],[float(r['estimated_detection_rate']) for r in rr],marker='o',label=f'{e} pp effect')
ax.axhline(.8,ls='--',lw=1); ax.set_ylim(0,1.03); ax.set_xlabel('Number of independent tasks'); ax.set_ylabel('Estimated detection rate'); ax.set_title('Power planning simulation (teaching aid)'); ax.legend(); save('power_curve.png')

# 7 practical significance map
summ={x['system']:x for x in report['overall']}; base=summ['baseline']; fig,ax=plt.subplots(figsize=(8.8,5.2))
for c in comps:
    s=c['system']; cost_pct=100*(summ[s]['avg_cost']-base['avg_cost'])/base['avg_cost']; ax.scatter(cost_pct,c['success_diff_pp'],s=60); ax.text(cost_pct+.4,c['success_diff_pp']+.15,c['label'],fontsize=9)
ax.axhline(3,ls=':',lw=1); ax.axvline(25,ls=':',lw=1); ax.set_xlabel('Cost increase vs Baseline (%)'); ax.set_ylabel('Success gain (percentage points)'); ax.set_title('Statistical significance ≠ Practical significance'); save('practical_significance.png')

print('Generated figures:', len(list(FIGURES.glob('*.png'))))
