"""Framework-independent adapter template for your future real Agent results.

This file does NOT call any API. It shows the minimum episode schema needed by
Lesson 42's statistical workflow. Replace the example rows with your own logs.
"""

def normalize_episode(raw: dict) -> dict:
    return {
        'task_id': str(raw['task_id']),          # independent task / cluster id
        'repeat': int(raw.get('repeat', 0)),     # repeated run within task
        'system': str(raw['system']),
        'success': int(bool(raw['success'])),
        'cost_units': float(raw.get('cost_units', 0.0)),
        'tokens': int(raw.get('tokens', 0)),
        'latency_ms': float(raw.get('latency_ms', 0.0)),
        'trajectory_quality': float(raw.get('trajectory_quality', 0.0)),
    }

if __name__=='__main__':
    demo={'task_id':'task_001','repeat':0,'system':'baseline','success':True,'cost_units':1.2,'tokens':900,'latency_ms':1400,'trajectory_quality':0.82}
    print(normalize_episode(demo))
