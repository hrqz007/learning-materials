from __future__ import annotations
import csv, json, math
from common import ROOT, DATA, RESULTS, SYSTEMS, LABELS, rng_for, sigmoid, base_logit, system_logit_bonus, cost_multiplier, recovery_probability, clamp

RESULTS.mkdir(exist_ok=True)

tasks=json.loads((DATA/'tasks.json').read_text(encoding='utf-8'))
config=json.loads((DATA/'experiment_config.json').read_text(encoding='utf-8'))
repeats=config['repeats_per_task']

fields=['task_id','horizon','difficulty','tool_risk','repeat','system','system_label','success','cost_units','tokens','latency_ms','first_bad_span','recovered','propagation_depth','trajectory_quality']
rows=[]
trace_path=RESULTS/'traces.jsonl'
with trace_path.open('w',encoding='utf-8') as tf:
    for task in tasks:
        for rep in range(repeats):
            # Common random numbers across systems create a paired design.
            common=rng_for('common',task['task_id'],rep)
            u_success=common.random()
            u_failure_pos=common.random()
            u_recover=common.random()
            common_latency=common.gauss(0,55)
            common_quality=common.gauss(0,0.025)
            for system in SYSTEMS:
                p=sigmoid(base_logit(task)+system_logit_bonus(system,task))
                success=int(u_success < p)
                base_cost=0.95 + 0.052*task['horizon'] + 0.10*task['tool_risk']
                sysrng=rng_for('sys',task['task_id'],rep,system)
                cost=base_cost*cost_multiplier(system)*(1+sysrng.gauss(0,0.025))
                tokens=int((420+72*task['horizon'])*cost_multiplier(system)*(1+sysrng.gauss(0,0.018)))
                latency=max(120.0,(430+47*task['horizon'])*cost_multiplier(system)+common_latency+sysrng.gauss(0,35))

                if success:
                    first_bad=-1; recovered=0; prop=0
                    q=clamp(0.82 - 0.012*task['horizon'] - 0.08*task['difficulty'] + 0.04*system_logit_bonus(system,task) + common_quality + sysrng.gauss(0,0.02),0,1)
                else:
                    # Failure can begin early or late. More verification increases recovery chance,
                    # but an episode recorded as final failure means any recovery was insufficient.
                    max_span=max(2, min(8, int(round(task['horizon']/3))))
                    first_bad=1+int(u_failure_pos*max_span)
                    rec=int(u_recover < recovery_probability(system,task))
                    # If final result still failed, 'recovered' means a local recovery happened but later failure remained.
                    recovered=rec
                    prop=max(1, max_span-first_bad+1 - (1 if rec else 0))
                    q=clamp(0.64 - 0.045*prop - 0.06*task['difficulty'] + common_quality + sysrng.gauss(0,0.025),0,1)

                row={
                    'task_id':task['task_id'],'horizon':task['horizon'],'difficulty':round(task['difficulty'],4),'tool_risk':round(task['tool_risk'],4),
                    'repeat':rep,'system':system,'system_label':LABELS[system],'success':success,
                    'cost_units':round(cost,4),'tokens':tokens,'latency_ms':round(latency,2),'first_bad_span':first_bad,
                    'recovered':recovered,'propagation_depth':prop,'trajectory_quality':round(q,4)
                }
                rows.append(row)

                spans=[]
                nsp=max(4,min(9,int(round(task['horizon']/3))+2))
                for s in range(nsp):
                    status='ok'
                    if first_bad>=0 and s>=first_bad:
                        status='error' if s==first_bad else 'propagated'
                    spans.append({'span_id':s,'module':['planner','tool','memory','verifier','executor','evaluator'][s%6], 'status':status})
                trace={
                    'teaching_simulation':True,
                    'task_id':task['task_id'],'repeat':rep,'system':system,'success':bool(success),
                    'metrics':{k:row[k] for k in ['cost_units','tokens','latency_ms','first_bad_span','recovered','propagation_depth','trajectory_quality']},
                    'spans':spans
                }
                tf.write(json.dumps(trace,ensure_ascii=False)+'\n')

with (RESULTS/'episodes.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)

# Separate pseudoreplication dataset: repeated runs are strongly correlated within task.
# It is intentionally constructed so the naive run-level CI is overconfident relative to task-cluster CI.
pseudo=[]
for ti in range(60):
    tr=rng_for('pseudo_task',ti)
    task_effect=tr.gauss(0.018,0.115)   # between-task heterogeneity dominates
    baseline_level=tr.uniform(0.48,0.78)
    for rep in range(25):
        rr=rng_for('pseudo_run',ti,rep)
        noise=rr.gauss(0,0.018)
        delta=task_effect+noise
        pseudo.append({'task_id':f'p{ti:02d}','repeat':rep,'baseline_quality':round(baseline_level+rr.gauss(0,0.01),4),'delta_quality':round(delta,4),'method_quality':round(clamp(baseline_level+delta,0,1),4)})
with (RESULTS/'pseudoreplication_runs.csv').open('w',newline='',encoding='utf-8-sig') as f:
    w=csv.DictWriter(f,fieldnames=pseudo[0].keys()); w.writeheader(); w.writerows(pseudo)

print(f"Generated {len(rows)} main episodes = {len(tasks)} tasks x {len(SYSTEMS)} systems x {repeats} repeats")
print(f"Generated {len(pseudo)} pseudoreplication rows = 60 tasks x 25 repeated runs")
print('TEACHING SIMULATION ONLY: results do not represent any real model or vendor.')
