# Agent Systems 零基础科研教程 · 第43讲

## 主题
Agent Systems 论文的 Method 怎么写：Problem Formulation、System Design、Algorithm、Notation、Pseudocode 与 Reproducibility Contract。

## 本讲最低闭环
Observation → Research Question → Hypothesis → Problem Formulation → Module Contract → Algorithm/Pseudocode → Code Mapping → Budget-Matched Baseline → Ablation → Trace Evidence → Reproducibility Contract。

## 建议学习顺序
1. 先读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 打开 `data/method_contract.json`，逐项看一个 Method 至少要写清什么。
3. 按 `03_实验指导书.docx` 实际运行 2400 个 episodes。
4. 运行 `src/inspect_trace.py`，把 Method → Code → Trace 对起来。
5. 阅读 `04_实验设计书.docx`，理解 Baseline、Resource-Matched Baseline 与 Ablation。
6. 完成练习题，再看答案。

## 一键运行
```bash
python src/run_experiment.py
python src/analyze_method.py
python src/audit_contract.py
python src/make_figures.py
python src/inspect_trace.py --task-id h08_t00 --repeat 3 --system full_brg
```

## 实际生成的数据
- 80 Tasks × 6 Systems × 5 Repeats = 2400 episodes。
- 33,557 条 step-level trace spans。
- Baseline / Budget-Matched Baseline / 3个 Ablations / Full Method。
- 完整 Method Contract、故意不完整 Contract、代码映射和自动审计结果。

## 教学模拟声明
BRG 是为了讲解 Method 结构而构造的教学机制，不声称科研创新。所有成功率、故障概率和成本均来自受控模拟，不代表 GPT、Claude、Gemini、任何真实 Agent、框架或 Benchmark 的性能。

## 真实科研迁移
未来研究真实 Agent 时，保留这里的“Method Contract 思维”，但重新定义真实的 Task、State、Module Contract、Budget、Baseline、Ablation 和 Trace schema；不要照搬本讲的模拟参数和结果。
