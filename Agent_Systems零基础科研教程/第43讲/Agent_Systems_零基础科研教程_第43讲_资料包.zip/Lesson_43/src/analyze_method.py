from __future__ import annotations
import csv, json, statistics
from collections import defaultdict
from common import RESULTS, SYSTEMS

def mean(xs): return sum(xs)/len(xs) if xs else float('nan')

def load_rows():
    with open(RESULTS/'episodes.csv',newline='',encoding='utf-8') as f: return list(csv.DictReader(f))

def write_csv(path, rows):
    if not rows: return
    with open(path,'w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=list(rows[0].keys())); w.writeheader(); w.writerows(rows)

def main():
    rows=load_rows(); groups=defaultdict(list)
    for r in rows: groups[r['system']].append(r)
    overall=[]
    for s,rs in groups.items():
        failures=[r for r in rs if int(r['failure_count'])>0]
        rec_attempt=[r for r in rs if int(r['recovery_attempts'])>0]
        overall.append({
            'system':s,'label':SYSTEMS[s]['label'],'n':len(rs),
            'success_rate':round(mean([int(r['success']) for r in rs]),4),
            'avg_cost':round(mean([float(r['cost']) for r in rs]),4),
            'avg_tokens':round(mean([int(r['tokens']) for r in rs]),2),
            'avg_latency_ms':round(mean([float(r['latency_ms']) for r in rs]),2),
            'failure_episode_rate':round(len(failures)/len(rs),4),
            'avg_detection_delay_on_failure':round(mean([float(r['detection_delay']) for r in failures if r['detection_delay']!='']),3) if failures else '',
            'avg_propagation_depth_on_failure':round(mean([int(r['max_propagation_depth']) for r in failures]),3) if failures else '',
            'recovery_success_per_attempt':round(sum(int(r['recoveries']) for r in rs)/max(1,sum(int(r['recovery_attempts']) for r in rs)),4),
        })
    order=['baseline','budget_matched','no_detector','no_checkpoint','no_state_reset','full_brg']
    overall=sorted(overall,key=lambda x:order.index(x['system']))
    write_csv(RESULTS/'summary_overall.csv',overall)
    # horizon slices
    slices=[]
    for h in sorted({int(r['horizon']) for r in rows}):
        for s in order:
            rs=[r for r in rows if int(r['horizon'])==h and r['system']==s]
            slices.append({'horizon':h,'system':s,'label':SYSTEMS[s]['label'],'n':len(rs),
                           'success_rate':round(mean([int(r['success']) for r in rs]),4),
                           'avg_cost':round(mean([float(r['cost']) for r in rs]),4),
                           'avg_propagation_depth':round(mean([int(r['max_propagation_depth']) for r in rs]),3)})
    write_csv(RESULTS/'summary_by_horizon.csv',slices)
    base={x['system']:x for x in overall}
    full=base['full_brg']
    effects=[]
    for s in ['baseline','budget_matched','no_detector','no_checkpoint','no_state_reset']:
        x=base[s]
        effects.append({
            'comparison':f'full_brg - {s}',
            'success_delta_pp':round(100*(full['success_rate']-x['success_rate']),2),
            'propagation_delta':round(float(full['avg_propagation_depth_on_failure'])-float(x['avg_propagation_depth_on_failure']),3),
            'cost_delta':round(full['avg_cost']-x['avg_cost'],4),
            'interpretation':'component/mechanism teaching contrast'
        })
    write_csv(RESULTS/'ablation_effects.csv',effects)
    report={'overall':overall,'horizon':slices,'ablation_effects':effects,
            'teaching_note':'Controlled simulator only; do not generalize to real models.'}
    (RESULTS/'analysis_report.json').write_text(json.dumps(report,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(report['overall'],ensure_ascii=False,indent=2))

if __name__=='__main__': main()
