from __future__ import annotations
import ast, json, sys
from pathlib import Path
from common import ROOT, DATA, RESULTS

REQUIRED_TOP=['method_name','research_origin','problem_formulation','modules','algorithm','hyperparameters','budget','metrics','ablations','baselines','trace_schema','reproducibility']
MODULE_KEYS=['name','input','output','state_effect','failure_semantics']

def symbols_in_file(path: Path):
    tree=ast.parse(path.read_text(encoding='utf-8'))
    return {n.name for n in ast.walk(tree) if isinstance(n,(ast.FunctionDef,ast.AsyncFunctionDef,ast.ClassDef))}

def audit(path: Path):
    obj=json.loads(path.read_text(encoding='utf-8'))
    checks=[]
    for k in REQUIRED_TOP:
        checks.append((f'top:{k}', k in obj and obj[k] not in (None,{},[],'')))
    if isinstance(obj.get('modules'),list):
        for i,m in enumerate(obj['modules']):
            for k in MODULE_KEYS: checks.append((f'module[{i}]:{k}', k in m and m[k] not in (None,'')))
    # reproducibility links
    repro=obj.get('reproducibility',{})
    for k in ['task_file','config_file','implementation_map','seed_policy','raw_artifacts']:
        checks.append((f'repro:{k}',k in repro and repro[k] not in (None,'',[])))
    # implementation map symbols, only when present
    impl_ok=[]
    impl_path=DATA/'implementation_map.json'
    if impl_path.exists() and path.name=='method_contract.json':
        impl=json.loads(impl_path.read_text(encoding='utf-8'))
        for name,meta in impl.items():
            f=ROOT/meta['file']; sym=meta['symbol']; ok=f.exists() and sym in symbols_in_file(f)
            checks.append((f'implementation:{name}->{meta["file"]}:{sym}',ok)); impl_ok.append(ok)
    passed=sum(1 for _,ok in checks if ok); total=len(checks)
    return {'file':path.name,'passed':passed,'total':total,'coverage':round(passed/total,4) if total else 0.0,
            'failed':[name for name,ok in checks if not ok], 'checks':[{'name':n,'pass':ok} for n,ok in checks]}

def main():
    RESULTS.mkdir(exist_ok=True)
    complete=audit(DATA/'method_contract.json')
    incomplete=audit(DATA/'incomplete_method_contract.json')
    out={'complete':complete,'incomplete':incomplete}
    (RESULTS/'method_audit.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))
    if complete['coverage'] < 0.95: raise SystemExit('complete contract coverage too low')

if __name__=='__main__': main()
