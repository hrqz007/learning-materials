from __future__ import annotations
import csv, hashlib, json, math, random
from pathlib import Path

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
RESULTS = ROOT / 'results'
FIGURES = ROOT / 'figures'

SYSTEMS = {
    'baseline': {
        'label': 'Baseline', 'detector_recall': 0.18, 'checkpoint_interval': None,
        'max_retries': 0, 'reset_effectiveness': 0.0, 'local_recovery': 0.18,
        'extra_check_cost': 0.00, 'extra_check_latency': 0.0,
    },
    'budget_matched': {
        'label': 'Budget-Matched Baseline', 'detector_recall': 0.25, 'checkpoint_interval': None,
        'max_retries': 1, 'reset_effectiveness': 0.0, 'local_recovery': 0.28,
        'extra_check_cost': 0.018, 'extra_check_latency': 7.0,
    },
    'no_detector': {
        'label': 'BRG - Detector', 'detector_recall': 0.0, 'checkpoint_interval': 4,
        'max_retries': 1, 'reset_effectiveness': 0.88, 'local_recovery': 0.28,
        'extra_check_cost': 0.010, 'extra_check_latency': 4.0,
    },
    'no_checkpoint': {
        'label': 'BRG - Checkpoint', 'detector_recall': 0.72, 'checkpoint_interval': None,
        'max_retries': 1, 'reset_effectiveness': 0.0, 'local_recovery': 0.46,
        'extra_check_cost': 0.022, 'extra_check_latency': 8.0,
    },
    'no_state_reset': {
        'label': 'BRG - StateReset', 'detector_recall': 0.72, 'checkpoint_interval': 4,
        'max_retries': 1, 'reset_effectiveness': 0.44, 'local_recovery': 0.28,
        'extra_check_cost': 0.026, 'extra_check_latency': 9.0,
    },
    'full_brg': {
        'label': 'Full BRG', 'detector_recall': 0.72, 'checkpoint_interval': 4,
        'max_retries': 1, 'reset_effectiveness': 0.88, 'local_recovery': 0.28,
        'extra_check_cost': 0.030, 'extra_check_latency': 10.0,
    },
}

TRACE_FIELDS = [
    'task_id','repeat','system','span_id','step','event','corrupted_before','detected',
    'recovery_attempted','recovery_success','corrupted_after','cost_delta','latency_delta_ms'
]

def stable_seed(*parts: object) -> int:
    raw = '|'.join(map(str, parts)).encode('utf-8')
    return int(hashlib.sha256(raw).hexdigest()[:16], 16)

def load_config():
    return json.loads((DATA/'experiment_config.json').read_text(encoding='utf-8'))

def make_tasks(cfg=None):
    cfg = cfg or load_config()
    tasks=[]
    idx=0
    for h in cfg['horizons']:
        for j in range(cfg['tasks_per_horizon']):
            # deterministic diversity; no external model involved
            difficulty = 0.18 + 0.64 * ((j * 7 + h) % 20) / 19
            tool_risk = 0.08 + 0.42 * ((j * 11 + h//4) % 20) / 19
            category = ['planning','tool','memory','mixed'][(j + h) % 4]
            tasks.append({
                'task_id': f'h{h:02d}_t{j:02d}', 'horizon': h,
                'difficulty': round(difficulty,4), 'tool_risk': round(tool_risk,4),
                'category': category, 'index': idx,
            })
            idx += 1
    return tasks

def save_tasks(tasks):
    (DATA/'tasks.json').write_text(json.dumps(tasks, ensure_ascii=False, indent=2), encoding='utf-8')

def attempt_detection(rng: random.Random, cfg: dict, corrupted: bool) -> bool:
    if not corrupted:
        return False
    return rng.random() < cfg['detector_recall']

def attempt_recovery(rng: random.Random, cfg: dict, has_checkpoint: bool, retry_count: int):
    if retry_count >= cfg['max_retries']:
        return False, False
    if has_checkpoint:
        return True, (rng.random() < cfg['reset_effectiveness'])
    return True, (rng.random() < cfg['local_recovery'])

def simulate_episode(task: dict, system: str, repeat: int, namespace: str):
    scfg = SYSTEMS[system]
    rng = random.Random(stable_seed(namespace, task['task_id'], system, repeat))
    H=task['horizon']; diff=task['difficulty']; risk=task['tool_risk']
    corrupted=False; first_bad=None; detect_step=None; last_checkpoint=0
    retry_count_for_event=0; total_retries=0; recoveries=0; recovery_attempts=0
    propagation_depth=0; max_propagation=0; critical_failure=False
    cost=0.22; latency=40.0; tokens=420; model_calls=1
    traces=[]; failure_types=[]
    span_id=0
    for step in range(1,H+1):
        span_id += 1
        corrupted_before=corrupted
        event='normal'
        detected=False; rec_attempt=False; rec_success=False
        step_cost=0.010 + scfg['extra_check_cost']
        step_latency=10.0 + scfg['extra_check_latency']
        step_tokens=45 + int(14*diff)
        # checkpoint is written only while state is clean
        if scfg['checkpoint_interval'] and (step-1) % scfg['checkpoint_interval']==0 and not corrupted:
            last_checkpoint=step-1
        if not corrupted:
            tool_factor = risk if step % 3 == 0 else 0.0
            p_error = 0.010 + 0.025*diff + 0.012*tool_factor + 0.006*(step/H)
            if rng.random() < p_error:
                corrupted=True; first_bad = first_bad or step; retry_count_for_event=0
                severity = 'critical' if rng.random() < (0.28 + 0.32*diff) else 'recoverable'
                failure_types.append(severity); event=f'failure:{severity}'
        if corrupted:
            propagation_depth += 1
            max_propagation=max(max_propagation, propagation_depth)
            detected = attempt_detection(rng, scfg, corrupted)
            if detected:
                detect_step = detect_step or step
                has_ckpt = scfg['checkpoint_interval'] is not None and last_checkpoint < step
                rec_attempt, rec_success = attempt_recovery(rng, scfg, has_ckpt, retry_count_for_event)
                if rec_attempt:
                    recovery_attempts += 1; total_retries += 1; retry_count_for_event += 1
                    model_calls += 1; step_cost += 0.055; step_latency += 28; step_tokens += 120
                    if rec_success:
                        recoveries += 1; corrupted=False; propagation_depth=0; detect_step=None; retry_count_for_event=0
                        event += '|recovered'
                    else:
                        event += '|recovery_failed'
            # if corruption persists, it can become terminal; long propagation is dangerous
            if corrupted:
                p_terminal = 0.012 + 0.018*propagation_depth + 0.020*diff
                if 'critical' in failure_types[-1:]:
                    p_terminal += 0.045
                if rng.random() < min(0.32,p_terminal):
                    critical_failure=True; event += '|terminal'
        cost += step_cost; latency += step_latency; tokens += step_tokens
        traces.append({
            'task_id':task['task_id'],'repeat':repeat,'system':system,'span_id':span_id,'step':step,
            'event':event,'corrupted_before':int(corrupted_before),'detected':int(detected),
            'recovery_attempted':int(rec_attempt),'recovery_success':int(rec_success),
            'corrupted_after':int(corrupted),'cost_delta':round(step_cost,4),'latency_delta_ms':round(step_latency,2)
        })
        if critical_failure:
            break
    # final result: unrecovered corruption may still be survived sometimes, but less likely as propagation grows
    if critical_failure:
        success=False
    elif corrupted:
        survival = max(0.05, 0.52 - 0.055*max_propagation - 0.12*diff)
        success = rng.random() < survival
    else:
        completion_noise = 0.96 - 0.035*diff - 0.010*(H/8-1)
        success = rng.random() < max(0.72, completion_noise)
    det_delay = None
    if first_bad is not None:
        detected_steps=[x['step'] for x in traces if x['detected']]
        if detected_steps:
            det_delay=max(0,min(detected_steps)-first_bad)
        else:
            det_delay=H-first_bad+1
    recovery_rate = (recoveries/recovery_attempts) if recovery_attempts else None
    return {
        'task_id':task['task_id'],'horizon':H,'difficulty':diff,'tool_risk':risk,'category':task['category'],
        'repeat':repeat,'system':system,'system_label':scfg['label'],'success':int(success),
        'first_bad_span':first_bad if first_bad is not None else '',
        'detection_delay':det_delay if det_delay is not None else '',
        'max_propagation_depth':max_propagation,'recovery_attempts':recovery_attempts,'recoveries':recoveries,
        'recovery_rate': round(recovery_rate,4) if recovery_rate is not None else '',
        'model_calls':model_calls,'tokens':tokens,'cost':round(cost,4),'latency_ms':round(latency,2),
        'trace_steps':len(traces),'failure_count':len(failure_types)
    }, traces

def read_csv(path):
    with open(path, newline='', encoding='utf-8') as f:
        return list(csv.DictReader(f))
