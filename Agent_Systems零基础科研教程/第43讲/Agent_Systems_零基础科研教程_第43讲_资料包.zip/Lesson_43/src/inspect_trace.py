from __future__ import annotations
import argparse, json
from common import RESULTS

def main():
    ap=argparse.ArgumentParser(); ap.add_argument('--task-id',default='h24_t07'); ap.add_argument('--repeat',type=int,default=0); ap.add_argument('--system',default='full_brg')
    a=ap.parse_args(); selected=[]
    with open(RESULTS/'traces.jsonl',encoding='utf-8') as f:
        for line in f:
            x=json.loads(line)
            if x['task_id']==a.task_id and x['repeat']==a.repeat and x['system']==a.system: selected.append(x)
    print(f"TRACE task={a.task_id} repeat={a.repeat} system={a.system} spans={len(selected)}")
    for x in selected:
        print(f"step={x['step']:>2} event={x['event']:<34} before={x['corrupted_before']} detect={x['detected']} recover={x['recovery_attempted']}/{x['recovery_success']} after={x['corrupted_after']} cost+={x['cost_delta']}")

if __name__=='__main__': main()
