from __future__ import annotations
import csv, json, math
from pathlib import Path
import matplotlib
matplotlib.use('Agg')
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch
from common import ROOT, RESULTS, FIGURES, SYSTEMS

FIGURES.mkdir(exist_ok=True)
BLUE='#1F4E79'; GREEN='#2E7D32'; ORANGE='#EF6C00'; RED='#C62828'; PURPLE='#6A1B9A'; GRAY='#707070'; LIGHT='#F4F6F8'; DARK='#222222'
plt.rcParams['font.sans-serif']=['Noto Sans CJK SC','DejaVu Sans']
plt.rcParams['axes.unicode_minus']=False

def box(ax,xy,w,h,text,fc='white',ec=BLUE,fontsize=10):
    p=FancyBboxPatch(xy,w,h,boxstyle='round,pad=0.012,rounding_size=0.02',fc=fc,ec=ec,lw=1.6)
    ax.add_patch(p); ax.text(xy[0]+w/2,xy[1]+h/2,text,ha='center',va='center',fontsize=fontsize,color=DARK,wrap=True)
    return p

def arrow(ax,a,b,color=GRAY):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=13,lw=1.4,color=color))

def save(name):
    plt.tight_layout(); plt.savefig(FIGURES/name,dpi=190,bbox_inches='tight'); plt.close()

# 1 Research -> Method pipeline
fig,ax=plt.subplots(figsize=(10,3.2)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
labels=[('Observed\nphenomenon',0.02,GREEN),('Research\nQuestion',0.18,BLUE),('Falsifiable\nHypothesis',0.34,PURPLE),('Mechanism\nMethod',0.50,ORANGE),('Controlled\nExperiment',0.66,BLUE),('Evidence +\nAblation',0.82,RED)]
for txt,x,c in labels: box(ax,(x,0.34),0.14,0.32,txt,fc='white',ec=c,fontsize=10)
for i in range(len(labels)-1): arrow(ax,(labels[i][1]+0.14,0.5),(labels[i+1][1],0.5))
ax.text(0.5,0.12,'Method is an operationalized hypothesis, not a decoration added before observing a problem.',ha='center',fontsize=10,color=PURPLE)
save('research_to_method_pipeline.png')

# 2 method contract layers
fig,ax=plt.subplots(figsize=(9,5)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
levels=[('Problem formulation\nInput / Output / State / Assumptions',0.78,BLUE),('Module contracts\nInput -> Operation -> Output -> State effect',0.60,GREEN),('Algorithm & control flow\nLoop / termination / retry / fallback',0.42,ORANGE),('Budget & hyperparameters\nCalls / tokens / retries / defaults',0.24,PURPLE),('Reproducibility artifacts\nConfig / code map / trace / evaluator',0.06,RED)]
for txt,y,c in levels: box(ax,(0.10,y),0.80,0.13,txt,fc='white',ec=c,fontsize=10.5)
for i in range(len(levels)-1): arrow(ax,(0.50,levels[i][1]),(0.50,levels[i+1][1]+0.13))
save('method_contract_layers.png')

# 3 state transition
fig,ax=plt.subplots(figsize=(9,4.2)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
box(ax,(0.05,0.58),0.20,0.20,'Clean state',fc='#E8F5E9',ec=GREEN)
box(ax,(0.39,0.58),0.22,0.20,'Corrupted state',fc='#FFEBEE',ec=RED)
box(ax,(0.73,0.58),0.22,0.20,'Recovered state',fc='#E3F2FD',ec=BLUE)
box(ax,(0.39,0.16),0.22,0.18,'Terminal failure',fc='#F5F5F5',ec=GRAY)
arrow(ax,(0.25,0.68),(0.39,0.68),RED); ax.text(0.32,0.72,'failure event',ha='center',fontsize=9,color=RED)
arrow(ax,(0.61,0.68),(0.73,0.68),BLUE); ax.text(0.67,0.72,'detect + gate + reset',ha='center',fontsize=8.5,color=BLUE)
arrow(ax,(0.50,0.58),(0.50,0.34),GRAY); ax.text(0.57,0.46,'unrecovered propagation',fontsize=8.5,color=GRAY)
arrow(ax,(0.84,0.58),(0.20,0.58),GREEN); ax.text(0.53,0.52,'resume loop',ha='center',fontsize=8.5,color=GREEN)
save('state_transition.png')

# 4 pseudocode flow
fig,ax=plt.subplots(figsize=(7.5,6.2)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
ys=[0.86,0.70,0.54,0.38,0.22,0.06]
texts=['Observe + Act','Update checkpoint if clean','Detector: failure evidence?','RecoveryGate: budget available?','StateReset / local recovery','Record trace span + continue']
colors=[BLUE,GREEN,PURPLE,ORANGE,RED,BLUE]
for y,t,c in zip(ys,texts,colors): box(ax,(0.20,y),0.60,0.10,t,fc='white',ec=c,fontsize=10)
for i in range(len(ys)-1): arrow(ax,(0.50,ys[i]),(0.50,ys[i+1]+0.10))
ax.text(0.82,0.57,'No -> record & continue',fontsize=8.5,color=GRAY)
ax.text(0.82,0.41,'No -> continue corrupted',fontsize=8.5,color=GRAY)
save('algorithm_flow.png')

# 5 method -> code -> artifact mapping
fig,ax=plt.subplots(figsize=(10,4.6)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
cols=[0.04,0.37,0.70]
headers=['Paper Method','Implementation','Runtime Evidence']
for x,h in zip(cols,headers): ax.text(x+0.13,0.92,h,ha='center',fontsize=12,fontweight='bold',color=BLUE)
items=[('Detector definition','attempt_detection()','trace.detected'),('Recovery rule','attempt_recovery()','recovery_attempted / success'),('State transition','simulate_episode()','corrupted_before / after'),('Budget','SYSTEMS config','model_calls / cost / tokens')]
for i,(a,b,c) in enumerate(items):
    y=0.72-i*0.18
    box(ax,(cols[0],y),0.26,0.11,a,ec=PURPLE,fontsize=9)
    box(ax,(cols[1],y),0.26,0.11,b,ec=ORANGE,fontsize=9)
    box(ax,(cols[2],y),0.26,0.11,c,ec=GREEN,fontsize=9)
    arrow(ax,(cols[0]+0.26,y+0.055),(cols[1],y+0.055)); arrow(ax,(cols[1]+0.26,y+0.055),(cols[2],y+0.055))
save('method_code_trace_mapping.png')

# load results
with open(RESULTS/'summary_overall.csv',newline='',encoding='utf-8') as f: rows=list(csv.DictReader(f))
order=[r['system'] for r in rows]; labels=[r['label'] for r in rows]
success=[float(r['success_rate']) for r in rows]; costs=[float(r['avg_cost']) for r in rows]
prop=[float(r['avg_propagation_depth_on_failure']) if r['avg_propagation_depth_on_failure'] else 0 for r in rows]

# 6 success and cost
fig,ax=plt.subplots(figsize=(10,4.6))
x=range(len(rows)); ax.bar(x,[v*100 for v in success],alpha=.85)
ax.set_xticks(list(x),labels,rotation=18,ha='right'); ax.set_ylabel('Task Success (%)'); ax.set_ylim(0,100); ax.set_title('Controlled teaching simulation: outcome comparison')
for i,v in enumerate(success): ax.text(i,v*100+1,f'{v*100:.1f}%',ha='center',fontsize=8)
save('result_task_success.png')

fig,ax=plt.subplots(figsize=(10,4.6)); ax.scatter(costs,[v*100 for v in success],s=70)
for c,s,l in zip(costs,success,labels): ax.annotate(l,(c,s*100),xytext=(5,4),textcoords='offset points',fontsize=8)
ax.set_xlabel('Average simulated cost'); ax.set_ylabel('Task Success (%)'); ax.set_title('Outcome-resource trade-off (teaching simulator only)')
save('result_cost_tradeoff.png')

# 7 ablation mechanism
fig,ax=plt.subplots(figsize=(10,4.6)); ax.bar(range(len(rows)),prop,alpha=.85)
ax.set_xticks(range(len(rows)),labels,rotation=18,ha='right'); ax.set_ylabel('Avg max propagation depth | failure episode'); ax.set_title('Mechanism metric: failure propagation')
for i,v in enumerate(prop): ax.text(i,v+0.03,f'{v:.2f}',ha='center',fontsize=8)
save('ablation_propagation.png')

# 8 contract audit
obj=json.loads((RESULTS/'method_audit.json').read_text(encoding='utf-8'))
vals=[obj['complete']['coverage']*100,obj['incomplete']['coverage']*100]
fig,ax=plt.subplots(figsize=(7.4,4.5)); ax.bar(['Complete contract','Incomplete description'],vals,alpha=.85)
ax.set_ylim(0,105); ax.set_ylabel('Audit coverage (%)'); ax.set_title('Method reproducibility contract audit')
for i,v in enumerate(vals): ax.text(i,v+2,f'{v:.1f}%',ha='center')
save('method_contract_audit.png')

print('figures=', len(list(FIGURES.glob('*.png'))))
