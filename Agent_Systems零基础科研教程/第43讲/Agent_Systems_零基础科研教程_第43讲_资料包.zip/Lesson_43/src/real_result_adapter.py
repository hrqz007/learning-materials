"""Framework-independent adapter template for migrating Lesson 43 to a real Agent experiment.
No API call is made in this file. It only documents the minimum artifact contract.
"""
REQUIRED_EPISODE_FIELDS = [
    'task_id','repeat','system','success','cost','tokens','latency_ms',
    'first_bad_span','detection_delay','max_propagation_depth','recovery_attempts','recoveries'
]
REQUIRED_METHOD_ARTIFACTS = [
    'problem formulation','module contracts','algorithm/control flow','budget','hyperparameters',
    'implementation map','raw trace schema','ablation definitions','baseline definitions'
]

def validate_episode(record: dict):
    return [k for k in REQUIRED_EPISODE_FIELDS if k not in record]

if __name__=='__main__':
    print('This is an adapter/checklist only; no external API is invoked.')
    print('required_episode_fields=', REQUIRED_EPISODE_FIELDS)
