from __future__ import annotations
import csv, json
from pathlib import Path
from common import ROOT, DATA, RESULTS, TRACE_FIELDS, SYSTEMS, load_config, make_tasks, save_tasks, simulate_episode

def main():
    RESULTS.mkdir(exist_ok=True); DATA.mkdir(exist_ok=True)
    cfg=load_config(); tasks=make_tasks(cfg); save_tasks(tasks)
    rows=[]; traces=[]
    for task in tasks:
        for system in cfg['systems']:
            for repeat in range(cfg['repeats']):
                row, tr = simulate_episode(task, system, repeat, cfg['seed_namespace'])
                rows.append(row); traces.extend(tr)
    fields=list(rows[0].keys())
    with open(RESULTS/'episodes.csv','w',newline='',encoding='utf-8') as f:
        w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(rows)
    with open(RESULTS/'traces.jsonl','w',encoding='utf-8') as f:
        for x in traces: f.write(json.dumps(x,ensure_ascii=False)+'\n')
    print(f"tasks={len(tasks)} systems={len(cfg['systems'])} repeats={cfg['repeats']} episodes={len(rows)} spans={len(traces)}")
    print(cfg['disclaimer'])

if __name__=='__main__': main()
