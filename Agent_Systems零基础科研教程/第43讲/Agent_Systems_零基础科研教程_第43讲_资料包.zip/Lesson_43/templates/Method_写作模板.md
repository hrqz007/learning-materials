# Agent Systems 论文 Method 写作模板

## 1. Problem Formulation
- 任务对象是什么？输入、输出、状态、环境分别是什么？
- 研究对象的边界在哪里？哪些因素被固定，哪些因素可变化？
- 用最少必要符号定义 H、s_t、o_t、a_t、e_t 等。

## 2. Method Overview
- 一句话说明方法要解决第41讲已经确认的哪个现象/假设。
- 给出系统结构图，不要把实验设置混入方法图。

## 3. Components
对每个模块写：Input → Operation → Output → State Effect → Failure Semantics。

## 4. Algorithm / Control Flow
- 给出主循环或状态机。
- 明确 termination、retry、timeout、fallback。
- 对随机或模型调用部分说明可控与不可控来源。

## 5. Resource / Budget
- 最大模型调用、Token、Retry、Agent 数量、并发度等。
- 若声称方法更有效，需要提前定义 resource-matched baseline。

## 6. Implementation Details
- 所有会改变结果的默认值都应可追溯到配置。
- 记录模型版本、Harness、工具、环境、Evaluator、Seed policy。

## 7. Ablation Plan
- 每个 Ablation 必须回答“移除哪一个机制？预计哪个 mechanism metric 会变化？”
- 不要把随机删模块当成 Ablation。

## 8. Reproducibility Contract
- task/split/config/code/trace/evaluator/analysis 的具体文件与版本。
