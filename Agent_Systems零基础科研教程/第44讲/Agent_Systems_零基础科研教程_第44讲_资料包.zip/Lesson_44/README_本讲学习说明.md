# 第44讲学习说明

## 主题

《Agent Systems 论文的 Experiments 怎么设计——从 Research Question 到完整实验矩阵、Baselines、Ablations、Stress Tests 与 Evidence Chain》

## 本讲核心目标

把“我会跑 Agent 实验”升级为“我能为论文中的每个 Claim 设计一条可审计证据链”。

核心结构：

Research Question → Hypothesis → Frozen Protocol → Experiment Matrix → Runs → Statistics → Trace Audit → Claim-Evidence Map

## 建议学习顺序

1. 阅读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 打开 `data/experiment_matrix.csv`，先理解四类实验家族。
3. 按 `03_实验指导书.docx` 运行源码。
4. 对照 `04_实验设计书.docx`，学习正式实验协议怎样写。
5. 独立完成 `05_练习题.docx`，再看 `06_练习题答案.docx`。
6. 用 `07_术语速查表.docx` 复习实验设计词汇。
7. 真正立项时，复制 `templates/` 下的模板。

## 最小运行命令

```bash
python -m py_compile src/*.py
python src/run_experiment.py
python src/analyze_experiment.py
python src/make_figures.py
python src/inspect_trace.py --first-failure
```

## 实际运行规模

- Main：1600 episodes
- Ablation：1280 episodes
- Stress：1440 episodes
- Scaling：900 episodes
- 总计：5220 episodes
- `results/traces.jsonl`：5220 条 episode-level JSONL，每条包含 span-level trace

## 重要声明

这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实 Agent、Benchmark、框架的实际性能。人为设置的概率只用于展示实验设计、资源匹配、Ablation、Stress、Scaling、Trace 和 Evidence Chain 的科研方法。

## 你完成本讲后的最低闭环能力

你应该能独立回答：

- 为什么一个主结果需要 Strong / Resource-Matched Baseline？
- 为什么 Main、Ablation、Stress、Scaling 不能混成一个“总分”？
- 为什么 Task 才常是 experimental unit，而 repeat 不是？
- 怎样避免 Full Factorial 导致实验矩阵爆炸？
- 怎样从论文中的一个 Claim 反向追到具体 run 和 trace？
