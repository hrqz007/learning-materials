# Lesson 44 Controlled Experiment Summary

> 仅为受控教学模拟，不代表任何真实模型性能。

本讲实验矩阵共有 5220 个 episodes：Main 1600、Ablation 1280、Stress 1440、Scaling 900。

教学目的不是证明 Candidate Recovery 是真实新方法，而是演示：

1. Main result 只能回答“统一协议下是否观察到差异”；
2. Resource-matched baseline 用于排除“只是用了更多 Token/Calls”的替代解释；
3. Ablation 需要同时观察 outcome 与 mechanism metrics；
4. Stress 与 Scaling 用于寻找结论边界；
5. 每个 Claim 应映射到固定协议、run set、summary、effect/CI 与 Trace。

本模拟器中 Candidate 与 Baseline、Token-Matched Baseline 出现明显差异；短任务上的差异较小，长任务和高压力条件下差异变大。这些现象由教学参数人为构造，只用于展示为什么 Experiment Matrix 必须覆盖 boundary conditions。
