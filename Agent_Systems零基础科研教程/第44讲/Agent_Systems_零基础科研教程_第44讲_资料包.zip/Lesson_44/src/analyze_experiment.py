"""Analyze Lesson 44 controlled experiment results."""
from __future__ import annotations

import csv
import json
import math
import statistics
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

from common import RESULTS_DIR, percentile, rng_for, dump_json


def read_csv(path: Path) -> List[dict]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def write_csv(path: Path, rows: List[dict], fields: List[str] | None = None) -> None:
    if not rows:
        return
    if fields is None:
        fields = list(rows[0].keys())
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader(); w.writerows(rows)


def f(x) -> float:
    if x in ("", None):
        return float("nan")
    return float(x)


def summarize(rows: List[dict], group_fields: List[str]) -> List[dict]:
    groups = defaultdict(list)
    for r in rows:
        groups[tuple(r[k] for k in group_fields)].append(r)
    out = []
    for key, rs in sorted(groups.items()):
        lat = [f(r["latency_ms"]) for r in rs]
        tok = [f(r["tokens"]) for r in rs]
        prop = [f(r["propagation_depth"]) for r in rs]
        rec_a = sum(int(r["recovery_attempts"]) for r in rs)
        rec_s = sum(int(r["recovery_successes"]) for r in rs)
        row = {k: v for k, v in zip(group_fields, key)}
        row.update({
            "n_runs": len(rs),
            "n_tasks": len(set(r["task_id"] for r in rs)),
            "task_success": round(sum(int(r["success"]) for r in rs) / len(rs), 4),
            "avg_tokens": round(statistics.mean(tok), 1),
            "avg_latency_ms": round(statistics.mean(lat), 1),
            "p95_latency_ms": round(percentile(lat, 0.95), 1),
            "avg_model_calls": round(statistics.mean(f(r["model_calls"]) for r in rs), 2),
            "avg_propagation_depth": round(statistics.mean(prop), 3),
            "recovery_rate": round(rec_s / rec_a, 4) if rec_a else "",
            "diagnostic_coverage": round(sum(int(r["diagnostic_hit"]) for r in rs) / len(rs), 4),
            "avg_redundant_actions": round(statistics.mean(f(r["redundant_actions"]) for r in rs), 3),
        })
        out.append(row)
    return out


def task_means(rows: List[dict], family: str, system: str, noise: str | None = None) -> Dict[str, float]:
    by_task = defaultdict(list)
    for r in rows:
        if r["family"] != family or r["system"] != system:
            continue
        if noise is not None and r["noise"] != noise:
            continue
        by_task[r["task_id"]].append(int(r["success"]))
    return {t: statistics.mean(v) for t, v in by_task.items()}


def paired_diff(rows: List[dict], family: str, a: str, b: str, noise: str | None = None) -> dict:
    # 返回 b-a 的 task-level paired difference，并对 task 做 bootstrap。
    ma = task_means(rows, family, a, noise)
    mb = task_means(rows, family, b, noise)
    tasks = sorted(set(ma) & set(mb))
    diffs = [mb[t] - ma[t] for t in tasks]
    obs = statistics.mean(diffs)
    rng = rng_for("lesson44-bootstrap", family, a, b, noise)
    boots = []
    for _ in range(4000):
        sample = [diffs[rng.randrange(len(diffs))] for _ in diffs]
        boots.append(statistics.mean(sample))
    boots.sort()
    lo = boots[int(0.025 * (len(boots) - 1))]
    hi = boots[int(0.975 * (len(boots) - 1))]
    return {
        "family": family,
        "comparison": f"{b} - {a}",
        "n_tasks": len(tasks),
        "mean_success_diff_pp": round(obs * 100, 2),
        "cluster_bootstrap_95ci_pp": [round(lo * 100, 2), round(hi * 100, 2)],
    }


def full_factorial_vs_plan() -> dict:
    # 假设有人粗暴把 7 系统×80任务×3噪声×5重复×4个 benchmark 直接笛卡尔积。
    full = 7 * 80 * 3 * 5 * 4
    plan = 1600 + 1280 + 1440 + 900
    return {
        "naive_full_factorial_runs": full,
        "tiered_matrix_runs": plan,
        "saved_runs": full - plan,
        "reduction_pct": round((1 - plan / full) * 100, 1),
        "note": "教学示例。真正实验规模应由 RQ、预算和统计设计决定。",
    }


def main() -> None:
    rows = read_csv(RESULTS_DIR / "episodes.csv")
    main_rows = [r for r in rows if r["family"] == "main"]
    ab_rows = [r for r in rows if r["family"] == "ablation"]
    stress_rows = [r for r in rows if r["family"] == "stress"]
    scaling_rows = [r for r in rows if r["family"] == "scaling"]

    write_csv(RESULTS_DIR / "main_summary.csv", summarize(main_rows, ["system", "system_display"]))
    write_csv(RESULTS_DIR / "main_by_horizon.csv", summarize(main_rows, ["horizon_band", "system", "system_display"]))
    write_csv(RESULTS_DIR / "ablation_summary.csv", summarize(ab_rows, ["system", "system_display"]))
    write_csv(RESULTS_DIR / "stress_summary.csv", summarize(stress_rows, ["noise", "system", "system_display"]))
    write_csv(RESULTS_DIR / "scaling_summary.csv", summarize(scaling_rows, ["horizon_band", "horizon", "system", "system_display"]))

    comparisons = [
        paired_diff(rows, "main", "baseline", "candidate", "standard"),
        paired_diff(rows, "main", "token_matched", "candidate", "standard"),
        paired_diff(rows, "main", "more_compute_retry", "candidate", "standard"),
        paired_diff(rows, "ablation", "no_detector", "candidate", "standard"),
        paired_diff(rows, "ablation", "no_checkpoint", "candidate", "standard"),
        paired_diff(rows, "ablation", "no_reset", "candidate", "standard"),
    ]
    write_csv(RESULTS_DIR / "paired_comparisons.csv", [
        {
            **{k: v for k, v in x.items() if k != "cluster_bootstrap_95ci_pp"},
            "ci_low_pp": x["cluster_bootstrap_95ci_pp"][0],
            "ci_high_pp": x["cluster_bootstrap_95ci_pp"][1],
        } for x in comparisons
    ])

    # Evidence chain: claim 不直接指向“一个数字”，而要指向 protocol + runs + metrics + artifacts。
    evidence_chain = {
        "C1_main_effect": {
            "claim": "Candidate 在标准条件下的任务成功率与 Baseline 不同。",
            "rq": "RQ1",
            "family": "main",
            "primary_metric": "task_success",
            "comparison": "candidate vs baseline",
            "supporting_artifacts": ["main_summary.csv", "paired_comparisons.csv", "traces.jsonl"],
            "required_controls": ["same tasks", "same noise", "paired task design", "fixed evaluator"],
        },
        "C2_resource_matched": {
            "claim": "Candidate 的差异不能仅用更多 Token 解释。",
            "rq": "RQ2",
            "family": "main",
            "comparison": "candidate vs token_matched",
            "supporting_artifacts": ["main_summary.csv", "paired_comparisons.csv"],
            "required_controls": ["approximately matched token budget", "same tasks", "same repeats"],
        },
        "C3_mechanism": {
            "claim": "Detector / checkpoint / state reset 对观察到的行为差异有贡献。",
            "rq": "RQ3",
            "family": "ablation",
            "supporting_artifacts": ["ablation_summary.csv", "paired_comparisons.csv", "traces.jsonl"],
            "required_controls": ["one component changed at a time", "same task set", "same evaluator"],
        },
        "C4_boundary": {
            "claim": "系统差异会随噪声水平或任务长度变化。",
            "rq": "RQ4/RQ5",
            "family": "stress + scaling",
            "supporting_artifacts": ["stress_summary.csv", "scaling_summary.csv"],
            "required_controls": ["stratified tasks", "fixed definitions of stress/horizon"],
        },
    }
    dump_json(RESULTS_DIR / "evidence_chain.json", evidence_chain)

    report = {
        "warning": "Controlled teaching simulation. Not real Agent performance.",
        "total_runs": len(rows),
        "comparisons": comparisons,
        "matrix_economy": full_factorial_vs_plan(),
        "interpretation_rules": [
            "先回答预先定义的 primary RQ，再看 exploratory 结果。",
            "资源不匹配时，不能把更高成功率直接归因于架构。",
            "Ablation 用于机制诊断，不等于证明严格因果机制。",
            "Stress/Scaling 用于边界条件，不应与 Main result 混成一个总分。",
            "所有数值先视为本模拟器内的 observation。",
        ],
    }
    dump_json(RESULTS_DIR / "analysis_report.json", report)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
