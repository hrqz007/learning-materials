"""零基础 Trace 查看器：按 episode_id 或失败条件打印一个 JSONL episode。"""
from __future__ import annotations
import argparse, json
from pathlib import Path
from common import RESULTS_DIR


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument("--episode-id", default=None)
    parser.add_argument("--first-failure", action="store_true")
    args = parser.parse_args()
    path = RESULTS_DIR / "traces.jsonl"
    with path.open("r", encoding="utf-8") as f:
        for line in f:
            obj = json.loads(line)
            if args.episode_id and obj["episode_id"] == args.episode_id:
                print(json.dumps(obj, ensure_ascii=False, indent=2)); return
            if args.first_failure and obj["meta"]["success"] == 0:
                print(json.dumps(obj, ensure_ascii=False, indent=2)); return
    print("未找到匹配的 episode。")

if __name__ == "__main__":
    main()
