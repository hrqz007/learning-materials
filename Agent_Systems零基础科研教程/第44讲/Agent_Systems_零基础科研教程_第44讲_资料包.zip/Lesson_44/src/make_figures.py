from __future__ import annotations
import csv, json
from pathlib import Path
import matplotlib.pyplot as plt
import matplotlib as mpl

from common import DATA_DIR, RESULTS_DIR, FIGURES_DIR

mpl.rcParams['font.family'] = ['Noto Sans CJK JP']
mpl.rcParams['axes.unicode_minus'] = False
mpl.rcParams['figure.dpi'] = 150

BLUE = '#2563EB'; GREEN = '#16A34A'; ORANGE = '#F59E0B'; RED = '#DC2626'; PURPLE = '#7C3AED'; GRAY='#64748B'; DARK='#0F172A'


def read_csv(name):
    with open(RESULTS_DIR/name, encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


def save(fig, name):
    fig.tight_layout()
    fig.savefig(FIGURES_DIR/name, bbox_inches='tight')
    plt.close(fig)


def flow_box(ax, x, y, w, h, text, fc, fontsize=11):
    from matplotlib.patches import FancyBboxPatch
    p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=0.02,rounding_size=0.03',fc=fc,ec='white',lw=1.5)
    ax.add_patch(p); ax.text(x+w/2,y+h/2,text,ha='center',va='center',color='white',fontsize=fontsize,fontweight='bold')
    return p


def fig_pipeline():
    fig,ax=plt.subplots(figsize=(12,4.2)); ax.set_xlim(0,1); ax.set_ylim(0,1); ax.axis('off')
    xs=[.02,.19,.36,.53,.70,.87]; labels=['Research\nQuestion','Claim &\nHypothesis','Protocol\nFreeze','Experiment\nMatrix','Runs +\nTrace','Evidence\nChain']
    cols=[PURPLE,BLUE,BLUE,ORANGE,GREEN,DARK]
    for i,(x,l,c) in enumerate(zip(xs,labels,cols)):
        flow_box(ax,x,.38,.11,.25,l,c,10.5)
        if i<len(xs)-1:
            ax.annotate('',xy=(xs[i+1]-.01,.505),xytext=(x+.115,.505),arrowprops=dict(arrowstyle='->',lw=2,color=GRAY))
    ax.text(.5,.84,'Experiments 不是“多跑几组结果”，而是把 Claim 变成可审计 Evidence 的结构',ha='center',fontsize=15,fontweight='bold',color=DARK)
    ax.text(.5,.13,'先冻结协议，再生成矩阵；每个表格数字都能追溯到 task / run / trace / evaluator。',ha='center',fontsize=11,color=GRAY)
    save(fig,'experiment_evidence_pipeline.png')


def fig_matrix_layers():
    fig,ax=plt.subplots(figsize=(10.5,6)); ax.axis('off'); ax.set_xlim(0,1); ax.set_ylim(0,1)
    layers=[(.12,.68,.76,.18,'CORE MATRIX\n主结论 + 公平 Baseline','回答论文最核心的 RQ；所有系统在同一任务、协议、Evaluator 下比较。',BLUE),
            (.18,.40,.64,.18,'DIAGNOSTIC MATRIX\nAblation + Trace / Failure','解释“为什么会这样”；删模块、看 First Bad Span、Propagation、Recovery。',PURPLE),
            (.24,.12,.52,.18,'BOUNDARY MATRIX\nStress + Scaling + Generalization','找方法在哪些条件下失效；噪声、任务长度、环境变化、成本约束。',ORANGE)]
    from matplotlib.patches import FancyBboxPatch
    for x,y,w,h,title,desc,c in layers:
        p=FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.025,rounding_size=.025',fc=c,ec='none',alpha=.95)
        ax.add_patch(p); ax.text(x+.03,y+h*.64,title,ha='left',va='center',color='white',fontsize=13,fontweight='bold')
        ax.text(x+.03,y+h*.25,desc,ha='left',va='center',color='white',fontsize=9.8)
    ax.text(.5,.95,'分层实验矩阵：不是把所有因素做 Full Factorial',ha='center',fontsize=16,fontweight='bold',color=DARK)
    save(fig,'experiment_matrix_layers.png')


def fig_explosion():
    report=json.load(open(RESULTS_DIR/'analysis_report.json',encoding='utf-8'))['matrix_economy']
    vals=[report['naive_full_factorial_runs'],report['tiered_matrix_runs']]
    fig,ax=plt.subplots(figsize=(8.5,5)); bars=ax.bar(['粗暴 Full Factorial','分层实验矩阵'],vals,color=[RED,GREEN])
    ax.set_ylabel('计划运行次数'); ax.set_title('实验矩阵爆炸：不是所有因素都应该同时做笛卡尔积',fontweight='bold')
    ax.grid(axis='y',alpha=.2)
    for b,v in zip(bars,vals): ax.text(b.get_x()+b.get_width()/2,v+max(vals)*.02,f'{v:,}',ha='center',fontweight='bold')
    ax.text(.5,.93,f"本教学设计减少 {report['reduction_pct']}% 运行，但保留 Main / Ablation / Stress / Scaling 四类证据",transform=ax.transAxes,ha='center',fontsize=10,color=GRAY)
    save(fig,'matrix_explosion.png')


def fig_main():
    rows=read_csv('main_summary.csv')
    order=['baseline','more_compute_retry','token_matched','candidate']
    m={r['system']:r for r in rows}
    labels=[m[x]['system_display'] for x in order]; succ=[float(m[x]['task_success'])*100 for x in order]; toks=[float(m[x]['avg_tokens']) for x in order]
    fig,ax=plt.subplots(figsize=(10,5.5)); x=range(len(order)); bars=ax.bar(x,succ,color=[GRAY,ORANGE,BLUE,GREEN])
    ax.set_xticks(list(x),labels,rotation=10); ax.set_ylabel('Task Success (%)'); ax.set_ylim(0,100); ax.set_title('Main Matrix：先看核心效果，再看资源是否匹配',fontweight='bold'); ax.grid(axis='y',alpha=.2)
    for i,(b,s,t) in enumerate(zip(bars,succ,toks)):
        ax.text(b.get_x()+b.get_width()/2,s+2,f'{s:.1f}%\n{t:.0f} tokens',ha='center',fontsize=9)
    save(fig,'main_success_and_tokens.png')


def fig_stress():
    rows=read_csv('stress_summary.csv'); noises=['clean','standard','high']; systems=['baseline','more_compute_retry','token_matched','candidate']; cm={'baseline':GRAY,'more_compute_retry':ORANGE,'token_matched':BLUE,'candidate':GREEN}
    fig,ax=plt.subplots(figsize=(9.5,5.5))
    for s in systems:
        ys=[]; label=None
        for n in noises:
            r=next(x for x in rows if x['system']==s and x['noise']==n); ys.append(float(r['task_success'])*100); label=r['system_display']
        ax.plot(noises,ys,marker='o',lw=2.2,label=label,color=cm[s])
    ax.set_ylim(30,100); ax.set_ylabel('Task Success (%)'); ax.set_xlabel('Environment Stress'); ax.set_title('Stress Matrix：方法差异可能只在压力条件下显现',fontweight='bold'); ax.grid(alpha=.2); ax.legend(frameon=False)
    save(fig,'stress_response.png')


def fig_scaling():
    rows=read_csv('scaling_summary.csv'); horizons=[4,8,12,16]; systems=['baseline','token_matched','candidate']; cm={'baseline':GRAY,'token_matched':BLUE,'candidate':GREEN}
    fig,ax=plt.subplots(figsize=(9.5,5.5))
    for s in systems:
        ys=[]; label=None
        for h in horizons:
            r=next(x for x in rows if x['system']==s and int(x['horizon'])==h); ys.append(float(r['task_success'])*100); label=r['system_display']
        ax.plot(horizons,ys,marker='o',lw=2.2,label=label,color=cm[s])
    ax.set_xticks(horizons); ax.set_ylim(30,100); ax.set_ylabel('Task Success (%)'); ax.set_xlabel('Task Horizon (steps)'); ax.set_title('Scaling Matrix：只看短任务可能掩盖长程可靠性差异',fontweight='bold'); ax.grid(alpha=.2); ax.legend(frameon=False)
    save(fig,'horizon_scaling.png')


def fig_ablation():
    rows=read_csv('ablation_summary.csv'); order=['candidate','no_detector','no_checkpoint','no_reset']; m={r['system']:r for r in rows}
    fig,ax=plt.subplots(figsize=(9.5,5.3)); vals=[float(m[x]['task_success'])*100 for x in order]; prop=[float(m[x]['avg_propagation_depth']) for x in order]
    bars=ax.bar(range(len(order)),vals,color=[GREEN,PURPLE,ORANGE,RED]); ax.set_xticks(range(len(order)),[m[x]['system_display'].replace('Ablation: ','- ') for x in order],rotation=9); ax.set_ylim(0,100); ax.set_ylabel('Task Success (%)'); ax.set_title('Ablation Matrix：删除一个组件，观察效果与机制指标一起变化',fontweight='bold'); ax.grid(axis='y',alpha=.2)
    for b,v,p in zip(bars,vals,prop): ax.text(b.get_x()+b.get_width()/2,v+2,f'{v:.1f}%\nprop={p:.2f}',ha='center',fontsize=9)
    save(fig,'ablation_result.png')


def fig_metric_stack():
    fig,ax=plt.subplots(figsize=(9.5,5.5)); ax.axis('off'); ax.set_xlim(0,1); ax.set_ylim(0,1)
    items=[(.10,.70,.80,.16,'PRIMARY','Task Success / primary claim','决定核心 RQ 是否得到支持；实验前冻结。',BLUE),
           (.17,.45,.66,.16,'SECONDARY','Cost / Latency / Recovery / Propagation','解释代价、可靠性与机制；数量应受控。',GREEN),
           (.24,.20,.52,.16,'EXPLORATORY','Trace slices / unexpected phenomena','用于发现后续 RQ，不要事后冒充 primary hypothesis。',PURPLE)]
    from matplotlib.patches import FancyBboxPatch
    for x,y,w,h,tag,metric,desc,c in items:
        ax.add_patch(FancyBboxPatch((x,y),w,h,boxstyle='round,pad=.02,rounding_size=.02',fc=c,ec='none'))
        ax.text(x+.03,y+.105,tag,ha='left',va='center',color='white',fontweight='bold',fontsize=12)
        ax.text(x+.22,y+.105,metric,ha='left',va='center',color='white',fontweight='bold',fontsize=11)
        ax.text(x+.03,y+.045,desc,ha='left',va='center',color='white',fontsize=9.5)
    ax.text(.5,.95,'Metric Hierarchy：先规定哪些指标用于“检验”，哪些用于“解释/探索”',ha='center',fontsize=15,fontweight='bold',color=DARK)
    save(fig,'metric_hierarchy.png')


def fig_evidence_chain():
    fig,ax=plt.subplots(figsize=(11,5.6)); ax.axis('off'); ax.set_xlim(0,1); ax.set_ylim(0,1)
    boxes=[(.04,.58,.15,.22,'Claim','Candidate 在标准协议下\n表现不同',PURPLE),(.23,.58,.15,.22,'Comparison','candidate vs baseline\n+ token-matched',BLUE),(.42,.58,.15,.22,'Runs','同任务、同噪声\n多次重复',ORANGE),(.61,.58,.15,.22,'Artifacts','CSV + JSONL Trace\nRun Ledger',GREEN),(.80,.58,.15,.22,'Evidence','Effect + CI\nFailure Trace',DARK)]
    for i,(x,y,w,h,t,b,c) in enumerate(boxes):
        flow_box(ax,x,y,w,h,t+'\n'+b,c,9.3)
        if i<len(boxes)-1:
            ax.annotate('',xy=(boxes[i+1][0]-.01,y+h/2),xytext=(x+w+.005,y+h/2),arrowprops=dict(arrowstyle='->',lw=2,color=GRAY))
    ax.text(.5,.92,'Evidence Chain：论文中的每个 Claim 都应该能向下追溯',ha='center',fontsize=16,fontweight='bold',color=DARK)
    ax.text(.5,.31,'反向审计：如果一个 Claim 找不到对应的 comparison / run / evaluator / trace，\n它更像“叙述”，而不是完整证据。',ha='center',va='center',fontsize=11,color=RED)
    save(fig,'evidence_chain.png')


def main():
    FIGURES_DIR.mkdir(exist_ok=True)
    fig_pipeline(); fig_matrix_layers(); fig_explosion(); fig_main(); fig_stress(); fig_scaling(); fig_ablation(); fig_metric_stack(); fig_evidence_chain()
    print('generated', len(list(FIGURES_DIR.glob('*.png'))), 'figures')

if __name__=='__main__': main()
