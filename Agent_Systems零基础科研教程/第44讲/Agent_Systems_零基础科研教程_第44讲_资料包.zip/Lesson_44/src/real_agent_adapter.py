"""
可选真实系统适配器（不调用任何 API，不需要 API Key）。

真实科研时，你可以让自己的 Agent runner 输出统一 JSONL：
{
  "task_id": "...", "system": "...", "repeat": 0,
  "success": 0/1, "tokens": 1234, "latency_ms": 4567,
  "model_calls": 5, "propagation_depth": 2,
  "recovery_attempts": 1, "recovery_successes": 1,
  "diagnostic_hit": 1
}

然后用这个脚本检查字段是否齐全。课程故意把“API 适配”与“实验协议”解耦，
以免把科研设计绑死在某个厂商 SDK。
"""
from __future__ import annotations
import argparse, json
from pathlib import Path

REQUIRED = {
    "task_id", "system", "repeat", "success", "tokens", "latency_ms",
    "model_calls", "propagation_depth", "recovery_attempts",
    "recovery_successes", "diagnostic_hit"
}


def main():
    p = argparse.ArgumentParser()
    p.add_argument("jsonl", type=Path)
    args = p.parse_args()
    bad = 0; total = 0
    with args.jsonl.open("r", encoding="utf-8") as f:
        for i, line in enumerate(f, 1):
            total += 1
            obj = json.loads(line)
            missing = sorted(REQUIRED - set(obj))
            if missing:
                bad += 1
                print(f"line {i}: missing {missing}")
    print(f"checked={total}, invalid={bad}")
    raise SystemExit(1 if bad else 0)

if __name__ == "__main__":
    main()
