"""
第44讲受控教学模拟：完整实验矩阵与证据链。

重要说明：
- 这是人为参数构造的受控教学模拟。
- 不代表 GPT / Claude / Gemini 或任何真实 Agent、Benchmark、框架的实际性能。
- 目的不是证明某个方法“更强”，而是训练如何把 RQ 拆成 Main / Matched / Ablation /
  Stress / Scaling / Failure Analysis 等实验家族，并保持协议一致。
"""

from __future__ import annotations

import csv
import json
from dataclasses import dataclass, asdict
from pathlib import Path
from typing import Dict, List, Tuple

from common import DATA_DIR, RESULTS_DIR, ensure_dirs, rng_for, clamp, dump_json, write_jsonl


@dataclass(frozen=True)
class SystemSpec:
    name: str
    display: str
    error_mult: float
    detector: float
    recovery: float
    reset_strength: float
    extra_calls: float
    token_mult: float
    latency_mult: float
    diagnostic_coverage: float


SYSTEMS: Dict[str, SystemSpec] = {
    "baseline": SystemSpec("baseline", "Baseline", 1.00, 0.12, 0.08, 0.00, 0.00, 1.00, 1.00, 0.28),
    "more_compute_retry": SystemSpec("more_compute_retry", "More-Compute Retry", 0.94, 0.24, 0.34, 0.10, 0.55, 1.40, 1.34, 0.44),
    "token_matched": SystemSpec("token_matched", "Token-Matched Baseline", 0.96, 0.28, 0.30, 0.14, 0.26, 1.10, 1.11, 0.50),
    "candidate": SystemSpec("candidate", "Candidate Recovery", 0.91, 0.66, 0.64, 0.78, 0.22, 1.18, 1.13, 0.82),
    "no_detector": SystemSpec("no_detector", "Ablation: no detector", 0.91, 0.18, 0.64, 0.78, 0.19, 1.12, 1.08, 0.46),
    "no_checkpoint": SystemSpec("no_checkpoint", "Ablation: no checkpoint", 0.91, 0.66, 0.42, 0.36, 0.21, 1.15, 1.11, 0.72),
    "no_reset": SystemSpec("no_reset", "Ablation: no state reset", 0.91, 0.66, 0.52, 0.18, 0.21, 1.16, 1.12, 0.76),
}

NOISE = {
    "clean": 0.75,
    "standard": 1.00,
    "high": 1.42,
}

HORIZON_BANDS = {
    "short": 4,
    "medium": 8,
    "long": 12,
    "very_long": 16,
}


def make_tasks() -> List[dict]:
    tasks: List[dict] = []
    difficulties = ["easy", "medium", "hard"]
    dbase = {"easy": 0.045, "medium": 0.065, "hard": 0.085}
    idx = 0
    # 80 个主任务，四种 horizon，每个 20 个。
    for band, horizon in HORIZON_BANDS.items():
        for j in range(20):
            difficulty = difficulties[(j + list(HORIZON_BANDS).index(band)) % 3]
            idx += 1
            tasks.append({
                "task_id": f"T{idx:03d}",
                "horizon_band": band,
                "horizon": horizon,
                "difficulty": difficulty,
                "base_step_error": dbase[difficulty],
                "tool_fragility": round(0.10 + 0.02 * ((j * 7 + horizon) % 6), 3),
            })
    return tasks


def make_scaling_tasks() -> List[dict]:
    tasks = []
    idx = 0
    for band, horizon in HORIZON_BANDS.items():
        for j in range(25):
            idx += 1
            difficulty = ["easy", "medium", "hard"][(j + horizon) % 3]
            dbase = {"easy": 0.045, "medium": 0.065, "hard": 0.085}[difficulty]
            tasks.append({
                "task_id": f"S{idx:03d}",
                "horizon_band": band,
                "horizon": horizon,
                "difficulty": difficulty,
                "base_step_error": dbase,
                "tool_fragility": round(0.11 + 0.02 * ((j * 5 + horizon) % 5), 3),
            })
    return tasks


def simulate_episode(task: dict, system: SystemSpec, noise_name: str, repeat: int, family: str) -> Tuple[dict, dict]:
    rng = rng_for("lesson44", family, task["task_id"], system.name, noise_name, repeat)
    horizon = int(task["horizon"])
    noise_mult = NOISE[noise_name]

    # 一个 episode 中可能出现多个局部错误。系统是否最终失败取决于：
    # 错误是否被发现、恢复是否成功、残留错误是否继续传播。
    active_error = False
    first_bad_step = None
    propagation_depth = 0
    detected_any = False
    recovery_attempts = 0
    recovery_successes = 0
    redundant_actions = 0
    spans = []
    model_calls = 0
    tokens = 0
    latency_ms = 0.0

    for step in range(1, horizon + 1):
        step_spans = []
        # Observe / Plan / Act 是最小 trace 结构。
        for kind, base_tok, base_lat in [
            ("observe", 35, 18),
            ("plan", 95, 62),
            ("tool", 42, 48),
        ]:
            jitter = 0.82 + rng.random() * 0.36
            tok = int(base_tok * system.token_mult * jitter)
            lat = base_lat * system.latency_mult * (0.85 + rng.random() * 0.35)
            step_spans.append({"step": step, "span": kind, "tokens": tok, "latency_ms": round(lat, 2), "status": "ok"})
            tokens += tok
            latency_ms += lat
            if kind == "plan":
                model_calls += 1

        p_error = task["base_step_error"] * noise_mult * system.error_mult
        # active_error 会让后续步骤更脆弱，表示 error propagation。
        if active_error:
            p_error *= 1.35
        tool_fault = rng.random() < task["tool_fragility"] * (noise_mult - 0.55) * 0.18
        new_error = rng.random() < clamp(p_error, 0, 0.42) or tool_fault

        if new_error and first_bad_step is None:
            first_bad_step = step

        if new_error:
            active_error = True
            step_spans[-1]["status"] = "fault"
            step_spans[-1]["fault_type"] = "tool_fault" if tool_fault else "reasoning_or_action_error"

        if active_error:
            propagation_depth += 1
            detect_prob = clamp(system.detector + 0.05 * (propagation_depth - 1), 0, 0.95)
            detected = rng.random() < detect_prob
            if detected:
                detected_any = True
                dtok = int(36 * system.token_mult * (0.9 + rng.random() * 0.2))
                dlat = 28 * system.latency_mult * (0.9 + rng.random() * 0.2)
                step_spans.append({"step": step, "span": "verify", "tokens": dtok, "latency_ms": round(dlat, 2), "status": "detected"})
                tokens += dtok
                latency_ms += dlat
                model_calls += 1

                recovery_attempts += 1
                p_recover = clamp(system.recovery + 0.18 * system.reset_strength - 0.055 * max(0, propagation_depth - 1), 0.02, 0.94)
                recovered = rng.random() < p_recover
                rtok = int(72 * system.token_mult * (0.88 + rng.random() * 0.28))
                rlat = 54 * system.latency_mult * (0.85 + rng.random() * 0.32)
                step_spans.append({
                    "step": step,
                    "span": "recovery",
                    "tokens": rtok,
                    "latency_ms": round(rlat, 2),
                    "status": "success" if recovered else "failed",
                })
                tokens += rtok
                latency_ms += rlat
                model_calls += 1
                if recovered:
                    recovery_successes += 1
                    active_error = rng.random() > system.reset_strength
                    if not active_error:
                        propagation_depth = max(0, propagation_depth - 1)
            else:
                # 没检测到时，可能继续做冗余动作。
                if rng.random() < 0.24 + 0.12 * noise_mult:
                    redundant_actions += 1

        spans.extend(step_spans)

    # 更高的传播深度使最终失败概率上升；没有残留错误仍有小概率结尾错误。
    final_fail_prob = 0.035 + 0.085 * propagation_depth + (0.22 if active_error else 0.0)
    final_fail_prob *= 1.0 if noise_name != "high" else 1.08
    success = rng.random() >= clamp(final_fail_prob, 0.02, 0.96)

    # More-compute 系统会无条件增加一部分重试调用，体现“花更多计算换分数”。
    extra_calls = int(system.extra_calls * horizon + rng.random())
    if extra_calls:
        model_calls += extra_calls
        extra_tok = int(extra_calls * 82 * system.token_mult)
        extra_lat = extra_calls * 46 * system.latency_mult
        tokens += extra_tok
        latency_ms += extra_lat
        redundant_actions += max(0, extra_calls - 1)

    if not success:
        spans.append({
            "step": horizon + 1,
            "span": "finalize",
            "tokens": 28,
            "latency_ms": 20,
            "status": "failed",
        })
    else:
        spans.append({
            "step": horizon + 1,
            "span": "finalize",
            "tokens": 28,
            "latency_ms": 20,
            "status": "success",
        })
    tokens += 28
    latency_ms += 20

    recovery_rate = recovery_successes / recovery_attempts if recovery_attempts else None
    diagnosis_possible = first_bad_step is None or detected_any
    diagnostic_hit = 1 if (first_bad_step is None or rng.random() < system.diagnostic_coverage) else 0

    episode = {
        "family": family,
        "task_id": task["task_id"],
        "horizon_band": task["horizon_band"],
        "horizon": horizon,
        "difficulty": task["difficulty"],
        "system": system.name,
        "system_display": system.display,
        "noise": noise_name,
        "repeat": repeat,
        "success": int(success),
        "model_calls": model_calls,
        "tokens": tokens,
        "latency_ms": round(latency_ms, 2),
        "first_bad_step": first_bad_step if first_bad_step is not None else "",
        "failure_detected": int(detected_any),
        "recovery_attempts": recovery_attempts,
        "recovery_successes": recovery_successes,
        "recovery_rate": round(recovery_rate, 4) if recovery_rate is not None else "",
        "propagation_depth": propagation_depth,
        "redundant_actions": redundant_actions,
        "diagnostic_hit": diagnostic_hit,
        "diagnosis_possible": int(diagnosis_possible),
    }
    trace = {
        "episode_id": f"{family}|{task['task_id']}|{system.name}|{noise_name}|r{repeat}",
        "meta": episode,
        "spans": spans,
    }
    return episode, trace


def write_csv(path: Path, rows: List[dict], fieldnames: List[str] | None = None) -> None:
    if not rows:
        return
    if fieldnames is None:
        fieldnames = list(rows[0].keys())
    with path.open("w", encoding="utf-8-sig", newline="") as f:
        w = csv.DictWriter(f, fieldnames=fieldnames)
        w.writeheader()
        w.writerows(rows)


def build_matrix_plan() -> List[dict]:
    # 这里故意不是“所有因素做全因子”。课程要训练的是分层实验矩阵，而不是暴力笛卡尔积。
    return [
        {
            "family": "main",
            "purpose": "主结果：在统一协议下比较核心系统",
            "systems": "baseline;more_compute_retry;token_matched;candidate",
            "task_scope": "80 main tasks",
            "noise_levels": "standard",
            "repeats": 5,
            "planned_runs": 80 * 4 * 5,
            "primary_metric": "task_success",
        },
        {
            "family": "ablation",
            "purpose": "机制诊断：删除 detector/checkpoint/reset 后是否退化",
            "systems": "candidate;no_detector;no_checkpoint;no_reset",
            "task_scope": "80 main tasks",
            "noise_levels": "standard",
            "repeats": 4,
            "planned_runs": 80 * 4 * 4,
            "primary_metric": "task_success + propagation_depth",
        },
        {
            "family": "stress",
            "purpose": "边界条件：噪声升高时收益是否保持",
            "systems": "baseline;token_matched;candidate;more_compute_retry",
            "task_scope": "40 stratified tasks",
            "noise_levels": "clean;standard;high",
            "repeats": 3,
            "planned_runs": 40 * 4 * 3 * 3,
            "primary_metric": "success under stress",
        },
        {
            "family": "scaling",
            "purpose": "Horizon scaling：任务变长时可靠性如何衰减",
            "systems": "baseline;token_matched;candidate",
            "task_scope": "100 scaling tasks",
            "noise_levels": "standard",
            "repeats": 3,
            "planned_runs": 100 * 3 * 3,
            "primary_metric": "success by horizon",
        },
    ]


def main() -> None:
    ensure_dirs()
    tasks = make_tasks()
    scaling_tasks = make_scaling_tasks()
    dump_json(DATA_DIR / "tasks.json", tasks)
    dump_json(DATA_DIR / "scaling_tasks.json", scaling_tasks)

    plan = build_matrix_plan()
    write_csv(DATA_DIR / "experiment_matrix.csv", plan)
    dump_json(DATA_DIR / "experiment_plan.json", {
        "lesson": 44,
        "warning": "Controlled teaching simulation; not real model performance.",
        "experimental_unit": "task",
        "paired_design": True,
        "main_noise": "standard",
        "families": plan,
        "primary_metric": "task success",
        "secondary_metrics": ["tokens", "latency_ms", "propagation_depth", "recovery_rate", "diagnostic_hit"],
        "frozen_fields": ["task set", "noise definition", "system specification", "evaluator", "repeat count", "analysis script"],
    })

    all_episodes: List[dict] = []
    all_traces: List[dict] = []

    # 1) Main matrix
    for task in tasks:
        for system_name in ["baseline", "more_compute_retry", "token_matched", "candidate"]:
            for repeat in range(5):
                ep, tr = simulate_episode(task, SYSTEMS[system_name], "standard", repeat, "main")
                all_episodes.append(ep); all_traces.append(tr)

    # 2) Ablation matrix
    for task in tasks:
        for system_name in ["candidate", "no_detector", "no_checkpoint", "no_reset"]:
            for repeat in range(4):
                ep, tr = simulate_episode(task, SYSTEMS[system_name], "standard", repeat, "ablation")
                all_episodes.append(ep); all_traces.append(tr)

    # 3) Stress matrix：按 horizon 分层抽 40 个，避免只取最容易的一批。
    stress_ids = set()
    for band in HORIZON_BANDS:
        band_tasks = [t for t in tasks if t["horizon_band"] == band]
        stress_ids.update(t["task_id"] for t in band_tasks[:10])
    stress_tasks = [t for t in tasks if t["task_id"] in stress_ids]
    for task in stress_tasks:
        for noise in ["clean", "standard", "high"]:
            for system_name in ["baseline", "more_compute_retry", "token_matched", "candidate"]:
                for repeat in range(3):
                    ep, tr = simulate_episode(task, SYSTEMS[system_name], noise, repeat, "stress")
                    all_episodes.append(ep); all_traces.append(tr)

    # 4) Scaling matrix：100 个任务，四个 horizon 分层。
    for task in scaling_tasks:
        for system_name in ["baseline", "token_matched", "candidate"]:
            for repeat in range(3):
                ep, tr = simulate_episode(task, SYSTEMS[system_name], "standard", repeat, "scaling")
                all_episodes.append(ep); all_traces.append(tr)

    write_csv(RESULTS_DIR / "episodes.csv", all_episodes)
    write_jsonl(RESULTS_DIR / "traces.jsonl", all_traces)

    # Run ledger 是每次实验的“账本”。以后真实科研时最好给每个 run 记录版本和协议哈希。
    ledger = []
    for i, ep in enumerate(all_episodes, 1):
        ledger.append({
            "run_id": f"R{i:05d}",
            "family": ep["family"],
            "task_id": ep["task_id"],
            "system": ep["system"],
            "noise": ep["noise"],
            "repeat": ep["repeat"],
            "protocol_version": "L44-v1",
            "evaluator_version": "mock-eval-v1",
            "status": "completed",
        })
    write_csv(RESULTS_DIR / "run_ledger.csv", ledger)

    expected = sum(int(x["planned_runs"]) for x in plan)
    summary = {
        "expected_runs_from_plan": expected,
        "actual_runs": len(all_episodes),
        "families": {fam: sum(1 for e in all_episodes if e["family"] == fam) for fam in ["main", "ablation", "stress", "scaling"]},
        "trace_records": len(all_traces),
        "note": "Every JSONL line contains one episode with span-level trace.",
    }
    dump_json(RESULTS_DIR / "run_summary.json", summary)
    print(json.dumps(summary, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
