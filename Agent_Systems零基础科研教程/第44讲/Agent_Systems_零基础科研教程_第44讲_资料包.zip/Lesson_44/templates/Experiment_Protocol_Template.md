# Agent Systems Experiment Protocol Template

> 在正式大规模运行前填写并冻结。修改后应升级 protocol_version。

## 1. Research Question
- RQ:
- 为什么值得研究：
- 预期可被什么证据回答：

## 2. Hypothesis / Falsifier
- H:
- Prediction:
- Falsifier / 什么结果会削弱或否定该假设：

## 3. Experimental Unit
- 独立实验单位：Task / User / Environment / Other
- Repeat / Seed 是否只是同一单位上的重复测量：

## 4. Systems
- Baseline:
- Strong Baseline:
- Resource-Matched Baseline:
- Proposed / Candidate:
- Ablation variants:

## 5. Task / Benchmark
- Dataset / benchmark version:
- Split:
- Task strata:
- Exclusion rule:

## 6. Environment / Harness
- Harness version:
- Tool versions:
- Sandbox / network policy:
- Model snapshot / API date:
- Prompt / system instruction version:

## 7. Budget
- Max model calls:
- Max tokens:
- Max wall-clock time:
- Retry policy:
- Concurrency:

## 8. Metrics
- Primary metric:
- Secondary metrics:
- Exploratory metrics:
- Evaluator version:

## 9. Repetition / Randomness
- Number of tasks:
- Repeats per task:
- Seed policy:
- Paired design:

## 10. Statistical Analysis Plan
- Effect size:
- Confidence interval:
- Statistical test:
- Multiple comparison correction:
- Missing / timeout handling:

## 11. Experiment Families
- Main:
- Ablation:
- Stress / robustness:
- Scaling:
- Efficiency:
- Failure / Trace audit:

## 12. Stopping Rule
- Pilot completion criteria:
- Main run stopping rule:
- API budget ceiling:

## 13. Artifacts
- episodes.csv:
- traces.jsonl:
- run_ledger.csv:
- configs:
- code commit:
- environment lockfile:

## 14. Claim -> Evidence Map
- Claim C1 -> comparison -> metric -> table/figure -> trace subset
- Claim C2 -> ...
