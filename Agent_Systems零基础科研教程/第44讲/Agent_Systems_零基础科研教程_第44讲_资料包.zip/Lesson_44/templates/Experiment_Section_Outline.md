# Experiments Section Outline

## 4.1 Experimental Setup
Task/benchmark、split、model、harness、tool、environment、budget、repeat、evaluator。

## 4.2 Baselines and Fairness Controls
Weak/strong/resource-matched baselines；说明哪些资源被匹配。

## 4.3 Metrics and Statistical Protocol
Primary / secondary / exploratory；effect size、CI、paired analysis、multiple comparisons。

## 4.4 Main Results
只回答最核心 RQ；主表不塞进所有 exploratory slice。

## 4.5 Ablation / Mechanism Analysis
一次改变一个关键组件；同时报告 outcome 与 mechanism metrics。

## 4.6 Robustness / Stress Tests
扰动环境、工具失败、任务难度、版本变化；说明边界条件。

## 4.7 Scaling and Efficiency
Horizon、Agent count、concurrency、token/cost/latency、p95/p99；资源匹配。

## 4.8 Failure / Trace Analysis
First bad span、root cause、propagation、recovery；给代表案例并说明抽样规则。

## 4.9 Threats to Validity / Limitations
数据代表性、模型版本、harness dependence、evaluator validity、API nondeterminism 等。
