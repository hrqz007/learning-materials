# Agent Systems 零基础科研教程 · 第45讲

## 主题

**Results 与 Evidence——怎样把 CSV、统计结果和 Trace 组织成论文 Claim，而不是只堆表格和曲线**

本讲承接第44讲“实验矩阵设计”。目标是完成下面一段科研闭环：

> Raw Runs → Task-level Aggregation → Statistical Evidence → Trace/Mechanism Evidence → Scoped Claim

## 重要声明

`results/` 中的所有数值都来自**受控教学模拟**，不是 GPT、Claude、Gemini 或任何真实 Agent、框架、Benchmark 的实际性能。模拟的目的，是让统计与 Failure Trace 的底层关系可控、可复现、可检查。

## 本讲实际生成的数据

- 120 个 Task
- 5 个 Agent System 条件
- 每个 Task / System 重复 5 次
- **3000 个 episode-level runs**
- **45,000 个 step-level Trace spans**
- 10 张原理/结果图
- Task-cluster bootstrap CI
- Paired permutation test
- Horizon slice analysis
- Failure root-cause / propagation analysis
- 预先规则驱动的 Trace case selection
- 独立的 Simpson's paradox / aggregation trap 教学示例

## 建议学习顺序

1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. `src/run_lesson45.py`
4. `results/summary_by_system.csv`
5. `results/summary_by_horizon.csv`
6. `results/paired_inference.json`
7. `results/selected_trace_cases.json`
8. `results/selected_trace_cases.jsonl`
9. `results/claim_evidence_registry.json`
10. `05_练习题.docx` → `06_练习题答案.docx`

## 运行方式

在 `Lesson_45/` 目录执行：

```bash
python src/run_lesson45.py
python src/make_figures.py
python src/build_claim_report.py
python src/trace_reader.py --episode "T103|Baseline|r4"
python src/trace_reader.py --episode "T103|BRG_Full|r4"
```

无需 GPU、无需 API Key、无需本地部署大模型。

## 将来换成真实 Agent 实验

`src/real_results_adapter.py` 提供最小 episode-level Schema 适配模板。它不调用任何 API，只负责把你未来的真实结果整理成统一字段，便于继续使用本讲的结果分析思路。

最低必需字段：

- `task_id`
- `system`
- `repeat`
- `task_success`
- `token_cost`
- `latency_ms`

## 本讲最低闭环能力

完成本讲后，应能独立做到：

1. 不把 Run 数误当独立 Task 数；
2. 主结果同时报告 effect size、uncertainty 和成本；
3. 主动检查 Horizon / difficulty / failure type 等异质性；
4. 用 Trace 解释机制，但不拿单条 Trace 代替统计证据；
5. 在看 Trace 内容之前写 Case Selection Rule；
6. 为每条论文 Claim 建立 Claim → CSV → Episode → Trace → Config 的证据路径；
7. 从异常结果继续形成新的 Research Question。
