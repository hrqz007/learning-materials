# Lesson 45 Claim-Evidence Audit

> 这是受控教学模拟，不代表任何真实模型或 Agent 产品的性能。

## C1：在本受控模拟中，BRG_Full 的总体 Task Success 高于 Baseline。
- Scope：120 tasks × 5 repeats；仅本教学模拟
- Primary evidence：summary_by_system.csv + paired_inference.json
- Mechanism evidence：failure_by_root_cause.csv / selected_trace_cases.jsonl
- Boundary/Risk：不能外推到真实LLM。

## C2：BRG_Full 的收益随任务 horizon 增大而更明显。
- Scope：horizon ∈ {4,8,16,32}
- Primary evidence：summary_by_horizon.csv
- Mechanism evidence：failure_propagation_depth
- Boundary/Risk：slice结果是探索性解释，不等同因果证明。

## C3：BRG_Full 的成功率收益伴随更高 token 与 latency 开销。
- Scope：相同任务、重复数
- Primary evidence：summary_by_system.csv
- Mechanism evidence：episodes.csv
- Boundary/Risk：成本单位为教学单位，不是实际API价格。

## C4：机制层证据与“更早检测/更高恢复/更浅传播”一致。
- Scope：发生failure的episodes
- Primary evidence：failure_by_root_cause.csv
- Mechanism evidence：selected_trace_cases.jsonl
- Boundary/Risk：一致性证据不自动构成唯一因果解释。

## C5：若系统在不同难度任务上的评测配比不同，只看总平均可能产生方向错误的结论。
- Scope：独立的Simpson教学示例
- Primary evidence：aggregation_trap_by_slice.csv + aggregation_trap_raw_aggregate.csv
- Mechanism evidence：无
- Boundary/Risk：该示例为人为构造，用于解释aggregation bias。

## 关键配对推断
- BRG_Full - Baseline：16.67 pp
- 95% task-cluster bootstrap CI：[11.67, 21.83] pp
- paired permutation p：5e-05
- mean token difference：+344.1 tokens
