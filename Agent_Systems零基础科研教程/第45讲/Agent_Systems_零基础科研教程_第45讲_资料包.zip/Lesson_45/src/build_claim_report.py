from pathlib import Path
import json, csv
ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'results'
claims=json.load(open(RES/'claim_evidence_registry.json',encoding='utf-8'))
actual=json.load(open(RES/'actual_results.json',encoding='utf-8'))
inf=actual['inference']
lines=['# Lesson 45 Claim-Evidence Audit','','> 这是受控教学模拟，不代表任何真实模型或 Agent 产品的性能。','']
for c in claims:
    lines += [f"## {c['claim_id']}：{c['claim']}",f"- Scope：{c['scope']}",f"- Primary evidence：{c['primary_evidence']}",f"- Mechanism evidence：{c['mechanism_evidence']}",f"- Boundary/Risk：{c['risk']}",'']
lines += ['## 关键配对推断',f"- BRG_Full - Baseline：{inf['task_level_paired_effect_pp']} pp",f"- 95% task-cluster bootstrap CI：[{inf['task_cluster_bootstrap_95ci_pp'][0]}, {inf['task_cluster_bootstrap_95ci_pp'][1]}] pp",f"- paired permutation p：{inf['paired_permutation_p']}",f"- mean token difference：+{inf['mean_token_difference']} tokens",'']
out=RES/'claim_evidence_audit.md'; out.write_text('\n'.join(lines),encoding='utf-8')
print(out)
