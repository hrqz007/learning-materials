"""根据 results/ 中“真实运行得到的教学模拟结果”绘制本讲全部图。

本文件不生成实验数据，只读取 CSV/JSON 并画图。这样把“数据生成”和“结果可视化”分开，
以后替换成真实 Agent 实验时更容易复用。图中的数值仍然只代表本受控教学模拟。
"""
from pathlib import Path
import json, csv
from collections import defaultdict
import matplotlib.pyplot as plt
import matplotlib as mpl
from matplotlib import font_manager
from matplotlib.patches import FancyBboxPatch, FancyArrowPatch

ROOT=Path(__file__).resolve().parents[1]
RES=ROOT/'results'; FIG=ROOT/'figures'; FIG.mkdir(exist_ok=True)
font_path=Path('/usr/share/fonts/opentype/noto/NotoSansCJK-Regular.ttc')
if font_path.exists():
    # 本资料包生成环境使用 Noto CJK；在 Linux 上可保证中文图正常。
    font_manager.fontManager.addfont(str(font_path))
    font_name=font_manager.FontProperties(fname=str(font_path)).get_name()
    mpl.rcParams['font.family']=font_name
else:
    # Windows / macOS 重跑时使用常见中文字体回退，不要求复制本环境字体文件。
    mpl.rcParams['font.sans-serif']=['Microsoft YaHei','SimHei','PingFang SC','Arial Unicode MS','DejaVu Sans']
mpl.rcParams['axes.unicode_minus']=False

def save(name):
    plt.tight_layout(); plt.savefig(FIG/name,dpi=180,bbox_inches='tight'); plt.close()

def box(ax, xy, w,h,text,fc='#eef3f8',ec='#4a6178',fs=10):
    p=FancyBboxPatch(xy,w,h,boxstyle='round,pad=0.02,rounding_size=0.015',facecolor=fc,edgecolor=ec,linewidth=1.5)
    ax.add_patch(p); ax.text(xy[0]+w/2,xy[1]+h/2,text,ha='center',va='center',fontsize=fs,wrap=True)

def arrow(ax,a,b):
    ax.add_patch(FancyArrowPatch(a,b,arrowstyle='-|>',mutation_scale=14,linewidth=1.4,color='#556'))

# 1 evidence chain
fig,ax=plt.subplots(figsize=(12,3.8)); ax.set_xlim(0,12); ax.set_ylim(0,4); ax.axis('off')
labels=[('Raw Runs\nEpisode / Span',0.3),('Task-level\nAggregation',2.65),('Statistics\nEffect + CI',5.0),('Trace Evidence\nMechanism',7.35),('Claim\nScope + Boundary',9.7)]
for txt,x in labels: box(ax,(x,1.35),1.9,1.15,txt)
for i in range(len(labels)-1): arrow(ax,(labels[i][1]+1.9,1.93),(labels[i+1][1],1.93))
ax.text(6,3.45,'Evidence Chain：从原始运行到可审计的论文 Claim',ha='center',fontsize=16,fontweight='bold')
ax.text(6,0.55,'任何一步缺失，都可能把“数字”误写成“结论”。',ha='center',fontsize=11)
save('evidence_chain.png')

# 2 claim anatomy
fig,ax=plt.subplots(figsize=(11,4.6)); ax.set_xlim(0,11); ax.set_ylim(0,5); ax.axis('off')
box(ax,(3.65,3.15),3.7,1.0,'一个合格的 Results Claim',fc='#f4f0ff',ec='#7154a3',fs=14)
parts=[('对象/比较\nA vs B',0.4,1.2),('效应大小\n+16.7pp',2.55,1.2),('不确定性\n95% CI',4.7,1.2),('条件/范围\n哪些Task',6.85,1.2),('代价/边界\nToken/Latency',9.0,1.2)]
for txt,x,y in parts:
    box(ax,(x,y),1.6,1.0,txt,fs=10); arrow(ax,(5.5,3.15),(x+0.8,y+1.0))
ax.text(5.5,0.35,'“更好”不是 Claim；“在什么条件下，以多大幅度、更好到什么程度、付出什么代价”才是。',ha='center',fontsize=10.5)
save('claim_anatomy.png')

# load summaries
with open(RES/'summary_by_system.csv',encoding='utf-8-sig') as f: summary=list(csv.DictReader(f))
order=['Baseline','TokenMatched','RetryOnly','Verifier','BRG_Full']
sm={r['system']:r for r in summary}

# 3 success
plt.figure(figsize=(8.4,4.8))
vals=[float(sm[s]['success_rate'])*100 for s in order]
lo=[float(sm[s]['success_ci_low'])*100 for s in order]; hi=[float(sm[s]['success_ci_high'])*100 for s in order]
yerr=[[v-l for v,l in zip(vals,lo)],[h-v for v,h in zip(vals,hi)]]
plt.bar(order,vals,yerr=yerr,capsize=4)
plt.ylabel('Task Success (%)'); plt.title('总体 Task Success 与 95% Wilson CI')
plt.xticks(rotation=18); plt.ylim(0,80); plt.grid(axis='y',alpha=.2)
save('overall_success.png')

# 4 horizon
with open(RES/'summary_by_horizon.csv',encoding='utf-8-sig') as f: hrs=list(csv.DictReader(f))
plt.figure(figsize=(8.5,5))
for s in ['Baseline','TokenMatched','Verifier','BRG_Full']:
    rs=sorted([r for r in hrs if r['system']==s],key=lambda x:int(x['horizon']))
    plt.plot([int(r['horizon']) for r in rs],[float(r['success_rate'])*100 for r in rs],marker='o',label=s)
plt.xlabel('Task Horizon'); plt.ylabel('Task Success (%)'); plt.title('只看总分会漏掉：收益随 Horizon 改变')
plt.xticks([4,8,16,32]); plt.legend(); plt.grid(alpha=.2)
save('success_by_horizon.png')

# 5 tradeoff scatter
plt.figure(figsize=(7.5,5.2))
for s in order:
    plt.scatter(float(sm[s]['mean_tokens']),float(sm[s]['success_rate'])*100,s=80)
    plt.text(float(sm[s]['mean_tokens'])+8,float(sm[s]['success_rate'])*100+0.5,s,fontsize=9)
plt.xlabel('Mean Token Cost'); plt.ylabel('Task Success (%)'); plt.title('Results 不能只写 Success：Success–Cost Trade-off')
plt.grid(alpha=.2)
save('success_cost_tradeoff.png')

# 6 latency mean vs p95
plt.figure(figsize=(8.5,5))
x=range(len(order)); mean=[float(sm[s]['mean_latency_ms']) for s in order]; p95=[float(sm[s]['p95_episode_latency_ms']) for s in order]
w=.36
plt.bar([i-w/2 for i in x],mean,width=w,label='Mean latency')
plt.bar([i+w/2 for i in x],p95,width=w,label='p95 latency')
plt.xticks(list(x),order,rotation=18); plt.ylabel('Latency (ms)'); plt.title('平均延迟会隐藏 Tail Latency'); plt.legend(); plt.grid(axis='y',alpha=.2)
save('latency_mean_vs_p95.png')

# 7 failure propagation
with open(RES/'failure_by_root_cause.csv',encoding='utf-8-sig') as f: fr=list(csv.DictReader(f))
plt.figure(figsize=(8.4,5))
causes=['planning','tool','memory','state']
for s in ['Baseline','Verifier','BRG_Full']:
    vals=[]
    for c in causes:
        r=next(x for x in fr if x['system']==s and x['root_cause']==c)
        vals.append(float(r['mean_propagation_depth']))
    plt.plot(causes,vals,marker='o',label=s)
plt.ylabel('Mean Failure Propagation Depth'); plt.title('机制证据：不同 Root Cause 下的错误传播深度')
plt.legend(); plt.grid(alpha=.2)
save('failure_propagation.png')

# 8 claim evidence matrix conceptual
fig,ax=plt.subplots(figsize=(11,5.3)); ax.set_xlim(0,11); ax.set_ylim(0,5.5); ax.axis('off')
claims=['C1 总体收益','C2 Horizon 异质性','C3 Cost/Latency 代价','C4 Failure 机制']
evidence=['Aggregate','Paired CI','Slice','Trace','Cost']
for i,c in enumerate(claims): ax.text(0.2,4.55-i*0.95,c,va='center',fontsize=11)
for j,e in enumerate(evidence): ax.text(3.0+j*1.5,5.15,e,ha='center',fontsize=10,fontweight='bold')
matrix=[[1,1,0,1,0],[0,0,1,1,0],[1,0,1,0,1],[0,0,1,1,0]]
for i,row in enumerate(matrix):
    for j,v in enumerate(row):
        ax.add_patch(FancyBboxPatch((2.45+j*1.5,4.2-i*0.95),1.1,.55,boxstyle='round,pad=.02',facecolor=('#dff0df' if v else '#f2f2f2'),edgecolor='#999'))
        ax.text(3.0+j*1.5,4.48-i*0.95,'✓' if v else '—',ha='center',va='center',fontsize=14)
ax.text(5.5,0.35,'Claim-Evidence Matrix：每条主张都应有明确的证据路径，而不是从“所有结果”随意挑数字。',ha='center',fontsize=10.5)
save('claim_evidence_matrix.png')

# 9 Simpson
with open(RES/'aggregation_trap_by_slice.csv',encoding='utf-8-sig') as f: sr=list(csv.DictReader(f))
with open(RES/'aggregation_trap_raw_aggregate.csv',encoding='utf-8-sig') as f: sa=list(csv.DictReader(f))
fig,ax=plt.subplots(figsize=(8.5,5))
for s in ['A','B']:
    rs=[r for r in sr if r['system']==s]
    ax.plot([r['slice'] for r in rs],[float(r['success_rate'])*100 for r in rs],marker='o',label=f'{s}（分层）')
for a in sa:
    ax.axhline(float(a['raw_aggregate_success_rate'])*100,linestyle='--',alpha=.55,label=f"{a['system']} 原始总平均={float(a['raw_aggregate_success_rate'])*100:.1f}%")
ax.set_ylabel('Success (%)'); ax.set_title('Aggregation Trap：任务配比不同可造成总体排名反转')
ax.legend(fontsize=8); ax.grid(alpha=.2)
save('aggregation_trap.png')

# 10 trace selection
fig,ax=plt.subplots(figsize=(11,4)); ax.set_xlim(0,11); ax.set_ylim(0,4); ax.axis('off')
box(ax,(.5,1.5),2.1,1.0,'先定义 Case\nSelection Rule',fc='#eef3f8')
box(ax,(3.25,1.5),2.1,1.0,'自动筛选\n所有候选 Trace',fc='#eef3f8')
box(ax,(6.0,1.5),2.1,1.0,'选代表案例\n不是最戏剧化案例',fc='#eef3f8')
box(ax,(8.75,1.5),1.8,1.0,'回到总体统计\n验证一致性',fc='#eef3f8')
arrow(ax,(2.6,2.0),(3.25,2.0)); arrow(ax,(5.35,2.0),(6.0,2.0)); arrow(ax,(8.1,2.0),(8.75,2.0))
ax.text(5.5,3.4,'Trace Case Selection：防止 Cherry-picking',ha='center',fontsize=16,fontweight='bold')
ax.text(5.5,.55,'Trace 用来解释机制，不应被用来替代总体证据。',ha='center',fontsize=11)
save('trace_case_selection.png')

print('generated', len(list(FIG.glob('*.png'))), 'figures')
