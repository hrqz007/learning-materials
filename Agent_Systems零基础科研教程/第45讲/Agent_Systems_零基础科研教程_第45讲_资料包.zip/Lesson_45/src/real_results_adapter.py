"""把真实 Agent 实验的 episode-level CSV 映射到本课最小结果 Schema。

本脚本不会调用任何 API。它只是一个离线适配器模板。
必须字段: task_id, system, repeat, task_success, token_cost, latency_ms
可选字段: horizon, root_cause, first_bad_span, failure_propagation_depth, recovered
"""
from __future__ import annotations
import argparse, csv
from pathlib import Path
REQ=['task_id','system','repeat','task_success','token_cost','latency_ms']
OPTIONAL=['horizon','root_cause','first_bad_span','failure_propagation_depth','recovered']

def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('input_csv'); ap.add_argument('output_csv')
    args=ap.parse_args()
    with open(args.input_csv,encoding='utf-8-sig') as f:
        r=csv.DictReader(f); fields=r.fieldnames or []
        miss=[x for x in REQ if x not in fields]
        if miss: raise SystemExit('缺少字段: '+', '.join(miss))
        rows=list(r)
    out_fields=REQ+OPTIONAL
    with open(args.output_csv,'w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=out_fields); w.writeheader()
        for row in rows: w.writerow({k:row.get(k,'') for k in out_fields})
    print(f'已规范化 {len(rows)} 行 -> {args.output_csv}')
if __name__=='__main__': main()
