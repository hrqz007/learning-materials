"""第45讲受控教学实验主程序。

零基础阅读顺序：
1. make_tasks()：先构造 120 个不同 Horizon / 难度的教学 Task。
2. simulate_episode()：模拟一个 Agent 完成一个 Task，并同时生成 episode-level 结果和 step-level Trace。
3. aggregate() / by_horizon()：把原始运行聚合成论文 Results 常用的总体表与分层表。
4. bootstrap_task_diff() / paired_perm_p()：按 Task 做配对统计，而不是把 repeat 误当独立样本。
5. select_cases()：先写规则、再自动选 Trace，避免 cherry-picking。
6. main()：真正批量运行 120 × 5 systems × 5 repeats = 3000 episodes，并写入 results/。

重要：所有概率和系统参数都是人为设置的受控教学参数，不代表任何真实模型或 Agent 产品。
"""
from __future__ import annotations
import csv, json, math, hashlib, random
from dataclasses import dataclass
from pathlib import Path
from collections import defaultdict, Counter
import statistics

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
RESULTS = ROOT / 'results'
FIGURES = ROOT / 'figures'
for p in [DATA, RESULTS, FIGURES]: p.mkdir(parents=True, exist_ok=True)

SEED = 450045
SYSTEMS = {
    'Baseline': dict(detect=0.10, recovery=0.08, delay=3.2, token_mult=1.00, latency_mult=1.00, retry=0.05, diag=0.25, redundant=0.14),
    'TokenMatched': dict(detect=0.28, recovery=0.18, delay=2.5, token_mult=1.30, latency_mult=1.12, retry=0.18, diag=0.38, redundant=0.12),
    'RetryOnly': dict(detect=0.36, recovery=0.42, delay=2.2, token_mult=1.14, latency_mult=1.16, retry=0.62, diag=0.44, redundant=0.16),
    'Verifier': dict(detect=0.62, recovery=0.53, delay=1.4, token_mult=1.24, latency_mult=1.25, retry=0.22, diag=0.67, redundant=0.09),
    'BRG_Full': dict(detect=0.82, recovery=0.76, delay=0.8, token_mult=1.31, latency_mult=1.34, retry=0.26, diag=0.86, redundant=0.07),
}
HORIZONS = [4, 8, 16, 32]
DIFFICULTIES = ['easy', 'medium', 'hard']
ROOT_CAUSES = ['planning', 'tool', 'memory', 'state']


def stable_rng(*parts):
    s = '|'.join(map(str, parts)).encode('utf-8')
    h = hashlib.sha256(s).hexdigest()
    return random.Random(int(h[:16], 16))


def make_tasks():
    rows=[]
    for i in range(120):
        horizon=HORIZONS[i % 4]
        difficulty=DIFFICULTIES[(i//4) % 3]
        diff_add={'easy':0.0,'medium':0.018,'hard':0.038}[difficulty]
        horizon_add={4:0.0,8:0.006,16:0.012,32:0.019}[horizon]
        root_bias = ROOT_CAUSES[(i*7) % len(ROOT_CAUSES)]
        rows.append({
            'task_id': f'T{i+1:03d}',
            'horizon': horizon,
            'difficulty': difficulty,
            'base_fault_prob': round(0.014 + diff_add + horizon_add, 4),
            'root_bias': root_bias,
        })
    return rows


def write_csv(path, rows, fields=None):
    if not rows:
        return
    fields = fields or list(rows[0].keys())
    with open(path, 'w', newline='', encoding='utf-8-sig') as f:
        w=csv.DictWriter(f, fieldnames=fields, extrasaction='ignore')
        w.writeheader(); w.writerows(rows)


def percentile(vals, q):
    if not vals: return 0.0
    x=sorted(vals)
    pos=(len(x)-1)*q
    lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi: return x[lo]
    return x[lo]*(hi-pos)+x[hi]*(pos-lo)


def wilson(k,n,z=1.96):
    if n==0: return (0,0)
    p=k/n; den=1+z*z/n
    center=(p+z*z/(2*n))/den
    half=z*math.sqrt((p*(1-p)+z*z/(4*n))/n)/den
    return center-half, center+half


def bootstrap_task_diff(task_rows_a, task_rows_b, B=5000, seed=45):
    common=sorted(set(task_rows_a)&set(task_rows_b))
    diffs=[task_rows_a[t]-task_rows_b[t] for t in common]
    rng=random.Random(seed)
    means=[]
    for _ in range(B):
        sample=[diffs[rng.randrange(len(diffs))] for __ in range(len(diffs))]
        means.append(sum(sample)/len(sample))
    return percentile(means,0.025), percentile(means,0.975), sum(diffs)/len(diffs)


def paired_perm_p(diffs, B=20000, seed=91):
    obs=abs(sum(diffs)/len(diffs))
    rng=random.Random(seed)
    ge=0
    for _ in range(B):
        m=sum((d if rng.random()<0.5 else -d) for d in diffs)/len(diffs)
        if abs(m) >= obs - 1e-12: ge += 1
    return (ge+1)/(B+1)


def simulate_episode(task, system, repeat):
    cfg=SYSTEMS[system]
    rng=stable_rng(SEED, task['task_id'], system, repeat)
    horizon=task['horizon']; diff=task['difficulty']
    active_corruption=False
    first_bad=None; detected_at=None; recovered=False; unrecovered=False
    root_cause='none'; retry_count=0; redundant=0; errors=0; propagated=0
    tokens=0; latencies=[]; trace=[]; successful_steps=0
    tool_correct=0; arg_valid=0; diagnostic=False
    # small system-specific functional gains not solely from recovery
    base_action_q={'Baseline':0.955,'TokenMatched':0.965,'RetryOnly':0.958,'Verifier':0.968,'BRG_Full':0.971}[system]
    for step in range(1,horizon+1):
        step_lat = max(15.0, rng.lognormvariate(math.log(120*cfg['latency_mult']), 0.38))
        latencies.append(step_lat)
        tokens_step=int(max(18, rng.gauss(72*cfg['token_mult'], 10)))
        tokens += tokens_step
        state='clean' if not active_corruption else 'corrupted'
        event='normal'
        # intrinsic action / tool validity
        tool_ok = rng.random() < base_action_q - (0.006 if diff=='hard' else 0)
        arg_ok = rng.random() < base_action_q + 0.01
        tool_correct += int(tool_ok); arg_valid += int(arg_ok)
        if rng.random() < cfg['redundant']:
            redundant += 1
        # fault may arrive only while clean
        if not active_corruption:
            step_fault_prob=float(task['base_fault_prob'])*(1+0.35*(step/horizon))
            if rng.random() < step_fault_prob:
                active_corruption=True
                first_bad=first_bad or step
                root_cause = task['root_bias'] if rng.random()<0.5 else rng.choice(ROOT_CAUSES)
                errors += 1
                event='fault_introduced'
        else:
            propagated += 1
            if rng.random()<0.25:
                errors += 1
            event='propagating'
        # detection and recovery once corrupted
        if active_corruption and detected_at is None:
            dynamic_detect=max(0.0,min(0.98,cfg['detect'] - 0.015*max(0, step-(first_bad or step))))
            if rng.random() < dynamic_detect:
                detected_at=step
                event='detected'
                diagnostic = rng.random() < cfg['diag']
                # retry is an action after detection
                if rng.random() < cfg['retry']:
                    retry_count += 1
                    tokens += int(40*cfg['token_mult'])
                    latencies[-1] += 65*cfg['latency_mult']
                # recovery probability drops with detection delay
                delay=max(0, step-(first_bad or step))
                p_rec=max(0.02, cfg['recovery'] - 0.06*delay)
                if rng.random() < p_rec:
                    active_corruption=False
                    recovered=True
                    event='recovered'
                else:
                    unrecovered=True
                    event='recovery_failed'
        # step-level correctness: corruption makes downstream outputs risky
        step_ok = (not active_corruption) and tool_ok and arg_ok
        successful_steps += int(step_ok)
        trace.append({
            'episode_id': f"{task['task_id']}|{system}|r{repeat}",
            'task_id': task['task_id'], 'system': system, 'repeat': repeat,
            'step': step, 'horizon': horizon, 'difficulty': diff,
            'event': event, 'state_before': state, 'active_corruption_after': bool(active_corruption),
            'root_cause': root_cause if first_bad else 'none',
            'tokens_step': tokens_step, 'latency_ms': round(latencies[-1],2),
            'tool_selection_correct': int(tool_ok), 'argument_valid': int(arg_ok),
        })
    # if detection happened but no recovery and corruption remained, unrecovered
    if active_corruption: unrecovered=True
    # success also requires a high fraction of non-faulty actions; makes task semantics nontrivial
    clean_fraction = successful_steps/horizon
    success = int((not active_corruption) and clean_fraction >= 0.82)
    completion=int(clean_fraction >= 0.70)
    propagation_depth = 0 if first_bad is None else max(0, (horizon-first_bad+1) if detected_at is None else detected_at-first_bad)
    recovery_rate = 1 if first_bad is not None and recovered else (0 if first_bad is not None else '')
    episode={
        'episode_id': f"{task['task_id']}|{system}|r{repeat}",
        'task_id': task['task_id'], 'system': system, 'repeat': repeat,
        'horizon': horizon, 'difficulty': diff,
        'task_success': success, 'completion_rate': completion,
        'tool_selection_accuracy': round(tool_correct/horizon,4),
        'argument_validity': round(arg_valid/horizon,4),
        'step_count': horizon,
        'token_cost': tokens,
        'estimated_api_cost_units': round(tokens/1000*0.01,6),
        'latency_ms': round(sum(latencies),2),
        'p95_step_latency_ms': round(percentile(latencies,0.95),2),
        'retry_count': retry_count,
        'recovery_rate': recovery_rate,
        'error_rate': round(errors/horizon,4),
        'redundant_actions': redundant,
        'communication_cost': 0,
        'first_bad_span': first_bad if first_bad is not None else '',
        'root_cause': root_cause,
        'failure_propagation_depth': propagation_depth,
        'diagnostic_coverage': int(diagnostic) if first_bad is not None else '',
        'had_failure': int(first_bad is not None),
        'recovered': int(recovered),
        'unrecovered': int(unrecovered),
    }
    return episode, trace


def aggregate(episodes):
    groups=defaultdict(list)
    for e in episodes: groups[e['system']].append(e)
    rows=[]
    for s,es in groups.items():
        succ=sum(x['task_success'] for x in es); n=len(es)
        fails=[x for x in es if x['had_failure']]
        rows.append({
            'system':s,'n':n,'success_rate':round(succ/n,4),
            'success_ci_low':round(wilson(succ,n)[0],4),'success_ci_high':round(wilson(succ,n)[1],4),
            'completion_rate':round(sum(x['completion_rate'] for x in es)/n,4),
            'mean_tokens':round(statistics.mean(x['token_cost'] for x in es),1),
            'mean_latency_ms':round(statistics.mean(x['latency_ms'] for x in es),1),
            'p95_episode_latency_ms':round(percentile([x['latency_ms'] for x in es],0.95),1),
            'mean_step_p95_ms':round(statistics.mean(x['p95_step_latency_ms'] for x in es),1),
            'mean_error_rate':round(statistics.mean(x['error_rate'] for x in es),4),
            'mean_redundant_actions':round(statistics.mean(x['redundant_actions'] for x in es),2),
            'recovery_rate_given_failure':round(sum(x['recovered'] for x in fails)/len(fails),4) if fails else '',
            'mean_propagation_depth_given_failure':round(statistics.mean(x['failure_propagation_depth'] for x in fails),3) if fails else '',
            'diagnostic_coverage_given_failure':round(sum(int(x['diagnostic_coverage']) for x in fails)/len(fails),4) if fails else '',
        })
    return sorted(rows,key=lambda r:r['success_rate'], reverse=True)


def by_horizon(episodes):
    groups=defaultdict(list)
    for e in episodes: groups[(e['system'],e['horizon'])].append(e)
    rows=[]
    for (s,h),es in sorted(groups.items(), key=lambda x:(x[0][1],x[0][0])):
        rows.append({'system':s,'horizon':h,'n':len(es),
                     'success_rate':round(sum(x['task_success'] for x in es)/len(es),4),
                     'mean_tokens':round(statistics.mean(x['token_cost'] for x in es),1),
                     'mean_latency_ms':round(statistics.mean(x['latency_ms'] for x in es),1),
                     'mean_propagation_depth':round(statistics.mean(x['failure_propagation_depth'] for x in es),3)})
    return rows


def task_means(episodes, system):
    d=defaultdict(list)
    for e in episodes:
        if e['system']==system: d[e['task_id']].append(e['task_success'])
    return {k:sum(v)/len(v) for k,v in d.items()}


def metric_task_means(episodes, system, metric):
    d=defaultdict(list)
    for e in episodes:
        if e['system']==system: d[e['task_id']].append(float(e[metric]))
    return {k:sum(v)/len(v) for k,v in d.items()}


def select_cases(episodes):
    idx={(e['task_id'],e['repeat'],e['system']):e for e in episodes}
    candidates=[]
    for e in episodes:
        if e['system']!='BRG_Full': continue
        b=idx.get((e['task_id'],e['repeat'],'Baseline'))
        if not b: continue
        if e['task_success']==1 and b['task_success']==0 and e['had_failure'] and b['had_failure']:
            candidates.append((e['horizon'], abs((e['token_cost']-b['token_cost'])-250), e, b))
    candidates.sort(key=lambda x:(abs(x[0]-16),x[1]))
    picked=[]
    if candidates:
        _,_,e,b=candidates[0]
        picked.append({'selection_rule':'预先规则：Baseline失败、BRG成功、优先horizon=16、再选token差最接近中位规模','task_id':e['task_id'],'repeat':e['repeat'],'baseline_episode':b['episode_id'],'brg_episode':e['episode_id']})
    # representative same-outcome case
    same=[]
    for e in episodes:
        if e['system']!='BRG_Full': continue
        b=idx.get((e['task_id'],e['repeat'],'Baseline'))
        if b and e['task_success']==b['task_success']==1 and e['horizon']==8:
            same.append((abs(e['token_cost']-statistics.mean([x['token_cost'] for x in episodes if x['system']=='BRG_Full' and x['horizon']==8])),e,b))
    same.sort(key=lambda x:x[0])
    if same:
        _,e,b=same[0]
        picked.append({'selection_rule':'预先规则：两系统都成功、horizon=8、BRG token最接近该slice均值','task_id':e['task_id'],'repeat':e['repeat'],'baseline_episode':b['episode_id'],'brg_episode':e['episode_id']})
    return picked


def make_simpson_demo():
    # A is better within each stratum, but because evaluation mix differs, raw aggregate favors B.
    rows=[
        {'system':'A','slice':'easy','n':20,'successes':18},
        {'system':'B','slice':'easy','n':80,'successes':68},
        {'system':'A','slice':'hard','n':80,'successes':48},
        {'system':'B','slice':'hard','n':20,'successes':11},
    ]
    for r in rows: r['success_rate']=round(r['successes']/r['n'],4)
    agg=[]
    for s in ['A','B']:
        rs=[r for r in rows if r['system']==s]
        n=sum(r['n'] for r in rs); k=sum(r['successes'] for r in rs)
        agg.append({'system':s,'n':n,'successes':k,'raw_aggregate_success_rate':round(k/n,4)})
    return rows, agg


def main():
    tasks=make_tasks(); write_csv(DATA/'tasks.csv',tasks)
    with open(DATA/'experiment_config.json','w',encoding='utf-8') as f:
        json.dump({'seed':SEED,'systems':SYSTEMS,'repeats':5,'controlled_teaching_simulation':True,
                   'disclaimer':'这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、Agent 框架或产品的实际性能。'},f,ensure_ascii=False,indent=2)
    with open(DATA/'failure_taxonomy.json','w',encoding='utf-8') as f:
        json.dump({'planning':'规划或分解错误','tool':'工具选择/执行错误','memory':'记忆读取或写入错误','state':'状态更新/传递错误'},f,ensure_ascii=False,indent=2)
    episodes=[]; traces=[]
    for task in tasks:
        for system in SYSTEMS:
            for r in range(1,6):
                e,tr=simulate_episode(task,system,r); episodes.append(e); traces.extend(tr)
    write_csv(RESULTS/'episodes.csv',episodes)
    with open(RESULTS/'traces.jsonl','w',encoding='utf-8') as f:
        for row in traces: f.write(json.dumps(row,ensure_ascii=False)+'\n')
    summary=aggregate(episodes); write_csv(RESULTS/'summary_by_system.csv',summary)
    horizon=by_horizon(episodes); write_csv(RESULTS/'summary_by_horizon.csv',horizon)
    # Paired inference full vs baseline at task level
    full=task_means(episodes,'BRG_Full'); base=task_means(episodes,'Baseline')
    lo,hi,diff=bootstrap_task_diff(full,base)
    diffs=[full[t]-base[t] for t in sorted(full)]
    p=paired_perm_p(diffs)
    # cost paired diff
    ft=metric_task_means(episodes,'BRG_Full','token_cost'); bt=metric_task_means(episodes,'Baseline','token_cost')
    costdiff=sum(ft[t]-bt[t] for t in ft)/len(ft)
    inference={'comparison':'BRG_Full - Baseline','task_level_paired_effect_pp':round(diff*100,2),
               'task_cluster_bootstrap_95ci_pp':[round(lo*100,2),round(hi*100,2)],
               'paired_permutation_p':round(p,6),'mean_token_difference':round(costdiff,1),'n_tasks':len(full),
               'interpretation_rule':'先看效应大小与CI，再看p值；同时报告成本与机制指标。'}
    with open(RESULTS/'paired_inference.json','w',encoding='utf-8') as f: json.dump(inference,f,ensure_ascii=False,indent=2)
    # Root cause and first bad span summaries
    rc=defaultdict(lambda:{'n':0,'success':0,'recovered':0,'prop':[]})
    for e in episodes:
        if e['had_failure']:
            k=(e['system'],e['root_cause']); d=rc[k]; d['n']+=1; d['success']+=e['task_success']; d['recovered']+=e['recovered']; d['prop'].append(e['failure_propagation_depth'])
    rc_rows=[]
    for (s,c),d in sorted(rc.items()):
        rc_rows.append({'system':s,'root_cause':c,'n_failures':d['n'],'success_after_failure':round(d['success']/d['n'],4),'recovery_rate':round(d['recovered']/d['n'],4),'mean_propagation_depth':round(statistics.mean(d['prop']),3)})
    write_csv(RESULTS/'failure_by_root_cause.csv',rc_rows)
    # first bad span distribution
    fbs=defaultdict(list)
    for e in episodes:
        if e['had_failure']: fbs[e['system']].append(int(e['first_bad_span']))
    fbs_rows=[]
    for s,v in fbs.items():
        fbs_rows.append({'system':s,'n_failures':len(v),'median_first_bad_span':round(percentile(v,0.5),2),'p25':round(percentile(v,0.25),2),'p75':round(percentile(v,0.75),2)})
    write_csv(RESULTS/'first_bad_span_summary.csv',fbs_rows)
    # Trace case selection rules, no cherry-picking
    cases=select_cases(episodes)
    with open(RESULTS/'selected_trace_cases.json','w',encoding='utf-8') as f: json.dump(cases,f,ensure_ascii=False,indent=2)
    # extract selected traces
    ids=set()
    for c in cases: ids|={c['baseline_episode'],c['brg_episode']}
    with open(RESULTS/'selected_trace_cases.jsonl','w',encoding='utf-8') as f:
        for row in traces:
            if row['episode_id'] in ids: f.write(json.dumps(row,ensure_ascii=False)+'\n')
    # Simpson demo
    sim,agg=make_simpson_demo(); write_csv(RESULTS/'aggregation_trap_by_slice.csv',sim); write_csv(RESULTS/'aggregation_trap_raw_aggregate.csv',agg)
    # Claim registry based on actual results
    sm={r['system']:r for r in summary}
    hz=defaultdict(dict)
    for r in horizon: hz[r['system']][r['horizon']]=r
    claims=[
      {'claim_id':'C1','claim':'在本受控模拟中，BRG_Full 的总体 Task Success 高于 Baseline。','scope':'120 tasks × 5 repeats；仅本教学模拟','primary_evidence':'summary_by_system.csv + paired_inference.json','mechanism_evidence':'failure_by_root_cause.csv / selected_trace_cases.jsonl','risk':'不能外推到真实LLM。'},
      {'claim_id':'C2','claim':'BRG_Full 的收益随任务 horizon 增大而更明显。','scope':'horizon ∈ {4,8,16,32}','primary_evidence':'summary_by_horizon.csv','mechanism_evidence':'failure_propagation_depth','risk':'slice结果是探索性解释，不等同因果证明。'},
      {'claim_id':'C3','claim':'BRG_Full 的成功率收益伴随更高 token 与 latency 开销。','scope':'相同任务、重复数','primary_evidence':'summary_by_system.csv','mechanism_evidence':'episodes.csv','risk':'成本单位为教学单位，不是实际API价格。'},
      {'claim_id':'C4','claim':'机制层证据与“更早检测/更高恢复/更浅传播”一致。','scope':'发生failure的episodes','primary_evidence':'failure_by_root_cause.csv','mechanism_evidence':'selected_trace_cases.jsonl','risk':'一致性证据不自动构成唯一因果解释。'},
      {'claim_id':'C5','claim':'若系统在不同难度任务上的评测配比不同，只看总平均可能产生方向错误的结论。','scope':'独立的Simpson教学示例','primary_evidence':'aggregation_trap_by_slice.csv + aggregation_trap_raw_aggregate.csv','mechanism_evidence':'无','risk':'该示例为人为构造，用于解释aggregation bias。'},
    ]
    with open(RESULTS/'claim_evidence_registry.json','w',encoding='utf-8') as f: json.dump(claims,f,ensure_ascii=False,indent=2)
    # compact actual numbers for document generator
    actual={'n_episodes':len(episodes),'n_traces':len(traces),'summary':summary,'inference':inference,'cases':cases,'claims':claims,'by_horizon':horizon}
    with open(RESULTS/'actual_results.json','w',encoding='utf-8') as f: json.dump(actual,f,ensure_ascii=False,indent=2)
    print(json.dumps({'episodes':len(episodes),'trace_spans':len(traces),'inference':inference,'summary':summary},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
