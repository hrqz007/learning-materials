from __future__ import annotations
import argparse, json
from pathlib import Path
ROOT=Path(__file__).resolve().parents[1]
TRACE=ROOT/'results'/'traces.jsonl'

def main():
    ap=argparse.ArgumentParser(description='读取指定 episode 的 step-level Trace')
    ap.add_argument('--episode',required=True,help='例如 T103|Baseline|r4')
    args=ap.parse_args()
    rows=[]
    with open(TRACE,encoding='utf-8') as f:
        for line in f:
            r=json.loads(line)
            if r['episode_id']==args.episode: rows.append(r)
    if not rows:
        raise SystemExit(f'未找到 episode: {args.episode}')
    print(f"episode={args.episode}, spans={len(rows)}")
    for r in rows:
        print(f"step={r['step']:>2} event={r['event']:<16} state_before={r['state_before']:<10} corrupted_after={r['active_corruption_after']} root={r['root_cause']:<8} token={r['tokens_step']:<3} latency={r['latency_ms']:>7}")
if __name__=='__main__': main()
