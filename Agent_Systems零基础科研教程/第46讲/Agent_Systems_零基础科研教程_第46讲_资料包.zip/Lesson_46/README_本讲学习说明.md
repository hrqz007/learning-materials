# Agent Systems 零基础科研教程 · 第46讲

主题：Discussion 与 Limitations——怎样解释机制、讨论边界、Threats to Validity，并避免把“相关”写成“因果”。

## 建议学习顺序
1. 先读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 按 `03_实验指导书.docx` 运行 `python src/run_lesson46.py`。
3. 对照 `results/summary.json`、CSV 和 `all_traces.jsonl` 区分事实、解释、因果与边界。
4. 再读 `04_实验设计书.docx`，理解如何预注册 validity threats。
5. 独立完成练习题，再看答案。

## 本讲真实运行规模
- Observational episodes: 1800
- Randomized/paired episodes: 1800
- Shift episodes: 3240
- Total episodes: 6840

## 教学实验声明
这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、Agent、Benchmark、框架或产品的实际性能。

## 最低闭环
看到一个结果后，至少能回答：
`What happened? -> Alternative explanations? -> Mechanism evidence? -> Boundary? -> Threats to validity? -> What can I safely claim?`
