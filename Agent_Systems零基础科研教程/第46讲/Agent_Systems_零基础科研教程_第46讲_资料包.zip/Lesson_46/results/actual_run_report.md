# 第46讲实际运行报告

> 这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实 Agent / 模型 / 产品的实际性能。

## 运行规模
- Tasks: 120
- Observational episodes: 1800
- RCT episodes: 1800
- Shift episodes: 3240
- Total episodes: 6840

## 核心现象
1. Naive observational difference: 45.9 pp
2. Horizon-standardized observational difference: 21.2 pp
3. Randomized paired effect: 21.2 pp, 95% CI [16.7, 25.8] pp
4. Budget-matched -> Early Monitor effect: 15.2 pp
5. Mean detection delay: Baseline 2.57, Early Monitor 0.45
6. Mean max propagation: Baseline 2.46, Early Monitor 1.01
7. Clean benefit: 27.5 pp; External-tool-shift benefit: 16.4 pp

## 教学结论边界
这些数字只用于展示：混杂会夸大关联、随机化更接近干预效应、Trace 可以支持但不能自动证明机制、换环境后结论范围会改变。
