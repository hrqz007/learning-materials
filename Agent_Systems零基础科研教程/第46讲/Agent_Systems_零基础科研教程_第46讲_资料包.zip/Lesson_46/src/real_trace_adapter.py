"""Optional adapter template for real Agent experiments.

This script does NOT call any API. It demonstrates how to map a real experiment's
CSV/JSONL fields into the Lesson 46 discussion/validity schema.
"""
from __future__ import annotations
import csv
from pathlib import Path

REQUIRED = [
    "task_id", "system", "environment", "repeat", "success",
    "token_cost", "latency_ms"
]
OPTIONAL_MECHANISM = [
    "first_bad_span", "first_detection_delay", "max_propagation", "recovery_rate"
]

def validate_csv(path: str) -> None:
    p = Path(path)
    with p.open("r", encoding="utf-8-sig", newline="") as f:
        reader = csv.DictReader(f)
        fields = reader.fieldnames or []
        missing = [x for x in REQUIRED if x not in fields]
        if missing:
            raise ValueError(f"Missing required fields: {missing}")
        print("Required fields: OK")
        print("Mechanism fields present:", [x for x in OPTIONAL_MECHANISM if x in fields])
        print("Remember: field availability does not by itself justify a causal claim.")

if __name__ == "__main__":
    import argparse
    ap = argparse.ArgumentParser()
    ap.add_argument("csv_path")
    args = ap.parse_args()
    validate_csv(args.csv_path)
