"""Lesson 46 controlled teaching experiment.

Purpose
-------
Demonstrate, with a fully reproducible local simulator, why Discussion/Limitations
must distinguish: association, intervention, mechanism evidence, boundary conditions,
and threats to validity.

Important
---------
This is a controlled educational simulation. The probabilities below are deliberately
chosen for teaching clarity. They are NOT measurements of GPT, Claude, Gemini, or
any real Agent system.

No network, GPU, API key, or external model is used.
"""
from __future__ import annotations

import csv
import hashlib
import json
import math
import random
from dataclasses import dataclass, asdict
from pathlib import Path
from statistics import mean
from typing import Dict, Iterable, List, Tuple

ROOT = Path(__file__).resolve().parents[1]
DATA_DIR = ROOT / "data"
RESULT_DIR = ROOT / "results"
FIG_DIR = ROOT / "figures"
for d in (DATA_DIR, RESULT_DIR, FIG_DIR):
    d.mkdir(parents=True, exist_ok=True)

GLOBAL_SEED = 460929
HORIZONS = [4, 8, 16, 32]
DOMAINS = ["coding", "web", "data", "planning"]
SYSTEMS = ["baseline", "budget_matched", "early_monitor"]
ENVIRONMENTS = ["clean", "internal_shift", "external_tool_shift"]

@dataclass(frozen=True)
class Task:
    task_id: str
    horizon: int
    domain: str
    difficulty: float


def stable_seed(*parts: object) -> int:
    """Turn experiment identifiers into a stable 32-bit seed.

    This avoids Python hash randomization and makes every episode reproducible across runs.
    """
    s = "|".join(map(str, parts)).encode("utf-8")
    return int(hashlib.sha256(s).hexdigest()[:16], 16) % (2**32)


def make_tasks() -> List[Task]:
    """Create 120 balanced synthetic tasks: 30 tasks for each horizon 4/8/16/32."""
    tasks: List[Task] = []
    idx = 0
    for h in HORIZONS:
        for j in range(30):
            domain = DOMAINS[j % len(DOMAINS)]
            domain_offset = {"coding": 0.03, "web": 0.06, "data": 0.02, "planning": 0.08}[domain]
            # Harder tasks tend to be longer; a little deterministic within-stratum variation.
            difficulty = 0.18 + 0.012 * h + domain_offset + (j % 5) * 0.015
            tasks.append(Task(f"T{idx:03d}", h, domain, round(difficulty, 4)))
            idx += 1
    return tasks


def write_tasks(tasks: List[Task]) -> None:
    p = DATA_DIR / "tasks.csv"
    with p.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=list(asdict(tasks[0]).keys()))
        w.writeheader()
        for t in tasks:
            w.writerow(asdict(t))


def clamp(x: float, lo: float = 0.0, hi: float = 1.0) -> float:
    return max(lo, min(hi, x))


def simulate_episode(task: Task, system: str, env: str, repeat: int, phase: str) -> Dict:
    """Run one synthetic Agent episode and return both summary metrics and step Trace.

    The simulator intentionally separates internal faults from external-tool faults.
    `early_monitor` improves detection of internal faults, while external faults remain
    mostly outside its observability boundary. This creates a teachable boundary condition.
    """
    rng = random.Random(stable_seed(GLOBAL_SEED, task.task_id, system, env, repeat, phase))

    env_internal = {"clean": 0.0, "internal_shift": 0.022, "external_tool_shift": 0.006}[env]
    env_external = {"clean": 0.0, "internal_shift": 0.004, "external_tool_shift": 0.055}[env]

    # Extra budget slightly reduces internal reasoning faults but does not improve detection timing.
    reasoning_bonus = {"baseline": 0.0, "budget_matched": 0.010, "early_monitor": 0.004}[system]
    monitor = system == "early_monitor"

    token_cost = 680 + task.horizon * 46
    if system in ("budget_matched", "early_monitor"):
        token_cost += 260 + task.horizon * 6

    external_failures = 0
    internal_failures = 0
    recovered_failures = 0
    first_bad_span = None
    max_propagation = 0
    first_detection_delay = None
    critical_failure = False
    spans = []
    active_internal_error_age = None

    for step in range(1, task.horizon + 1):
        step_seed = stable_seed(GLOBAL_SEED, task.task_id, system, env, repeat, phase, step)
        srng = random.Random(step_seed)

        # Per-step internal and external fault risks.
        p_internal = clamp(0.010 + 0.0025 * task.horizon + 0.018 * task.difficulty + env_internal - reasoning_bonus, 0.004, 0.18)
        p_external = clamp(0.006 + 0.004 * task.difficulty + env_external, 0.002, 0.14)

        internal_fault = srng.random() < p_internal
        external_fault = srng.random() < p_external

        event = "ok"
        detected = False
        recovered = False
        delay = None
        propagation = 0

        if internal_fault:
            internal_failures += 1
            if first_bad_span is None:
                first_bad_span = step
            # Monitor detects sooner; budget matched gets no detection advantage.
            if monitor:
                delay = 0 if srng.random() < 0.62 else (1 if srng.random() < 0.90 else 2)
            else:
                delay = srng.choice([1, 2, 3, 4])
            detected = True
            if first_detection_delay is None:
                first_detection_delay = delay
            rec_prob = clamp(0.86 - 0.17 * delay - 0.35 * task.difficulty + (0.08 if monitor else 0.0), 0.05, 0.93)
            recovered = srng.random() < rec_prob
            if recovered:
                recovered_failures += 1
                propagation = max(0, delay)
                event = "internal_fault_recovered"
            else:
                propagation = delay + srng.choice([1, 2, 3])
                event = "internal_fault_unrecovered"
                if propagation >= 4 or (task.horizon >= 16 and srng.random() < 0.35):
                    critical_failure = True
            max_propagation = max(max_propagation, propagation)

        if external_fault:
            external_failures += 1
            if first_bad_span is None:
                first_bad_span = step
            # External tool failures are largely outside the monitor's visibility.
            ext_detect_prob = 0.52 + (0.03 if monitor else 0.0)
            detected_ext = srng.random() < ext_detect_prob
            rec_prob_ext = 0.44 if detected_ext else 0.12
            recovered_ext = srng.random() < rec_prob_ext
            if recovered_ext:
                recovered_failures += 1
                event = "external_fault_recovered"
                max_propagation = max(max_propagation, 1)
            else:
                event = "external_fault_unrecovered"
                max_propagation = max(max_propagation, 3)
                if srng.random() < 0.72:
                    critical_failure = True

        # A residual task-level failure chance independent of monitored mechanism.
        base_residual = 0.012 + 0.16 * task.difficulty / max(task.horizon, 4)
        residual_failure = srng.random() < base_residual
        if residual_failure and step == task.horizon:
            critical_failure = True
            event = "residual_failure"

        spans.append({
            "step": step,
            "event": event,
            "internal_fault": int(internal_fault),
            "external_fault": int(external_fault),
            "detected": int(detected),
            "recovered": int(recovered),
            "detection_delay": delay,
            "propagation_depth": propagation,
        })

    success = 0 if critical_failure else 1
    failures = internal_failures + external_failures
    recovery_rate = recovered_failures / failures if failures else 1.0
    latency_ms = 520 + task.horizon * 77 + (170 if system != "baseline" else 0) + rng.randint(-80, 80)
    if env == "external_tool_shift":
        latency_ms += 260 + rng.randint(0, 180)
    elif env == "internal_shift":
        latency_ms += 70 + rng.randint(0, 80)

    return {
        "phase": phase,
        "task_id": task.task_id,
        "domain": task.domain,
        "horizon": task.horizon,
        "difficulty": task.difficulty,
        "system": system,
        "environment": env,
        "repeat": repeat,
        "success": success,
        "internal_failures": internal_failures,
        "external_failures": external_failures,
        "failure_count": failures,
        "recovered_failures": recovered_failures,
        "recovery_rate": round(recovery_rate, 6),
        "first_bad_span": first_bad_span,
        "first_detection_delay": first_detection_delay,
        "max_propagation": max_propagation,
        "token_cost": token_cost,
        "latency_ms": latency_ms,
        "trace": spans,
    }


def run_rct(tasks: List[Task]) -> List[Dict]:
    """Randomized/paired teaching experiment: every task is run under every system."""
    rows = []
    for t in tasks:
        for system in SYSTEMS:
            for repeat in range(5):
                rows.append(simulate_episode(t, system, "clean", repeat, "rct"))
    return rows


def run_shift(tasks: List[Task]) -> List[Dict]:
    """Stress-test the same systems under clean, internal-shift, and external-tool-shift environments."""
    rows = []
    for t in tasks:
        for env in ENVIRONMENTS:
            for system in SYSTEMS:
                for repeat in range(3):
                    rows.append(simulate_episode(t, system, env, repeat, "shift"))
    return rows


def run_observational(tasks: List[Task]) -> List[Dict]:
    """Create intentionally confounded observational data for teaching.

    Easy/short tasks receive the monitor more often. Direct group comparison therefore
    mixes the monitor effect with task difficulty.
    """
    rows = []
    # Treatment assignment is confounded by horizon/difficulty: easy tasks are much more likely to receive monitor.
    for t in tasks:
        propensity = {4: 0.82, 8: 0.70, 16: 0.40, 32: 0.20}[t.horizon]
        for repeat in range(15):
            rng = random.Random(stable_seed(GLOBAL_SEED, "obs_assign", t.task_id, repeat))
            system = "early_monitor" if rng.random() < propensity else "baseline"
            rows.append(simulate_episode(t, system, "clean", repeat, "observational"))
    return rows


def write_episode_csv(rows: List[Dict], path: Path) -> None:
    fields = [k for k in rows[0] if k != "trace"]
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.DictWriter(f, fieldnames=fields)
        w.writeheader()
        for r in rows:
            w.writerow({k: r[k] for k in fields})


def write_trace_jsonl(groups: Iterable[List[Dict]], path: Path) -> None:
    with path.open("w", encoding="utf-8") as f:
        for rows in groups:
            for r in rows:
                f.write(json.dumps(r, ensure_ascii=False) + "\n")


def group_mean(rows: List[Dict], key: str, value: str) -> Dict[str, float]:
    buckets: Dict[str, List[float]] = {}
    for r in rows:
        buckets.setdefault(str(r[key]), []).append(float(r[value]))
    return {k: mean(v) for k, v in buckets.items()}


def aggregate_task_level(rows: List[Dict], system: str, env: str = "clean") -> Dict[str, float]:
    bucket: Dict[str, List[int]] = {}
    for r in rows:
        if r["system"] == system and r["environment"] == env:
            bucket.setdefault(r["task_id"], []).append(int(r["success"]))
    return {tid: mean(vals) for tid, vals in bucket.items()}


def bootstrap_paired_diff(rows: List[Dict], a: str, b: str, env: str = "clean", n_boot: int = 4000) -> Tuple[float, float, float]:
    """Estimate task-level paired success difference and a task-cluster bootstrap 95% CI."""
    ta = aggregate_task_level(rows, a, env)
    tb = aggregate_task_level(rows, b, env)
    tids = sorted(set(ta) & set(tb))
    diffs = [tb[t] - ta[t] for t in tids]
    obs = mean(diffs)
    rng = random.Random(stable_seed(GLOBAL_SEED, "bootstrap", a, b, env))
    boots = []
    for _ in range(n_boot):
        sample = [diffs[rng.randrange(len(diffs))] for _ in range(len(diffs))]
        boots.append(mean(sample))
    boots.sort()
    lo = boots[int(0.025 * len(boots))]
    hi = boots[int(0.975 * len(boots)) - 1]
    return obs, lo, hi


def observational_analysis(rows: List[Dict]) -> Dict:
    """Compare naive observational difference with horizon-standardized difference."""
    groups: Dict[str, List[int]] = {"baseline": [], "early_monitor": []}
    for r in rows:
        groups[r["system"]].append(r["success"])
    naive = mean(groups["early_monitor"]) - mean(groups["baseline"])

    strata = {}
    adjusted_diffs = []
    for h in HORIZONS:
        sub = [r for r in rows if r["horizon"] == h]
        m = [r["success"] for r in sub if r["system"] == "early_monitor"]
        b = [r["success"] for r in sub if r["system"] == "baseline"]
        diff = mean(m) - mean(b)
        strata[str(h)] = {
            "monitor_success": mean(m),
            "baseline_success": mean(b),
            "difference": diff,
            "n_monitor": len(m),
            "n_baseline": len(b),
        }
        adjusted_diffs.append(diff)
    # Equal-weight standardization across horizons (because task design is balanced by horizon).
    adjusted = mean(adjusted_diffs)
    return {
        "naive_difference": naive,
        "horizon_standardized_difference": adjusted,
        "strata": strata,
        "monitor_rate_by_horizon": {
            str(h): sum(1 for r in rows if r["horizon"] == h and r["system"] == "early_monitor") / sum(1 for r in rows if r["horizon"] == h)
            for h in HORIZONS
        }
    }


def mechanism_summary(rows: List[Dict]) -> Dict:
    out = {}
    for system in SYSTEMS:
        sub = [r for r in rows if r["system"] == system and r["environment"] == "clean"]
        delays = [r["first_detection_delay"] for r in sub if r["first_detection_delay"] is not None]
        out[system] = {
            "success_rate": mean([r["success"] for r in sub]),
            "mean_first_detection_delay": mean(delays) if delays else None,
            "mean_max_propagation": mean([r["max_propagation"] for r in sub]),
            "mean_recovery_rate": mean([r["recovery_rate"] for r in sub]),
            "mean_token_cost": mean([r["token_cost"] for r in sub]),
            "mean_latency_ms": mean([r["latency_ms"] for r in sub]),
        }
    return out


def shift_summary(rows: List[Dict]) -> Dict:
    out = {}
    for env in ENVIRONMENTS:
        out[env] = {}
        for system in SYSTEMS:
            sub = [r for r in rows if r["environment"] == env and r["system"] == system]
            out[env][system] = {
                "success_rate": mean([r["success"] for r in sub]),
                "mean_propagation": mean([r["max_propagation"] for r in sub]),
                "mean_recovery_rate": mean([r["recovery_rate"] for r in sub]),
                "mean_token_cost": mean([r["token_cost"] for r in sub]),
            }
    return out


def horizon_effect(rows: List[Dict], a: str, b: str, env: str = "clean") -> Dict[str, float]:
    out = {}
    for h in HORIZONS:
        aa = [r["success"] for r in rows if r["horizon"] == h and r["system"] == a and r["environment"] == env]
        bb = [r["success"] for r in rows if r["horizon"] == h and r["system"] == b and r["environment"] == env]
        out[str(h)] = mean(bb) - mean(aa)
    return out


def write_json(obj: object, path: Path) -> None:
    path.write_text(json.dumps(obj, ensure_ascii=False, indent=2), encoding="utf-8")


def main() -> None:
    tasks = make_tasks()
    write_tasks(tasks)

    observational = run_observational(tasks)
    rct = run_rct(tasks)
    shift = run_shift(tasks)

    write_episode_csv(observational, RESULT_DIR / "observational_episodes.csv")
    write_episode_csv(rct, RESULT_DIR / "rct_episodes.csv")
    write_episode_csv(shift, RESULT_DIR / "shift_episodes.csv")
    write_trace_jsonl([observational, rct, shift], RESULT_DIR / "all_traces.jsonl")

    obs = observational_analysis(observational)
    mechanism = mechanism_summary(rct)
    shifts = shift_summary(shift)
    rct_effect, rct_lo, rct_hi = bootstrap_paired_diff(rct, "baseline", "early_monitor", "clean")
    matched_effect, matched_lo, matched_hi = bootstrap_paired_diff(rct, "budget_matched", "early_monitor", "clean")
    horizon = horizon_effect(rct, "baseline", "early_monitor")

    # Association between detection delay and propagation among episodes with an internal fault.
    fault_rows = [r for r in rct if r["first_detection_delay"] is not None]
    pairs = [(float(r["first_detection_delay"]), float(r["max_propagation"])) for r in fault_rows]
    if pairs:
        mx = mean([x for x, _ in pairs]); my = mean([y for _, y in pairs])
        cov = sum((x-mx)*(y-my) for x,y in pairs)
        vx = sum((x-mx)**2 for x,_ in pairs); vy=sum((y-my)**2 for _,y in pairs)
        corr = cov / math.sqrt(vx*vy) if vx and vy else 0.0
    else:
        corr = 0.0

    summary = {
        "teaching_notice": "Controlled educational simulation. These values do not represent GPT, Claude, Gemini, or any real agent/model/product.",
        "counts": {
            "tasks": len(tasks),
            "observational_episodes": len(observational),
            "rct_episodes": len(rct),
            "shift_episodes": len(shift),
            "total_episodes": len(observational)+len(rct)+len(shift),
        },
        "observational": obs,
        "rct": {
            "baseline_vs_early_monitor_diff": rct_effect,
            "baseline_vs_early_monitor_95ci": [rct_lo, rct_hi],
            "budget_matched_vs_early_monitor_diff": matched_effect,
            "budget_matched_vs_early_monitor_95ci": [matched_lo, matched_hi],
            "effect_by_horizon": horizon,
        },
        "mechanism": mechanism,
        "detection_delay_propagation_correlation": corr,
        "external_validity": shifts,
        "discussion_claims": [
            {
                "claim_id": "C1",
                "claim": "In the randomized clean-environment teaching experiment, early monitoring improved task success relative to baseline.",
                "scope": "120 synthetic tasks, clean environment, controlled simulator only",
                "evidence": "paired task-level effect + cluster bootstrap CI",
                "causal_strength": "interventional within the simulator",
            },
            {
                "claim_id": "C2",
                "claim": "The improvement is consistent with earlier error detection and reduced propagation, but the trace association alone is not a complete causal mediation proof.",
                "scope": "internal-fault traces in the controlled simulator",
                "evidence": "detection delay, propagation depth, recovery rate",
                "causal_strength": "mechanistic support, not full mediation identification",
            },
            {
                "claim_id": "C3",
                "claim": "The benefit attenuates when failures move into an external tool layer that the monitor cannot directly observe.",
                "scope": "external_tool_shift condition in the controlled simulator",
                "evidence": "environment-stratified success differences",
                "causal_strength": "boundary-condition evidence within simulator",
            },
        ],
    }
    write_json(summary, RESULT_DIR / "summary.json")

    # Human-readable claim-evidence table.
    with (RESULT_DIR / "claim_evidence_matrix.csv").open("w", newline="", encoding="utf-8-sig") as f:
        w = csv.writer(f)
        w.writerow(["Claim_ID", "Claim", "Primary_Evidence", "Alternative_Explanation", "Scope_Limit", "Allowed_Language"])
        w.writerow(["C1", "Early monitor improves success in clean randomized simulator", "paired effect + bootstrap CI", "extra compute", "synthetic tasks; clean env", "improved / increased within this controlled setup"])
        w.writerow(["C2", "Earlier detection is a plausible mechanism", "delay↓; propagation↓; recovery↑", "monitor may change other behaviors", "no formal mediation identification", "consistent with / supports the mechanism"])
        w.writerow(["C3", "Benefit weakens under external tool shift", "stratified stress test", "stress model is synthetic", "one simulated shift family", "attenuated under this shift"])
        w.writerow(["C4", "Naive observational association is confounded", "naive vs horizon-standardized vs RCT", "other synthetic confounders", "teaching assignment mechanism", "naive association overstates/changes the estimate"])

    print(json.dumps(summary, ensure_ascii=False, indent=2))

if __name__ == "__main__":
    main()
