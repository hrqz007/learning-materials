# Agent Systems 零基础科研教程 · 第47讲

主题：Introduction、Related Work 与 Contribution——从真实问题到文献定位与可验证贡献。

## 建议学习顺序
1. 先读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 运行 `python src/run_lesson47.py`。
3. 对照 `results/retrieval_comparison.csv` 与 `results/literature_search_trace.jsonl` 理解检索表述如何改变“看见的文献空间”。
4. 查看 `results/candidate_novelty_audit.csv`，牢记：UNRESOLVED ≠ NOVEL。
5. 再读 `04_实验设计书.docx`，理解这个教学实验的效度边界。
6. 独立做练习，再看答案。

## 本讲真实运行
- 8 篇真实代表性论文卡片（内容为人工概括）
- 4 个教学查询
- 3 种离线检索策略
- 4 条候选 Contribution/Novelty 说法

## 关键声明
这是受控教学用的文献检索/定位实验；小型语料库不能证明真正的学术新颖性，也不代表完整领域现状。

## 最低闭环
`Observation → Concept decomposition → Synonym expansion → Anchor papers → Positioning Matrix → Precise Gap → RQ/Hypothesis → Contribution–Evidence Contract → Safe wording`
