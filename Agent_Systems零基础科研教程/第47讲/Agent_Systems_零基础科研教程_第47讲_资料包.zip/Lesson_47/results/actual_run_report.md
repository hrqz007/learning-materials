# 第47讲实际运行报告

- 语料库 paper cards: 8
- 教学查询: 4
- 检索方法: 3

## 平均结果（仅对本讲小型教学语料库有效）
- exact_lexical: precision=0.542, recall=0.750, mean retrieved=2.25
- synonym_expanded: precision=0.625, recall=0.750, mean retrieved=2.25
- structured_axis: precision=1.000, recall=1.000, mean retrieved=1.75

## 关键解释
- Exact lexical search 只能看到字面相同的术语，容易漏掉“不同术语、同一机制”的工作。
- Synonym expansion 和 structured-axis search 在这个教学语料库中用于演示“概念检索”的价值。
- 这些数字不是对真实 Scholar/Google/arXiv/OpenReview 搜索引擎质量的测评。
- `candidate_novelty_audit.csv` 只负责提示潜在重叠；任何 `UNRESOLVED` 都不能写成“我们是首个”。

> 这是受控教学用的文献检索/定位实验；小型语料库不能证明真正的学术新颖性，也不代表完整领域现状。