from __future__ import annotations
from pathlib import Path
import csv, json, re, hashlib
from collections import defaultdict

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT / 'data'
RES = ROOT / 'results'
RES.mkdir(exist_ok=True)

TEACHING_NOTICE = '这是受控教学用的文献检索/定位实验；小型语料库不能证明真正的学术新颖性，也不代表完整领域现状。'


def norm_tokens(text: str):
    return set(re.findall(r"[a-z0-9]+", text.lower()))


def load_csv(path):
    with open(path, encoding='utf-8-sig', newline='') as f:
        return list(csv.DictReader(f))


def split_terms(x):
    return [s.strip().lower() for s in x.split('|') if s.strip()]


def exact_score(query, paper):
    q = norm_tokens(query)
    text = ' '.join([paper['title'], paper['problem_axes'], paper['mechanism_axes'], paper['environment_axes'], paper['evaluation_axes']])
    t = norm_tokens(text)
    if not q:
        return 0.0
    return len(q & t) / len(q)


def expanded_query(query, synonym_map):
    tokens = norm_tokens(query)
    expanded = set(tokens)
    for key, vals in synonym_map.items():
        group = {key, *vals}
        if tokens & group:
            expanded |= group
    return expanded


def expanded_score(query, paper, synonym_map):
    q = expanded_query(query, synonym_map)
    fields = ' '.join([paper['title'], paper['problem_axes'], paper['mechanism_axes'], paper['environment_axes'], paper['evaluation_axes'], paper['notes']])
    t = norm_tokens(fields)
    if not q:
        return 0.0
    return len(q & t) / len(q)


def axis_score(query_spec, paper):
    score = 0.0
    reasons = []
    total = 0
    for axis in ['problem_axes','mechanism_axes','environment_axes','evaluation_axes']:
        wants = set(query_spec.get(axis, []))
        if not wants:
            continue
        total += 1
        has = set(split_terms(paper[axis]))
        overlap = wants & has
        if overlap:
            score += 1
            reasons.append(f"{axis}:{','.join(sorted(overlap))}")
    return (score / total if total else 0.0), reasons


def top_ids(scored, threshold=0.20):
    return [pid for pid, score, _ in scored if score >= threshold]


def metrics(retrieved, relevant):
    r, g = set(retrieved), set(relevant)
    tp = len(r & g)
    precision = tp / len(r) if r else 0.0
    recall = tp / len(g) if g else 0.0
    return precision, recall


def main():
    papers = load_csv(DATA / 'paper_cards.csv')
    queries = json.load(open(DATA / 'queries.json', encoding='utf-8'))
    synonyms = json.load(open(DATA / 'synonyms.json', encoding='utf-8'))
    candidate_claims = json.load(open(DATA / 'candidate_claims.json', encoding='utf-8'))
    pmap = {p['paper_id']: p for p in papers}

    traces = []
    comparison = []
    for q in queries:
        relevant = q['relevant_ids']
        methods = {}

        ex = []
        for p in papers:
            s = exact_score(q['query'], p)
            ex.append((p['paper_id'], s, ['literal_overlap']))
        ex.sort(key=lambda x: (-x[1], x[0]))
        methods['exact_lexical'] = ex

        xp = []
        for p in papers:
            s = expanded_score(q['query'], p, synonyms)
            xp.append((p['paper_id'], s, ['synonym_expansion']))
        xp.sort(key=lambda x: (-x[1], x[0]))
        methods['synonym_expanded'] = xp

        ax = []
        for p in papers:
            s, reasons = axis_score(q['axis_query'], p)
            ax.append((p['paper_id'], s, reasons))
        ax.sort(key=lambda x: (-x[1], x[0]))
        methods['structured_axis'] = ax

        for method, scored in methods.items():
            # Different methods have deliberately simple thresholds; this is a teaching retrieval system.
            thr = 0.34 if method == 'exact_lexical' else (0.18 if method == 'synonym_expanded' else 0.50)
            retrieved = top_ids(scored, thr)
            precision, recall = metrics(retrieved, relevant)
            comparison.append({
                'query_id': q['query_id'], 'query': q['query'], 'method': method,
                'retrieved_ids': '|'.join(retrieved), 'n_retrieved': len(retrieved),
                'precision': round(precision, 4), 'recall': round(recall, 4),
                'ground_truth_relevant_ids': '|'.join(relevant),
                'threshold': thr,
            })
            traces.append({
                'query_id': q['query_id'], 'method': method, 'query': q['query'],
                'expanded_terms': sorted(expanded_query(q['query'], synonyms)) if method == 'synonym_expanded' else None,
                'ranked': [
                    {'paper_id': pid, 'title': pmap[pid]['title'], 'score': round(score, 4), 'reasons': reasons}
                    for pid, score, reasons in scored
                ],
                'retrieved_ids': retrieved,
                'relevant_ids': relevant,
                'teaching_notice': TEACHING_NOTICE,
            })

    with open(RES / 'retrieval_comparison.csv', 'w', encoding='utf-8-sig', newline='') as f:
        w = csv.DictWriter(f, fieldnames=list(comparison[0].keys())); w.writeheader(); w.writerows(comparison)
    with open(RES / 'literature_search_trace.jsonl', 'w', encoding='utf-8') as f:
        for x in traces: f.write(json.dumps(x, ensure_ascii=False) + '\n')

    # Build positioning matrix: one row per paper, structured dimensions only.
    pos_fields = ['paper_id','title','year','venue_status','problem_axes','mechanism_axes','environment_axes','evaluation_axes','contribution_type','relation_hint','source_url']
    with open(RES / 'positioning_matrix.csv','w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=pos_fields); w.writeheader()
        for p in papers: w.writerow({k:p[k] for k in pos_fields})

    # Candidate novelty audit: overlap flags are warnings, not novelty judgments.
    audit=[]
    for c in candidate_claims:
        scores=[]
        spec=c['axis_query']
        for p in papers:
            s,reasons=axis_score(spec,p)
            scores.append((p['paper_id'],s,reasons))
        scores.sort(key=lambda x:(-x[1],x[0]))
        strong=[x for x in scores if x[1]>=0.50]
        if strong:
            status='OVERLAP_FLAG: do not claim novelty without narrower distinction and broader search'
        else:
            status='UNRESOLVED: no strong match in mini-corpus; broader up-to-date search is still mandatory'
        audit.append({
            'claim_id':c['claim_id'], 'candidate_claim':c['claim'], 'audit_status':status,
            'strong_overlap_ids':'|'.join(x[0] for x in strong),
            'top_matches':' | '.join(f"{pid}:{score:.2f}" for pid,score,_ in scores[:3]),
            'required_next_step':c['required_next_step'],
        })
    with open(RES/'candidate_novelty_audit.csv','w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(audit[0].keys()));w.writeheader();w.writerows(audit)

    # Contribution-evidence contract: reusable teaching artifact.
    contrib_rows=[
        {'contribution_type':'Phenomenon / empirical finding','safe_claim_template':'We identify/characterize X under Y conditions.','minimum_evidence':'Repeated controlled observations + uncertainty + boundary slices','common_overclaim':'We discover a universal law.'},
        {'contribution_type':'Mechanism / explanation','safe_claim_template':'Evidence supports mechanism M in the tested setup.','minimum_evidence':'Intervention/ablation + process metric + alternative-explanation checks','common_overclaim':'M is the only cause.'},
        {'contribution_type':'Method / system','safe_claim_template':'We propose M and evaluate it against strong/resource-matched baselines.','minimum_evidence':'Strong baselines + ablation + cost/reliability trade-off','common_overclaim':'M is generally superior.'},
        {'contribution_type':'Benchmark / evaluation','safe_claim_template':'We introduce an evaluation setting that measures X.','minimum_evidence':'Task validity + metric validity + reproducibility + baseline coverage','common_overclaim':'Leaderboard rank proves real-world superiority.'},
        {'contribution_type':'Artifact / infrastructure','safe_claim_template':'We release an artifact enabling reproducible study of X.','minimum_evidence':'Versioned code/config/data + smoke tests + documented scope','common_overclaim':'Artifact availability itself proves scientific novelty.'},
    ]
    with open(RES/'contribution_evidence_contract.csv','w',encoding='utf-8-sig',newline='') as f:
        w=csv.DictWriter(f,fieldnames=list(contrib_rows[0].keys()));w.writeheader();w.writerows(contrib_rows)

    # Summary aggregated by method.
    agg=defaultdict(list)
    for r in comparison: agg[r['method']].append(r)
    method_summary={}
    for m,rows in agg.items():
        method_summary[m]={
            'mean_precision':round(sum(float(r['precision']) for r in rows)/len(rows),4),
            'mean_recall':round(sum(float(r['recall']) for r in rows)/len(rows),4),
            'mean_n_retrieved':round(sum(int(r['n_retrieved']) for r in rows)/len(rows),2),
        }
    summary={
        'teaching_notice':TEACHING_NOTICE,
        'paper_count':len(papers),
        'query_count':len(queries),
        'method_summary':method_summary,
        'novelty_audit_status_counts':dict((s, sum(1 for a in audit if a['audit_status'].startswith(s))) for s in ['OVERLAP_FLAG','UNRESOLVED']),
        'critical_rule':'No match in this mini-corpus is NOT evidence of novelty. True novelty requires broad, current, concept-level literature search and evidence comparison.',
    }
    json.dump(summary,open(RES/'summary.json','w',encoding='utf-8'),ensure_ascii=False,indent=2)

    report = [
        '# 第47讲实际运行报告', '',
        f'- 语料库 paper cards: {len(papers)}',
        f'- 教学查询: {len(queries)}',
        f'- 检索方法: {len(method_summary)}', '',
        '## 平均结果（仅对本讲小型教学语料库有效）'
    ]
    for m,v in method_summary.items():
        report += [f"- {m}: precision={v['mean_precision']:.3f}, recall={v['mean_recall']:.3f}, mean retrieved={v['mean_n_retrieved']}"]
    report += ['', '## 关键解释',
        '- Exact lexical search 只能看到字面相同的术语，容易漏掉“不同术语、同一机制”的工作。',
        '- Synonym expansion 和 structured-axis search 在这个教学语料库中用于演示“概念检索”的价值。',
        '- 这些数字不是对真实 Scholar/Google/arXiv/OpenReview 搜索引擎质量的测评。',
        '- `candidate_novelty_audit.csv` 只负责提示潜在重叠；任何 `UNRESOLVED` 都不能写成“我们是首个”。', '',
        f'> {TEACHING_NOTICE}'
    ]
    (RES/'actual_run_report.md').write_text('\n'.join(report),encoding='utf-8')

    # Integrity print for rerun checking.
    h=hashlib.sha256()
    for p in [RES/'retrieval_comparison.csv',RES/'candidate_novelty_audit.csv',RES/'summary.json']:
        h.update(p.read_bytes())
    print(json.dumps({'status':'ok','paper_count':len(papers),'query_count':len(queries),'fingerprint':h.hexdigest()},ensure_ascii=False))

if __name__=='__main__':
    main()
