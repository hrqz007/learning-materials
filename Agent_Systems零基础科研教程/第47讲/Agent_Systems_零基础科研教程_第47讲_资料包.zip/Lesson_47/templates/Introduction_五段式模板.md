# Introduction 五段式模板

1. **Problem / Motivation**：具体系统问题是什么？为什么重要？
2. **Known Evidence**：最近邻工作已经建立了什么？
3. **Precise Gap**：缺的是哪个可验证轴，而不是笼统“仍有挑战”。
4. **RQ / Study**：本研究具体改变什么、控制什么、测量什么？
5. **Contributions**：每一条贡献对应哪一组 Figure/Table/Ablation/Trace evidence？

## 禁止自动写入的句子
- “Few studies have...” —— 除非检索有证据。
- “We are the first...” —— 除非最新、广泛、概念级检索支持。
- “Our method is robust/reliable...” —— 除非已定义并验证 robust/reliable。
