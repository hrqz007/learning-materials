# Novelty Audit Checklist

- [ ] 我是否把问题拆成 Problem / Mechanism / Environment / Evaluation / Resource 五个轴？
- [ ] 我是否准备了同义词和传统领域术语？
- [ ] 是否找到 3–5 篇 anchor papers？
- [ ] 是否做 backward + forward citation chaining？
- [ ] 是否读过 Methods / Ablation / Limitations / Supplementary？
- [ ] 是否检查 GitHub / issue / benchmark implementation？
- [ ] 是否明确最近邻工作的相同点与差异点？
- [ ] 是否在实验结束后再次更新文献定位？
- [ ] 是否在投稿前重新检索最新工作？
- [ ] 任何“first / novel / never”是否都有可审计依据？
