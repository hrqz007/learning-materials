# Agent Systems 零基础科研教程 · 第48讲

主题：**Pilot Experiment——5–20个任务的小实验，判断现象是否值得继续研究**

## 学习顺序
1. 先读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 按 `03_实验指导书.docx` 运行无 API 实验。
3. 打开 `results/pilot_go_no_go.json`，不要只看 success。
4. 从 `pilot_trace.jsonl` 至少手工读两条 Failure Trace。
5. 再做 `05_练习题.docx`，最后核对答案。

## 必做命令
```bash
cd Lesson_48/src
python pilot_experiment.py --tasks ../data/pilot_tasks.jsonl --out-dir ../results --repeats 5
python analyze_pilot.py --episode-csv ../results/pilot_episode_results.csv --out-dir ../results
```

## 实际运行状态
- 16 个独立 Tasks
- 3 个 Systems
- 5 repeats / Task-System
- 240 episodes
- 完整 JSONL Trace
- Go/No-Go decision：`GO_TO_MAIN_EXPERIMENT`

## 重要声明
**这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、Agent、Benchmark 或产品的实际性能。**
Pilot 的用途是决定是否进入正式实验，而不是形成发表级结论。

## 可选真实 API
`src/optional_real_api_pilot.py` 是选学模板。它使用 OpenAI Agents SDK 的 Agent + Runner 方式，不硬编码模型名。真实运行前显式设置 `OPENAI_API_KEY` 与 `OPENAI_MODEL`，并记录 SDK / 模型 / 日期 / Prompt / Trace 配置。真实运行会产生费用。

## 目录
- `src/`：完整源码
- `data/`：Pilot Task / Config
- `results/`：实际运行结果、CSV、JSON、JSONL
- `figures/`：原理图与结果图
- `templates/`：以后科研可复用的 Pilot 模板
