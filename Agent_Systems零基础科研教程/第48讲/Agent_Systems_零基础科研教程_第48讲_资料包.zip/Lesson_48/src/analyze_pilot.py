from __future__ import annotations
import csv, json, argparse, random, statistics, math
from pathlib import Path
from collections import defaultdict


def read_csv(path):
    with open(path, newline='', encoding='utf-8-sig') as f:
        return list(csv.DictReader(f))


def mean(xs):
    return sum(xs)/len(xs) if xs else float('nan')


def percentile(sorted_x, q):
    if not sorted_x: return float('nan')
    pos=(len(sorted_x)-1)*q
    lo=int(math.floor(pos)); hi=int(math.ceil(pos))
    if lo==hi: return sorted_x[lo]
    return sorted_x[lo]*(hi-pos)+sorted_x[hi]*(pos-lo)


def task_level(rows):
    by=defaultdict(list)
    for r in rows:
        by[(r['task_id'],r['system'])].append(r)
    out=[]
    for (task_id,system), rs in sorted(by.items()):
        out.append({
            'task_id':task_id,
            'system':system,
            'family':rs[0]['family'],
            'horizon':int(rs[0]['horizon']),
            'success_rate':mean([int(x['task_success']) for x in rs]),
            'mean_tokens':mean([int(x['tokens']) for x in rs]),
            'mean_latency_ms':mean([float(x['latency_ms']) for x in rs]),
            'mean_propagation_depth':mean([int(x['propagation_depth']) for x in rs]),
            'mean_recovery_count':mean([int(x['recovery_count']) for x in rs]),
            'runs':len(rs),
        })
    return out


def paired_task_diffs(task_rows, a='bounded_recovery', b='baseline'):
    by=defaultdict(dict)
    for r in task_rows:
        by[r['task_id']][r['system']]=r
    diffs=[]
    for tid, d in sorted(by.items()):
        if a in d and b in d:
            diffs.append((tid, d[a]['success_rate']-d[b]['success_rate'], d[a]['horizon']))
    return diffs


def bootstrap_ci(diffs, n_boot=10000, seed=4801):
    rng=random.Random(seed)
    vals=[d[1] for d in diffs]
    boots=[]
    for _ in range(n_boot):
        sample=[vals[rng.randrange(len(vals))] for _ in vals]
        boots.append(mean(sample))
    boots.sort()
    return percentile(boots,0.025), percentile(boots,0.975)


def main():
    ap=argparse.ArgumentParser()
    ap.add_argument('--episode-csv', default='../results/pilot_episode_results.csv')
    ap.add_argument('--out-dir', default='../results')
    args=ap.parse_args()
    out=Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)
    rows=read_csv(args.episode_csv)
    task_rows=task_level(rows)

    # Write task-level table
    with (out/'pilot_task_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        fields=list(task_rows[0].keys()); w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(task_rows)

    # System summary
    bysys=defaultdict(list)
    for r in task_rows: bysys[r['system']].append(r)
    sys_rows=[]
    for s, rs in sorted(bysys.items()):
        sys_rows.append({
            'system':s,
            'n_tasks':len(rs),
            'task_macro_success':mean([x['success_rate'] for x in rs]),
            'mean_tokens_per_task_run':mean([x['mean_tokens'] for x in rs]),
            'mean_latency_ms_per_task_run':mean([x['mean_latency_ms'] for x in rs]),
            'mean_propagation_depth':mean([x['mean_propagation_depth'] for x in rs]),
        })
    with (out/'pilot_system_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        fields=list(sys_rows[0].keys()); w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(sys_rows)

    # Horizon summary
    byh=defaultdict(list)
    for r in task_rows: byh[(r['horizon'],r['system'])].append(r)
    hrows=[]
    for (h,s), rs in sorted(byh.items()):
        hrows.append({
            'horizon':h,'system':s,'n_tasks':len(rs),
            'success_rate':mean([x['success_rate'] for x in rs]),
            'mean_propagation_depth':mean([x['mean_propagation_depth'] for x in rs]),
            'mean_tokens':mean([x['mean_tokens'] for x in rs]),
        })
    with (out/'pilot_horizon_summary.csv').open('w',newline='',encoding='utf-8-sig') as f:
        fields=list(hrows[0].keys()); w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(hrows)

    diffs=paired_task_diffs(task_rows)
    overall=mean([x[1] for x in diffs]); ci=bootstrap_ci(diffs)
    direction=sum(1 for _,d,_ in diffs if d>0)/len(diffs)
    long=[x for x in diffs if x[2]>=16]; short=[x for x in diffs if x[2]<=8]
    long_gap=mean([x[1] for x in long]); short_gap=mean([x[1] for x in short])

    # Mechanism comparison at task-level.
    bd={r['task_id']:r for r in task_rows if r['system']=='bounded_recovery'}
    bl={r['task_id']:r for r in task_rows if r['system']=='baseline'}
    prop_delta=mean([bd[t]['mean_propagation_depth']-bl[t]['mean_propagation_depth'] for t in sorted(bd)])

    # Pipeline sanity from raw rows.
    expected=len(set(r['task_id'] for r in rows))*len(set(r['system'] for r in rows))*len(set(r['repeat'] for r in rows))
    sanity = {
        'expected_episode_count': expected,
        'actual_episode_count': len(rows),
        'episode_count_match': expected==len(rows),
        'missing_task_success': sum(1 for r in rows if r['task_success']==''),
        'duplicate_episode_keys': len(rows)-len(set((r['task_id'],r['system'],r['repeat']) for r in rows)),
    }
    (out/'sanity_checks.json').write_text(json.dumps(sanity,ensure_ascii=False,indent=2),encoding='utf-8')

    criteria={
        'C1_pipeline_sanity': sanity['episode_count_match'] and sanity['missing_task_success']==0 and sanity['duplicate_episode_keys']==0,
        'C2_direction_consistency_ge_0_60': direction>=0.60,
        'C3_long_horizon_gap_ge_0_08': long_gap>=0.08,
        'C4_long_gap_exceeds_short_gap_by_0_04': (long_gap-short_gap)>=0.04,
        'C5_propagation_depth_reduced_by_ge_0_50': prop_delta<=-0.50,
    }
    go = all(criteria.values())
    decision={
        'decision':'GO_TO_MAIN_EXPERIMENT' if go else 'NO_GO_OR_REDESIGN',
        'interpretation':'Pilot 只支持是否值得进入正式实验，不支持发表级结论。' if go else '先修正测量、任务或机制，再扩大实验。',
        'n_independent_tasks':len(diffs),
        'paired_success_gap':overall,
        'task_cluster_bootstrap_95ci':[ci[0],ci[1]],
        'direction_consistency':direction,
        'short_horizon_gap':short_gap,
        'long_horizon_gap':long_gap,
        'long_minus_short_gap':long_gap-short_gap,
        'mean_propagation_depth_delta_brg_minus_baseline':prop_delta,
        'criteria':criteria,
        'warning':'这是受控教学模拟，不代表任何真实模型或 Agent 系统性能；Pilot 结果不能替代正式 confirmatory experiment。'
    }
    (out/'pilot_go_no_go.json').write_text(json.dumps(decision,ensure_ascii=False,indent=2),encoding='utf-8')

    # Simple budget projection in token units, no provider price assumption.
    total_tokens_by=defaultdict(int); total_runs_by=defaultdict(int)
    for r in rows:
        total_tokens_by[r['system']]+=int(r['tokens']); total_runs_by[r['system']]+=1
    budget_rows=[]
    for s in sorted(total_tokens_by):
        mean_t=total_tokens_by[s]/total_runs_by[s]
        budget_rows.append({
            'system':s,
            'pilot_runs':total_runs_by[s],
            'pilot_total_tokens_proxy':total_tokens_by[s],
            'mean_tokens_per_run_proxy':round(mean_t,2),
            'projected_tokens_100_tasks_x_10_repeats':round(mean_t*100*10),
            'usd_formula':'projected_tokens / 1e6 * YOUR_PRICE_PER_1M_TOKENS'
        })
    with (out/'budget_projection.csv').open('w',newline='',encoding='utf-8-sig') as f:
        fields=list(budget_rows[0].keys()); w=csv.DictWriter(f,fieldnames=fields); w.writeheader(); w.writerows(budget_rows)

    print(json.dumps(decision,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
