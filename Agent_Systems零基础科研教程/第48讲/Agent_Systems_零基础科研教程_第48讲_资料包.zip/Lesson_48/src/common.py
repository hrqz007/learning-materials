from __future__ import annotations
import json, random, math
from dataclasses import dataclass
from pathlib import Path

@dataclass(frozen=True)
class Task:
    task_id: str
    horizon: int
    difficulty: float
    fault_pressure: float
    family: str

SYSTEMS = {
    "baseline": {
        "label": "Baseline",
        "base_error": 0.045,
        "verify_strength": 0.00,
        "detect_prob": 0.00,
        "recovery_prob": 0.00,
        "extra_tokens_per_step": 0,
        "recovery_tokens": 0,
    },
    "token_matched": {
        "label": "Token-Matched Baseline",
        "base_error": 0.039,
        "verify_strength": 0.10,
        "detect_prob": 0.00,
        "recovery_prob": 0.00,
        "extra_tokens_per_step": 20,
        "recovery_tokens": 0,
    },
    "bounded_recovery": {
        "label": "Bounded Recovery",
        "base_error": 0.044,
        "verify_strength": 0.02,
        "detect_prob": 0.84,
        "recovery_prob": 0.80,
        "extra_tokens_per_step": 13,
        "recovery_tokens": 38,
    },
}


def stable_seed(*parts) -> int:
    text = "|".join(map(str, parts))
    # Avoid Python hash randomization.
    x = 2166136261
    for ch in text.encode('utf-8'):
        x ^= ch
        x = (x * 16777619) & 0xffffffff
    return x


def load_tasks(path: str|Path):
    tasks=[]
    with open(path, 'r', encoding='utf-8') as f:
        for line in f:
            if line.strip():
                tasks.append(Task(**json.loads(line)))
    return tasks


def simulate_episode(task: Task, system_name: str, repeat: int):
    cfg = SYSTEMS[system_name]
    rng = random.Random(stable_seed(task.task_id, system_name, repeat, "lesson48"))
    contaminated = False
    first_bad = None
    first_detect = None
    error_events = 0
    recoveries = 0
    redundant_actions = 0
    trace=[]
    tokens=70  # prompt/task framing proxy
    latency=35.0

    # The simulator intentionally makes persistence matter: a bad state can poison later steps.
    for step in range(1, task.horizon+1):
        # Error risk rises mildly with task difficulty and horizon position.
        position_factor = 1.0 + 0.55*(step/max(task.horizon,1))
        p_err = cfg['base_error'] * task.difficulty * task.fault_pressure * position_factor
        if contaminated:
            p_err += 0.10 + 0.006*min(step, 20)  # propagation feedback
        p_err *= (1.0 - cfg['verify_strength'])
        p_err = max(0.0, min(0.60, p_err))

        local_error = rng.random() < p_err
        if local_error:
            error_events += 1
            if first_bad is None:
                first_bad = step
            contaminated = True

        detected = False
        recovered = False
        if contaminated and cfg['detect_prob'] > 0:
            # Detection gets slightly harder if the error has persisted for many steps.
            age = step - (first_bad or step)
            p_detect = max(0.45, cfg['detect_prob'] - 0.02*min(age, 8))
            detected = rng.random() < p_detect
            if detected:
                if first_detect is None:
                    first_detect = step
                if rng.random() < cfg['recovery_prob']:
                    recovered = True
                    recoveries += 1
                    contaminated = False
                    tokens += cfg['recovery_tokens']
                    latency += 11.0
                else:
                    redundant_actions += 1

        # Step resource proxy: intentionally designed so token_matched is close to bounded recovery in budget.
        base_step_tokens = 47 + int(5*task.difficulty) + rng.randint(-3,3)
        tokens += base_step_tokens + cfg['extra_tokens_per_step']
        latency += 16 + 1.8*task.difficulty + rng.random()*4 + (6 if detected else 0)

        trace.append({
            'step': step,
            'local_error': local_error,
            'state_contaminated_after_step': contaminated,
            'detected': detected,
            'recovered': recovered,
            'tokens_cumulative': tokens,
            'latency_ms_cumulative': round(latency,2),
        })

    # If final state is contaminated, task fails. Clean runs can still have a small terminal formatting failure.
    terminal_format_failure = (not contaminated) and (rng.random() < 0.015*task.difficulty)
    success = (not contaminated) and (not terminal_format_failure)
    if terminal_format_failure and first_bad is None:
        first_bad = task.horizon
        error_events += 1

    if first_bad is None:
        propagation_depth = 0
        detection_delay = None
    else:
        # Propagation depth counts how many steps after first error remain affected at end, reduced by recovery.
        last_contaminated = None
        for item in trace:
            if item['state_contaminated_after_step']:
                last_contaminated = item['step']
        if last_contaminated is None:
            propagation_depth = 0
        else:
            propagation_depth = max(1, last_contaminated-first_bad+1)
        detection_delay = (first_detect-first_bad) if first_detect is not None else None

    return {
        'task_id': task.task_id,
        'family': task.family,
        'horizon': task.horizon,
        'difficulty': task.difficulty,
        'fault_pressure': task.fault_pressure,
        'system': system_name,
        'system_label': cfg['label'],
        'repeat': repeat,
        'task_success': int(success),
        'terminal_format_failure': int(terminal_format_failure),
        'error_events': error_events,
        'first_bad_step': first_bad,
        'first_detect_step': first_detect,
        'detection_delay': detection_delay,
        'propagation_depth': propagation_depth,
        'recovery_count': recoveries,
        'redundant_actions': redundant_actions,
        'tokens': tokens,
        'latency_ms': round(latency,2),
        'trace': trace,
    }
