"""Optional real-model pilot template using the current OpenAI Agents SDK.

This file is NOT required for Lesson 48. The offline controlled simulation is the required experiment.
It deliberately does not hard-code a model name. Set OPENAI_MODEL explicitly so the experiment records
exactly which model snapshot/alias you chose.

Install separately:
    pip install openai-agents
Environment:
    OPENAI_API_KEY=...
    OPENAI_MODEL=...

Important: real API runs cost money and are non-deterministic. Freeze model, prompt, task set, SDK version,
and date in your run manifest before collecting confirmatory evidence.
"""
from __future__ import annotations
import os, json, time
from pathlib import Path


def main():
    try:
        from agents import Agent, Runner, RunConfig
    except Exception as e:
        raise SystemExit("Missing optional dependency. Install with: pip install openai-agents") from e
    model=os.environ.get('OPENAI_MODEL')
    if not model:
        raise SystemExit('Set OPENAI_MODEL explicitly; this tutorial does not hard-code a model name.')
    if not os.environ.get('OPENAI_API_KEY'):
        raise SystemExit('Set OPENAI_API_KEY first.')

    agent=Agent(
        name='PilotAgent',
        model=model,
        instructions=(
            'You are participating in a research pilot. Solve the task carefully. '
            'Return a concise final answer. Do not claim access to tools that were not provided.'
        ),
    )
    tasks=[
        'Explain in two sentences why a pilot experiment should not be treated as confirmatory evidence.',
        'List three pieces of run metadata needed for an Agent Systems experiment.',
    ]
    out=[]
    for i,task in enumerate(tasks):
        t0=time.time()
        result=Runner.run_sync(
            agent,
            task,
            run_config=RunConfig(
                workflow_name='lesson48_optional_real_api_pilot',
                trace_metadata={'lesson':48,'task_id':f'api_{i:02d}','model':model},
            ),
        )
        out.append({'task_id':f'api_{i:02d}','model':model,'output':result.final_output,'wall_seconds':time.time()-t0})
    Path('../results/optional_real_api_results.json').write_text(json.dumps(out,ensure_ascii=False,indent=2),encoding='utf-8')
    print(json.dumps(out,ensure_ascii=False,indent=2))

if __name__=='__main__':
    main()
