from __future__ import annotations
import csv, json, argparse
from pathlib import Path
from common import load_tasks, simulate_episode, SYSTEMS


def main():
    ap=argparse.ArgumentParser(description='Lesson 48 controlled pilot experiment (no API key required).')
    ap.add_argument('--tasks', default='../data/pilot_tasks.jsonl')
    ap.add_argument('--out-dir', default='../results')
    ap.add_argument('--repeats', type=int, default=5)
    args=ap.parse_args()
    tasks=load_tasks(args.tasks)
    out=Path(args.out_dir); out.mkdir(parents=True, exist_ok=True)

    episode_rows=[]
    trace_path=out/'pilot_trace.jsonl'
    with trace_path.open('w', encoding='utf-8') as tf:
        for task in tasks:
            for system_name in SYSTEMS:
                for repeat in range(args.repeats):
                    ep=simulate_episode(task, system_name, repeat)
                    trace_record={k:v for k,v in ep.items() if k!='trace'}
                    trace_record['spans']=ep['trace']
                    tf.write(json.dumps(trace_record, ensure_ascii=False)+'\n')
                    episode_rows.append({k:v for k,v in ep.items() if k!='trace'})

    fields=list(episode_rows[0].keys())
    with (out/'pilot_episode_results.csv').open('w', newline='', encoding='utf-8-sig') as f:
        w=csv.DictWriter(f, fieldnames=fields); w.writeheader(); w.writerows(episode_rows)

    metadata={
        'lesson': 48,
        'simulation_notice': '这是受控教学模拟，不代表 GPT / Claude / Gemini 或任何真实模型、Agent、Benchmark 或产品的实际性能。',
        'tasks': len(tasks),
        'systems': list(SYSTEMS.keys()),
        'repeats_per_task_system': args.repeats,
        'episodes': len(episode_rows),
        'experimental_unit_for_inference': 'task',
    }
    (out/'run_metadata.json').write_text(json.dumps(metadata, ensure_ascii=False, indent=2), encoding='utf-8')
    print(json.dumps(metadata, ensure_ascii=False, indent=2))

if __name__=='__main__':
    main()
