# Pilot Go / No-Go Checklist

- [ ] RQ 写清楚
- [ ] Go/No-Go 条件在看结果前写好
- [ ] 5–20 个独立任务覆盖关键 slice
- [ ] 每个任务有少量 repeats
- [ ] 至少一个强 baseline；必要时 resource-matched
- [ ] Primary / mechanism / resource metrics 都记录
- [ ] JSONL Trace 可回到 First Bad Span
- [ ] Evaluator sanity check 通过
- [ ] Missing / timeout / retry 有规则
- [ ] 预算外推完成
- [ ] GO / REDESIGN / NO-GO 有明确理由
- [ ] 若 GO，正式实验重新冻结协议
