# Pilot Protocol Template

## Observation

## Pilot Research Question

## Fact / Inference / Exploratory Hypothesis

## Independent Tasks (5–20)

## Systems / Baselines

## Primary Metric

## Mechanism Metrics

## Resource Metrics

## Repeats / Seeds

## Go / No-Go Gate (freeze before data)

## Trace Schema

## Budget Projection

## Decision
- GO / REDESIGN / NO-GO

## What must be frozen for Main Experiment
