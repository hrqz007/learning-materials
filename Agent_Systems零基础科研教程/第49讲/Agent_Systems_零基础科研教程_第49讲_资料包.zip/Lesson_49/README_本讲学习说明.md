# Agent Systems 零基础科研教程 · 第49讲

## 主题
正式实验（Main / Confirmatory Experiment）：把通过 Pilot 的现象升级为可用于论文的证据闭环。

## 重要声明
`results/` 中所有数字来自**受控教学模拟**，不代表 GPT / Claude / Gemini 或任何真实 Agent、模型、Benchmark、框架或产品的实际性能。

## 最快学习路径
1. 阅读 `02_零基础讲义.pdf`。
2. 查看 `data/preregistration.json`，理解什么叫“主实验前冻结”。
3. 进入 `src/`：
   - `python run_formal_experiment.py`
   - `python analyze_results.py`
4. 查看 `results/confirmatory_statistics.json` 与 `results/protocol_audit.json`。
5. 用 `results/task_level.csv` 和 `results/traces.jsonl` 追踪 Claim。
6. 完成 `05_练习题.docx` 后再看答案。

## 本包实际运行规模
- 120 held-out tasks
- 4 systems
- 3 environments
- 6 repeats
- 8640 episodes

Primary teaching result: 12.78 pp, 95% CI [7.78, 17.78] pp, SESOI=5pp。

## 不需要
- GPU
- API Key
- 本地大模型
- 额外 Python 第三方依赖（实验源码本身仅用标准库）

## 可选真实系统版本
`src/optional_real_api_template.py` 只提供稳定 schema，不绑定任何可能过时的具体 API。未来接入真实 Agent runtime 时，应保持 protocol 和 output schema 不变，并另外记录 model snapshot / API date / harness commit。
