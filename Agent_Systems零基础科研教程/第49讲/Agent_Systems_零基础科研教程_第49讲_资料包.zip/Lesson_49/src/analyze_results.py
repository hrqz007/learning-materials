from __future__ import annotations

import csv
import json
import random
from collections import defaultdict
from pathlib import Path
from typing import Dict, List, Tuple

from common import mean, percentile, stable_seed

PRIMARY_ENV = "internal_fault"
PRIMARY_TREAT = "BRG_Full"
PRIMARY_CONTROL = "TokenMatched"
SESOI_PP = 5.0


def read_csv(path: Path) -> List[Dict[str, str]]:
    with path.open("r", encoding="utf-8-sig", newline="") as f:
        return list(csv.DictReader(f))


def task_level(rows: List[Dict[str, str]]) -> List[Dict[str, object]]:
    groups = defaultdict(list)
    for r in rows:
        groups[(r["task_id"], r["system"], r["environment"])].append(r)
    out = []
    for (task_id, system, env), rs in sorted(groups.items()):
        fault_rs = [r for r in rs if int(r["fault_opportunity"]) == 1]
        detected_rs = [r for r in fault_rs if int(r["detected"]) == 1]
        out.append({
            "task_id": task_id,
            "system": system,
            "environment": env,
            "horizon": int(rs[0]["horizon"]),
            "category": rs[0]["category"],
            "success_rate": mean(float(r["success"]) for r in rs),
            "mean_tokens": mean(float(r["tokens"]) for r in rs),
            "mean_latency_ms": mean(float(r["latency_ms"]) for r in rs),
            "mean_detection_delay": mean(float(r["detection_delay"]) for r in detected_rs) if detected_rs else 0.0,
            "mean_propagation_depth": mean(float(r["propagation_depth"]) for r in fault_rs) if fault_rs else 0.0,
            "recovery_rate": mean(float(r["recovered"]) for r in detected_rs) if detected_rs else 0.0,
            "n_repeats": len(rs),
        })
    return out


def paired_diffs(tl: List[Dict[str, object]], env: str, treat: str, control: str) -> List[Tuple[str, float]]:
    table = defaultdict(dict)
    for r in tl:
        if r["environment"] == env:
            table[r["task_id"]][r["system"]] = float(r["success_rate"])
    diffs = []
    for task_id, m in sorted(table.items()):
        if treat in m and control in m:
            diffs.append((task_id, m[treat] - m[control]))
    return diffs


def cluster_bootstrap_ci(diffs: List[Tuple[str, float]], n_boot: int = 5000) -> Tuple[float, float, float]:
    vals = [d for _, d in diffs]
    rng = random.Random(stable_seed("lesson49", "bootstrap"))
    boots = []
    n = len(vals)
    for _ in range(n_boot):
        sample = [vals[rng.randrange(n)] for __ in range(n)]
        boots.append(mean(sample))
    return mean(vals), percentile(boots, 0.025), percentile(boots, 0.975)


def paired_permutation_p(diffs: List[Tuple[str, float]], n_perm: int = 12000) -> float:
    vals = [d for _, d in diffs]
    observed = abs(mean(vals))
    rng = random.Random(stable_seed("lesson49", "perm"))
    ge = 0
    for _ in range(n_perm):
        m = mean(v if rng.random() < 0.5 else -v for v in vals)
        if abs(m) >= observed - 1e-12:
            ge += 1
    return (ge + 1) / (n_perm + 1)


def summarize(rows: List[Dict[str, str]]) -> List[Dict[str, object]]:
    groups = defaultdict(list)
    for r in rows:
        groups[(r["system"], r["environment"])].append(r)
    result = []
    for (system, env), rs in sorted(groups.items()):
        lat = [float(r["latency_ms"]) for r in rs]
        fault = [r for r in rs if int(r["fault_opportunity"]) == 1]
        detected = [r for r in fault if int(r["detected"]) == 1]
        result.append({
            "system": system,
            "environment": env,
            "episodes": len(rs),
            "success_rate": mean(float(r["success"]) for r in rs),
            "mean_tokens": mean(float(r["tokens"]) for r in rs),
            "mean_latency_ms": mean(lat),
            "p95_latency_ms": percentile(lat, 0.95),
            "p99_latency_ms": percentile(lat, 0.99),
            "detection_rate": mean(float(r["detected"]) for r in fault) if fault else 0.0,
            "recovery_rate": mean(float(r["recovered"]) for r in detected) if detected else 0.0,
            "mean_detection_delay": mean(float(r["detection_delay"]) for r in detected) if detected else 0.0,
            "mean_propagation_depth": mean(float(r["propagation_depth"]) for r in fault) if fault else 0.0,
        })
    return result


def horizon_effects(tl: List[Dict[str, object]], env: str = PRIMARY_ENV) -> List[Dict[str, object]]:
    out = []
    for h in [4, 8, 16, 32]:
        sub = [r for r in tl if r["environment"] == env and r["horizon"] == h]
        by_task = defaultdict(dict)
        for r in sub:
            by_task[r["task_id"]][r["system"]] = float(r["success_rate"])
        diffs = []
        for task_id, m in by_task.items():
            if PRIMARY_TREAT in m and PRIMARY_CONTROL in m:
                diffs.append((task_id, m[PRIMARY_TREAT] - m[PRIMARY_CONTROL]))
        est, lo, hi = cluster_bootstrap_ci(diffs, 3000)
        out.append({"horizon": h, "n_tasks": len(diffs), "effect_pp": est * 100, "ci_low_pp": lo * 100, "ci_high_pp": hi * 100})
    return out


def write_csv(path: Path, rows: List[Dict[str, object]]) -> None:
    if not rows:
        return
    with path.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(rows[0].keys()))
        writer.writeheader()
        writer.writerows(rows)


def main() -> None:
    root = Path(__file__).resolve().parents[1]
    results = root / "results"
    rows = read_csv(results / "episodes.csv")
    tl = task_level(rows)
    write_csv(results / "task_level.csv", tl)

    sys_summary = summarize(rows)
    write_csv(results / "system_environment_summary.csv", sys_summary)

    diffs = paired_diffs(tl, PRIMARY_ENV, PRIMARY_TREAT, PRIMARY_CONTROL)
    est, lo, hi = cluster_bootstrap_ci(diffs)
    p = paired_permutation_p(diffs)
    primary = {
        "primary_environment": PRIMARY_ENV,
        "treatment": PRIMARY_TREAT,
        "control": PRIMARY_CONTROL,
        "n_independent_tasks": len(diffs),
        "effect_pp": round(est * 100, 4),
        "ci95_low_pp": round(lo * 100, 4),
        "ci95_high_pp": round(hi * 100, 4),
        "paired_permutation_p": round(p, 6),
        "predeclared_sesoi_pp": SESOI_PP,
        "criterion_effect_ge_sesoi": est * 100 >= SESOI_PP,
        "criterion_ci_excludes_zero": lo > 0,
        "confirmatory_conclusion": "SUPPORTED" if (est * 100 >= SESOI_PP and lo > 0) else "NOT_SUPPORTED",
        "interpretation_scope": "Controlled teaching simulation only; no real-model claim.",
    }
    (results / "confirmatory_statistics.json").write_text(json.dumps(primary, ensure_ascii=False, indent=2), encoding="utf-8")

    hfx = horizon_effects(tl)
    write_csv(results / "horizon_effects.csv", hfx)

    # Predeclared protocol audit: did the run match the frozen design?
    manifest = json.loads((results / "run_manifest.json").read_text(encoding="utf-8"))
    prereg = json.loads((root / "data" / "preregistration.json").read_text(encoding="utf-8"))
    checks = {
        "n_tasks_match": manifest["n_tasks"] == prereg["design"]["n_tasks"],
        "systems_match": manifest["systems"] == prereg["design"]["systems"],
        "environments_match": manifest["environments"] == prereg["design"]["environments"],
        "repeats_match": manifest["repeats"] == prereg["design"]["repeats"],
        "held_out_split": manifest["task_split"] == "held_out_confirmatory",
        "pilot_tasks_not_reused": manifest["pilot_tasks_reused"] is False,
        "primary_endpoint_predeclared": prereg["primary_endpoint"]["name"] == "task_level_success_difference_pp",
        "sesoi_predeclared": prereg["primary_endpoint"]["sesoi_pp"] == SESOI_PP,
    }
    audit = {"all_pass": all(checks.values()), "checks": checks}
    (results / "protocol_audit.json").write_text(json.dumps(audit, ensure_ascii=False, indent=2), encoding="utf-8")

    # Evidence lock: explicit mapping from claims to frozen evidence artifacts.
    evidence = [
        {
            "claim_id": "C1_PRIMARY",
            "claim": "On held-out tasks under internal faults, BRG_Full improves task-level success over TokenMatched by at least the predeclared SESOI and the 95% task-cluster bootstrap CI excludes zero.",
            "scope": "controlled teaching simulator, internal_fault condition",
            "artifacts": ["results/task_level.csv", "results/confirmatory_statistics.json", "results/traces.jsonl"],
            "status": primary["confirmatory_conclusion"],
        },
        {
            "claim_id": "C2_BOUNDARY",
            "claim": "The magnitude of the benefit varies by environment and horizon; this is treated as secondary/generalization evidence, not a replacement for the primary endpoint.",
            "scope": "controlled teaching simulator",
            "artifacts": ["results/system_environment_summary.csv", "results/horizon_effects.csv"],
            "status": "SECONDARY",
        },
    ]
    write_csv(results / "claim_evidence_registry.csv", evidence)

    print(json.dumps(primary, ensure_ascii=False, indent=2))
    print(json.dumps(audit, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
