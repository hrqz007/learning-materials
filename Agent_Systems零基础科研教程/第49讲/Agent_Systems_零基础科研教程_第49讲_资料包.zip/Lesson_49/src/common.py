from __future__ import annotations

import hashlib
import math
from dataclasses import dataclass
from typing import Iterable, List, Dict, Tuple


def stable_seed(*parts: object) -> int:
    """Create a deterministic 32-bit seed from arbitrary values."""
    raw = "||".join(str(p) for p in parts).encode("utf-8")
    digest = hashlib.sha256(raw).hexdigest()
    return int(digest[:8], 16)


def sigmoid(x: float) -> float:
    return 1.0 / (1.0 + math.exp(-x))


@dataclass(frozen=True)
class Task:
    task_id: str
    horizon: int
    difficulty: float
    category: str


def make_tasks(n: int = 120) -> List[Task]:
    """Create a deterministic held-out confirmatory task set.

    This is a controlled teaching simulation. Tasks are synthetic and are not
    benchmark items from any real Agent benchmark.
    """
    import random

    rng = random.Random(20260929)
    horizons = [4, 8, 16, 32]
    categories = ["tool_chain", "planning", "memory", "verification"]
    tasks: List[Task] = []
    for i in range(n):
        horizon = horizons[i % len(horizons)]
        category = categories[(i // len(horizons)) % len(categories)]
        # Balanced but not identical difficulty. Kept in [0.08, 0.92].
        difficulty = min(0.92, max(0.08, rng.betavariate(2.3, 2.3)))
        tasks.append(Task(f"confirm_{i+1:03d}", horizon, difficulty, category))
    return tasks


def task_to_dict(t: Task) -> Dict[str, object]:
    return {
        "task_id": t.task_id,
        "horizon": t.horizon,
        "difficulty": round(t.difficulty, 6),
        "category": t.category,
        "split": "held_out_confirmatory",
    }


def mean(xs: Iterable[float]) -> float:
    xs = list(xs)
    return sum(xs) / len(xs) if xs else float("nan")


def percentile(xs: List[float], q: float) -> float:
    if not xs:
        return float("nan")
    ys = sorted(xs)
    if len(ys) == 1:
        return ys[0]
    pos = (len(ys) - 1) * q
    lo = int(math.floor(pos))
    hi = int(math.ceil(pos))
    if lo == hi:
        return ys[lo]
    w = pos - lo
    return ys[lo] * (1 - w) + ys[hi] * w
