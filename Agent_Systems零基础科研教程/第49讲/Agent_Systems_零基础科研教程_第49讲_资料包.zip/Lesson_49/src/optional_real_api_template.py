"""Optional real-system adapter template.

No provider-specific API is hard-coded here. The research protocol should stay
stable while the model client is swapped behind this interface.

To use it later, implement `call_agent_system(task, config)` with the provider
or local runtime you have selected, and keep the same output schema.
"""
from __future__ import annotations
from typing import Dict, Any

REQUIRED_OUTPUT_FIELDS = [
    "task_id", "system", "environment", "repeat", "success",
    "tokens", "latency_ms", "trace"
]


def call_agent_system(task: Dict[str, Any], config: Dict[str, Any]) -> Dict[str, Any]:
    raise NotImplementedError("Connect a real Agent runtime here; do not change the analysis schema.")


def validate_output(record: Dict[str, Any]) -> None:
    missing = [k for k in REQUIRED_OUTPUT_FIELDS if k not in record]
    if missing:
        raise ValueError(f"Missing fields: {missing}")
