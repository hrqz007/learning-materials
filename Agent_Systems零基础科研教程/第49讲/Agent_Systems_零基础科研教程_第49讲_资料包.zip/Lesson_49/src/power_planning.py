"""Simple simulation-based planning aid for teaching.

This is not a universal sample-size calculator. It shows why formal experiments
should plan around an effect smaller than the optimistic Pilot estimate.
"""
from __future__ import annotations
import random
from statistics import mean


def estimate_power(n_tasks: int, true_effect_pp: float = 8.0, task_sd_pp: float = 24.0, trials: int = 4000) -> float:
    rng = random.Random(490049 + n_tasks)
    successes = 0
    for _ in range(trials):
        diffs = [rng.gauss(true_effect_pp, task_sd_pp) for __ in range(n_tasks)]
        # Approximate normal CI for planning only.
        m = mean(diffs)
        variance = sum((x - m) ** 2 for x in diffs) / max(1, n_tasks - 1)
        se = (variance / n_tasks) ** 0.5
        lo = m - 1.96 * se
        if lo > 0:
            successes += 1
    return successes / trials


if __name__ == "__main__":
    for n in [40, 60, 80, 100, 120, 160]:
        print(n, f"{estimate_power(n):.3f}")
