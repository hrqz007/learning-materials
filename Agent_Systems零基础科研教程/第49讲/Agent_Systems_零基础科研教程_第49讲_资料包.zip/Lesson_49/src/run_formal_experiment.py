from __future__ import annotations

import argparse
import csv
import json
import math
import random
from pathlib import Path
from typing import Dict, List

from common import make_tasks, sigmoid, stable_seed, task_to_dict

SYSTEMS = ["Baseline", "TokenMatched", "BRG_NoReset", "BRG_Full"]
ENVIRONMENTS = ["clean", "internal_fault", "external_tool_shift"]
REPEATS = 6

# Controlled teaching simulator parameters. They do not describe any real model.
SYSTEM_EFFECTS = {
    "Baseline": {"clean": 0.00, "internal_fault": 0.00, "external_tool_shift": 0.00},
    "TokenMatched": {"clean": 0.03, "internal_fault": 0.05, "external_tool_shift": 0.03},
    "BRG_NoReset": {"clean": 0.08, "internal_fault": 0.44, "external_tool_shift": 0.12},
    "BRG_Full": {"clean": 0.10, "internal_fault": 0.69, "external_tool_shift": 0.18},
}


def base_logit(horizon: int, difficulty: float, env: str) -> float:
    env_penalty = {"clean": 0.00, "internal_fault": -0.42, "external_tool_shift": -0.28}[env]
    # Longer tasks and harder tasks are more difficult.
    return 2.25 - 0.055 * horizon - 1.85 * difficulty + env_penalty


def system_tokens(system: str, horizon: int, jitter: float) -> int:
    base = 980 + 34 * horizon
    overhead = {
        "Baseline": 0,
        "TokenMatched": 360 + 5 * horizon,
        "BRG_NoReset": 330 + 5 * horizon,
        "BRG_Full": 365 + 5 * horizon,
    }[system]
    return max(50, int(base + overhead + jitter))


def simulate_episode(task, system: str, env: str, repeat: int) -> Dict[str, object]:
    seed = stable_seed(task.task_id, system, env, repeat, "lesson49")
    rng = random.Random(seed)

    p = sigmoid(base_logit(task.horizon, task.difficulty, env) + SYSTEM_EFFECTS[system][env])
    success = int(rng.random() < p)

    # A fault opportunity becomes more likely as horizon grows.
    fault_opportunity = rng.random() < min(0.88, 0.12 + 0.022 * task.horizon)
    if env == "internal_fault":
        fault_opportunity = True if rng.random() < 0.80 else fault_opportunity
    elif env == "external_tool_shift":
        fault_opportunity = True if rng.random() < 0.68 else fault_opportunity

    # Synthetic process-level metrics.
    if not fault_opportunity:
        detected = 0
        detection_delay = 0.0
        propagation = 0.0
        recovered = 0
        first_bad_span = None
    else:
        detect_prob = {
            "Baseline": 0.16,
            "TokenMatched": 0.18,
            "BRG_NoReset": 0.78 if env != "external_tool_shift" else 0.48,
            "BRG_Full": 0.88 if env != "external_tool_shift" else 0.56,
        }[system]
        detected = int(rng.random() < detect_prob)
        if detected:
            delay_base = {"Baseline": 3.2, "TokenMatched": 3.0, "BRG_NoReset": 1.05, "BRG_Full": 0.58}[system]
            if env == "external_tool_shift":
                delay_base += 0.8
            detection_delay = max(0.05, rng.gauss(delay_base, 0.55))
        else:
            detection_delay = min(float(task.horizon), 4.5 + 0.18 * task.horizon + rng.random() * 2.0)

        reset_bonus = 1.0 if system == "BRG_Full" else 0.0
        propagation = max(
            0.1,
            0.45 * detection_delay
            + 0.11 * task.horizon
            + (0.9 if not detected else 0.0)
            - 0.85 * reset_bonus
            + rng.gauss(0.0, 0.45),
        )
        recovery_prob = {
            "Baseline": 0.25,
            "TokenMatched": 0.28,
            "BRG_NoReset": 0.61,
            "BRG_Full": 0.80,
        }[system]
        if env == "external_tool_shift":
            recovery_prob -= 0.20
        recovered = int(detected and rng.random() < max(0.02, recovery_prob))
        first_bad_span = int(max(1, min(task.horizon, round(rng.uniform(1, max(1, task.horizon - 1))))))

    token_jitter = rng.gauss(0, 55)
    tokens = system_tokens(system, task.horizon, token_jitter)
    latency_ms = max(50, int(510 + 21 * task.horizon + 0.30 * tokens + rng.gauss(0, 95)))
    if system.startswith("BRG"):
        latency_ms += int(80 + 25 * detected)

    # Generate a compact trace with a few representative spans rather than one span per token/action.
    spans: List[Dict[str, object]] = []
    span_count = min(10, max(4, task.horizon // 3 + 3))
    for s in range(1, span_count + 1):
        event = "reasoning"
        status = "ok"
        if fault_opportunity and first_bad_span is not None and s == max(1, min(span_count, int(first_bad_span / max(1, task.horizon) * span_count))):
            event = "fault_observed"
            status = "bad"
        elif detected and s == min(span_count, max(2, span_count // 2)):
            event = "detector_alert"
            status = "warning"
        elif recovered and s == min(span_count, max(3, span_count // 2 + 1)):
            event = "recovery"
            status = "recovered"
        elif s == span_count:
            event = "finalize"
            status = "success" if success else "failure"
        spans.append({
            "span_id": s,
            "event": event,
            "status": status,
            "synthetic": True,
        })

    return {
        "task_id": task.task_id,
        "category": task.category,
        "horizon": task.horizon,
        "difficulty": round(task.difficulty, 6),
        "split": "held_out_confirmatory",
        "system": system,
        "environment": env,
        "repeat": repeat,
        "seed": seed,
        "success": success,
        "fault_opportunity": int(fault_opportunity),
        "detected": detected,
        "recovered": recovered,
        "detection_delay": round(detection_delay, 4),
        "propagation_depth": round(propagation, 4),
        "first_bad_span": first_bad_span,
        "tokens": tokens,
        "latency_ms": latency_ms,
        "trace": spans,
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument("--out_dir", default="../results")
    parser.add_argument("--task_file", default="../data/tasks.csv")
    args = parser.parse_args()

    here = Path(__file__).resolve().parent
    out_dir = (here / args.out_dir).resolve()
    task_file = (here / args.task_file).resolve()
    out_dir.mkdir(parents=True, exist_ok=True)
    task_file.parent.mkdir(parents=True, exist_ok=True)

    tasks = make_tasks(120)
    with task_file.open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=list(task_to_dict(tasks[0]).keys()))
        writer.writeheader()
        for t in tasks:
            writer.writerow(task_to_dict(t))

    episodes: List[Dict[str, object]] = []
    trace_path = out_dir / "traces.jsonl"
    with trace_path.open("w", encoding="utf-8") as tf:
        for task in tasks:
            for env in ENVIRONMENTS:
                for system in SYSTEMS:
                    for repeat in range(1, REPEATS + 1):
                        ep = simulate_episode(task, system, env, repeat)
                        trace = ep.pop("trace")
                        episodes.append(ep)
                        tf.write(json.dumps({**ep, "trace": trace}, ensure_ascii=False) + "\n")

    fields = list(episodes[0].keys())
    with (out_dir / "episodes.csv").open("w", newline="", encoding="utf-8-sig") as f:
        writer = csv.DictWriter(f, fieldnames=fields)
        writer.writeheader()
        writer.writerows(episodes)

    manifest = {
        "lesson": 49,
        "simulation_notice": "Controlled teaching simulation; not real model or benchmark performance.",
        "n_tasks": len(tasks),
        "systems": SYSTEMS,
        "environments": ENVIRONMENTS,
        "repeats": REPEATS,
        "episodes": len(episodes),
        "task_split": "held_out_confirmatory",
        "pilot_tasks_reused": False,
    }
    (out_dir / "run_manifest.json").write_text(json.dumps(manifest, ensure_ascii=False, indent=2), encoding="utf-8")
    print(json.dumps(manifest, ensure_ascii=False, indent=2))


if __name__ == "__main__":
    main()
