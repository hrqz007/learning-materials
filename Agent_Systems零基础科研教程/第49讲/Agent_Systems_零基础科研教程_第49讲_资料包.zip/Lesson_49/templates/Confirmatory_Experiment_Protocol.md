# Confirmatory Experiment Protocol Template

## 1. Observation / Pilot evidence
- What was observed?
- What remains uncertain?
- Which Pilot results are *not* reused as confirmatory evidence?

## 2. Research Question
Write one falsifiable question.

## 3. Primary Hypothesis
State direction, comparator, condition, primary endpoint, and minimum meaningful effect (SESOI).

## 4. Primary Endpoint
- Experimental unit:
- Aggregation level:
- Primary metric:
- Effect size:
- 95% CI method:
- Supporting test:

## 5. Frozen Design
- Held-out tasks:
- Systems:
- Environments:
- Repeats:
- Pairing/randomization:
- Model/API version:
- Harness version:
- Tool/environment snapshot:

## 6. Baselines
- Simple baseline:
- Strong baseline:
- Token/compute/cost-matched baseline:

## 7. Secondary Analyses
List them before the run. Mark later additions as exploratory.

## 8. Missingness / timeout policy
Specify before seeing results.

## 9. Stopping Rule
Do not stop when the result becomes attractive.

## 10. Evidence Lock
Map every planned claim to exact CSV/JSON/Trace artifacts.
