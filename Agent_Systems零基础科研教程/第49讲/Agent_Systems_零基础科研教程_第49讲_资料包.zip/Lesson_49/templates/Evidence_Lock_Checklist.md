# Evidence Lock Checklist

For every paper claim, record:
1. Claim ID
2. Exact wording
3. Scope / population / environment
4. Primary or secondary status
5. Source table/figure
6. Underlying CSV/JSON
7. Relevant Trace selection rule
8. Statistical unit
9. CI / uncertainty
10. Known limitation

If a claim cannot be traced back to frozen artifacts, do not write it as a confirmed result.
