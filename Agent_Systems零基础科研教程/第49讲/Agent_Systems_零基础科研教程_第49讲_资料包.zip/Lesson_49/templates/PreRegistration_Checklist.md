# Pre-registration checklist

- [ ] RQ fixed before main run
- [ ] Primary hypothesis fixed
- [ ] Experimental unit identified
- [ ] Primary endpoint fixed
- [ ] SESOI fixed
- [ ] Held-out task set created
- [ ] Pilot tasks excluded from confirmatory set
- [ ] Strong/resource-matched baseline fixed
- [ ] Model/Harness/Tool/Environment versions recorded
- [ ] Repeats and stopping rule fixed
- [ ] Missing/timeout handling fixed
- [ ] Statistical analysis fixed
- [ ] Secondary vs exploratory analyses separated
- [ ] Claim-Evidence registry template prepared
