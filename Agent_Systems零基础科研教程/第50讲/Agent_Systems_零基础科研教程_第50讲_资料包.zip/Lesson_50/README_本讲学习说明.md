# Agent Systems 零基础科研教程 · 第50讲

## 主题

**把 Agent Systems 项目整理成“可投稿论文工程”——Repository、Config、Artifact、Reproducibility Checklist 与自动生成 Figure/Table**

## 本讲最小闭环

1. 先阅读 `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`。
2. 运行快速检查：
   ```bash
   python src/pipeline.py --mode smoke
   ```
3. 完整重建本讲受控教学实验：
   ```bash
   python src/pipeline.py --mode full
   ```
4. 验证“相同冻结协议能否得到完全相同的核心文件”：
   ```bash
   python src/pipeline.py --mode reproduce
   ```
5. 检查 artifact：
   ```bash
   python src/validate_artifact.py
   python src/validate_artifact.py --demo-broken
   ```
6. 打开：
   - `results/JSON/run_manifest.json`
   - `results/checksums.sha256`
   - `results/CSV/paper_artifact_registry.csv`
   - `results/tables/table1_main_results.*`
   - `figures/result_*.png`

## 受控教学模拟声明

本讲实验是人为设定机制参数的**受控教学模拟**，用于学习科研工程、数据谱系、自动制图制表、Manifest 和 reproducibility audit。

**它不代表 GPT、Claude、Gemini 或任何真实模型、Agent 框架、Benchmark、产品的实际性能。**

## 推荐阅读顺序

讲义 → 实验指导书 → 跑 `smoke` → 跑 `full` → 删除一项 metadata 后看 validator 为什么失败 → 做练习题 → 对照答案。

## 关键思想

> 论文不是最终的“真相文件”。论文中的数字、表格和图，应该能追溯到冻结配置、原始运行、处理代码与具体 artifact。

推荐的数据链路：

`Frozen Config → Raw Episode/Trace → Aggregation → Statistical Summary → Table/Figure → Paper Claim`

## 运行环境

本包实际验证环境记录在 `results/JSON/environment_snapshot.json`。

核心 Python 依赖见 `requirements.txt`。本实验无需 GPU、无需本地大模型、无需 API Key。
