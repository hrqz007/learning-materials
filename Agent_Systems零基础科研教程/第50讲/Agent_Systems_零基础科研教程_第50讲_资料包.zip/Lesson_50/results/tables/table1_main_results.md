| System | Environment | Task Success | Avg Tokens | Avg Latency (ms) | Avg Cost Units |
| --- | --- | --- | --- | --- | --- |
| Baseline | clean | 70.3% | 1240 | 1355 | 1.24 |
| Baseline | stress | 53.1% | 1239 | 1353 | 1.239 |
| Recovery | clean | 76.0% | 1602 | 1857 | 1.602 |
| Recovery | stress | 62.0% | 1617 | 1871 | 1.617 |
| Reflection | clean | 75.0% | 1860 | 2237 | 1.86 |
| Reflection | stress | 60.4% | 1880 | 2264 | 1.88 |
