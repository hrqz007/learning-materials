#!/usr/bin/env bash
set -euo pipefail
python src/pipeline.py --mode full
python src/pipeline.py --mode reproduce
