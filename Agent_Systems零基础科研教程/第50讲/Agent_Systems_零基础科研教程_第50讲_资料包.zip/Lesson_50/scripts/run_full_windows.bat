@echo off
python src\pipeline.py --mode full
if errorlevel 1 exit /b 1
python src\pipeline.py --mode reproduce
