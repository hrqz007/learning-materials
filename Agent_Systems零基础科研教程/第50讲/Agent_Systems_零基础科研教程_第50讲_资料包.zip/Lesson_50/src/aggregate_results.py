from __future__ import annotations

import argparse
import json
from pathlib import Path

import pandas as pd

from artifact_utils import ROOT, ensure_output_tree, save_json


def aggregate(output_root: Path) -> dict[str, int]:
    paths = ensure_output_tree(output_root)
    episodes = pd.read_csv(paths['csv'] / 'episodes.csv')

    task_level = (
        episodes.groupby(['task_id', 'system', 'environment', 'horizon', 'difficulty'], as_index=False)
        .agg(
            success=('success', 'mean'),
            tokens=('tokens', 'mean'),
            latency_ms=('latency_ms', 'mean'),
            cost_units=('cost_units', 'mean'),
            retries=('retries', 'mean'),
            recovery_rate=('recovered', 'mean'),
            propagation_depth=('propagation_depth', 'mean'),
        )
    )
    task_level.to_csv(paths['csv'] / 'task_level.csv', index=False, encoding='utf-8-sig')

    summary = (
        task_level.groupby(['system', 'environment'], as_index=False)
        .agg(
            task_success=('success', 'mean'),
            avg_tokens=('tokens', 'mean'),
            avg_latency_ms=('latency_ms', 'mean'),
            avg_cost_units=('cost_units', 'mean'),
            avg_retries=('retries', 'mean'),
            avg_recovery_rate=('recovery_rate', 'mean'),
            avg_propagation_depth=('propagation_depth', 'mean'),
            n_tasks=('task_id', 'nunique'),
        )
    )
    summary.to_csv(paths['csv'] / 'system_summary.csv', index=False, encoding='utf-8-sig')

    # Paper artifact registry: every paper-facing output points to its source and generator.
    registry = pd.DataFrame([
        {'artifact_id': 'Table1', 'paper_role': 'Main results', 'source': 'results/CSV/system_summary.csv', 'generator': 'src/make_paper_artifacts.py', 'output': 'results/tables/table1_main_results.*'},
        {'artifact_id': 'Figure1', 'paper_role': 'Success by system/environment', 'source': 'results/CSV/system_summary.csv', 'generator': 'src/make_paper_artifacts.py', 'output': 'figures/result_success_by_system.png'},
        {'artifact_id': 'Figure2', 'paper_role': 'Success-cost trade-off', 'source': 'results/CSV/system_summary.csv', 'generator': 'src/make_paper_artifacts.py', 'output': 'figures/result_success_cost_tradeoff.png'},
        {'artifact_id': 'Figure3', 'paper_role': 'Horizon slice', 'source': 'results/CSV/task_level.csv', 'generator': 'src/make_paper_artifacts.py', 'output': 'figures/result_success_by_horizon.png'},
    ])
    registry.to_csv(paths['csv'] / 'paper_artifact_registry.csv', index=False, encoding='utf-8-sig')

    stats = {
        'episode_rows': int(len(episodes)),
        'task_level_rows': int(len(task_level)),
        'summary_rows': int(len(summary)),
        'unique_tasks': int(episodes['task_id'].nunique()),
        'unique_runs': int(episodes['run_id'].nunique()),
    }
    save_json(paths['json'] / 'aggregation_report.json', stats)
    return stats


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, default=ROOT / 'results')
    args = parser.parse_args()
    print(json.dumps(aggregate(args.output_root), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
