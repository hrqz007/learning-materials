from __future__ import annotations

import csv
import hashlib
import json
import os
import platform
import random
import sys
from pathlib import Path
from typing import Any, Iterable

ROOT = Path(__file__).resolve().parents[1]


def load_json(path: Path) -> Any:
    with path.open('r', encoding='utf-8') as f:
        return json.load(f)


def save_json(path: Path, obj: Any) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8') as f:
        json.dump(obj, f, ensure_ascii=False, indent=2, sort_keys=True)
        f.write('\n')


def sha256_file(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(1024 * 1024), b''):
            h.update(chunk)
    return h.hexdigest()


def sha256_text(text: str) -> str:
    return hashlib.sha256(text.encode('utf-8')).hexdigest()


def stable_seed(*parts: Any) -> int:
    raw = '||'.join(str(x) for x in parts)
    return int(hashlib.sha256(raw.encode('utf-8')).hexdigest()[:16], 16)


def deterministic_rng(*parts: Any) -> random.Random:
    return random.Random(stable_seed(*parts))


def ensure_output_tree(base: Path) -> dict[str, Path]:
    paths = {
        'csv': base / 'CSV',
        'json': base / 'JSON',
        'trace': base / 'JSONL_Trace',
        'tables': base / 'tables',
    }
    for p in paths.values():
        p.mkdir(parents=True, exist_ok=True)
    return paths


def write_csv(path: Path, rows: Iterable[dict[str, Any]], fieldnames: list[str]) -> None:
    path.parent.mkdir(parents=True, exist_ok=True)
    with path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=fieldnames)
        writer.writeheader()
        writer.writerows(rows)


def source_fingerprint(src_dir: Path) -> str:
    records: list[str] = []
    for path in sorted(src_dir.rglob('*.py')):
        records.append(f"{path.relative_to(src_dir).as_posix()}:{sha256_file(path)}")
    return sha256_text('\n'.join(records))


def environment_snapshot() -> dict[str, Any]:
    packages = {}
    for name in ['numpy', 'pandas', 'matplotlib']:
        try:
            module = __import__(name)
            packages[name] = getattr(module, '__version__', 'unknown')
        except Exception as exc:  # pragma: no cover
            packages[name] = f'unavailable: {exc}'
    return {
        'python_version': sys.version.split()[0],
        'python_implementation': platform.python_implementation(),
        'platform': platform.platform(),
        'machine': platform.machine(),
        'packages': packages,
        'locale_env': {
            'LANG': os.environ.get('LANG'),
            'LC_ALL': os.environ.get('LC_ALL'),
        },
    }
