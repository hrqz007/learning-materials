from __future__ import annotations

import argparse
import json
from pathlib import Path

from artifact_utils import ROOT, ensure_output_tree, load_json, save_json, sha256_file, source_fingerprint


def build(output_root: Path) -> dict:
    paths = ensure_output_tree(output_root)
    cfg_path = ROOT / 'data' / 'config' / 'frozen_protocol.json'
    task_path = ROOT / 'data' / 'tasks.json'
    cfg = load_json(cfg_path)
    manifest = {
        'artifact_type': 'controlled_teaching_simulation',
        'lesson': 50,
        'experiment_id': cfg['experiment_id'],
        'generated_at_utc': cfg['frozen_generated_at_utc'],
        'command': 'python src/pipeline.py --mode full',
        'model_id': cfg['model_id'],
        'harness_version': cfg['harness_version'],
        'evaluator_version': cfg['evaluator_version'],
        'global_seed': cfg['global_seed'],
        'repeats': cfg['repeats'],
        'systems': cfg['systems'],
        'environments': cfg['environments'],
        'config_sha256': sha256_file(cfg_path),
        'tasks_sha256': sha256_file(task_path),
        'source_fingerprint_sha256': source_fingerprint(ROOT / 'src'),
        'primary_outputs': [
            'results/CSV/episodes.csv',
            'results/CSV/task_level.csv',
            'results/CSV/system_summary.csv',
            'results/JSONL_Trace/traces.jsonl',
            'results/tables/table1_main_results.csv',
            'figures/result_success_by_system.png',
        ],
        'notes': 'Teaching artifact only; no claim about real GPT/Claude/Gemini or any real Agent system.',
    }
    save_json(paths['json'] / 'run_manifest.json', manifest)
    return manifest


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, default=ROOT / 'results')
    args = parser.parse_args()
    print(json.dumps(build(args.output_root), ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
