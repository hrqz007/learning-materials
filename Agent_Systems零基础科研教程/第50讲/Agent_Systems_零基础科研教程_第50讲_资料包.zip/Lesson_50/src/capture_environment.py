from __future__ import annotations

import argparse
import json
from pathlib import Path

from artifact_utils import ROOT, environment_snapshot, ensure_output_tree, save_json


def capture(output_root: Path) -> dict:
    paths = ensure_output_tree(output_root)
    snap = environment_snapshot()
    save_json(paths['json'] / 'environment_snapshot.json', snap)
    lines = [
        f"Python: {snap['python_version']} ({snap['python_implementation']})",
        f"Platform: {snap['platform']}",
        f"Machine: {snap['machine']}",
    ]
    for name, version in snap['packages'].items():
        lines.append(f"{name}: {version}")
    (paths['json'] / 'environment_snapshot.txt').write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return snap


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, default=ROOT / 'results')
    args = parser.parse_args()
    print(json.dumps(capture(args.output_root), ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
