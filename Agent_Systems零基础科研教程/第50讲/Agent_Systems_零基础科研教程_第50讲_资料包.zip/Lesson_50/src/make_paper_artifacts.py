from __future__ import annotations

import argparse
import json
from pathlib import Path

import matplotlib.pyplot as plt
import pandas as pd

from artifact_utils import ROOT, ensure_output_tree


def make_markdown_table(df: pd.DataFrame) -> str:
    headers = list(df.columns)
    lines = ['| ' + ' | '.join(headers) + ' |', '| ' + ' | '.join(['---'] * len(headers)) + ' |']
    for _, row in df.iterrows():
        lines.append('| ' + ' | '.join(str(row[h]) for h in headers) + ' |')
    return '\n'.join(lines) + '\n'


def escape_tex(s: str) -> str:
    return s.replace('_', '\\_').replace('%', '\\%')


def make_latex_table(df: pd.DataFrame) -> str:
    cols = 'l' * len(df.columns)
    out = [f'\\begin{{tabular}}{{{cols}}}', '\\toprule', ' & '.join(escape_tex(c) for c in df.columns) + ' \\\\', '\\midrule']
    for _, row in df.iterrows():
        out.append(' & '.join(escape_tex(str(v)) for v in row.tolist()) + ' \\\\')
    out.extend(['\\bottomrule', '\\end{tabular}', ''])
    return '\n'.join(out)


def make_artifacts(output_root: Path, figure_root: Path) -> dict[str, str]:
    paths = ensure_output_tree(output_root)
    figure_root.mkdir(parents=True, exist_ok=True)
    summary = pd.read_csv(paths['csv'] / 'system_summary.csv')
    task_level = pd.read_csv(paths['csv'] / 'task_level.csv')

    table = summary.copy()
    table['Task Success'] = (100 * table['task_success']).round(1).astype(str) + '%'
    table['Avg Tokens'] = table['avg_tokens'].round(0).astype(int)
    table['Avg Latency (ms)'] = table['avg_latency_ms'].round(0).astype(int)
    table['Avg Cost Units'] = table['avg_cost_units'].round(3)
    table = table[['system', 'environment', 'Task Success', 'Avg Tokens', 'Avg Latency (ms)', 'Avg Cost Units']]
    table.columns = ['System', 'Environment', 'Task Success', 'Avg Tokens', 'Avg Latency (ms)', 'Avg Cost Units']
    table.to_csv(paths['tables'] / 'table1_main_results.csv', index=False, encoding='utf-8-sig')
    (paths['tables'] / 'table1_main_results.md').write_text(make_markdown_table(table), encoding='utf-8')
    (paths['tables'] / 'table1_main_results.tex').write_text(make_latex_table(table), encoding='utf-8')

    # Figure 1: success by system/environment
    pivot = summary.pivot(index='system', columns='environment', values='task_success')
    ax = pivot.plot(kind='bar', figsize=(8.2, 4.8), rot=0)
    ax.set_ylabel('Task Success')
    ax.set_xlabel('System')
    ax.set_ylim(0, 1)
    ax.set_title('Controlled Teaching Simulation: Task Success')
    ax.legend(title='Environment')
    ax.grid(axis='y', alpha=0.25)
    plt.tight_layout()
    plt.savefig(figure_root / 'result_success_by_system.png', dpi=180)
    plt.close()

    # Figure 2: success-cost trade-off
    fig, ax = plt.subplots(figsize=(7.6, 5.0))
    markers = {'clean': 'o', 'stress': 's'}
    for env, sub in summary.groupby('environment'):
        ax.scatter(sub['avg_cost_units'], sub['task_success'], s=85, marker=markers.get(env, 'o'), label=env)
        for _, r in sub.iterrows():
            ax.annotate(r['system'], (r['avg_cost_units'], r['task_success']), xytext=(5, 4), textcoords='offset points', fontsize=9)
    ax.set_xlabel('Average Cost Units')
    ax.set_ylabel('Task Success')
    ax.set_ylim(0, 1)
    ax.set_title('Success-Cost Trade-off')
    ax.grid(alpha=0.25)
    ax.legend(title='Environment')
    fig.tight_layout()
    fig.savefig(figure_root / 'result_success_cost_tradeoff.png', dpi=180)
    plt.close(fig)

    # Figure 3: horizon slice under stress
    stress = task_level[task_level['environment'] == 'stress']
    hor = stress.groupby(['horizon', 'system'], as_index=False)['success'].mean()
    fig, ax = plt.subplots(figsize=(7.8, 4.8))
    for system, sub in hor.groupby('system'):
        sub = sub.sort_values('horizon')
        ax.plot(sub['horizon'], sub['success'], marker='o', label=system)
    ax.set_xlabel('Task Horizon')
    ax.set_ylabel('Task Success')
    ax.set_ylim(0, 1)
    ax.set_xticks(sorted(hor['horizon'].unique()))
    ax.set_title('Stress Environment: Horizon Slice')
    ax.grid(alpha=0.25)
    ax.legend()
    fig.tight_layout()
    fig.savefig(figure_root / 'result_success_by_horizon.png', dpi=180)
    plt.close(fig)

    return {
        'table': str(paths['tables'] / 'table1_main_results.csv'),
        'figure1': str(figure_root / 'result_success_by_system.png'),
        'figure2': str(figure_root / 'result_success_cost_tradeoff.png'),
        'figure3': str(figure_root / 'result_success_by_horizon.png'),
    }


def main() -> None:
    parser = argparse.ArgumentParser()
    parser.add_argument('--output-root', type=Path, default=ROOT / 'results')
    parser.add_argument('--figure-root', type=Path, default=ROOT / 'figures')
    args = parser.parse_args()
    print(json.dumps(make_artifacts(args.output_root, args.figure_root), ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
