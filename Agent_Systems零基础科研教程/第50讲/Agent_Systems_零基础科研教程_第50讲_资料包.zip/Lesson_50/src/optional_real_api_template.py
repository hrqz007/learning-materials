"""Optional real-API template.

This file intentionally does NOT call any provider. It shows what metadata should be
recorded if you later replace the teaching simulator with a real model/API.

Never place API keys inside a repository or run manifest.
"""

REAL_API_RUN_MANIFEST_FIELDS = {
    'provider': '<provider>',
    'model_id_exact': '<exact model or snapshot id>',
    'request_timestamp_utc': '<timestamp>',
    'temperature': '<value>',
    'top_p': '<value>',
    'max_output_tokens': '<value>',
    'system_prompt_sha256': '<hash>',
    'tool_schema_sha256': '<hash>',
    'harness_commit_or_version': '<version>',
    'benchmark_version': '<version>',
    'task_ids_sha256': '<hash>',
    'evaluator_version': '<version>',
    'retry_policy': '<policy>',
    'timeout_seconds': '<value>',
    'concurrency': '<value>',
    'raw_response_storage_policy': '<policy>',
    'token_usage': '<captured usage>',
    'cost_accounting_method': '<method>',
}

if __name__ == '__main__':
    import json
    print(json.dumps(REAL_API_RUN_MANIFEST_FIELDS, indent=2))
