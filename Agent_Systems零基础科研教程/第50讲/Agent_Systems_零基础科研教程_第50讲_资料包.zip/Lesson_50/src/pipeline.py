from __future__ import annotations

import argparse
import json
import shutil
import tempfile
from pathlib import Path

from artifact_utils import ROOT, sha256_file
from aggregate_results import aggregate
from build_run_manifest import build
from capture_environment import capture
from make_paper_artifacts import make_artifacts
from run_experiment import run
from validate_artifact import audit, broken_fixture_demo
from write_checksums import write as write_checksums

CORE_REPRO_FILES = [
    'CSV/episodes.csv',
    'CSV/task_level.csv',
    'CSV/system_summary.csv',
    'tables/table1_main_results.csv',
    'tables/table1_main_results.md',
    'tables/table1_main_results.tex',
]


def run_full() -> dict:
    run_report = run(ROOT / 'results')
    agg_report = aggregate(ROOT / 'results')
    art_report = make_artifacts(ROOT / 'results', ROOT / 'figures')
    env = capture(ROOT / 'results')
    manifest = build(ROOT / 'results')
    write_checksums(ROOT)
    broken = broken_fixture_demo()
    from artifact_utils import save_json
    save_json(ROOT / 'results/JSON/broken_fixture_audit.json', broken)
    report = audit(ROOT)
    save_json(ROOT / 'results/JSON/artifact_audit.json', report)
    return {'run': run_report, 'aggregate': agg_report, 'artifacts': art_report, 'audit_all_passed': report['all_passed']}


def run_smoke() -> dict:
    with tempfile.TemporaryDirectory(prefix='lesson50_smoke_') as td:
        out = Path(td) / 'results'
        run_report = run(out, task_limit=4, repeats_override=1)
        agg_report = aggregate(out)
        return {'smoke': True, 'run': run_report, 'aggregate': agg_report}


def rebuild_derived() -> dict:
    agg_report = aggregate(ROOT / 'results')
    art_report = make_artifacts(ROOT / 'results', ROOT / 'figures')
    manifest = build(ROOT / 'results')
    write_checksums(ROOT)
    return {'aggregate': agg_report, 'artifacts': art_report, 'manifest_id': manifest['experiment_id']}


def reproduce_main() -> dict:
    reference = ROOT / 'results'
    with tempfile.TemporaryDirectory(prefix='lesson50_reproduce_') as td:
        td = Path(td)
        out = td / 'results'
        figs = td / 'figures'
        run(out)
        aggregate(out)
        make_artifacts(out, figs)
        comparisons = []
        for rel in CORE_REPRO_FILES:
            a = reference / rel
            b = out / rel
            comparisons.append({'file': rel, 'match': sha256_file(a) == sha256_file(b), 'reference_sha256': sha256_file(a), 'rerun_sha256': sha256_file(b)})
        return {'all_match': all(x['match'] for x in comparisons), 'comparisons': comparisons}


def main():
    parser = argparse.ArgumentParser(description='Lesson 50 one-command artifact pipeline.')
    parser.add_argument('--mode', choices=['full','smoke','rebuild','reproduce'], default='full')
    args = parser.parse_args()
    if args.mode == 'full':
        report = run_full()
    elif args.mode == 'smoke':
        report = run_smoke()
    elif args.mode == 'rebuild':
        report = rebuild_derived()
    else:
        report = reproduce_main()
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
