from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path
from typing import Any

from artifact_utils import ROOT, deterministic_rng, ensure_output_tree, load_json

DIFF_PENALTY = {'low': 0.00, 'medium': 0.06, 'high': 0.12}


def simulate_episode(task: dict[str, Any], system: str, env: str, repeat: int, cfg: dict[str, Any]) -> tuple[dict[str, Any], dict[str, Any]]:
    seed = cfg['global_seed']
    rng = deterministic_rng(seed, task['task_id'], system, env, repeat)
    horizon = int(task['horizon'])
    difficulty = task['difficulty']

    # 受控教学模拟：人为设定的机制参数，只用于演示 artifact / pipeline。
    fault_base = 0.06 + 0.006 * horizon + (0.02 if difficulty == 'high' else 0.0)
    if env == 'stress':
        fault_base += 0.20
    fault_triggered = rng.random() < min(fault_base, 0.65)

    detect_prob = {'Baseline': 0.18, 'Reflection': 0.48, 'Recovery': 0.84}[system]
    recover_prob = {'Baseline': 0.08, 'Reflection': 0.38, 'Recovery': 0.78}[system]
    detected = fault_triggered and (rng.random() < detect_prob)
    recovered = detected and (rng.random() < recover_prob)

    base_success = 0.95 - 0.0085 * horizon - DIFF_PENALTY[difficulty]
    if env == 'stress':
        base_success -= 0.07
    system_bonus = {'Baseline': 0.00, 'Reflection': 0.045, 'Recovery': 0.025}[system]
    success_prob = base_success + system_bonus
    if fault_triggered:
        success_prob -= 0.43
        if recovered:
            success_prob += 0.36
        elif detected:
            success_prob += 0.08
    success_prob = max(0.03, min(0.97, success_prob))
    success = rng.random() < success_prob

    retries = 0
    if system == 'Reflection':
        retries = int(rng.random() < 0.55) + int(fault_triggered and rng.random() < 0.35)
    elif system == 'Recovery':
        retries = int(detected) + int(detected and not recovered and rng.random() < 0.45)

    token_base = 520 + horizon * 42 + {'low': 0, 'medium': 90, 'high': 180}[difficulty]
    token_overhead = {'Baseline': 0, 'Reflection': 520, 'Recovery': 330}[system]
    tokens = int(token_base + token_overhead + retries * 170 + rng.randint(-45, 45))
    steps = horizon + {'Baseline': 1, 'Reflection': 3, 'Recovery': 2}[system] + retries
    latency_ms = int(tokens * {'Baseline': 1.03, 'Reflection': 1.16, 'Recovery': 1.11}[system] + rng.randint(25, 130))
    cost_units = round(tokens / 1000.0, 4)

    first_bad_step = None
    propagation_depth = 0
    if fault_triggered:
        first_bad_step = max(1, min(horizon, int(rng.uniform(1, horizon + 0.999))))
        if recovered:
            propagation_depth = max(1, int(rng.uniform(1, 3.2)))
        elif detected:
            propagation_depth = max(2, int(rng.uniform(2, 5.5)))
        else:
            propagation_depth = max(3, int(rng.uniform(3, max(4, horizon / 2 + 2))))

    run_id = f"{task['task_id']}__{system}__{env}__r{repeat}"
    episode = {
        'run_id': run_id,
        'task_id': task['task_id'],
        'system': system,
        'environment': env,
        'repeat': repeat,
        'horizon': horizon,
        'difficulty': difficulty,
        'success': int(success),
        'fault_triggered': int(fault_triggered),
        'detected': int(detected),
        'recovered': int(recovered),
        'first_bad_step': first_bad_step if first_bad_step is not None else '',
        'propagation_depth': propagation_depth,
        'retries': retries,
        'steps': steps,
        'tokens': tokens,
        'latency_ms': latency_ms,
        'cost_units': cost_units,
        'seed': cfg['global_seed'],
        'model_id': cfg['model_id'],
        'harness_version': cfg['harness_version'],
        'evaluator_version': cfg['evaluator_version'],
    }

    spans: list[dict[str, Any]] = [
        {'span_id': 0, 'name': 'observe', 'status': 'ok', 'detail': 'task loaded'},
        {'span_id': 1, 'name': 'plan', 'status': 'ok', 'detail': f'horizon={horizon}'},
        {'span_id': 2, 'name': 'execute', 'status': 'error' if fault_triggered else 'ok', 'detail': 'controlled fault' if fault_triggered else 'tool path normal'},
        {'span_id': 3, 'name': 'verify', 'status': 'ok' if detected or not fault_triggered else 'missed', 'detail': f'detected={detected}'},
    ]
    if detected:
        spans.append({'span_id': 4, 'name': 'recovery', 'status': 'ok' if recovered else 'failed', 'detail': f'retries={retries}'})
    spans.append({'span_id': len(spans), 'name': 'finalize', 'status': 'ok' if success else 'failed', 'detail': f'success={success}'})

    trace = {
        'run_id': run_id,
        'task_id': task['task_id'],
        'system': system,
        'environment': env,
        'repeat': repeat,
        'controlled_teaching_simulation': True,
        'spans': spans,
    }
    return episode, trace


def run(output_root: Path, task_limit: int | None = None, repeats_override: int | None = None) -> dict[str, Any]:
    cfg = load_json(ROOT / 'data' / 'config' / 'frozen_protocol.json')
    tasks = load_json(ROOT / 'data' / 'tasks.json')
    if task_limit is not None:
        tasks = tasks[:task_limit]
    repeats = repeats_override or int(cfg['repeats'])
    paths = ensure_output_tree(output_root)

    episodes: list[dict[str, Any]] = []
    traces: list[dict[str, Any]] = []
    for task in tasks:
        for system in cfg['systems']:
            for env in cfg['environments']:
                for repeat in range(repeats):
                    ep, tr = simulate_episode(task, system, env, repeat, cfg)
                    episodes.append(ep)
                    traces.append(tr)

    csv_path = paths['csv'] / 'episodes.csv'
    with csv_path.open('w', encoding='utf-8-sig', newline='') as f:
        writer = csv.DictWriter(f, fieldnames=list(episodes[0].keys()))
        writer.writeheader()
        writer.writerows(episodes)

    trace_path = paths['trace'] / 'traces.jsonl'
    with trace_path.open('w', encoding='utf-8') as f:
        for tr in traces:
            f.write(json.dumps(tr, ensure_ascii=False, sort_keys=True) + '\n')

    return {'episodes': len(episodes), 'traces': len(traces), 'task_count': len(tasks), 'repeats': repeats}


def main() -> None:
    parser = argparse.ArgumentParser(description='Run controlled teaching Agent experiment.')
    parser.add_argument('--output-root', type=Path, default=ROOT / 'results')
    parser.add_argument('--task-limit', type=int, default=None)
    parser.add_argument('--repeats', type=int, default=None)
    args = parser.parse_args()
    report = run(args.output_root, args.task_limit, args.repeats)
    print(json.dumps(report, ensure_ascii=False, indent=2))


if __name__ == '__main__':
    main()
