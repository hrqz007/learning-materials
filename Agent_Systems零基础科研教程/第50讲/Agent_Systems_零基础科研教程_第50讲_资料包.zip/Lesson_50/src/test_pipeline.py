from __future__ import annotations

import csv
import json
import tempfile
from pathlib import Path

from aggregate_results import aggregate
from run_experiment import run


def main():
    with tempfile.TemporaryDirectory(prefix='lesson50_test_') as td:
        out = Path(td) / 'results'
        report = run(out, task_limit=3, repeats_override=1)
        assert report['episodes'] == 3 * 3 * 2 * 1
        aggregate(out)
        with (out / 'CSV/episodes.csv').open('r', encoding='utf-8-sig') as f:
            rows = list(csv.DictReader(f))
        assert len(rows) == report['episodes']
        with (out / 'JSONL_Trace/traces.jsonl').open('r', encoding='utf-8') as f:
            traces = [json.loads(line) for line in f if line.strip()]
        assert len(traces) == len(rows)
        assert {r['run_id'] for r in rows} == {t['run_id'] for t in traces}
    print('PASS: smoke unit checks')

if __name__ == '__main__':
    main()
