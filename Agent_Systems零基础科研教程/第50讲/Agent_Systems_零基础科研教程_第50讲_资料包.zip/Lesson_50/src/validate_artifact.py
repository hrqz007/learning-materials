from __future__ import annotations

import argparse
import csv
import json
from pathlib import Path

from artifact_utils import ROOT, load_json, save_json, sha256_file

REQUIRED = [
    'README_本讲学习说明.md',
    'requirements.txt',
    'data/config/frozen_protocol.json',
    'data/tasks.json',
    'src/pipeline.py',
    'src/run_experiment.py',
    'src/aggregate_results.py',
    'src/make_paper_artifacts.py',
    'results/CSV/episodes.csv',
    'results/CSV/task_level.csv',
    'results/CSV/system_summary.csv',
    'results/JSON/run_manifest.json',
    'results/JSON/environment_snapshot.json',
    'results/JSONL_Trace/traces.jsonl',
    'results/tables/table1_main_results.csv',
    'figures/result_success_by_system.png',
    'results/checksums.sha256',
]


def audit(root: Path) -> dict:
    checks: list[dict] = []

    for rel in REQUIRED:
        p = root / rel
        checks.append({'check': f'exists:{rel}', 'passed': p.exists(), 'detail': '' if p.exists() else 'missing'})

    cfg = load_json(root / 'data/config/frozen_protocol.json')
    for key in ['experiment_id', 'global_seed', 'systems', 'environments', 'repeats', 'model_id', 'harness_version', 'evaluator_version']:
        checks.append({'check': f'config_key:{key}', 'passed': key in cfg, 'detail': '' if key in cfg else 'missing key'})

    episodes = root / 'results/CSV/episodes.csv'
    rows = 0
    run_ids = set()
    if episodes.exists():
        with episodes.open('r', encoding='utf-8-sig', newline='') as f:
            reader = csv.DictReader(f)
            required_cols = {'run_id','task_id','system','environment','repeat','success','tokens','latency_ms','seed','model_id','harness_version','evaluator_version'}
            cols = set(reader.fieldnames or [])
            checks.append({'check': 'episodes_schema', 'passed': required_cols.issubset(cols), 'detail': f'missing={sorted(required_cols-cols)}'})
            for r in reader:
                rows += 1
                run_ids.add(r['run_id'])
    expected = len(cfg['systems']) * len(cfg['environments']) * int(cfg['repeats']) * int(cfg['task_count'])
    checks.append({'check': 'episode_count', 'passed': rows == expected, 'detail': f'found={rows}, expected={expected}'})

    trace_path = root / 'results/JSONL_Trace/traces.jsonl'
    trace_ids = set()
    trace_lines = 0
    if trace_path.exists():
        with trace_path.open('r', encoding='utf-8') as f:
            for line in f:
                if line.strip():
                    obj = json.loads(line)
                    trace_lines += 1
                    trace_ids.add(obj['run_id'])
    checks.append({'check': 'trace_count_matches', 'passed': trace_lines == rows, 'detail': f'traces={trace_lines}, episodes={rows}'})
    checks.append({'check': 'trace_run_id_coverage', 'passed': trace_ids == run_ids, 'detail': f'difference={len(trace_ids.symmetric_difference(run_ids))}'})

    checksum_path = root / 'results/checksums.sha256'
    checksum_ok = True
    checksum_detail = []
    if checksum_path.exists():
        for line in checksum_path.read_text(encoding='utf-8').splitlines():
            if not line.strip():
                continue
            digest, rel = line.split('  ', 1)
            p = root / rel
            actual = sha256_file(p) if p.exists() else 'MISSING'
            if actual != digest:
                checksum_ok = False
                checksum_detail.append(rel)
    else:
        checksum_ok = False
        checksum_detail.append('checksums.sha256 missing')
    checks.append({'check': 'core_checksums', 'passed': checksum_ok, 'detail': ','.join(checksum_detail)})

    passed = sum(int(c['passed']) for c in checks)
    report = {
        'artifact_root': '.',
        'checks_total': len(checks),
        'checks_passed': passed,
        'all_passed': passed == len(checks),
        'checks': checks,
        'interpretation': 'Checklist coverage is an engineering QA signal, not a scientific quality score.',
    }
    return report


def broken_fixture_demo() -> dict:
    # Deliberately incomplete metadata: used only to show what an auditor should catch.
    fixture = {
        'experiment_id': 'broken-demo',
        'model_id': 'mock-agent-v1',
        'repeats': 3,
        # intentionally missing seed / evaluator / harness / task split identity
    }
    required = ['experiment_id','model_id','global_seed','evaluator_version','harness_version','task_split_sha256']
    checks = [{'field': k, 'present': k in fixture} for k in required]
    return {
        'controlled_broken_fixture': True,
        'checks': checks,
        'missing_fields': [x['field'] for x in checks if not x['present']],
        'lesson': 'A runnable script alone is not a complete reproducibility artifact.',
    }


def main():
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    parser.add_argument('--demo-broken', action='store_true')
    args = parser.parse_args()
    if args.demo_broken:
        report = broken_fixture_demo()
        save_json(args.root / 'results/JSON/broken_fixture_audit.json', report)
    else:
        report = audit(args.root)
        save_json(args.root / 'results/JSON/artifact_audit.json', report)
    print(json.dumps(report, ensure_ascii=False, indent=2))

if __name__ == '__main__':
    main()
