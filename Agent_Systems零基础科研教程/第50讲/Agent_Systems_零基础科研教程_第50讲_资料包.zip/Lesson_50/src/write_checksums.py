from __future__ import annotations

import argparse
from pathlib import Path

from artifact_utils import ROOT, sha256_file

CORE_FILES = [
    'data/config/frozen_protocol.json',
    'data/tasks.json',
    'results/CSV/episodes.csv',
    'results/CSV/task_level.csv',
    'results/CSV/system_summary.csv',
    'results/CSV/paper_artifact_registry.csv',
    'results/JSON/aggregation_report.json',
    'results/JSON/run_manifest.json',
    'results/JSONL_Trace/traces.jsonl',
    'results/tables/table1_main_results.csv',
    'results/tables/table1_main_results.md',
    'results/tables/table1_main_results.tex',
    'figures/result_success_by_system.png',
    'figures/result_success_cost_tradeoff.png',
    'figures/result_success_by_horizon.png',
]


def write(root: Path = ROOT) -> Path:
    out = root / 'results' / 'checksums.sha256'
    lines = []
    for rel in CORE_FILES:
        p = root / rel
        if p.exists():
            lines.append(f"{sha256_file(p)}  {rel}")
    out.write_text('\n'.join(lines) + '\n', encoding='utf-8')
    return out

if __name__ == '__main__':
    parser = argparse.ArgumentParser()
    parser.add_argument('--root', type=Path, default=ROOT)
    args = parser.parse_args()
    print(write(args.root))
