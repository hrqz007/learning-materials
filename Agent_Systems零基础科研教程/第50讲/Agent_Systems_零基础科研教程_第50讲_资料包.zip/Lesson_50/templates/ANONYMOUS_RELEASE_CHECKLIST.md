# Double-blind / Anonymous Artifact Checklist

- [ ] Remove author names, institution names, usernames, home-directory paths and identifying repository history.
- [ ] Use an anonymous repository or submission artifact mechanism permitted by the venue.
- [ ] Remove API keys, tokens, credentials and private endpoints.
- [ ] Check commit messages, issue links, file metadata and notebook outputs for identity leakage.
- [ ] Keep enough version information to reproduce the experiment without revealing author identity.
- [ ] Follow the target venue's current anonymity policy; do not assume every venue uses the same rules.
