# Artifact README Template

## 1. What claim does this artifact reproduce?
State one or more paper claims and point to the exact table/figure.

## 2. Quick start
Provide the shortest smoke test and expected output.

## 3. Full reproduction
Give the exact command, estimated runtime, hardware/API requirements, and expected files.

## 4. Repository map
Explain code, config, data, raw results, processed results, figures, tables, and manifests.

## 5. Frozen experimental identity
List benchmark/task split, model/snapshot, harness/runtime, evaluator, prompt/tool schema, seed/repeats, budget, retry/timeout/concurrency.

## 6. Artifact lineage
For every paper-facing figure/table, list source data + generator script + output path.

## 7. Known non-determinism
Explain what cannot be bitwise reproduced, especially remote model/API behavior and external tools.

## 8. Expected deviations
State what numerical drift is acceptable and why.

## 9. Licenses / access restrictions
Document data/model/tool licenses and any unavailable proprietary dependency.

## 10. Contact / issue reporting
Provide a reproducible bug report template: command, environment, logs, hashes, observed vs expected result.
