# Agent Systems Reproducibility Checklist

## A. Identity
- [ ] Exact task/benchmark version and task IDs are recorded.
- [ ] Exact model/provider snapshot or model ID is recorded.
- [ ] Harness/runtime version or commit is recorded.
- [ ] Evaluator version is recorded.
- [ ] Prompt/tool schema/config hashes are recorded.

## B. Experimental protocol
- [ ] Primary metric and unit of analysis are defined before analysis.
- [ ] Seeds/repeats and stopping rule are recorded.
- [ ] Retry, timeout, concurrency, rate-limit behavior are recorded.
- [ ] Compute/token/cost budgets are recorded.
- [ ] Baselines use comparable resources or the mismatch is disclosed.

## C. Artifact lineage
- [ ] Raw outputs are preserved and not hand-edited.
- [ ] Processed tables are generated from raw outputs by code.
- [ ] Figures are generated from processed/raw data by code.
- [ ] Paper tables/figures can be traced to source files and generator scripts.
- [ ] Run manifest and checksums are included.

## D. Agent-specific observability
- [ ] Episode-level result exists.
- [ ] Trace/trajectory exists when mechanism claims depend on process behavior.
- [ ] Tool calls, errors, retries, recovery and evaluator outcomes are recorded when relevant.
- [ ] Failure annotation rules are documented.

## E. Reproduction experience
- [ ] Smoke test finishes quickly.
- [ ] Main result has a one-command path.
- [ ] Environment/dependency instructions are included.
- [ ] Expected outputs and sanity checks are documented.
- [ ] Closed/proprietary dependencies are explicitly disclosed.
