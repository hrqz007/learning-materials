# 第51讲学习说明

主题：完整科研综合项目——从 Trace 中发现现象，到 Pilot、Confirmatory Experiment、统计与论文 Claim。

## 推荐顺序
1. 先读 `02_零基础讲义.pdf`。
2. 再按 `03_实验指导书.docx` 运行 `python src/collective_simulation.py`。
3. 打开 `results/confirmatory_traces.jsonl` 找 wrong-consensus trace。
4. 查看 `04_实验设计书.docx`，把结构迁移到自己的真实研究。
5. 独立完成 `05_练习题.docx`，最后核对答案。

## 实际运行规模
- Pilot: 240 episodes。
- Confirmatory: 2592 episodes。
- Held-out confirmatory tasks: 108。
- High-bias primary slice: 53 tasks。

## 重要声明
本讲所有性能数字来自受控教学模拟，不代表 GPT、Claude、Gemini 或任何真实模型、Agent Framework、Benchmark 或产品的实际性能。
