from __future__ import annotations
import csv, json, math, random, hashlib
from pathlib import Path
from itertools import combinations
from statistics import mean

ROOT = Path(__file__).resolve().parents[1]
DATA = ROOT/'data'; RESULTS = ROOT/'results'
RESULTS.mkdir(exist_ok=True)

STRATEGIES = ['single_agent','independent_vote_4','full_communication_4','diverse_vote_4']


def stable_seed(*parts):
    h=hashlib.sha256('|'.join(map(str,parts)).encode()).hexdigest()
    return int(h[:16],16)


def generate_tasks(n=120, seed=51):
    rng=random.Random(seed)
    tasks=[]
    for i in range(n):
        difficulty=rng.choice(['easy','medium','hard','hard'])
        bias=rng.choice(['low','medium','high','high'])
        d={'easy':0.10,'medium':0.22,'hard':0.34}[difficulty]
        b={'low':0.05,'medium':0.16,'high':0.30}[bias]
        tasks.append({'task_id':f'T{i+1:03d}','difficulty':difficulty,'bias_level':bias,'base_error':d,'common_bias':b})
    return tasks


def bernoulli(rng,p): return 1 if rng.random()<p else 0


def run_episode(task, strategy, repeat, phase='confirmatory'):
    rng=random.Random(stable_seed(task['task_id'],strategy,repeat,phase))
    n_agents=1 if strategy=='single_agent' else 4
    common_event=bernoulli(rng, task['common_bias'])
    errors=[]; initial_answers=[]
    # strategy-specific independent error and correlation exposure
    if strategy=='diverse_vote_4':
        independent_scale=0.92; common_weight=0.45
    elif strategy=='full_communication_4':
        independent_scale=0.97; common_weight=1.00
    else:
        independent_scale=1.00; common_weight=0.75 if strategy!='single_agent' else 0.9
    for a in range(n_agents):
        p=min(0.88, task['base_error']*independent_scale + common_event*task['common_bias']*common_weight)
        err=bernoulli(rng,p)
        errors.append(err); initial_answers.append(0 if err else 1)
    comm_messages=0
    final_answers=list(initial_answers)
    # full communication: 2 rounds; agents may conform to current majority, including wrong majority.
    if strategy=='full_communication_4':
        for _ in range(2):
            comm_messages += n_agents*(n_agents-1)
            maj = 1 if sum(final_answers)>=3 else 0 if sum(final_answers)<=1 else rng.choice([0,1])
            for a in range(n_agents):
                if final_answers[a]!=maj and rng.random()<0.72:
                    final_answers[a]=maj
    # other voting systems no interactive communication, just aggregate at the end.
    if n_agents==1:
        system_answer=final_answers[0]
    else:
        s=sum(final_answers)
        system_answer=1 if s>=3 else 0 if s<=1 else rng.choice([0,1])
    success=system_answer
    wrong_consensus=int(n_agents>1 and len(set(final_answers))==1 and final_answers[0]==0)
    consensus=int(n_agents>1 and len(set(final_answers))==1)
    # pairwise error correlation proxy inside episode: whether pairs share same error status; aggregate later.
    pair_same=[]
    if n_agents>1:
        final_errors=[1-x for x in final_answers]
        for i,j in combinations(range(n_agents),2): pair_same.append(int(final_errors[i]==final_errors[j]))
    token_cost = 380*n_agents + comm_messages*26 + (80 if n_agents>1 else 0)
    trace=[
        {'span':'task_start','task_id':task['task_id'],'strategy':strategy,'repeat':repeat},
        {'span':'initial_reasoning','agents':n_agents,'initial_answers':initial_answers,'errors':errors,'common_event':common_event},
    ]
    if strategy=='full_communication_4':
        trace.append({'span':'communication','messages':comm_messages,'final_agent_answers':final_answers})
    trace.append({'span':'aggregation','system_answer':system_answer,'success':success,'wrong_consensus':wrong_consensus})
    return {
        'task_id':task['task_id'],'difficulty':task['difficulty'],'bias_level':task['bias_level'],
        'strategy':strategy,'repeat':repeat,'phase':phase,'success':success,
        'mean_individual_error':sum(errors)/len(errors),'consensus':consensus,'wrong_consensus':wrong_consensus,
        'pair_same_error':mean(pair_same) if pair_same else '', 'messages':comm_messages,'token_cost':token_cost,
        'trace':trace
    }


def write_rows(rows, stem):
    csv_path=RESULTS/f'{stem}_episodes.csv'; jsonl_path=RESULTS/f'{stem}_traces.jsonl'
    fields=[k for k in rows[0] if k!='trace']
    with csv_path.open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=fields);w.writeheader();w.writerows([{k:r[k] for k in fields} for r in rows])
    with jsonl_path.open('w',encoding='utf-8') as f:
        for r in rows: f.write(json.dumps({'task_id':r['task_id'],'strategy':r['strategy'],'repeat':r['repeat'],'trace':r['trace']},ensure_ascii=False)+'\n')
    return csv_path,jsonl_path


def aggregate(rows):
    out=[]
    for strat in STRATEGIES:
        rr=[r for r in rows if r['strategy']==strat]
        out.append({
            'strategy':strat,'episodes':len(rr),'success_rate':mean(r['success'] for r in rr),
            'wrong_consensus_rate':mean(r['wrong_consensus'] for r in rr),
            'mean_pair_same_error':mean(float(r['pair_same_error']) for r in rr if r['pair_same_error']!='') if strat!='single_agent' else None,
            'mean_token_cost':mean(r['token_cost'] for r in rr), 'mean_messages':mean(r['messages'] for r in rr)
        })
    return out


def task_level(rows):
    by={}
    for r in rows:
        by.setdefault((r['task_id'],r['strategy']),[]).append(r)
    tasks=[]
    meta={}
    for r in rows: meta[r['task_id']]={'difficulty':r['difficulty'],'bias_level':r['bias_level']}
    tids=sorted(set(r['task_id'] for r in rows))
    for tid in tids:
        rec={'task_id':tid,**meta[tid]}
        for s in STRATEGIES:
            rr=by[(tid,s)]; rec[s]=mean(x['success'] for x in rr)
        rec['gain_diverse_vs_single']=rec['diverse_vote_4']-rec['single_agent']
        rec['gain_comm_vs_independent']=rec['full_communication_4']-rec['independent_vote_4']
        tasks.append(rec)
    return tasks


def bootstrap_ci(values, B=5000, seed=5151):
    rng=random.Random(seed); n=len(values); stats=[]
    for _ in range(B): stats.append(mean(values[rng.randrange(n)] for _ in range(n)))
    stats.sort(); return stats[int(.025*B)],stats[int(.975*B)]


def analyze(rows, stem):
    ag=aggregate(rows); tasks=task_level(rows)
    with (RESULTS/f'{stem}_summary.json').open('w',encoding='utf-8') as f: json.dump(ag,f,ensure_ascii=False,indent=2)
    with (RESULTS/f'{stem}_task_level.csv').open('w',newline='',encoding='utf-8-sig') as f:
        w=csv.DictWriter(f,fieldnames=tasks[0].keys());w.writeheader();w.writerows(tasks)
    # primary confirmatory contrast: diverse vs full communication on high-bias tasks, task as unit
    high=[t for t in tasks if t['bias_level']=='high']
    diffs=[t['diverse_vote_4']-t['full_communication_4'] for t in high]
    ci=bootstrap_ci(diffs,seed=99)
    # secondary: full communication vs independent on high bias
    d2=[t['full_communication_4']-t['independent_vote_4'] for t in high]
    ci2=bootstrap_ci(d2,seed=100)
    result={'n_tasks':len(tasks),'n_high_bias_tasks':len(high),'primary_effect_diverse_minus_full_comm':mean(diffs),'primary_ci95':ci,
            'secondary_effect_full_comm_minus_independent':mean(d2),'secondary_ci95':ci2}
    with (RESULTS/f'{stem}_statistics.json').open('w',encoding='utf-8') as f:json.dump(result,f,indent=2)
    return ag,tasks,result


def main():
    tasks=generate_tasks();
    with (DATA/'tasks.json').open('w',encoding='utf-8') as f: json.dump(tasks,f,ensure_ascii=False,indent=2)
    # Pilot uses first 12 tasks, 5 repeats.
    pilot=[]
    for t in tasks[:12]:
        for s in STRATEGIES:
            for r in range(5): pilot.append(run_episode(t,s,r,'pilot'))
    write_rows(pilot,'pilot'); analyze(pilot,'pilot')
    # Confirmatory uses held-out remaining 108 tasks, 6 repeats.
    conf=[]
    for t in tasks[12:]:
        for s in STRATEGIES:
            for r in range(6): conf.append(run_episode(t,s,r,'confirmatory'))
    write_rows(conf,'confirmatory'); ag,tasks2,stats=analyze(conf,'confirmatory')
    print(json.dumps({'pilot_episodes':len(pilot),'confirmatory_episodes':len(conf),'summary':ag,'stats':stats},ensure_ascii=False,indent=2))

if __name__=='__main__': main()
