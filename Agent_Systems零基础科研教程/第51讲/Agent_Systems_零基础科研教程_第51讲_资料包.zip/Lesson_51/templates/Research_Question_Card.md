# Research Question Card

- Observation:
- Stability check:
- Research Question:
- Fact / Inference / Hypothesis:
- Hypothesis:
- Falsifier:
- Closest prior work:
- Pilot design:
- Go/No-Go rule:
- Confirmatory protocol:
- Primary metric:
- Experimental unit:
- Baselines:
- Ablations:
- Boundary conditions:
- Final scoped claim:
