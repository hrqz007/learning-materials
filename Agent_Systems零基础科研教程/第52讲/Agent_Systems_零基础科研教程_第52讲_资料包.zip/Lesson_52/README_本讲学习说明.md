# 第52讲学习说明

主题：**如何独立启动并完成第一篇真实 Agent Systems 论文**。

这是原定 52 讲主课程的最后一讲。目标不是继续堆知识点，而是把前面课程压缩成一个可以独立重复执行的科研操作系统。

## 建议学习顺序

1. `01_零基础讲义.docx` 或 `02_零基础讲义.pdf`
2. `03_实验指导书.docx`
3. 在本目录运行三个脚本
4. 查看 `results/`
5. 完成 `05_练习题.docx`
6. 再查看 `06_练习题答案.docx`
7. 把 `templates/` 复制到未来真实论文项目

## 无 API Key 实践

本讲只使用 Python 3 标准库：

```bash
python src/readiness_audit.py --status data/project_status.json --out results
python src/claim_evidence_audit.py --input data/claim_evidence_map.csv --out results/claim_evidence_audit.csv
python src/rebuttal_triage.py --input data/review_comments.json --out results/rebuttal_matrix.csv
```

默认教学输入得到 `readiness_score = 90.5`。这只是**受控项目管理教学模拟**，不代表任何真实论文质量、研究者能力或发表概率。

## 这一讲真正要带走的东西

- 真实论文从 `Observation -> RQ -> Pilot -> Frozen Protocol -> Main Experiment -> Evidence -> Scoped Claim` 走出来。
- 每次改变研究协议都要留下 Decision Log。
- 投稿前分别检查 Scientific / Reproducibility / Venue Compliance。
- Rebuttal 不是赢辩论，而是降低审稿人对正确性和证据的合理不确定性。
- 52讲结束后，不再无限补课；第一篇真实项目本身就是下一阶段课程。

## 当前流程资料的时效性

讲义中的 arXiv / OpenReview / NeurIPS / ACM 流程说明按 2026-09-29 官方页面整理。真正投稿时，必须重新打开目标 venue 当年的官方页面确认规则。
