#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Audit whether each paper claim has evidence, scope and limitation entries."""
import csv, argparse
from pathlib import Path

def main(inp: Path, out: Path):
    with inp.open(encoding='utf-8-sig') as f:
        rows=list(csv.DictReader(f))
    audited=[]
    for r in rows:
        missing=[]
        for k in ['claim','evidence','scope','limitation']:
            if not r.get(k,'').strip(): missing.append(k)
        audited.append({**r, 'audit_status':'PASS' if not missing else 'FAIL', 'missing_fields':';'.join(missing)})
    with out.open('w', newline='', encoding='utf-8-sig') as f:
        w=csv.DictWriter(f, fieldnames=audited[0].keys()); w.writeheader(); w.writerows(audited)
    print(f"PASS={sum(r['audit_status']=='PASS' for r in audited)}/{len(audited)}")

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--input',default='data/claim_evidence_map.csv'); ap.add_argument('--out',default='results/claim_evidence_audit.csv'); a=ap.parse_args(); main(Path(a.input),Path(a.out))
