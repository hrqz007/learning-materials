#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Lesson 52: paper-project readiness audit.

This is a controlled teaching project-management simulation. It does NOT assess
any real user's paper and does NOT evaluate any real model/product performance.
"""
from __future__ import annotations
import json, csv, hashlib, argparse
from pathlib import Path

WEIGHTS = {
    "phenomenon_verified": 10,
    "literature_positioned": 10,
    "rq_falsifiable": 8,
    "pilot_passed": 8,
    "protocol_frozen": 10,
    "strong_baselines": 8,
    "main_experiment_complete": 12,
    "statistics_complete": 10,
    "trace_mechanism_evidence": 8,
    "claims_scoped": 6,
    "artifact_reproducible": 6,
    "submission_package_ready": 4,
}

GAP_ACTIONS = {
    "phenomenon_verified": "Return to traces; confirm the phenomenon across multiple tasks/runs.",
    "literature_positioned": "Run broader synonym/citation-chain search and update closest-work matrix.",
    "rq_falsifiable": "Rewrite the RQ/Hypothesis so a concrete result could falsify it.",
    "pilot_passed": "Run a small pilot with predeclared Go/No-Go criteria.",
    "protocol_frozen": "Freeze task set, metrics, budgets, seeds, harness/evaluator versions and stopping rule.",
    "strong_baselines": "Add a strong baseline and resource-matched baseline when relevant.",
    "main_experiment_complete": "Complete the confirmatory experiment on held-out tasks.",
    "statistics_complete": "Aggregate at the correct experimental unit; report effect sizes and uncertainty.",
    "trace_mechanism_evidence": "Inspect traces and quantify mechanism-level signals, not only final success.",
    "claims_scoped": "Build a Claim-Evidence Matrix and shrink any overbroad claims.",
    "artifact_reproducible": "Create one-command reproduction, manifests, checksums, and environment snapshot.",
    "submission_package_ready": "Prepare anonymized paper/supplement, compliance checklist, metadata and deadline plan.",
}


def sha256(path: Path) -> str:
    h = hashlib.sha256()
    with path.open('rb') as f:
        for chunk in iter(lambda: f.read(65536), b''):
            h.update(chunk)
    return h.hexdigest()


def audit(status_path: Path, out_dir: Path) -> dict:
    status = json.loads(status_path.read_text(encoding='utf-8'))
    gates = status["gates"]
    total = sum(WEIGHTS.values())
    earned = 0
    rows = []
    for gate, weight in WEIGHTS.items():
        state = gates.get(gate, False)
        if isinstance(state, (int, float)) and not isinstance(state, bool):
            fraction = max(0.0, min(1.0, float(state)))
        else:
            fraction = 1.0 if bool(state) else 0.0
        pts = weight * fraction
        earned += pts
        rows.append({
            "gate": gate,
            "weight": weight,
            "completion": round(fraction, 2),
            "points": round(pts, 2),
            "gap_action": "" if fraction >= 1 else GAP_ACTIONS[gate],
        })
    score = round(100 * earned / total, 1)
    if score >= 90:
        level = "SUBMISSION_READY_WITH_FINAL_QA"
    elif score >= 75:
        level = "CLOSE_BUT_HAS_BLOCKING_GAPS"
    elif score >= 50:
        level = "RESEARCH_IN_PROGRESS"
    else:
        level = "TOO_EARLY_TO_SUBMIT"
    result = {
        "teaching_simulation": True,
        "project_name": status.get("project_name", "Teaching Project"),
        "readiness_score": score,
        "readiness_level": level,
        "blocking_gaps": [r["gate"] for r in rows if r["completion"] < 1.0],
        "source_sha256": sha256(status_path),
    }
    out_dir.mkdir(parents=True, exist_ok=True)
    (out_dir / "readiness_report.json").write_text(json.dumps(result, ensure_ascii=False, indent=2), encoding='utf-8')
    with (out_dir / "readiness_gates.csv").open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.DictWriter(f, fieldnames=rows[0].keys())
        w.writeheader(); w.writerows(rows)
    with (out_dir / "gap_backlog.csv").open('w', newline='', encoding='utf-8-sig') as f:
        w = csv.writer(f); w.writerow(["priority", "gate", "next_action"])
        priority = 1
        for r in rows:
            if r["completion"] < 1:
                w.writerow([priority, r["gate"], r["gap_action"]]); priority += 1
    return result

if __name__ == "__main__":
    ap = argparse.ArgumentParser()
    ap.add_argument("--status", default="data/project_status.json")
    ap.add_argument("--out", default="results")
    args = ap.parse_args()
    res = audit(Path(args.status), Path(args.out))
    print(json.dumps(res, ensure_ascii=False, indent=2))
