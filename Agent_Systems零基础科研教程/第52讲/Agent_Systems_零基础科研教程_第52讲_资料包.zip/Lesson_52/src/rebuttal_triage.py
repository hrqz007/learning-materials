#!/usr/bin/env python3
# -*- coding: utf-8 -*-
"""Convert teaching review comments into a response matrix."""
from __future__ import annotations
import csv, json, argparse
from pathlib import Path

PRIORITY = {"correctness": 1, "missing_experiment": 2, "clarity": 3, "scope": 4, "presentation": 5}

def main(inp: Path, out: Path):
    comments = json.loads(inp.read_text(encoding='utf-8'))
    rows=[]
    for c in comments:
        cat=c["category"]
        rows.append({
            "priority": PRIORITY.get(cat, 9),
            "reviewer": c["reviewer"],
            "comment_id": c["id"],
            "category": cat,
            "reviewer_concern": c["text"],
            "evidence_needed": c["evidence_needed"],
            "response_plan": c["response_plan"],
            "paper_change": c["paper_change"],
        })
    rows.sort(key=lambda x:(x["priority"], x["reviewer"], x["comment_id"]))
    out.parent.mkdir(parents=True, exist_ok=True)
    with out.open('w', newline='', encoding='utf-8-sig') as f:
        w=csv.DictWriter(f, fieldnames=rows[0].keys()); w.writeheader(); w.writerows(rows)
    print(f"wrote {len(rows)} rows to {out}")

if __name__=='__main__':
    ap=argparse.ArgumentParser(); ap.add_argument('--input',default='data/review_comments.json'); ap.add_argument('--out',default='results/rebuttal_matrix.csv'); a=ap.parse_args()
    main(Path(a.input),Path(a.out))
