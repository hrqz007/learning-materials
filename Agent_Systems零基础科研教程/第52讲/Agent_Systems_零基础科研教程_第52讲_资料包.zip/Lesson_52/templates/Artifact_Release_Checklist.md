# Artifact Release Checklist

- [ ] Inventory: every file/directory has a purpose.
- [ ] README starts with a 5-minute smoke test.
- [ ] Expected runtime and resource requirements are stated.
- [ ] Environment/dependency versions are pinned or recorded.
- [ ] Raw vs derived artifacts are separated.
- [ ] Scripts regenerate each reported figure/table.
- [ ] Checksums/manifest are generated.
- [ ] Secrets/API keys are absent.
- [ ] Paths and usernames are scrubbed.
- [ ] Double-blind version is anonymized when required.
- [ ] Data/model licenses and access conditions are stated.
- [ ] Public archival location/DOI is used when venue/artifact policy calls for durable availability.
