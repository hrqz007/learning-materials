# Research Charter

## 1. Observed phenomenon
What did you actually observe? Separate fact from interpretation.

## 2. Research question
Write one falsifiable RQ.

## 3. Hypothesis and falsifier
- Hypothesis:
- What result would count against it?

## 4. Closest prior work
- Closest paper/system:
- Same phenomenon?
- Same mechanism?
- Same evaluation?
- What remains unresolved?

## 5. Pilot
- Independent tasks:
- Repeats per task:
- Baselines:
- Mechanism metrics:
- Go/No-Go criteria:

## 6. Main experiment
- Experimental unit:
- Primary endpoint:
- SESOI:
- Resource matching:
- Frozen factors:
- Planned slices/ablations:

## 7. Claim ceiling
What is the strongest claim the planned evidence could justify?

## 8. Stop conditions
What evidence would make you stop or redesign the project?
