# Review / Rebuttal Principles

1. Correctness first: address factual/technical errors before presentation issues.
2. Restate the concern fairly; do not fight a stronger version you invented.
3. Answer with evidence: point to table/figure/analysis or explicitly concede a limitation.
4. Do not promise experiments you cannot finish or that the venue disallows.
5. Separate: misunderstanding -> clarification; missing evidence -> new analysis/limitation; true flaw -> correction.
6. Keep scope precise. A narrower defensible claim is better than a broad fragile claim.
7. Update the paper, not only the rebuttal, when the process allows it.
