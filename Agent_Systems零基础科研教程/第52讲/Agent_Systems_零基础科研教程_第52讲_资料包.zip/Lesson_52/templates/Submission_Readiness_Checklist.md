# Submission Readiness Checklist

## Scientific
- [ ] RQ is explicit and falsifiable.
- [ ] Closest prior work is identified using more than exact-keyword search.
- [ ] Experimental unit is correct.
- [ ] Strong and resource-matched baselines are included when relevant.
- [ ] Primary endpoint was not switched after seeing results.
- [ ] Effect size + uncertainty are reported.
- [ ] Failure/trace evidence supports mechanism discussion.
- [ ] Negative/null/mixed results are not hidden.
- [ ] Limitations and boundary conditions are explicit.

## Reproducibility
- [ ] Frozen config/manifest exists.
- [ ] Exact model/API/harness/evaluator/tool versions are recorded.
- [ ] Seeds/repeats/timeouts/retry/concurrency/budgets are recorded.
- [ ] One-command smoke test works.
- [ ] Figure/table generation is scripted.
- [ ] Artifact was tested in a clean environment.
- [ ] License/data access restrictions are documented.

## Submission
- [ ] Current venue instructions checked directly from official website.
- [ ] Page limit/template/anonymity rules satisfied.
- [ ] Supplementary is anonymized if required.
- [ ] Author profiles/accounts are ready before deadline.
- [ ] PDF metadata and filenames do not leak identity in double-blind review.
- [ ] Conflict-of-interest information is current.
- [ ] Final PDF rendered and inspected page by page.
