《大数据综合项目实战》第1讲 Starter Pack

目录：
  data/users.csv
  data/products.csv
  data/orders_history.csv
  data/order_events.jsonl
  scripts/01_verify_data.py

建议操作：
1. 解压到 Ubuntu 虚拟机的 ~/bigdata-capstone/ 目录。
2. 在 VS Code Remote SSH 中打开该目录。
3. 终端执行：python3 scripts/01_verify_data.py
4. 标准答案应包含：
   PAID订单数 = 10
   Beijing: 6874
   Guangzhou: 676
   Shanghai: 6984
   Shenzhen: 299
   总销售额 = 14833
   实时事件条数 = 8
