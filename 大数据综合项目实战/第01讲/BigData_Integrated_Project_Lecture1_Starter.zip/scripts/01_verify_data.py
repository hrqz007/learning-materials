import csv, json
from pathlib import Path

root = Path(__file__).resolve().parent.parent / 'data'

# 1) 基础文件存在性
files = ['users.csv', 'products.csv', 'orders_history.csv', 'order_events.jsonl']
for name in files:
    path = root / name
    assert path.exists(), f'缺少文件: {path}'
    print(f'[OK] {name}: {path.stat().st_size} bytes')

# 2) 读取商品价格
prices = {}
with open(root/'products.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        prices[row['product_id']] = int(row['unit_price'])

# 3) 手算历史已支付订单的城市销售额
city_total = {}
paid_count = 0
with open(root/'orders_history.csv', encoding='utf-8') as f:
    for row in csv.DictReader(f):
        if row['status'] != 'PAID':
            continue
        paid_count += 1
        amount = int(row['quantity']) * prices[row['product_id']]
        city_total[row['city']] = city_total.get(row['city'], 0) + amount

print('\n历史数据标准答案：')
print('PAID订单数 =', paid_count)
for city in sorted(city_total):
    print(f'{city}: {city_total[city]}')
print('总销售额 =', sum(city_total.values()))

# 4) 验证 JSONL
n = 0
with open(root/'order_events.jsonl', encoding='utf-8') as f:
    for line in f:
        event = json.loads(line)
        for key in ['event_id','order_id','user_id','city','amount','event_type','event_time']:
            assert key in event, f'实时事件缺字段: {key}'
        n += 1
print(f'\n实时事件条数 = {n}')
print('[PASS] 数据包结构与标准答案校验通过')
