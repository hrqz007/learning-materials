#!/usr/bin/env bash
set -e

# 《大数据综合项目实战》第2讲辅助脚本
# 目的：在你已经手工理解每一步以后，用于快速重复实验。
# 不负责自动启动 Hadoop 服务。

cd "$HOME/bigdata-capstone"

echo "[1/5] 本地数据"
ls -lh data/users.csv data/products.csv data/orders_history.csv

echo "[2/5] 创建 HDFS 目录"
hdfs dfs -mkdir -p /bigdata-capstone/raw/users
hdfs dfs -mkdir -p /bigdata-capstone/raw/products
hdfs dfs -mkdir -p /bigdata-capstone/raw/orders
hdfs dfs -mkdir -p /bigdata-capstone/output/mapreduce
hdfs dfs -mkdir -p /bigdata-capstone/output/spark
hdfs dfs -mkdir -p /bigdata-capstone/tmp

echo "[3/5] 上传"
hdfs dfs -put -f data/users.csv /bigdata-capstone/raw/users/
hdfs dfs -put -f data/products.csv /bigdata-capstone/raw/products/
hdfs dfs -put -f data/orders_history.csv /bigdata-capstone/raw/orders/

echo "[4/5] HDFS 目录"
hdfs dfs -ls -R /bigdata-capstone/raw

echo "[5/5] 行数验证"
echo -n "users HDFS lines: "
hdfs dfs -cat /bigdata-capstone/raw/users/users.csv | wc -l
echo -n "products HDFS lines: "
hdfs dfs -cat /bigdata-capstone/raw/products/products.csv | wc -l
echo -n "orders HDFS lines: "
hdfs dfs -cat /bigdata-capstone/raw/orders/orders_history.csv | wc -l

echo "完成。进一步检查 Block："
echo "hdfs fsck /bigdata-capstone/raw -files -blocks -locations"
