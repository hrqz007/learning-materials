第2讲辅助工具

文件：02_hdfs_prepare_and_verify.sh

用法：
1. 先按 PDF 手工完成一遍，理解每条命令。
2. 把脚本放到 ~/bigdata-capstone/ 目录或任意位置。
3. chmod +x 02_hdfs_prepare_and_verify.sh
4. ./02_hdfs_prepare_and_verify.sh

注意：脚本不会自动启动 HDFS/YARN；请先手工启动并验证服务。
