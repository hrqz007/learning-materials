#!/usr/bin/env bash
set -euo pipefail

# 《大数据综合项目实战》第3讲辅助脚本
# 建议：先按照 PDF 手工完成一遍，再使用本脚本重复实验。

PROJECT="$HOME/bigdata-capstone"
WORK="$PROJECT/mapreduce/lecture3"
SRC="$WORK/src/CityPaidSales.java"
BUILD="$WORK/build"
JAR="$WORK/CityPaidSales.jar"
ORDERS="/bigdata-capstone/raw/orders/orders_history.csv"
PRODUCTS="hdfs:///bigdata-capstone/raw/products/products.csv"
OUTPUT="/bigdata-capstone/output/mapreduce/city_paid_sales"

cd "$WORK"

echo "[1/7] 检查 HDFS 输入"
hdfs dfs -test -e "$ORDERS" || { echo "缺少 $ORDERS"; exit 1; }
hdfs dfs -test -e /bigdata-capstone/raw/products/products.csv || { echo "缺少 products.csv"; exit 1; }

echo "[2/7] 清理并编译"
rm -rf "$BUILD"
mkdir -p "$BUILD"
javac -encoding UTF-8 -classpath "$(hadoop classpath)" -d "$BUILD" "$SRC"

echo "[3/7] 打 Jar"
rm -f "$JAR"
jar -cvf "$JAR" -C "$BUILD" .

echo "[4/7] 清理旧输出目录"
hdfs dfs -rm -r -f "$OUTPUT" >/dev/null 2>&1 || true

echo "[5/7] 提交 MapReduce Job"
hadoop jar "$JAR" CityPaidSales "$ORDERS" "$OUTPUT" "$PRODUCTS"

echo "[6/7] 输出结果"
hdfs dfs -cat "$OUTPUT"/part-r-00000

echo "[7/7] 业务总额"
hdfs dfs -cat "$OUTPUT"/part-r-00000 | awk '{sum += $2} END {print "TOTAL=" sum}'

echo "标准答案 TOTAL=14833"
