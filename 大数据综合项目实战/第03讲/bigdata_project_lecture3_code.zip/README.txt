《大数据综合项目实战》第3讲辅助代码包

文件：
- src/CityPaidSales.java：完整 Java MapReduce 源码
- 03_compile_and_run.sh：自动编译、打 Jar、提交、验收脚本

建议：
1. 先按 PDF 手工完成一遍，不要一上来运行脚本。
2. 确保第2讲已经把 orders_history.csv 和 products.csv 上传到 HDFS。
3. 将本包内容放到 ~/bigdata-capstone/mapreduce/lecture3/。
