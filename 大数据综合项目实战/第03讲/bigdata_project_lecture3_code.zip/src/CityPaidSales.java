import java.io.BufferedReader;
import java.io.FileReader;
import java.io.IOException;
import java.net.URI;
import java.util.HashMap;
import java.util.Map;

import org.apache.hadoop.conf.Configuration;
import org.apache.hadoop.fs.Path;
import org.apache.hadoop.io.LongWritable;
import org.apache.hadoop.io.Text;
import org.apache.hadoop.mapreduce.Job;
import org.apache.hadoop.mapreduce.Mapper;
import org.apache.hadoop.mapreduce.Reducer;
import org.apache.hadoop.mapreduce.lib.input.FileInputFormat;
import org.apache.hadoop.mapreduce.lib.output.FileOutputFormat;

/**
 * 综合项目第3讲：统计各城市 PAID 订单销售额。
 *
 * orders_history.csv 中没有单价，因此把小表 products.csv 放入 Distributed Cache，
 * 每个 Mapper 在 setup() 中加载 product_id -> unit_price，再进行 Map-side Join。
 */
public class CityPaidSales {

    // 自定义 Counter：帮助我们证明“程序到底处理了多少数据”。
    public enum DataCounter {
        INPUT_ROWS,
        HEADER_ROWS,
        NON_PAID_ROWS,
        VALID_PAID_ORDERS,
        BAD_ORDER_ROWS,
        MISSING_PRODUCT,
        PRODUCT_ROWS,
        BAD_PRODUCT_ROWS
    }

    public static class SalesMapper
            extends Mapper<LongWritable, Text, Text, LongWritable> {

        // 商品价格维度表：product_id -> unit_price
        private final Map<String, Long> productPrice = new HashMap<>();
        private final Text outCity = new Text();
        private final LongWritable outAmount = new LongWritable();

        @Override
        protected void setup(Context context) throws IOException {
            // Driver 中使用 #products.csv 指定本地别名。
            // YARN 会把 HDFS 中的小表本地化到 Mapper 工作目录。
            try (BufferedReader reader = new BufferedReader(new FileReader("products.csv"))) {
                String line;
                while ((line = reader.readLine()) != null) {
                    if (line.startsWith("product_id,")) {
                        continue; // 跳过 CSV 表头
                    }

                    String[] fields = line.split(",", -1);
                    if (fields.length != 4) {
                        context.getCounter(DataCounter.BAD_PRODUCT_ROWS).increment(1);
                        continue;
                    }

                    try {
                        String productId = fields[0].trim();
                        long unitPrice = Long.parseLong(fields[3].trim());
                        productPrice.put(productId, unitPrice);
                        context.getCounter(DataCounter.PRODUCT_ROWS).increment(1);
                    } catch (NumberFormatException e) {
                        context.getCounter(DataCounter.BAD_PRODUCT_ROWS).increment(1);
                    }
                }
            }

            if (productPrice.isEmpty()) {
                throw new IOException("products.csv was not loaded or contains no valid product rows");
            }
        }

        @Override
        protected void map(LongWritable key, Text value, Context context)
                throws IOException, InterruptedException {

            context.getCounter(DataCounter.INPUT_ROWS).increment(1);
            String line = value.toString().trim();

            if (line.isEmpty()) {
                context.getCounter(DataCounter.BAD_ORDER_ROWS).increment(1);
                return;
            }

            if (line.startsWith("order_id,")) {
                context.getCounter(DataCounter.HEADER_ROWS).increment(1);
                return;
            }

            String[] fields = line.split(",", -1);
            if (fields.length != 7) {
                context.getCounter(DataCounter.BAD_ORDER_ROWS).increment(1);
                return;
            }

            String productId = fields[3].trim();
            String quantityText = fields[4].trim();
            String status = fields[5].trim();
            String city = fields[6].trim();

            // 只统计已经支付的订单。
            if (!"PAID".equals(status)) {
                context.getCounter(DataCounter.NON_PAID_ROWS).increment(1);
                return;
            }

            try {
                long quantity = Long.parseLong(quantityText);
                Long unitPrice = productPrice.get(productId);

                if (unitPrice == null) {
                    context.getCounter(DataCounter.MISSING_PRODUCT).increment(1);
                    return;
                }

                // 当前教学数据单价单位就是“元”，且均为整数，所以用 long 精确计算。
                long amount = quantity * unitPrice;

                outCity.set(city);
                outAmount.set(amount);
                context.write(outCity, outAmount);
                context.getCounter(DataCounter.VALID_PAID_ORDERS).increment(1);

            } catch (NumberFormatException e) {
                context.getCounter(DataCounter.BAD_ORDER_ROWS).increment(1);
            }
        }
    }

    public static class SalesReducer
            extends Reducer<Text, LongWritable, Text, LongWritable> {

        private final LongWritable result = new LongWritable();

        @Override
        protected void reduce(Text city, Iterable<LongWritable> amounts, Context context)
                throws IOException, InterruptedException {

            long sum = 0L;
            for (LongWritable amount : amounts) {
                sum += amount.get();
            }

            result.set(sum);
            context.write(city, result);
        }
    }

    public static void main(String[] args) throws Exception {
        if (args.length != 3) {
            System.err.println("Usage: CityPaidSales <orders_input> <output> <products_cache_hdfs_path>");
            System.exit(2);
        }

        Configuration conf = new Configuration();
        Job job = Job.getInstance(conf, "bigdata-capstone-city-paid-sales");

        job.setJarByClass(CityPaidSales.class);
        job.setMapperClass(SalesMapper.class);

        // 求和满足结合律/交换律，所以可以安全使用同一个 Reducer 做 Combiner。
        job.setCombinerClass(SalesReducer.class);
        job.setReducerClass(SalesReducer.class);

        job.setMapOutputKeyClass(Text.class);
        job.setMapOutputValueClass(LongWritable.class);
        job.setOutputKeyClass(Text.class);
        job.setOutputValueClass(LongWritable.class);

        // 教学数据量很小，固定 1 个 Reducer，方便得到单个 part-r-00000。
        job.setNumReduceTasks(1);

        FileInputFormat.addInputPath(job, new Path(args[0]));
        FileOutputFormat.setOutputPath(job, new Path(args[1]));

        // URI fragment (#products.csv) 指定 Mapper 工作目录中的本地别名。
        job.addCacheFile(new URI(args[2] + "#products.csv"));

        System.exit(job.waitForCompletion(true) ? 0 : 1);
    }
}
