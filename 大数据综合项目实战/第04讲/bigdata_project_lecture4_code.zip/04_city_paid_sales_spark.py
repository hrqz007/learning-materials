from pyspark.sql import SparkSession
from pyspark.sql.functions import broadcast, col, sum as spark_sum
from pyspark.sql.types import StructType, StructField, StringType, IntegerType

ORDERS = "/bigdata-capstone/raw/orders/orders_history.csv"
PRODUCTS = "/bigdata-capstone/raw/products/products.csv"
OUTPUT = "/bigdata-capstone/output/spark/city_paid_sales_parquet"

orders_schema = StructType([
    StructField("order_id", StringType(), False),
    StructField("order_time", StringType(), False),
    StructField("user_id", StringType(), False),
    StructField("product_id", StringType(), False),
    StructField("quantity", IntegerType(), False),
    StructField("status", StringType(), False),
    StructField("city", StringType(), False),
])

products_schema = StructType([
    StructField("product_id", StringType(), False),
    StructField("product_name", StringType(), False),
    StructField("category", StringType(), False),
    StructField("unit_price", IntegerType(), False),
])

spark = (
    SparkSession.builder
    .appName("bigdata-capstone-spark-city-paid-sales")
    .getOrCreate()
)

spark.sparkContext.setLogLevel("WARN")

print("\n========== 1. 读取 HDFS CSV ==========")
orders = (
    spark.read
    .option("header", True)
    .schema(orders_schema)
    .csv(ORDERS)
)
products = (
    spark.read
    .option("header", True)
    .schema(products_schema)
    .csv(PRODUCTS)
)

print("orders schema:")
orders.printSchema()
print("products schema:")
products.printSchema()

orders_count = orders.count()
products_count = products.count()
print(f"orders rows = {orders_count} (expected 12)")
print(f"products rows = {products_count} (expected 5)")

print("\n========== 2. 过滤 PAID ==========")
paid = orders.filter(col("status") == "PAID")
paid_count = paid.count()
print(f"PAID rows = {paid_count} (expected 10)")

print("\n========== 3. Broadcast Join ==========")
joined = (
    paid.join(
        broadcast(products.select("product_id", "unit_price")),
        on="product_id",
        how="inner",
    )
    .withColumn("amount", col("quantity") * col("unit_price"))
)

joined_count = joined.count()
print(f"joined rows = {joined_count} (expected 10)")

print("\n========== 4. 按城市聚合 ==========")
result = (
    joined.groupBy("city")
    .agg(spark_sum("amount").alias("sales_amount"))
    .orderBy("city")
)

result.show(truncate=False)

total = result.agg(spark_sum("sales_amount").alias("total")).collect()[0]["total"]
print(f"TOTAL = {total} (expected 14833)")

expected = {
    "Beijing": 6874,
    "Guangzhou": 676,
    "Shanghai": 6984,
    "Shenzhen": 299,
}
actual = {row["city"]: row["sales_amount"] for row in result.collect()}

assert orders_count == 12, f"orders rows unexpected: {orders_count}"
assert products_count == 5, f"products rows unexpected: {products_count}"
assert paid_count == 10, f"PAID rows unexpected: {paid_count}"
assert joined_count == 10, f"joined rows unexpected: {joined_count}"
assert actual == expected, f"city totals mismatch: {actual}"
assert total == 14833, f"TOTAL mismatch: {total}"
print("[PASS] 业务标准答案全部匹配。")

print("\n========== 5. 查看 Physical Plan ==========")
result.explain(mode="formatted")

print("\n========== 6. 写入 HDFS Parquet ==========")
(
    result.write
    .mode("overwrite")
    .parquet(OUTPUT)
)
print(f"Parquet written to: {OUTPUT}")

print("\n========== 7. 回读 Parquet 验证 ==========")
check = spark.read.parquet(OUTPUT).orderBy("city")
check.show(truncate=False)
check_total = check.agg(spark_sum("sales_amount").alias("total")).collect()[0]["total"]
assert check_total == 14833, f"Parquet read-back TOTAL mismatch: {check_total}"
print(f"[PASS] Parquet read-back TOTAL = {check_total}")

spark.stop()
