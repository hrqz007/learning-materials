#!/usr/bin/env bash
set -euo pipefail

# 《大数据综合项目实战》第4讲辅助脚本
# 建议：先按 PDF 手工执行一次，再使用本脚本重复实验。

PROJECT="$HOME/bigdata-capstone"
WORK="$PROJECT/spark/lecture4"
PYFILE="$WORK/04_city_paid_sales_spark.py"

ORDERS="/bigdata-capstone/raw/orders/orders_history.csv"
PRODUCTS="/bigdata-capstone/raw/products/products.csv"
OUTPUT="/bigdata-capstone/output/spark/city_paid_sales_parquet"

cd "$WORK"

echo "[1/6] 检查 Spark 命令"
command -v spark-submit >/dev/null || { echo "找不到 spark-submit，请先检查 Spark 环境。"; exit 1; }
spark-submit --version 2>&1 | head -n 12 || true

echo "[2/6] 检查 HDFS 输入"
hdfs dfs -test -e "$ORDERS" || { echo "缺少 $ORDERS"; exit 1; }
hdfs dfs -test -e "$PRODUCTS" || { echo "缺少 $PRODUCTS"; exit 1; }

echo "[3/6] 清理旧 Spark 输出"
hdfs dfs -rm -r -f "$OUTPUT" >/dev/null 2>&1 || true

echo "[4/6] 提交 Spark on YARN"
spark-submit \
  --master yarn \
  --deploy-mode client \
  --num-executors 1 \
  --executor-cores 1 \
  --executor-memory 1g \
  "$PYFILE"

echo "[5/6] 查看 Parquet 输出目录"
hdfs dfs -ls "$OUTPUT"

echo "[6/6] 提示"
echo "标准答案：Beijing=6874, Guangzhou=676, Shanghai=6984, Shenzhen=299, TOTAL=14833"
