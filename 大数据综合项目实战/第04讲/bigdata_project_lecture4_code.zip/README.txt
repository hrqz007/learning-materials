《大数据综合项目实战》第4讲代码包

文件：
- 04_city_paid_sales_spark.py：完整 PySpark DataFrame 程序
- 04_run_spark.sh：辅助运行脚本（建议手工跑通后再使用）

前提：
1. 第2讲已经将 orders_history.csv 和 products.csv 上传到 HDFS。
2. HDFS/YARN 已正常启动。
3. spark-submit 命令可用。

推荐放置目录：
~/bigdata-capstone/spark/lecture4/
