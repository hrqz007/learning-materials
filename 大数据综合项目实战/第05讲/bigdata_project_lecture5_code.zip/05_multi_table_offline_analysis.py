from pyspark.sql import SparkSession
from pyspark.sql.functions import broadcast, col, count, sum as spark_sum, desc
from pyspark.sql.types import StructType, StructField, StringType, IntegerType
from pyspark import StorageLevel

ORDERS = "/bigdata-capstone/raw/orders/orders_history.csv"
PRODUCTS = "/bigdata-capstone/raw/products/products.csv"
USERS = "/bigdata-capstone/raw/users/users.csv"
OUT_BASE = "/bigdata-capstone/output/spark/lecture5"

orders_schema = StructType([
    StructField("order_id", StringType(), False),
    StructField("order_time", StringType(), False),
    StructField("user_id", StringType(), False),
    StructField("product_id", StringType(), False),
    StructField("quantity", IntegerType(), False),
    StructField("status", StringType(), False),
    StructField("city", StringType(), False),
])

products_schema = StructType([
    StructField("product_id", StringType(), False),
    StructField("product_name", StringType(), False),
    StructField("category", StringType(), False),
    StructField("unit_price", IntegerType(), False),
])

users_schema = StructType([
    StructField("user_id", StringType(), False),
    StructField("name", StringType(), False),
    StructField("city", StringType(), False),
    StructField("level", StringType(), False),
])

spark = SparkSession.builder.appName("bigdata-capstone-lecture5-multi-analysis").getOrCreate()
spark.sparkContext.setLogLevel("WARN")

print("\n========== 1. 读取三张 HDFS CSV ==========")
orders = spark.read.option("header", True).schema(orders_schema).csv(ORDERS)
products = spark.read.option("header", True).schema(products_schema).csv(PRODUCTS)
users = spark.read.option("header", True).schema(users_schema).csv(USERS)

orders_count = orders.count()
products_count = products.count()
users_count = users.count()
print(f"orders={orders_count} (expected 12)")
print(f"products={products_count} (expected 5)")
print(f"users={users_count} (expected 5)")
assert orders_count == 12
assert products_count == 5
assert users_count == 5

print("\n========== 2. 检查维度表主键唯一性 ==========")
product_key_count = products.select("product_id").distinct().count()
user_key_count = users.select("user_id").distinct().count()
print(f"products distinct product_id={product_key_count}")
print(f"users distinct user_id={user_key_count}")
assert product_key_count == products_count, "products.product_id 存在重复，会导致 Join 行数膨胀"
assert user_key_count == users_count, "users.user_id 存在重复，会导致 Join 行数膨胀"

print("\n========== 3. 过滤 PAID ==========")
paid = orders.filter(col("status") == "PAID")
paid_count = paid.count()
print(f"PAID rows={paid_count} (expected 10)")
assert paid_count == 10

print("\n========== 4. 两次 Broadcast Join，构造 enriched ==========")
products_dim = products.select("product_id", "product_name", "category", "unit_price")
users_dim = (
    users.select("user_id", "name", "city", "level")
    .withColumnRenamed("city", "user_city")
)

after_product = paid.join(broadcast(products_dim), on="product_id", how="inner")
after_product_count = after_product.count()
print(f"after product join={after_product_count} (expected 10)")
assert after_product_count == 10, "商品 Join 后行数不为 10：检查缺失 key 或重复 key"

enriched = (
    after_product.join(broadcast(users_dim), on="user_id", how="inner")
    .withColumn("amount", col("quantity") * col("unit_price"))
    .select(
        "order_id", "order_time", "user_id", "name", "level", "user_city",
        "product_id", "product_name", "category", "quantity", "unit_price",
        "amount", "city"
    )
)

# 本讲会从 enriched 计算 5 组结果，适合缓存复用。
enriched.persist(StorageLevel.MEMORY_AND_DISK)
enriched_count = enriched.count()  # materialize cache
print(f"after user join / enriched={enriched_count} (expected 10)")
assert enriched_count == 10, "用户 Join 后行数不为 10"

print("\n========== 5. 城市销售额 ==========")
city_sales = (
    enriched.groupBy("city")
    .agg(count("order_id").alias("paid_order_count"), spark_sum("amount").alias("total_sales"))
    .orderBy("city")
)
city_sales.show(truncate=False)

print("\n========== 6. 品类销售额 ==========")
category_sales = (
    enriched.groupBy("category")
    .agg(
        count("order_id").alias("paid_order_count"),
        spark_sum("quantity").alias("total_quantity"),
        spark_sum("amount").alias("total_sales"),
    )
    .orderBy(desc("total_sales"), "category")
)
category_sales.show(truncate=False)

print("\n========== 7. 商品销量 Top3 ==========")
product_stats = (
    enriched.groupBy("product_id", "product_name")
    .agg(spark_sum("quantity").alias("total_quantity"), spark_sum("amount").alias("total_sales"))
)
product_top3 = product_stats.orderBy(desc("total_quantity"), desc("total_sales"), "product_id").limit(3)
product_top3.show(truncate=False)

print("\n========== 8. 会员等级消费 ==========")
level_sales = (
    enriched.groupBy("level")
    .agg(count("order_id").alias("paid_order_count"), spark_sum("amount").alias("total_sales"))
    .orderBy("level")
)
level_sales.show(truncate=False)

print("\n========== 9. 用户消费排行 ==========")
user_sales = (
    enriched.groupBy("user_id", "name", "level")
    .agg(count("order_id").alias("paid_order_count"), spark_sum("amount").alias("total_sales"))
    .orderBy(desc("total_sales"), "user_id")
)
user_sales.show(truncate=False)

print("\n========== 10. 自动业务验收 ==========")
expected_city = {
    "Beijing": (4, 6874),
    "Guangzhou": (2, 676),
    "Shanghai": (3, 6984),
    "Shenzhen": (1, 299),
}
actual_city = {r["city"]: (r["paid_order_count"], r["total_sales"]) for r in city_sales.collect()}
assert actual_city == expected_city, f"city mismatch: {actual_city}"

expected_category = {
    "Digital": (4, 4, 12996),
    "Accessory": (4, 8, 1542),
    "Education": (2, 5, 295),
}
actual_category = {r["category"]: (r["paid_order_count"], r["total_quantity"], r["total_sales"]) for r in category_sales.collect()}
assert actual_category == expected_category, f"category mismatch: {actual_category}"

actual_top3 = [(r["product_id"], r["total_quantity"], r["total_sales"]) for r in product_top3.collect()]
expected_top3 = [("P002", 5, 645), ("P003", 5, 295), ("P004", 3, 897)]
assert actual_top3 == expected_top3, f"product top3 mismatch: {actual_top3}"

expected_level = {"Normal": (5, 7601), "VIP": (5, 7232)}
actual_level = {r["level"]: (r["paid_order_count"], r["total_sales"]) for r in level_sales.collect()}
assert actual_level == expected_level, f"level mismatch: {actual_level}"

expected_users = [
    ("U002", "LiSi", "Normal", 3, 6984),
    ("U001", "ZhangSan", "VIP", 2, 6257),
    ("U003", "WangWu", "VIP", 2, 676),
    ("U004", "ZhaoLiu", "Normal", 2, 617),
    ("U005", "SunQi", "VIP", 1, 299),
]
actual_users = [(r["user_id"], r["name"], r["level"], r["paid_order_count"], r["total_sales"]) for r in user_sales.collect()]
assert actual_users == expected_users, f"user ranking mismatch: {actual_users}"

assert enriched.agg(spark_sum("amount").alias("total")).collect()[0]["total"] == 14833
print("[PASS] 5 组业务结果与 TOTAL=14833 全部匹配。")

print("\n========== 11. 查看执行计划 ==========")
level_sales.explain(mode="formatted")

print("\n========== 12. 写入 5 个 Parquet 数据集 ==========")
outputs = {
    "city_sales": city_sales,
    "category_sales": category_sales,
    "product_top3": product_top3,
    "level_sales": level_sales,
    "user_sales": user_sales,
}
for name, df in outputs.items():
    path = f"{OUT_BASE}/{name}"
    df.write.mode("overwrite").parquet(path)
    print(f"written: {path}")

print("\n========== 13. 回读 Parquet 验证 ==========")
check_city = spark.read.parquet(f"{OUT_BASE}/city_sales").orderBy("city")
check_city.show(truncate=False)
check_total = check_city.agg(spark_sum("total_sales").alias("total")).collect()[0]["total"]
assert check_total == 14833
print(f"[PASS] Parquet read-back TOTAL={check_total}")

enriched.unpersist()
spark.stop()
