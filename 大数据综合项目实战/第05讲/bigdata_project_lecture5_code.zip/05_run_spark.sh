#!/usr/bin/env bash
set -euo pipefail

# 《大数据综合项目实战》第5讲辅助脚本
# 第一次建议严格按 PDF 手工执行，跑通后再用脚本复现实验。

WORK="$HOME/bigdata-capstone/spark/lecture5"
PYFILE="$WORK/05_multi_table_offline_analysis.py"
OUT_BASE="/bigdata-capstone/output/spark/lecture5"

cd "$WORK"

echo "[1/7] 检查 Spark / Hadoop"
command -v spark-submit >/dev/null || { echo "找不到 spark-submit"; exit 1; }
command -v hdfs >/dev/null || { echo "找不到 hdfs"; exit 1; }

spark-submit --version 2>&1 | head -n 12 || true

echo "[2/7] 检查三张 HDFS 输入表"
for f in \
  /bigdata-capstone/raw/orders/orders_history.csv \
  /bigdata-capstone/raw/products/products.csv \
  /bigdata-capstone/raw/users/users.csv; do
  hdfs dfs -test -e "$f" || { echo "缺少 HDFS 输入：$f"; exit 1; }
done

echo "[3/7] 清理旧输出"
hdfs dfs -rm -r -f "$OUT_BASE" >/dev/null 2>&1 || true

echo "[4/7] 提交 Spark on YARN"
spark-submit \
  --master yarn \
  --deploy-mode client \
  --num-executors 1 \
  --executor-cores 1 \
  --executor-memory 1g \
  --driver-memory 1g \
  "$PYFILE"

echo "[5/7] 查看 5 个输出目录"
hdfs dfs -ls "$OUT_BASE"

echo "[6/7] 递归查看 Parquet 文件"
hdfs dfs -ls -R "$OUT_BASE" | head -n 80

echo "[7/7] 标准答案提醒"
echo "TOTAL=14833；VIP=7232；Normal=7601；Top3 by quantity=P002,P003,P004"
