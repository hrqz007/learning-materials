《大数据综合项目实战》第5讲代码包

文件：
- 05_multi_table_offline_analysis.py：完整三表 Spark DataFrame 离线分析程序
- 05_run_spark.sh：辅助运行脚本（第一次请先按 PDF 手工操作）
- expected_results.txt：标准答案速查

推荐目录：
~/bigdata-capstone/spark/lecture5/

前提：
1. HDFS 中已存在 orders_history.csv、products.csv、users.csv。
2. HDFS/YARN 已启动。
3. spark-submit 可用。
