《大数据综合项目实战》第6讲代码包 - Kafka 实时事件链

推荐目录：~/bigdata-capstone/kafka/lecture6/

文件：
- data/order_events.jsonl：8 条基础事件（与第1讲一致）
- data/order_events_extra.jsonl：3 条用于 Lag 演示的新增事件
- scripts/06_kafka_doctor.sh：检查 Kafka 命令、Java、9092、进程
- scripts/06_create_topic.sh：创建 orders_raw（3 partitions）
- scripts/06_prepare_keyed_events.py：把 JSONL 转成 order_id|json，供 console producer 使用
- scripts/06_produce_events.sh：批量发送 JSONL
- scripts/06_consume_from_beginning.sh：从头读固定条数并打印 key/partition/offset
- scripts/06_consume_group.sh：使用 Consumer Group 消费
- scripts/06_show_group_lag.sh：查看 CURRENT-OFFSET / LOG-END-OFFSET / LAG

第一次请严格跟 PDF 手工操作。脚本用于第二遍复现。
