#!/usr/bin/env bash
set -euo pipefail

find_kafka_cmd() {
  local name="$1"
  if command -v "$name" >/dev/null 2>&1; then command -v "$name"; return 0; fi
  local roots=()
  [[ -n "${KAFKA_HOME:-}" ]] && roots+=("$KAFKA_HOME")
  roots+=("/opt/kafka" "/usr/local/kafka" "$HOME/kafka")
  for r in "${roots[@]}"; do
    [[ -x "$r/bin/$name" ]] && { echo "$r/bin/$name"; return 0; }
  done
  return 1
}

KAFKA_TOPICS="$(find_kafka_cmd kafka-topics.sh || true)"
KAFKA_PRODUCER="$(find_kafka_cmd kafka-console-producer.sh || true)"
KAFKA_CONSUMER="$(find_kafka_cmd kafka-console-consumer.sh || true)"
KAFKA_GROUPS="$(find_kafka_cmd kafka-consumer-groups.sh || true)"

if [[ -z "$KAFKA_TOPICS" ]]; then
  echo "[ERROR] 找不到 Kafka 命令。请先设置 KAFKA_HOME，例如：export KAFKA_HOME=/opt/kafka" >&2
  exit 1
fi

echo "Kafka topics command: $KAFKA_TOPICS"
echo "Kafka version:"
"$KAFKA_TOPICS" --version || true

echo "Java:"
java -version 2>&1 | head -n 3 || true

echo "9092 端口："
ss -lnt 2>/dev/null | grep ':9092' || echo "[WARN] 当前没有看到 9092 监听"

echo "jps："
jps || true

echo
cat <<'TXT'
启动模式提示：
- 如果 Kafka 已经在运行，不要重复启动。
- 如果是已有课程 VM，请沿用 VM 已配置好的 Kafka 启动方式。
- 不要在本讲重新 format KRaft storage；这可能破坏已有 Kafka 数据。
TXT
