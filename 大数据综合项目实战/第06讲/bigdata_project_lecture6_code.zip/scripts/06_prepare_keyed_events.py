#!/usr/bin/env python3
import json, sys
if len(sys.argv) != 2:
    raise SystemExit("用法: python3 06_prepare_keyed_events.py data/order_events.jsonl")
path=sys.argv[1]
count=0
with open(path,encoding='utf-8') as f:
    for lineno,line in enumerate(f,1):
        line=line.strip()
        if not line: continue
        obj=json.loads(line)
        if 'order_id' not in obj:
            raise ValueError(f"第{lineno}行缺 order_id")
        # stdout 只输出 Kafka producer 需要的 key|value，避免混入日志。
        print(f"{obj['order_id']}|{json.dumps(obj, ensure_ascii=False, separators=(',',':'))}")
        count += 1
print(f"[INFO] prepared {count} events", file=sys.stderr)
