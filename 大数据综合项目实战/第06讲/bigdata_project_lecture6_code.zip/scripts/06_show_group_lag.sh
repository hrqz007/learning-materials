#!/usr/bin/env bash
set -euo pipefail

find_kafka_cmd() {
  local name="$1"
  if command -v "$name" >/dev/null 2>&1; then command -v "$name"; return 0; fi
  local roots=()
  [[ -n "${KAFKA_HOME:-}" ]] && roots+=("$KAFKA_HOME")
  roots+=("/opt/kafka" "/usr/local/kafka" "$HOME/kafka")
  for r in "${roots[@]}"; do
    [[ -x "$r/bin/$name" ]] && { echo "$r/bin/$name"; return 0; }
  done
  return 1
}

KAFKA_TOPICS="$(find_kafka_cmd kafka-topics.sh || true)"
KAFKA_PRODUCER="$(find_kafka_cmd kafka-console-producer.sh || true)"
KAFKA_CONSUMER="$(find_kafka_cmd kafka-console-consumer.sh || true)"
KAFKA_GROUPS="$(find_kafka_cmd kafka-consumer-groups.sh || true)"

if [[ -z "$KAFKA_TOPICS" ]]; then
  echo "[ERROR] 找不到 Kafka 命令。请先设置 KAFKA_HOME，例如：export KAFKA_HOME=/opt/kafka" >&2
  exit 1
fi

BOOTSTRAP="${BOOTSTRAP:-localhost:9092}"
GROUP="${GROUP:-capstone-l6}"
"$KAFKA_GROUPS" --bootstrap-server "$BOOTSTRAP" --describe --group "$GROUP"
