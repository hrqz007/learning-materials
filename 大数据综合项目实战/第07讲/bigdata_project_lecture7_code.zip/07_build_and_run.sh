#!/usr/bin/env bash
set -euo pipefail
: "${FLINK_HOME:?请先 export FLINK_HOME=/你的/flink目录}"

SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$SCRIPT_DIR"

echo "[1/4] Java:"
java -version

echo "[2/4] Flink:"
"$FLINK_HOME/bin/flink" --version

echo "[3/4] Maven package..."
mvn -DskipTests clean package

JAR=$(ls -1 target/flink-kafka-city-sales-*-all.jar | head -1)
echo "[4/4] Submit: $JAR"
"$FLINK_HOME/bin/flink" run -d \
  -c edu.project.realtime.CitySalesRealtimeJob \
  "$JAR"
