#!/usr/bin/env python3
import argparse, json, sys, time

p = argparse.ArgumentParser()
p.add_argument("file")
p.add_argument("--delay", type=float, default=1.0)
args = p.parse_args()

with open(args.file, "r", encoding="utf-8") as f:
    for raw in f:
        raw = raw.strip()
        if not raw:
            continue
        obj = json.loads(raw)
        # kafka-console-producer 将 | 左边当 key，右边当 value。
        print(f"{obj['order_id']}|{raw}", flush=True)
        time.sleep(args.delay)
