#!/usr/bin/env bash
set -euo pipefail
: "${KAFKA_HOME:?请先 export KAFKA_HOME=/你的/kafka目录}"
BOOTSTRAP="${BOOTSTRAP:-localhost:9092}"
TOPIC="orders_raw_l7"

"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --delete --topic "$TOPIC" >/dev/null 2>&1 || true
sleep 2
"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --create --if-not-exists \
  --topic "$TOPIC" --partitions 3 --replication-factor 1
"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --describe --topic "$TOPIC"
