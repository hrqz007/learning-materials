#!/usr/bin/env bash
set -euo pipefail
: "${KAFKA_HOME:?请先 export KAFKA_HOME=/你的/kafka目录}"
BOOTSTRAP="${BOOTSTRAP:-localhost:9092}"
TOPIC="orders_raw_l7"
SCRIPT_DIR="$(cd "$(dirname "$0")" && pwd)"

python3 "$SCRIPT_DIR/07_emit_keyed_events.py" \
  "$SCRIPT_DIR/data/late_event_after_watermark.jsonl" --delay 0 \
| "$KAFKA_HOME/bin/kafka-console-producer.sh" \
    --bootstrap-server "$BOOTSTRAP" \
    --topic "$TOPIC" \
    --property parse.key=true \
    --property key.separator='|'
