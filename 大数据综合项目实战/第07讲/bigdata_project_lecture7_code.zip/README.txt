《大数据综合项目实战》第7讲代码包

目录：
- pom.xml
- src/main/java/edu/project/realtime/CitySalesRealtimeJob.java
- data/order_events_window_demo.jsonl
- data/late_event_after_watermark.jsonl
- 07_emit_keyed_events.py
- 07_reset_topic.sh
- 07_send_demo_events.sh
- 07_send_late_event.sh
- 07_build_and_run.sh

建议：
1. 第一次严格按 PDF 手工执行，不要直接跑脚本。
2. 确认 Kafka、Flink 与 Java 版本后，再执行 Maven 构建。
3. 本项目 pom 默认：Flink 1.20.3 + Kafka Connector 3.4.0-1.20 + Java 11。
   若你的 Flink 版本不同，请把 pom.xml 中两个版本属性改成与实际环境匹配的版本。
4. 教学 Topic：orders_raw_l7。为保证标准答案可复现，建议每次实验前重建该 Topic。
5. Flink 结果通过 print() 输出到 TaskManager stdout；单机 standalone 可到 $FLINK_HOME/log/ 下查看 taskexecutor 的 .out 文件。

标准输出应包含：
- [10:01:00,10:02:00) Beijing 1单 258.00
- [10:01:00,10:02:00) Shanghai 1单 499.00
- [10:02:00,10:03:00) Beijing 1单 118.00

late_event_after_watermark.jsonl 中的 E010 属于已经关闭的 [10:01,10:02) 窗口，默认 allowed lateness=0 时不会修正已输出窗口。
