package edu.project.realtime;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.functions.FilterFunction;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.java.tuple.Tuple2;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.flink.api.common.serialization.SimpleStringSchema;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class CitySalesRealtimeJob {

    private static final String BOOTSTRAP_SERVERS = "localhost:9092";
    private static final String TOPIC = "orders_raw_l7";
    private static final String GROUP_ID = "flink-city-sales-l7";
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");
    private static final DateTimeFormatter EVENT_TIME_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 教学演示先固定为 1，保证输出和 Watermark 推演最容易观察。
        // 理解以后可改成 2/3，再观察 Kafka 多分区下的 Watermark 与并行度。
        env.setParallelism(1);
        env.getConfig().setAutoWatermarkInterval(1000L);

        KafkaSource<String> source = KafkaSource.<String>builder()
                .setBootstrapServers(BOOTSTRAP_SERVERS)
                .setTopics(TOPIC)
                .setGroupId(GROUP_ID)
                .setStartingOffsets(OffsetsInitializer.earliest())
                .setValueOnlyDeserializer(new SimpleStringSchema())
                .build();

        DataStream<String> raw = env.fromSource(
                source,
                WatermarkStrategy.noWatermarks(),
                "Kafka orders_raw_l7"
        );

        DataStream<OrderEvent> parsed = raw
                .map(new ParseOrderEvent())
                .name("parse-json");

        // 先分配 Event Time / Watermark，再过滤 PAY。
        // 这样 CREATE/CANCEL 等非 PAY 事件也能推进“事件时间进度”。
        WatermarkStrategy<OrderEvent> wm = WatermarkStrategy
                .<OrderEvent>forBoundedOutOfOrderness(Duration.ofSeconds(5))
                .withTimestampAssigner(new SerializableTimestampAssigner<OrderEvent>() {
                    @Override
                    public long extractTimestamp(OrderEvent element, long recordTimestamp) {
                        return element.eventTimeMillis;
                    }
                })
                .withIdleness(Duration.ofSeconds(20));

        DataStream<OrderEvent> withWatermarks = parsed
                .assignTimestampsAndWatermarks(wm)
                .name("event-time-watermarks");

        DataStream<OrderEvent> paid = withWatermarks
                .filter((FilterFunction<OrderEvent>) e -> "PAY".equals(e.eventType))
                .name("filter-pay");

        DataStream<CitySalesResult> result = paid
                .keyBy(e -> e.city)
                .window(TumblingEventTimeWindows.of(Duration.ofMinutes(1)))
                .aggregate(new SalesAgg(), new AddWindowInfo())
                .name("city-1min-sales");

        result.print("CITY_SALES").name("stdout-sink");

        env.execute("BigData Project L7 - Realtime City Sales");
    }

    /** JSON -> OrderEvent。金额转成“分”的 long，避免直接用 double 做金额累计。 */
    public static class ParseOrderEvent implements MapFunction<String, OrderEvent> {
        private transient ObjectMapper mapper;

        @Override
        public OrderEvent map(String value) throws Exception {
            if (mapper == null) {
                mapper = new ObjectMapper();
            }
            JsonNode n = mapper.readTree(value);

            OrderEvent e = new OrderEvent();
            e.eventId = n.get("event_id").asText();
            e.orderId = n.get("order_id").asText();
            e.userId = n.get("user_id").asText();
            e.city = n.get("city").asText();
            e.eventType = n.get("event_type").asText();
            e.eventTime = n.get("event_time").asText();

            BigDecimal amountYuan = new BigDecimal(n.get("amount").asText());
            e.amountCents = amountYuan.movePointRight(2).longValueExact();

            LocalDateTime ldt = LocalDateTime.parse(e.eventTime, EVENT_TIME_FMT);
            e.eventTimeMillis = ldt.atZone(BUSINESS_ZONE).toInstant().toEpochMilli();
            return e;
        }
    }

    /** 增量聚合：acc.f0 = 订单数，acc.f1 = 销售额（分）。 */
    public static class SalesAgg implements AggregateFunction<OrderEvent, Tuple2<Long, Long>, Tuple2<Long, Long>> {
        @Override
        public Tuple2<Long, Long> createAccumulator() {
            return Tuple2.of(0L, 0L);
        }

        @Override
        public Tuple2<Long, Long> add(OrderEvent value, Tuple2<Long, Long> acc) {
            return Tuple2.of(acc.f0 + 1L, acc.f1 + value.amountCents);
        }

        @Override
        public Tuple2<Long, Long> getResult(Tuple2<Long, Long> acc) {
            return acc;
        }

        @Override
        public Tuple2<Long, Long> merge(Tuple2<Long, Long> a, Tuple2<Long, Long> b) {
            return Tuple2.of(a.f0 + b.f0, a.f1 + b.f1);
        }
    }

    /** 给聚合结果补上 city 与窗口起止时间。 */
    public static class AddWindowInfo
            extends ProcessWindowFunction<Tuple2<Long, Long>, CitySalesResult, String, TimeWindow> {

        @Override
        public void process(String city,
                            Context context,
                            Iterable<Tuple2<Long, Long>> elements,
                            Collector<CitySalesResult> out) {
            Tuple2<Long, Long> agg = elements.iterator().next();

            CitySalesResult r = new CitySalesResult();
            r.city = city;
            r.windowStart = formatMillis(context.window().getStart());
            r.windowEnd = formatMillis(context.window().getEnd());
            r.paidOrderCount = agg.f0;
            r.salesCents = agg.f1;
            out.collect(r);
        }
    }

    private static String formatMillis(long millis) {
        return EVENT_TIME_FMT.format(
                Instant.ofEpochMilli(millis).atZone(BUSINESS_ZONE).toLocalDateTime()
        );
    }

    public static class OrderEvent {
        public String eventId;
        public String orderId;
        public String userId;
        public String city;
        public long amountCents;
        public String eventType;
        public String eventTime;
        public long eventTimeMillis;

        public OrderEvent() {}
    }

    public static class CitySalesResult {
        public String city;
        public String windowStart;
        public String windowEnd;
        public long paidOrderCount;
        public long salesCents;

        public CitySalesResult() {}

        @Override
        public String toString() {
            return String.format(
                    "window=[%s, %s), city=%s, paid_orders=%d, sales=%.2f",
                    windowStart,
                    windowEnd,
                    city,
                    paidOrderCount,
                    salesCents / 100.0
            );
        }
    }
}
