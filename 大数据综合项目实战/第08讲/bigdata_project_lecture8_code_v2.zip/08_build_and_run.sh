#!/usr/bin/env bash
set -euo pipefail

: "${FLINK_HOME:?请先设置 FLINK_HOME}"
DIR="$(cd "$(dirname "$0")" && pwd)"
cd "$DIR"

mvn -DskipTests clean package
JAR="target/flink-order-timeout-alert-1.0-SNAPSHOT-all.jar"

"$FLINK_HOME/bin/flink" run -d \
  -c edu.project.realtime.OrderTimeoutAlertJob \
  "$JAR"
