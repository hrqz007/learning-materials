#!/usr/bin/env python3
import json
import sys
import time

if len(sys.argv) < 2:
    print("用法: python3 08_emit_keyed_events.py <jsonl文件> [每条间隔秒数]", file=sys.stderr)
    sys.exit(1)

path = sys.argv[1]
delay = float(sys.argv[2]) if len(sys.argv) >= 3 else 1.0

with open(path, "r", encoding="utf-8") as f:
    for raw in f:
        raw = raw.strip()
        if not raw:
            continue
        obj = json.loads(raw)
        order_id = obj["order_id"]
        print(f"{order_id}|{raw}", flush=True)
        time.sleep(delay)
