#!/usr/bin/env bash
set -euo pipefail

: "${KAFKA_HOME:?请先设置 KAFKA_HOME}"
TOPIC="orders_timeout_l8"
BOOTSTRAP="localhost:9092"

"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --delete --topic "$TOPIC" || true
sleep 2
"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" \
  --create --if-not-exists --topic "$TOPIC" \
  --partitions 3 --replication-factor 1

"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server "$BOOTSTRAP" --describe --topic "$TOPIC"
