#!/usr/bin/env bash
set -euo pipefail

: "${KAFKA_HOME:?请先设置 KAFKA_HOME}"
DIR="$(cd "$(dirname "$0")" && pwd)"

python3 "$DIR/08_emit_keyed_events.py" "$DIR/data/late_pay_after_timeout.jsonl" 0 | \
  "$KAFKA_HOME/bin/kafka-console-producer.sh" \
    --bootstrap-server localhost:9092 \
    --topic orders_timeout_l8 \
    --property parse.key=true \
    --property key.separator='|'
