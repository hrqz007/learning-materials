《大数据综合项目实战》第8讲：订单15分钟未支付自动告警

目录：
- pom.xml
- src/main/java/edu/project/realtime/OrderTimeoutAlertJob.java
- data/order_timeout_demo.jsonl
- data/late_pay_after_timeout.jsonl
- 08_emit_keyed_events.py
- 08_reset_topic.sh
- 08_send_demo_events.sh
- 08_send_late_pay.sh
- 08_build_and_run.sh
- expected_results.txt

第一次请严格按照 PDF 手工执行，不要直接一键运行脚本。
脚本主要用于第二遍复现实验。

版本策略与第7讲保持一致：
- Flink 1.20.3
- flink-connector-kafka 3.4.0-1.20
- Java 11

如果你的 VM 中实际版本不同，请先根据 PDF 的“版本适配”部分调整 pom.xml。
