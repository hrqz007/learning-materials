package edu.project.realtime;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.MapFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;

import java.math.BigDecimal;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class OrderTimeoutAlertJob {

    private static final String BOOTSTRAP_SERVERS = "localhost:9092";
    private static final String TOPIC = "orders_timeout_l8";
    private static final String GROUP_ID = "flink-order-timeout-l8";
    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");
    private static final DateTimeFormatter EVENT_TIME_FMT =
            DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final long TIMEOUT_MILLIS = Duration.ofMinutes(15).toMillis();

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();

        // 教学演示固定并行度 1，便于观察 Watermark 与 Event-Time Timer。
        env.setParallelism(1);
        env.getConfig().setAutoWatermarkInterval(200L);

        // 让 State / Timer / Kafka Source Offset 可以被周期性快照。
        env.enableCheckpointing(5000L, CheckpointingMode.EXACTLY_ONCE);

        KafkaSource<String> source = KafkaSource.<String>builder()
                .setBootstrapServers(BOOTSTRAP_SERVERS)
                .setTopics(TOPIC)
                .setGroupId(GROUP_ID)
                .setStartingOffsets(OffsetsInitializer.earliest())
                .setValueOnlyDeserializer(new SimpleStringSchema())
                .build();

        DataStream<String> raw = env.fromSource(
                source,
                WatermarkStrategy.noWatermarks(),
                "Kafka orders_timeout_l8"
        );

        DataStream<OrderEvent> parsed = raw
                .map(new ParseOrderEvent())
                .name("parse-json");

        WatermarkStrategy<OrderEvent> wm = WatermarkStrategy
                .<OrderEvent>forBoundedOutOfOrderness(Duration.ofSeconds(5))
                .withTimestampAssigner(new SerializableTimestampAssigner<OrderEvent>() {
                    @Override
                    public long extractTimestamp(OrderEvent element, long recordTimestamp) {
                        return element.eventTimeMillis;
                    }
                })
                .withIdleness(Duration.ofSeconds(20));

        DataStream<OrderEvent> withWatermarks = parsed
                .assignTimestampsAndWatermarks(wm)
                .name("event-time-watermarks");

        DataStream<MonitorResult> results = withWatermarks
                .keyBy(e -> e.orderId)
                .process(new OrderTimeoutProcess())
                .name("order-timeout-state-timer");

        results.print("ORDER_MONITOR").name("stdout-sink");

        env.execute("BigData Project L8 - Order Timeout Alert");
    }

    /** JSON -> OrderEvent。金额统一转成“分”的 long。 */
    public static class ParseOrderEvent implements MapFunction<String, OrderEvent> {
        private transient ObjectMapper mapper;

        @Override
        public OrderEvent map(String value) throws Exception {
            if (mapper == null) {
                mapper = new ObjectMapper();
            }
            JsonNode n = mapper.readTree(value);

            OrderEvent e = new OrderEvent();
            e.eventId = n.get("event_id").asText();
            e.orderId = n.get("order_id").asText();
            e.userId = n.get("user_id").asText();
            e.city = n.get("city").asText();
            e.eventType = n.get("event_type").asText();
            e.eventTime = n.get("event_time").asText();

            BigDecimal amountYuan = new BigDecimal(n.get("amount").asText());
            e.amountCents = amountYuan.movePointRight(2).longValueExact();

            LocalDateTime ldt = LocalDateTime.parse(e.eventTime, EVENT_TIME_FMT);
            e.eventTimeMillis = ldt.atZone(BUSINESS_ZONE).toInstant().toEpochMilli();
            return e;
        }
    }

    /**
     * 每个 order_id 一份状态：
     * CREATE -> 保存状态 + 注册 Event-Time Timer
     * PAY    -> 删除 Timer + 清状态 + 输出 PAID_IN_TIME
     * CANCEL -> 删除 Timer + 清状态 + 输出 CANCELLED
     * Timer  -> 若状态仍在，输出 TIMEOUT_ALERT + 清状态
     */
    public static class OrderTimeoutProcess
            extends KeyedProcessFunction<String, OrderEvent, MonitorResult> {

        private transient ValueState<OrderState> orderState;

        @Override
        public void open(Configuration parameters) {
            ValueStateDescriptor<OrderState> desc =
                    new ValueStateDescriptor<>("order-state", OrderState.class);
            orderState = getRuntimeContext().getState(desc);
        }

        @Override
        public void processElement(OrderEvent e,
                                   Context ctx,
                                   Collector<MonitorResult> out) throws Exception {
            OrderState current = orderState.value();

            if ("CREATE".equals(e.eventType)) {
                // 简化策略：一个订单只接受第一次 CREATE；重复 CREATE 不重新延长超时时间。
                if (current == null) {
                    long deadline = e.eventTimeMillis + TIMEOUT_MILLIS;

                    OrderState s = new OrderState();
                    s.orderId = e.orderId;
                    s.userId = e.userId;
                    s.city = e.city;
                    s.amountCents = e.amountCents;
                    s.createTimeMillis = e.eventTimeMillis;
                    s.timerTimestamp = deadline;

                    orderState.update(s);
                    ctx.timerService().registerEventTimeTimer(deadline);
                }
                return;
            }

            if ("PAY".equals(e.eventType)) {
                if (current != null) {
                    ctx.timerService().deleteEventTimeTimer(current.timerTimestamp);
                    out.collect(MonitorResult.fromState(
                            "PAID_IN_TIME", current, e.eventTimeMillis,
                            "15分钟超时前收到 PAY，删除 Timer 并清理 State"
                    ));
                    orderState.clear();
                } else {
                    out.collect(MonitorResult.fromEvent(
                            "PAY_WITHOUT_ACTIVE_CREATE", e,
                            "当前 Key 已没有活动 CREATE 状态；可能是迟到 PAY、重复 PAY 或数据缺失"
                    ));
                }
                return;
            }

            if ("CANCEL".equals(e.eventType)) {
                if (current != null) {
                    ctx.timerService().deleteEventTimeTimer(current.timerTimestamp);
                    out.collect(MonitorResult.fromState(
                            "CANCELLED", current, e.eventTimeMillis,
                            "订单取消，删除 Timer 并清理 State"
                    ));
                    orderState.clear();
                }
            }
        }

        @Override
        public void onTimer(long timestamp,
                            OnTimerContext ctx,
                            Collector<MonitorResult> out) throws Exception {
            OrderState current = orderState.value();

            if (current != null && current.timerTimestamp == timestamp) {
                out.collect(MonitorResult.fromState(
                        "TIMEOUT_ALERT", current, timestamp,
                        "Watermark 已推进到超时点，订单仍未 PAY/CANCEL"
                ));
                orderState.clear();
            }
        }
    }

    private static String formatMillis(long millis) {
        return EVENT_TIME_FMT.format(
                Instant.ofEpochMilli(millis)
                        .atZone(BUSINESS_ZONE)
                        .toLocalDateTime()
        );
    }

    public static class OrderEvent {
        public String eventId;
        public String orderId;
        public String userId;
        public String city;
        public long amountCents;
        public String eventType;
        public String eventTime;
        public long eventTimeMillis;

        public OrderEvent() {}
    }

    public static class OrderState {
        public String orderId;
        public String userId;
        public String city;
        public long amountCents;
        public long createTimeMillis;
        public long timerTimestamp;

        public OrderState() {}
    }

    public static class MonitorResult {
        public String status;
        public String orderId;
        public String city;
        public long amountCents;
        public String createTime;
        public String actionTime;
        public String note;

        public MonitorResult() {}

        public static MonitorResult fromState(String status,
                                              OrderState s,
                                              long actionMillis,
                                              String note) {
            MonitorResult r = new MonitorResult();
            r.status = status;
            r.orderId = s.orderId;
            r.city = s.city;
            r.amountCents = s.amountCents;
            r.createTime = formatMillis(s.createTimeMillis);
            r.actionTime = formatMillis(actionMillis);
            r.note = note;
            return r;
        }

        public static MonitorResult fromEvent(String status,
                                              OrderEvent e,
                                              String note) {
            MonitorResult r = new MonitorResult();
            r.status = status;
            r.orderId = e.orderId;
            r.city = e.city;
            r.amountCents = e.amountCents;
            r.createTime = "-";
            r.actionTime = formatMillis(e.eventTimeMillis);
            r.note = note;
            return r;
        }

        @Override
        public String toString() {
            return String.format(
                    "status=%s, order_id=%s, city=%s, amount=%.2f, create_time=%s, action_time=%s, note=%s",
                    status,
                    orderId,
                    city,
                    amountCents / 100.0,
                    createTime,
                    actionTime,
                    note
            );
        }
    }
}
