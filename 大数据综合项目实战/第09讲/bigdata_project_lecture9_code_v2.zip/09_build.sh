#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mvn -DskipTests clean package
ls -lh target/*-all.jar
