#!/usr/bin/env bash
set -euo pipefail
: "${KAFKA_HOME:?Please set KAFKA_HOME first}"
"$KAFKA_HOME/bin/kafka-console-consumer.sh" \
  --bootstrap-server localhost:9092 \
  --topic city_sales_l9 \
  --from-beginning \
  --property print.key=true \
  --property key.separator=' | ' \
  --consumer-property isolation.level=read_committed
