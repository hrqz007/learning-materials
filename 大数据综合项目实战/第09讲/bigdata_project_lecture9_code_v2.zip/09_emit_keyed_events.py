#!/usr/bin/env python3
import json
import subprocess
import sys
import time

if len(sys.argv) < 3:
    print("Usage: 09_emit_keyed_events.py <topic> <jsonl_file> [delay_seconds]")
    sys.exit(1)

topic = sys.argv[1]
path = sys.argv[2]
delay = float(sys.argv[3]) if len(sys.argv) >= 4 else 0.4
kafka_home = __import__('os').environ.get('KAFKA_HOME')
if not kafka_home:
    raise SystemExit('KAFKA_HOME is not set')

cmd = [
    f"{kafka_home}/bin/kafka-console-producer.sh",
    "--bootstrap-server", "localhost:9092",
    "--topic", topic,
    "--property", "parse.key=true",
    "--property", "key.separator=|",
]

p = subprocess.Popen(cmd, stdin=subprocess.PIPE, text=True)
with open(path, encoding='utf-8') as f:
    for line in f:
        line = line.strip()
        if not line:
            continue
        obj = json.loads(line)
        key = obj['order_id']
        payload = json.dumps(obj, ensure_ascii=False, separators=(',', ':'))
        print(f"SEND {topic}: {key} -> {payload}")
        p.stdin.write(f"{key}|{payload}\n")
        p.stdin.flush()
        time.sleep(delay)
p.stdin.close()
rc = p.wait()
if rc != 0:
    raise SystemExit(rc)
