#!/usr/bin/env bash
set -euo pipefail
: "${KAFKA_HOME:?Please set KAFKA_HOME first}"

TOPICS=(orders_sales_l9 city_sales_l9 orders_timeout_l9 order_alerts_l9)
for t in "${TOPICS[@]}"; do
  "$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --delete --topic "$t" >/dev/null 2>&1 || true
done
sleep 2

"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --create --if-not-exists --topic orders_sales_l9  --partitions 3 --replication-factor 1
"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --create --if-not-exists --topic city_sales_l9   --partitions 3 --replication-factor 1
"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --create --if-not-exists --topic orders_timeout_l9 --partitions 3 --replication-factor 1
"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --create --if-not-exists --topic order_alerts_l9  --partitions 3 --replication-factor 1

"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --list | grep -E 'orders_sales_l9|city_sales_l9|orders_timeout_l9|order_alerts_l9'
