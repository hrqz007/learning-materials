#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 09_emit_keyed_events.py orders_sales_l9 data/city_sales_demo.jsonl 0.5
