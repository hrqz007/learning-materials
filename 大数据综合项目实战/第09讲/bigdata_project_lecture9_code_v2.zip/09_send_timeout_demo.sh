#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
python3 09_emit_keyed_events.py orders_timeout_l9 data/order_timeout_demo.jsonl 0.5
