USE bigdata_project;
SELECT window_start, window_end, city, order_count, sales_amount
FROM city_sales_rt
ORDER BY window_start, city;

SELECT alert_id, order_id, alert_type, city, amount, create_time, action_time
FROM order_timeout_alerts
ORDER BY action_time, order_id;
