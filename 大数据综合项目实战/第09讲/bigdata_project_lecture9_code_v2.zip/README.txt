BigData Integrated Project - Lecture 9
External Sinks: Kafka Exactly-Once + MySQL Idempotent Upsert

Files:
  pom.xml
  src/main/java/edu/project/realtime/CitySalesExternalSinkJob.java
  src/main/java/edu/project/realtime/OrderTimeoutExternalSinkJob.java
  sql/09_init_mysql.sql
  data/city_sales_demo.jsonl
  data/order_timeout_demo.jsonl
  09_reset_topics.sh
  09_emit_keyed_events.py
  09_send_city_sales_demo.sh
  09_send_timeout_demo.sh
  09_build.sh
  09_run_city_sales.sh
  09_run_timeout.sh
  09_consume_city_sales.sh
  09_consume_alerts.sh
  09_verify_mysql.sql
  expected_results.txt

Important environment variables:
  export KAFKA_HOME=...
  export FLINK_HOME=...
  export MYSQL_USER=root
  export MYSQL_PASSWORD='your-password'
  export MYSQL_URL='jdbc:mysql://localhost:3306/bigdata_project?useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true'

Recommended order:
  1) Read the PDF and do the first run manually.
  2) Initialize MySQL with sql/09_init_mysql.sql.
  3) Reset/create topics with 09_reset_topics.sh.
  4) Build once with 09_build.sh.
  5) Run CitySalesExternalSinkJob, then send city sales demo.
  6) Verify Kafka city_sales_l9 with read_committed and query MySQL.
  7) Run OrderTimeoutExternalSinkJob, then send timeout demo.
  8) Verify Kafka order_alerts_l9 and query MySQL.
