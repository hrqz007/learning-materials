#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
mvn -q -DskipTests clean package
ls -lh target/*-all.jar
