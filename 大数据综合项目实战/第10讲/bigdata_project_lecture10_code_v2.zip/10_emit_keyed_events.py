#!/usr/bin/env python3
import json, os, subprocess, sys, time
if len(sys.argv) < 3:
    print("Usage: 10_emit_keyed_events.py <topic> <jsonl_file> [delay_seconds]")
    raise SystemExit(1)
topic, path = sys.argv[1], sys.argv[2]
delay = float(sys.argv[3]) if len(sys.argv) >= 4 else 0.4
kafka_home = os.environ.get("KAFKA_HOME")
if not kafka_home:
    raise SystemExit("KAFKA_HOME is not set")
cmd = [f"{kafka_home}/bin/kafka-console-producer.sh", "--bootstrap-server", "localhost:9092", "--topic", topic,
       "--property", "parse.key=true", "--property", "key.separator=|"]
p = subprocess.Popen(cmd, stdin=subprocess.PIPE, text=True)
with open(path, encoding="utf-8") as f:
    for raw in f:
        raw = raw.strip()
        if not raw:
            continue
        obj = json.loads(raw)
        key = obj["order_id"]
        payload = json.dumps(obj, ensure_ascii=False, separators=(",", ":"))
        print(f"SEND {topic}: {key} -> {payload}")
        p.stdin.write(f"{key}|{payload}\n")
        p.stdin.flush()
        time.sleep(delay)
p.stdin.close()
raise SystemExit(p.wait())
