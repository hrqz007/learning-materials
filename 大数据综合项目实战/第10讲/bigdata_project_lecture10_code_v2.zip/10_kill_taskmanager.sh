#!/usr/bin/env bash
set -euo pipefail
pid=$(jps | awk '/TaskManagerRunner|TaskManager/ {print $1; exit}')
if [[ -z "${pid:-}" ]]; then echo 'No TaskManager JVM found.'; exit 1; fi
echo "TaskManager PID=$pid"
if [[ "${CONFIRM_KILL:-NO}" != "YES" ]]; then
  echo 'Dry run only. To really terminate it: CONFIRM_KILL=YES ./10_kill_taskmanager.sh'
  exit 0
fi
kill "$pid"
echo "Sent SIGTERM to TaskManager PID=$pid"
