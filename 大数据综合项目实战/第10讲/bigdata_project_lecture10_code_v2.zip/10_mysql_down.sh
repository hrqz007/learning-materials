#!/usr/bin/env bash
set -euo pipefail
if [[ "${CONFIRM_MYSQL_STOP:-NO}" != "YES" ]]; then
  echo 'Dry run only. To stop MySQL: CONFIRM_MYSQL_STOP=YES ./10_mysql_down.sh'
  exit 0
fi
if systemctl list-unit-files 2>/dev/null | grep -q '^mysql\.service'; then sudo systemctl stop mysql
elif systemctl list-unit-files 2>/dev/null | grep -q '^mysqld\.service'; then sudo systemctl stop mysqld
else echo 'Could not detect mysql/mysqld systemd service.'; exit 1; fi
ss -lntp 2>/dev/null | grep ':3306 ' || echo 'Port 3306 is not listening.'
