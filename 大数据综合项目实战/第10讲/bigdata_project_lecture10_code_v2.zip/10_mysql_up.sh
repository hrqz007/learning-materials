#!/usr/bin/env bash
set -euo pipefail
if systemctl list-unit-files 2>/dev/null | grep -q '^mysql\.service'; then sudo systemctl start mysql
elif systemctl list-unit-files 2>/dev/null | grep -q '^mysqld\.service'; then sudo systemctl start mysqld
else echo 'Could not detect mysql/mysqld systemd service.'; exit 1; fi
sleep 3
ss -lntp 2>/dev/null | grep ':3306 ' || true
