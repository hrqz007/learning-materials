#!/usr/bin/env bash
set -u
echo '=== ENV ==='
echo "KAFKA_HOME=${KAFKA_HOME:-<unset>}"
echo "FLINK_HOME=${FLINK_HOME:-<unset>}"
echo "HADOOP_HOME=${HADOOP_HOME:-<unset>}"
echo '=== JAVA / MVN ==='
java -version 2>&1 | head -3 || true
mvn -version 2>&1 | head -3 || true
echo '=== PORTS ==='
for p in 8081 9092 3306 9870 8088; do
  echo "-- port $p --"; ss -lntp 2>/dev/null | grep ":$p " || true
done
echo '=== JVM PROCESSES ==='
jps 2>/dev/null || true
echo '=== FLINK JOBS ==='
if [[ -n "${FLINK_HOME:-}" ]]; then "$FLINK_HOME/bin/flink" list -r || true; fi
echo '=== KAFKA TOPICS ==='
if [[ -n "${KAFKA_HOME:-}" ]]; then "$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --list 2>/dev/null | grep -E 'orders_sales_l9|city_sales_l9|orders_timeout_l9|order_alerts_l9' || true; fi
