#!/usr/bin/env bash
set -euo pipefail
: "${KAFKA_HOME:?Please set KAFKA_HOME first}"
TOPICS=(orders_sales_l9 city_sales_l9 orders_timeout_l9 order_alerts_l9)
for t in "${TOPICS[@]}"; do
  "$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --delete --topic "$t" >/dev/null 2>&1 || true
done
sleep 2
for spec in "orders_sales_l9:3" "city_sales_l9:3" "orders_timeout_l9:3" "order_alerts_l9:3"; do
  t=${spec%%:*}; p=${spec##*:}
  "$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --create --if-not-exists --topic "$t" --partitions "$p" --replication-factor 1
done
"$KAFKA_HOME/bin/kafka-topics.sh" --bootstrap-server localhost:9092 --list | grep -E 'orders_sales_l9|city_sales_l9|orders_timeout_l9|order_alerts_l9'
