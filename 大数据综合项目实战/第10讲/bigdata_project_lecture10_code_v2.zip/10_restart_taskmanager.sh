#!/usr/bin/env bash
set -euo pipefail
: "${FLINK_HOME:?Please set FLINK_HOME first}"
"$FLINK_HOME/bin/taskmanager.sh" start
sleep 3
jps | grep -E 'TaskManagerRunner|TaskManager' || true
