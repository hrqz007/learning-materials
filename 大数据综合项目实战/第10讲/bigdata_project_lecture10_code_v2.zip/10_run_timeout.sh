#!/usr/bin/env bash
set -euo pipefail
: "${FLINK_HOME:?Please set FLINK_HOME first}"
cd "$(dirname "$0")"
export MYSQL_URL="${MYSQL_URL:-jdbc:mysql://localhost:3306/bigdata_project?useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true}"
export MYSQL_USER="${MYSQL_USER:-root}"
: "${MYSQL_PASSWORD:?Please export MYSQL_PASSWORD before running}"
"$FLINK_HOME/bin/flink" run -d -c edu.project.realtime.OrderTimeoutExternalSinkJob target/flink-external-sinks-1.0-SNAPSHOT-all.jar
