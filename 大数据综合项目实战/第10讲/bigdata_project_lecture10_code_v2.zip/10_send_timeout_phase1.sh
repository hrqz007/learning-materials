#!/usr/bin/env bash
set -euo pipefail
cd "$(dirname "$0")"
./10_emit_keyed_events.py orders_timeout_l9 data/timeout_fault_phase1.jsonl 0.5
