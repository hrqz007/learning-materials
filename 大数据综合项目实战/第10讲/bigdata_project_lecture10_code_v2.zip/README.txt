BigData Integrated Project - Lecture 10
Fault Injection, Recovery, and Final End-to-End Acceptance

This package is self-contained and includes the two Lecture 9 Flink jobs plus Lecture 10 fault/verification scripts.

Recommended order (do the PDF manually first):
1. export KAFKA_HOME / FLINK_HOME / MYSQL_USER / MYSQL_PASSWORD / MYSQL_URL.
2. ./10_preflight.sh
3. mysql -u root -p < sql/10_init_mysql.sql
4. ./10_reset_topics.sh
5. ./10_build.sh
6. Run OrderTimeoutExternalSinkJob with ./10_run_timeout.sh
7. Send phase 1: ./10_send_timeout_phase1.sh
8. Wait until Flink Web UI shows at least one COMPLETED checkpoint.
9. Dry-run TaskManager kill: ./10_kill_taskmanager.sh
10. Actually kill: CONFIRM_KILL=YES ./10_kill_taskmanager.sh
11. Restart TaskManager: ./10_restart_taskmanager.sh
12. Wait until the job returns to RUNNING and a new checkpoint completes.
13. Send phase 2: ./10_send_timeout_phase2.sh
14. Verify Kafka: ./10_consume_alerts.sh (Ctrl+C after seeing records)
15. Verify MySQL: mysql -u root -p < sql/10_final_verify_mysql.sql

Optional MySQL outage drill:
- Start CitySales job, wait for a completed checkpoint.
- Stop MySQL only after reading the PDF warnings:
  CONFIRM_MYSQL_STOP=YES ./10_mysql_down.sh
- Send city sales demo: ./10_send_city_sales_demo.sh
- Observe Flink status / logs / checkpoint behavior.
- Restart MySQL: ./10_mysql_up.sh
- Wait for recovery, then verify Kafka + MySQL.

Important:
- Fault drills are intentionally disruptive. Run ONE fault at a time.
- Always capture a healthy baseline first.
- Do not run these scripts on a production machine.
