USE bigdata_project;
SELECT 'city_sales_rt_count' AS metric, COUNT(*) AS value FROM city_sales_rt;
SELECT window_start, window_end, city, order_count, sales_amount FROM city_sales_rt ORDER BY window_start, city;
SELECT 'order_timeout_alerts_count' AS metric, COUNT(*) AS value FROM order_timeout_alerts;
SELECT alert_id, order_id, alert_type, city, amount, create_time, action_time FROM order_timeout_alerts ORDER BY action_time, order_id;
