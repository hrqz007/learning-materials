CREATE DATABASE IF NOT EXISTS bigdata_project
  DEFAULT CHARACTER SET utf8mb4
  DEFAULT COLLATE utf8mb4_0900_ai_ci;

USE bigdata_project;

CREATE TABLE IF NOT EXISTS city_sales_rt (
    window_start DATETIME NOT NULL,
    window_end   DATETIME NOT NULL,
    city         VARCHAR(64) NOT NULL,
    order_count  BIGINT NOT NULL,
    sales_amount DECIMAL(18,2) NOT NULL,
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                 ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (window_start, city)
);

CREATE TABLE IF NOT EXISTS order_timeout_alerts (
    alert_id     VARCHAR(160) NOT NULL,
    order_id     VARCHAR(64) NOT NULL,
    alert_type   VARCHAR(32) NOT NULL,
    city         VARCHAR(64),
    amount       DECIMAL(18,2),
    create_time  DATETIME NOT NULL,
    action_time  DATETIME NOT NULL,
    note         VARCHAR(255),
    updated_at   TIMESTAMP NOT NULL DEFAULT CURRENT_TIMESTAMP
                 ON UPDATE CURRENT_TIMESTAMP,
    PRIMARY KEY (alert_id),
    KEY idx_order_id (order_id)
);

SELECT 'city_sales_rt' AS table_name, COUNT(*) AS rows_now FROM city_sales_rt
UNION ALL
SELECT 'order_timeout_alerts', COUNT(*) FROM order_timeout_alerts;
