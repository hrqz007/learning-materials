package edu.project.realtime;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.functions.AggregateFunction;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.jdbc.JdbcConnectionOptions;
import org.apache.flink.connector.jdbc.JdbcExecutionOptions;
import org.apache.flink.connector.jdbc.JdbcSink;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema.KafkaSinkContext;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.datastream.SingleOutputStreamOperator;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.windowing.ProcessWindowFunction;
import org.apache.flink.streaming.api.windowing.assigners.TumblingEventTimeWindows;
import org.apache.flink.streaming.api.windowing.time.Time;
import org.apache.flink.streaming.api.windowing.windows.TimeWindow;
import org.apache.flink.util.Collector;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class CitySalesExternalSinkJob {

    private static final String BOOTSTRAP = env("KAFKA_BOOTSTRAP", "localhost:9092");
    private static final String SOURCE_TOPIC = env("SOURCE_TOPIC", "orders_sales_l9");
    private static final String OUTPUT_TOPIC = env("CITY_SALES_TOPIC", "city_sales_l9");
    private static final String GROUP_ID = env("CITY_SALES_GROUP", "flink-city-sales-l9");

    private static final String MYSQL_URL = env(
            "MYSQL_URL",
            "jdbc:mysql://localhost:3306/bigdata_project?useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true");
    private static final String MYSQL_USER = env("MYSQL_USER", "root");
    private static final String MYSQL_PASSWORD = env("MYSQL_PASSWORD", "");

    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1); // 教学环境便于观察；生产环境不要机械固定为1。
        env.getConfig().setAutoWatermarkInterval(200L);
        env.enableCheckpointing(5000L, CheckpointingMode.EXACTLY_ONCE);

        KafkaSource<String> source = KafkaSource.<String>builder()
                .setBootstrapServers(BOOTSTRAP)
                .setTopics(SOURCE_TOPIC)
                .setGroupId(GROUP_ID)
                .setStartingOffsets(OffsetsInitializer.earliest())
                .setValueOnlyDeserializer(new SimpleStringSchema())
                .build();

        DataStream<OrderEvent> events = env.fromSource(
                        source,
                        WatermarkStrategy.noWatermarks(),
                        "Kafka orders_sales_l9")
                .map(CitySalesExternalSinkJob::parseEvent)
                .name("parse-order-json")
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy.<OrderEvent>forBoundedOutOfOrderness(Duration.ofSeconds(5))
                                .withTimestampAssigner(new SerializableTimestampAssigner<OrderEvent>() {
                                    @Override
                                    public long extractTimestamp(OrderEvent element, long recordTimestamp) {
                                        return element.eventTimeMillis;
                                    }
                                })
                                .withIdleness(Duration.ofSeconds(20)))
                .name("event-time-watermark");

        SingleOutputStreamOperator<CitySalesResult> citySales = events
                .filter(e -> "PAY".equals(e.eventType))
                .name("filter-pay")
                .keyBy(e -> e.city)
                .window(TumblingEventTimeWindows.of(Time.minutes(1)))
                .aggregate(new CitySalesAgg(), new AddWindowInfo())
                .name("one-minute-city-sales");

        // 1) Kafka：Exactly-once 事务写入。
        KafkaSink<CitySalesResult> kafkaSink = KafkaSink.<CitySalesResult>builder()
                .setBootstrapServers(BOOTSTRAP)
                .setRecordSerializer(new CitySalesKafkaSerializer())
                .setDeliveryGuarantee(DeliveryGuarantee.EXACTLY_ONCE)
                .setTransactionalIdPrefix("city-sales-l9-")
                .build();
        citySales.sinkTo(kafkaSink).name("kafka-city-sales-exactly-once");

        // 2) MySQL：普通 JdbcSink 是 at-least-once；使用主键 + ON DUPLICATE KEY UPDATE 实现幂等 Upsert。
        citySales.addSink(JdbcSink.sink(
                "INSERT INTO city_sales_rt " +
                        "(window_start, window_end, city, order_count, sales_amount) " +
                        "VALUES (?, ?, ?, ?, ?) " +
                        "ON DUPLICATE KEY UPDATE " +
                        "window_end=VALUES(window_end), order_count=VALUES(order_count), " +
                        "sales_amount=VALUES(sales_amount)",
                (ps, r) -> {
                    ps.setTimestamp(1, new Timestamp(r.windowStart));
                    ps.setTimestamp(2, new Timestamp(r.windowEnd));
                    ps.setString(3, r.city);
                    ps.setLong(4, r.orderCount);
                    ps.setBigDecimal(5, BigDecimal.valueOf(r.salesCents, 2));
                },
                JdbcExecutionOptions.builder()
                        .withBatchSize(50)
                        .withBatchIntervalMs(1000)
                        .withMaxRetries(3)
                        .build(),
                new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                        .withUrl(MYSQL_URL)
                        .withDriverName("com.mysql.cj.jdbc.Driver")
                        .withUsername(MYSQL_USER)
                        .withPassword(MYSQL_PASSWORD)
                        .build()
        )).name("mysql-city-sales-idempotent-upsert");

        citySales.print("CITY_SALES_DEBUG");
        env.execute("BigData Project L9 - City Sales External Sinks");
    }

    private static OrderEvent parseEvent(String value) throws Exception {
        ObjectMapper mapper = Holder.MAPPER;
        JsonNode n = mapper.readTree(value);
        OrderEvent e = new OrderEvent();
        e.orderId = n.get("order_id").asText();
        e.city = n.get("city").asText();
        e.eventType = n.get("event_type").asText();
        BigDecimal amountYuan = new BigDecimal(n.get("amount").asText());
        e.amountCents = amountYuan.movePointRight(2).longValueExact();
        LocalDateTime ldt = LocalDateTime.parse(n.get("event_time").asText(), FMT);
        e.eventTimeMillis = ldt.atZone(BUSINESS_ZONE).toInstant().toEpochMilli();
        return e;
    }

    private static String env(String key, String defaultValue) {
        String v = System.getenv(key);
        return (v == null || v.trim().isEmpty()) ? defaultValue : v.trim();
    }

    private static String fmt(long millis) {
        return FMT.format(Instant.ofEpochMilli(millis).atZone(BUSINESS_ZONE).toLocalDateTime());
    }

    private static class Holder {
        private static final ObjectMapper MAPPER = new ObjectMapper();
    }

    public static class OrderEvent {
        public String orderId;
        public String city;
        public String eventType;
        public long amountCents;
        public long eventTimeMillis;
        public OrderEvent() {}
    }

    public static class CityAcc {
        public long orderCount;
        public long salesCents;
        public CityAcc() {}
    }

    public static class CitySalesResult {
        public String city;
        public long windowStart;
        public long windowEnd;
        public long orderCount;
        public long salesCents;
        public CitySalesResult() {}

        public String kafkaKey() {
            return fmt(windowStart) + "|" + city;
        }

        public String toJson() {
            return String.format(
                    "{\"window_start\":\"%s\",\"window_end\":\"%s\",\"city\":\"%s\",\"order_count\":%d,\"sales_amount\":%.2f}",
                    fmt(windowStart), fmt(windowEnd), city, orderCount, salesCents / 100.0);
        }

        @Override
        public String toString() {
            return kafkaKey() + " -> " + toJson();
        }
    }

    public static class CitySalesAgg implements AggregateFunction<OrderEvent, CityAcc, CityAcc> {
        @Override
        public CityAcc createAccumulator() { return new CityAcc(); }

        @Override
        public CityAcc add(OrderEvent value, CityAcc acc) {
            acc.orderCount += 1;
            acc.salesCents += value.amountCents;
            return acc;
        }

        @Override
        public CityAcc getResult(CityAcc acc) { return acc; }

        @Override
        public CityAcc merge(CityAcc a, CityAcc b) {
            CityAcc r = new CityAcc();
            r.orderCount = a.orderCount + b.orderCount;
            r.salesCents = a.salesCents + b.salesCents;
            return r;
        }
    }

    public static class AddWindowInfo extends ProcessWindowFunction<CityAcc, CitySalesResult, String, TimeWindow> {
        @Override
        public void process(String city,
                            Context context,
                            Iterable<CityAcc> elements,
                            Collector<CitySalesResult> out) {
            CityAcc acc = elements.iterator().next();
            CitySalesResult r = new CitySalesResult();
            r.city = city;
            r.windowStart = context.window().getStart();
            r.windowEnd = context.window().getEnd();
            r.orderCount = acc.orderCount;
            r.salesCents = acc.salesCents;
            out.collect(r);
        }
    }

    public static class CitySalesKafkaSerializer implements KafkaRecordSerializationSchema<CitySalesResult> {
        @Override
        public ProducerRecord<byte[], byte[]> serialize(CitySalesResult r,
                                                         KafkaSinkContext context,
                                                         Long timestamp) {
            byte[] key = r.kafkaKey().getBytes(StandardCharsets.UTF_8);
            byte[] value = r.toJson().getBytes(StandardCharsets.UTF_8);
            return new ProducerRecord<>(OUTPUT_TOPIC, key, value);
        }
    }
}
