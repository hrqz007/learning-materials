package edu.project.realtime;

import com.fasterxml.jackson.databind.JsonNode;
import com.fasterxml.jackson.databind.ObjectMapper;
import org.apache.flink.api.common.eventtime.SerializableTimestampAssigner;
import org.apache.flink.api.common.eventtime.WatermarkStrategy;
import org.apache.flink.api.common.serialization.SimpleStringSchema;
import org.apache.flink.api.common.state.ValueState;
import org.apache.flink.api.common.state.ValueStateDescriptor;
import org.apache.flink.configuration.Configuration;
import org.apache.flink.connector.base.DeliveryGuarantee;
import org.apache.flink.connector.jdbc.JdbcConnectionOptions;
import org.apache.flink.connector.jdbc.JdbcExecutionOptions;
import org.apache.flink.connector.jdbc.JdbcSink;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema;
import org.apache.flink.connector.kafka.sink.KafkaRecordSerializationSchema.KafkaSinkContext;
import org.apache.flink.connector.kafka.sink.KafkaSink;
import org.apache.flink.connector.kafka.source.KafkaSource;
import org.apache.flink.connector.kafka.source.enumerator.initializer.OffsetsInitializer;
import org.apache.flink.streaming.api.CheckpointingMode;
import org.apache.flink.streaming.api.datastream.DataStream;
import org.apache.flink.streaming.api.environment.StreamExecutionEnvironment;
import org.apache.flink.streaming.api.functions.KeyedProcessFunction;
import org.apache.flink.util.Collector;
import org.apache.kafka.clients.producer.ProducerRecord;

import java.math.BigDecimal;
import java.nio.charset.StandardCharsets;
import java.sql.Timestamp;
import java.time.Duration;
import java.time.Instant;
import java.time.LocalDateTime;
import java.time.ZoneId;
import java.time.format.DateTimeFormatter;

public class OrderTimeoutExternalSinkJob {

    private static final String BOOTSTRAP = env("KAFKA_BOOTSTRAP", "localhost:9092");
    private static final String SOURCE_TOPIC = env("TIMEOUT_SOURCE_TOPIC", "orders_timeout_l9");
    private static final String OUTPUT_TOPIC = env("ALERT_TOPIC", "order_alerts_l9");
    private static final String GROUP_ID = env("ALERT_GROUP", "flink-order-alert-l9");

    private static final String MYSQL_URL = env(
            "MYSQL_URL",
            "jdbc:mysql://localhost:3306/bigdata_project?useSSL=false&serverTimezone=Asia/Shanghai&allowPublicKeyRetrieval=true");
    private static final String MYSQL_USER = env("MYSQL_USER", "root");
    private static final String MYSQL_PASSWORD = env("MYSQL_PASSWORD", "");

    private static final ZoneId BUSINESS_ZONE = ZoneId.of("Asia/Shanghai");
    private static final DateTimeFormatter FMT = DateTimeFormatter.ofPattern("yyyy-MM-dd HH:mm:ss");
    private static final long TIMEOUT_MILLIS = Duration.ofMinutes(15).toMillis();

    public static void main(String[] args) throws Exception {
        StreamExecutionEnvironment env = StreamExecutionEnvironment.getExecutionEnvironment();
        env.setParallelism(1);
        env.getConfig().setAutoWatermarkInterval(200L);
        env.enableCheckpointing(5000L, CheckpointingMode.EXACTLY_ONCE);

        KafkaSource<String> source = KafkaSource.<String>builder()
                .setBootstrapServers(BOOTSTRAP)
                .setTopics(SOURCE_TOPIC)
                .setGroupId(GROUP_ID)
                .setStartingOffsets(OffsetsInitializer.earliest())
                .setValueOnlyDeserializer(new SimpleStringSchema())
                .build();

        DataStream<OrderEvent> events = env.fromSource(
                        source,
                        WatermarkStrategy.noWatermarks(),
                        "Kafka orders_timeout_l9")
                .map(OrderTimeoutExternalSinkJob::parseEvent)
                .name("parse-timeout-json")
                .assignTimestampsAndWatermarks(
                        WatermarkStrategy.<OrderEvent>forBoundedOutOfOrderness(Duration.ofSeconds(5))
                                .withTimestampAssigner(new SerializableTimestampAssigner<OrderEvent>() {
                                    @Override
                                    public long extractTimestamp(OrderEvent element, long recordTimestamp) {
                                        return element.eventTimeMillis;
                                    }
                                })
                                .withIdleness(Duration.ofSeconds(20)))
                .name("event-time-watermark");

        DataStream<AlertResult> alerts = events
                .keyBy(e -> e.orderId)
                .process(new OrderTimeoutProcess())
                .name("order-timeout-state-timer")
                .filter(a -> "TIMEOUT_ALERT".equals(a.alertType))
                .name("timeout-only");

        KafkaSink<AlertResult> kafkaSink = KafkaSink.<AlertResult>builder()
                .setBootstrapServers(BOOTSTRAP)
                .setRecordSerializer(new AlertKafkaSerializer())
                .setDeliveryGuarantee(DeliveryGuarantee.EXACTLY_ONCE)
                .setTransactionalIdPrefix("order-alert-l9-")
                .build();
        alerts.sinkTo(kafkaSink).name("kafka-alert-exactly-once");

        alerts.addSink(JdbcSink.sink(
                "INSERT INTO order_timeout_alerts " +
                        "(alert_id, order_id, alert_type, city, amount, create_time, action_time, note) " +
                        "VALUES (?, ?, ?, ?, ?, ?, ?, ?) " +
                        "ON DUPLICATE KEY UPDATE note=VALUES(note), amount=VALUES(amount)",
                (ps, a) -> {
                    ps.setString(1, a.alertId());
                    ps.setString(2, a.orderId);
                    ps.setString(3, a.alertType);
                    ps.setString(4, a.city);
                    ps.setBigDecimal(5, BigDecimal.valueOf(a.amountCents, 2));
                    ps.setTimestamp(6, new Timestamp(a.createTimeMillis));
                    ps.setTimestamp(7, new Timestamp(a.actionTimeMillis));
                    ps.setString(8, a.note);
                },
                JdbcExecutionOptions.builder()
                        .withBatchSize(50)
                        .withBatchIntervalMs(1000)
                        .withMaxRetries(3)
                        .build(),
                new JdbcConnectionOptions.JdbcConnectionOptionsBuilder()
                        .withUrl(MYSQL_URL)
                        .withDriverName("com.mysql.cj.jdbc.Driver")
                        .withUsername(MYSQL_USER)
                        .withPassword(MYSQL_PASSWORD)
                        .build()
        )).name("mysql-alert-idempotent-upsert");

        alerts.print("ALERT_DEBUG");
        env.execute("BigData Project L9 - Order Timeout External Sinks");
    }

    private static OrderEvent parseEvent(String value) throws Exception {
        JsonNode n = Holder.MAPPER.readTree(value);
        OrderEvent e = new OrderEvent();
        e.orderId = n.get("order_id").asText();
        e.city = n.get("city").asText();
        e.eventType = n.get("event_type").asText();
        e.amountCents = new BigDecimal(n.get("amount").asText()).movePointRight(2).longValueExact();
        LocalDateTime ldt = LocalDateTime.parse(n.get("event_time").asText(), FMT);
        e.eventTimeMillis = ldt.atZone(BUSINESS_ZONE).toInstant().toEpochMilli();
        return e;
    }

    private static String env(String key, String defaultValue) {
        String v = System.getenv(key);
        return (v == null || v.trim().isEmpty()) ? defaultValue : v.trim();
    }

    private static String fmt(long millis) {
        return FMT.format(Instant.ofEpochMilli(millis).atZone(BUSINESS_ZONE).toLocalDateTime());
    }

    private static class Holder {
        private static final ObjectMapper MAPPER = new ObjectMapper();
    }

    public static class OrderEvent {
        public String orderId;
        public String city;
        public String eventType;
        public long amountCents;
        public long eventTimeMillis;
        public OrderEvent() {}
    }

    public static class OrderState {
        public String orderId;
        public String city;
        public long amountCents;
        public long createTimeMillis;
        public long timerTimestamp;
        public OrderState() {}
    }

    public static class AlertResult {
        public String orderId;
        public String alertType;
        public String city;
        public long amountCents;
        public long createTimeMillis;
        public long actionTimeMillis;
        public String note;
        public AlertResult() {}

        public String alertId() {
            return orderId + "|" + alertType + "|" + actionTimeMillis;
        }

        public String toJson() {
            return String.format(
                    "{\"alert_id\":\"%s\",\"order_id\":\"%s\",\"alert_type\":\"%s\",\"city\":\"%s\",\"amount\":%.2f,\"create_time\":\"%s\",\"action_time\":\"%s\",\"note\":\"%s\"}",
                    alertId(), orderId, alertType, city, amountCents / 100.0,
                    fmt(createTimeMillis), fmt(actionTimeMillis), note.replace("\"", "'"));
        }
    }

    public static class OrderTimeoutProcess extends KeyedProcessFunction<String, OrderEvent, AlertResult> {
        private transient ValueState<OrderState> state;

        @Override
        public void open(Configuration parameters) {
            state = getRuntimeContext().getState(
                    new ValueStateDescriptor<>("order-timeout-state", OrderState.class));
        }

        @Override
        public void processElement(OrderEvent e, Context ctx, Collector<AlertResult> out) throws Exception {
            OrderState current = state.value();
            if ("CREATE".equals(e.eventType)) {
                if (current == null) {
                    OrderState s = new OrderState();
                    s.orderId = e.orderId;
                    s.city = e.city;
                    s.amountCents = e.amountCents;
                    s.createTimeMillis = e.eventTimeMillis;
                    s.timerTimestamp = e.eventTimeMillis + TIMEOUT_MILLIS;
                    state.update(s);
                    ctx.timerService().registerEventTimeTimer(s.timerTimestamp);
                }
                return;
            }
            if (("PAY".equals(e.eventType) || "CANCEL".equals(e.eventType)) && current != null) {
                ctx.timerService().deleteEventTimeTimer(current.timerTimestamp);
                state.clear();
            }
        }

        @Override
        public void onTimer(long timestamp, OnTimerContext ctx, Collector<AlertResult> out) throws Exception {
            OrderState current = state.value();
            if (current != null && current.timerTimestamp == timestamp) {
                AlertResult a = new AlertResult();
                a.orderId = current.orderId;
                a.alertType = "TIMEOUT_ALERT";
                a.city = current.city;
                a.amountCents = current.amountCents;
                a.createTimeMillis = current.createTimeMillis;
                a.actionTimeMillis = timestamp;
                a.note = "15分钟未PAY/CANCEL，Event-Time Timer触发";
                out.collect(a);
                state.clear();
            }
        }
    }

    public static class AlertKafkaSerializer implements KafkaRecordSerializationSchema<AlertResult> {
        @Override
        public ProducerRecord<byte[], byte[]> serialize(AlertResult a,
                                                         KafkaSinkContext context,
                                                         Long timestamp) {
            byte[] key = a.alertId().getBytes(StandardCharsets.UTF_8);
            byte[] value = a.toJson().getBytes(StandardCharsets.UTF_8);
            return new ProducerRecord<>(OUTPUT_TOPIC, key, value);
        }
    }
}
