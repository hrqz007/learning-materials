大语言模型零基础课 - 第2讲材料包
主题：Token：大语言模型眼里的文字到底是什么？

文件：
1. 完整讲义 PDF
2. 核心概念速查卡 PDF
3. 练习题与答案 PDF
4. toy_tokenizer_demo.py（纯 Python，无第三方依赖）

建议顺序：完整讲义 -> 运行 toy demo -> 独立练习 -> 速查卡复习。
下一讲：Embedding。
