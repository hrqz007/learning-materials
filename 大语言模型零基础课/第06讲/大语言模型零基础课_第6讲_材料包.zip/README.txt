大语言模型零基础课 - 第6讲材料包

1. 01_第6讲_训练集验证集测试集过拟合与泛化_完整讲义.pdf
2. 02_第6讲_数据划分与泛化核心概念速查卡.pdf
3. 03_第6讲_练习题与答案.pdf
4. 04_overfitting_demo.py

实验运行：python 04_overfitting_demo.py
需要 numpy 和 matplotlib。
