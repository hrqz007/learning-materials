大语言模型零基础课 · 第8讲材料包

01 完整讲义 PDF
02 Attention/QKV 核心概念速查卡 PDF
03 练习题与答案 PDF
04 Attention/QKV 玩具实验 Python 代码（仅标准库）
04_attention_qkv_demo_output.txt 实际运行输出

建议顺序：完整讲义 -> 独立练习 -> 运行代码 -> 对照答案 -> 速查卡复习。
