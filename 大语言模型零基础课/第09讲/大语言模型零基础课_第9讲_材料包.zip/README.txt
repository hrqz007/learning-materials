大语言模型零基础课 · 第9讲材料包

01 完整讲义 PDF
02 Multi-Head Attention 核心概念速查卡 PDF
03 练习题与答案 PDF
04 Multi-Head Attention 玩具实验 Python 代码（仅标准库）
04_multi_head_attention_demo_output.txt 实际运行输出

建议顺序：完整讲义 -> 独立练习 -> 运行代码 -> 对照答案 -> 速查卡复习。
