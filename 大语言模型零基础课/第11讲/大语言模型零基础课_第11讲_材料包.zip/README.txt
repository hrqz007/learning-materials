大语言模型零基础课 - 第11讲材料包

主题：一个完整 Transformer Block 到底怎样工作？

文件：
1. 完整讲义 PDF
2. 核心概念速查卡 PDF
3. 练习题与答案 PDF
4. tiny_transformer_block_demo.py
5. 代码运行输出 txt

建议顺序：完整讲义 -> 自己运行代码 -> 练习题 -> 速查卡复习。
