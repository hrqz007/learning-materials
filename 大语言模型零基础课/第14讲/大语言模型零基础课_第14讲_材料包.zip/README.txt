大语言模型零基础课 - 第14讲材料包

1. 01_第14讲_训练数据_大语言模型到底吃什么长大_完整讲义.pdf
2. 02_第14讲_训练数据核心概念速查卡.pdf
3. 03_第14讲_练习题与答案.pdf
4. 04_training_data_pipeline_demo.py
5. 04_training_data_pipeline_demo_output.txt

建议顺序：先读主讲义 -> 独立做练习 -> 看答案 -> 运行 Python 小实验 -> 用速查卡复习。
