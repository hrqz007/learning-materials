大语言模型零基础课 - 第15讲材料包

1. 01_第15讲_ScalingLaw_参数数据算力为什么必须一起扩展_完整讲义.pdf
2. 02_第15讲_ScalingLaw核心概念速查卡.pdf
3. 03_第15讲_练习题与答案.pdf
4. 04_scaling_law_toy_demo.py
5. 04_scaling_law_toy_demo_output.txt

建议顺序：主讲义 -> 独立练习 -> 参考答案 -> 运行 Python 小实验 -> 速查卡复习。
