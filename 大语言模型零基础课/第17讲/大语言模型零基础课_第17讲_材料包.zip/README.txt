大语言模型零基础课 - 第17讲材料包

主题：Preference Learning、RLHF、RLAIF 与 DPO

文件：
01 完整讲义 PDF
02 核心概念速查卡 PDF
03 练习题与答案 PDF
04 preference learning 教学玩具实验 Python
04 实验运行结果 TXT

建议学习顺序：先完整讲义，再运行代码，最后做练习并对照答案。
