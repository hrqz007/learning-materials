大语言模型零基础课 - 第20讲材料包

01 完整讲义 PDF
02 核心概念速查卡 PDF
03 练习题与答案 PDF
04 Temperature / Top-k / Top-p 实验 Python
04 实验运行结果 TXT
sampling_probability_demo.png 概率分布图
