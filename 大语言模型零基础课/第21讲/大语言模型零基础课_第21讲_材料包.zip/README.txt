大语言模型零基础课 - 第21讲材料包

01 完整讲义 PDF
02 核心概念速查卡 PDF
03 练习题与答案 PDF
04 Context Window / Retrieval 教学实验 Python
04 实验运行结果 TXT
context_budget_demo.png Context 预算图
