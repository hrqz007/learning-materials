大语言模型零基础课第26讲材料包：RAG。
包含完整讲义、速查卡、练习答案、Toy RAG Retrieval 代码、运行结果和 Recall/Precision 图。
