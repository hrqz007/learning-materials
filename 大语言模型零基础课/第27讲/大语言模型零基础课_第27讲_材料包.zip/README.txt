大语言模型零基础课第27讲材料包：Tool Use / Function Calling。
包含完整讲义、速查卡、练习答案、Toy Tool Runtime 代码与运行结果。
