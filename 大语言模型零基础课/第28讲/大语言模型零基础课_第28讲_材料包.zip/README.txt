大语言模型零基础课第28讲材料包：从 LLM 到 Agent。
包含完整讲义、速查卡、练习答案、Toy Agent Loop 代码与运行结果。
