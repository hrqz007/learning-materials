大语言模型零基础课第31讲材料包：LLM Evaluation。
包含完整讲义、速查卡、练习答案、Pass@k/LLM Judge Bias 教学实验及运行结果。
