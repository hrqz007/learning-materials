大语言模型零基础课第32讲材料包：Uncertainty & Calibration。
包含完整讲义、速查卡、练习答案、Calibration/ECE/Risk-Coverage/Agent Agreement 教学实验及运行结果。
