大语言模型零基础课第33讲材料包：Fine-tuning、LoRA 与 QLoRA。
包含完整讲义、速查卡、练习答案、LoRA 低秩教学实验与运行结果。
