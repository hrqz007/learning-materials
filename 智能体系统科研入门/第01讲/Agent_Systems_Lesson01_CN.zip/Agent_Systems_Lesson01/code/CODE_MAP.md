# 第1讲代码阅读地图

第1讲先看运行过程，不要求读懂全部语法。所有源代码均有中文注释。`lesson01_demo.py` 是完整参考实现；`practice.py` 是只需改三个参数的练习入口。

| 名称 | 作用 | 观察重点 |
|---|---|---|
| load_scenarios | 读取场景 | 数据与策略分开 |
| make_world | 创建全新环境 | 每种策略有相同初始条件 |
| execute_tool | 执行查询、预约、验证 | 真正改变环境的是这里 |
| run_case | 组织一次实验 | 预算、策略、轨迹与停止 |
| call | 执行入口 | 先检查预算，再执行并记录 |
| attempt | 尝试一个房间 | 查询、预约、验证是不同调用 |
| save_results | 保存记录 | 区分汇总数字与原始轨迹 |

`fixed`只尝试B；`feedback`按反馈迭代候选；`branch`预写B和C分支。后三者的代码没有使用大模型，也没有读取隐藏事件来提前规避失败。

字段例子：`available`是当前空闲；`reserved`是预约操作成功；`verified`是验证找到记录。`True/true`表示真，`False/false`表示假；大小写差异来自Python与JSON格式，含义相同。`None/null`表示没有相应值。

`selected_room`只在策略完成验证后填写；它为空不代表环境中一定没有预约。实际预约请看`final_bookings`，特别注意额度不足、来不及验证的案例。

JSON是结构化的文本数据格式；本讲不用背语法。场景文件的逐项解释在data/README.md。终端运行步骤在02_Lab_Guide中。

练习顺序：先保持默认参数预测；再只改MAX_ACTIONS为4；最后比较fixed和branch。每次只改变一个条件，保留旧结果，再解释差异。
