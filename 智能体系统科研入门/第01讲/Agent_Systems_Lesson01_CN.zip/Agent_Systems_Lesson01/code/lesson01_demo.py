"""第1讲：科研讨论室预约的离线教学演示。

用途：观察目标、工具、反馈、状态和停止条件怎样组成一个系统。
边界：决策由人写的规则产生；没有调用大模型，不代表任何模型的能力。
依赖：Python 3.9 或更新版本，仅使用标准库；不联网，不需要 API 密钥。
提示：第1讲只要求看懂运行记录。函数、字典和异常会在后续课程展开。
"""

import argparse  # 把终端中的 --scenario 等选项转换成程序可读取的参数。
import csv  # 将汇总结果保存为表格文本，便于用 Excel 或文本编辑器查看。
import json  # 读取实验场景，并保存包含执行过程的结构化记录。
from datetime import datetime  # 为每次运行创建独立文件夹，避免覆盖旧实验。
from pathlib import Path  # 处理文件路径，兼容 Windows 和 Linux。


# __file__ 是本代码文件的位置；parents[1] 指向解压后的课程包根目录。
# 因此，数据读取不依赖你从哪个文件夹启动程序。
PACKAGE_ROOT = Path(__file__).resolve().parents[1]
SCENARIO_FILE = PACKAGE_ROOT / "data" / "scenarios.json"
POLICIES = ("fixed", "feedback", "branch")
LABELS = {"fixed": "只尝试B的预设流程", "feedback": "按反馈换候选的规则策略", "branch": "预写B和C分支的工作流"}


class BudgetExceeded(Exception):
    """工具调用额度用完时，停止继续行动；这不是房间一定不可用。"""


def load_scenarios():
    """读取课程自带场景；UTF-8 是保存中文文字的编码方式。"""
    with SCENARIO_FILE.open("r", encoding="utf-8") as handle:
        return json.load(handle)


def make_world(scenario):
    """每次实验创建全新环境，避免上一次预约影响下一种策略。"""
    return {
        "free": dict(scenario["initial_free"]),  # 复制可用状态，避免修改原始场景。
        "conflict_pending": scenario["conflict_on_first_B_reservation"],
        "bookings": [],  # 真正的预约记录；最终评分检查这里，而非打印文字。
    }


def execute_tool(world, tool, room):
    """执行本地模拟工具；真实系统中，这层才会访问预约服务。

    决策者只能收到这个函数返回的观察，不能直接读取隐藏冲突开关。
    这里只接受明确列出的工具和房间，不执行任意字符串命令。
    """
    if room not in ("B", "C"):
        raise ValueError("本实验候选房间只允许 B 或 C")

    if tool == "check":
        # 查询只告诉我们此刻是否空闲，并不保证稍后预订时仍然空闲。
        return {"available": world["free"][room]}

    if tool == "reserve":
        # 冲突场景：在第一次预订B的这一刻，模拟别人抢先完成预约。
        if room == "B" and world["conflict_pending"]:
            world["free"]["B"] = False
            world["conflict_pending"] = False
        if not world["free"][room]:
            return {"reserved": False, "message": "房间已被占用"}
        # 真正修改环境：占用房间，并添加可以独立检查的预约记录。
        world["free"][room] = False
        world["bookings"].append({"room": room, "slot": "14:00-14:30", "people": 4})
        return {"reserved": True, "message": "已写入预约记录"}

    if tool == "verify":
        # 验证检查真实记录，不能仅根据助手说“完成了”就判断成功。
        found = any(item["room"] == room for item in world["bookings"])
        return {"verified": found}

    raise ValueError("未知工具：" + tool)


def run_case(scenario, policy, max_actions=6):
    """运行一种策略，记录全部实际发生的工具调用。

    三种策略共享环境实现、工具、候选顺序和工具调用上限。
    fixed 特意只尝试 B，属于有明确局限的教学基线。
    branch 说明预写失败分支的工作流也能完成这些简单任务。
    """
    world = make_world(scenario)
    trace = []  # 轨迹：依次记录动作以及工具返回的观察。
    verified = False
    selected_room = None
    stop_reason = "未找到可完成的预约"

    def call(tool, room):
        """统一执行入口：先检查预算，再行动，最后记录返回值。"""
        if len(trace) >= max_actions:
            raise BudgetExceeded("已达到工具调用上限")
        observation = execute_tool(world, tool, room)
        trace.append({
            "step": len(trace) + 1,  # 只统计真正执行的调用，不统计被拒绝的请求。
            "tool": tool,
            "room": room,
            "observation": observation,
        })
        return observation

    def attempt(room):
        """尝试一个房间：查询、预约、验证；每一步都读取实际反馈。"""
        if not call("check", room)["available"]:
            return False
        if not call("reserve", room)["reserved"]:
            return False
        return call("verify", room)["verified"]

    try:
        if policy == "fixed":
            # 固定候选：B失败后就停止，不使用本来同样允许访问的C。
            verified = attempt("B")
            if verified:
                selected_room = "B"
        elif policy == "branch":
            # 开发者明确预写两个分支。工作流可以包含条件判断和反馈。
            if attempt("B"):
                verified, selected_room = True, "B"
            elif attempt("C"):
                verified, selected_room = True, "C"
        elif policy == "feedback":
            # 规则决策：一次失败之后，才根据反馈进入下一个候选。
            # 这里的 for 循环仍由人预写，不是大模型自主规划。
            for room in ("B", "C"):
                if attempt(room):
                    verified, selected_room = True, room
                    break  # 已完成且验证成功，立即停止，避免重复预约。
        else:
            raise ValueError("未知策略：" + policy)
        if verified:
            stop_reason = "预约已完成并通过验证"
    except BudgetExceeded:
        # 可能预约已写入，但还没有额度验证。保留这种区别，不虚报完成。
        stop_reason = "工具调用额度耗尽"

    # 这是实验评分者读取环境的步骤，不是给策略提供额外信息的工具。
    environment_goal = any(
        item["slot"] == "14:00-14:30" and item["people"] == 4
        for item in world["bookings"]
    )
    return {
        "scenario": scenario["id"],
        "policy": policy,
        "max_actions": max_actions,
        "tool_calls": len(trace),
        "environment_goal": environment_goal,  # 环境中是否真的存在合格预约。
        "verified_by_controller": verified,  # 系统是否已经获得验证反馈。
        "task_success": environment_goal and verified,  # 本任务要求两者同时成立。
        "selected_room": selected_room,
        "stop_reason": stop_reason,
        "trace": trace,
        "final_bookings": world["bookings"],
    }


def save_results(results, output_dir):
    """保存详细轨迹、汇总表和中文阅读版；不改动课程原始数据。"""
    output_dir.mkdir(parents=True, exist_ok=True)
    with (output_dir / "traces.json").open("w", encoding="utf-8") as handle:
        json.dump(results, handle, ensure_ascii=False, indent=2)
    fields = ["scenario", "policy", "max_actions", "tool_calls", "environment_goal", "verified_by_controller", "task_success", "selected_room", "stop_reason"]
    # utf-8-sig 带编码标记，便于 Windows 上的表格软件正确识别中文。
    with (output_dir / "summary.csv").open("w", encoding="utf-8-sig", newline="") as handle:
        writer = csv.DictWriter(handle, fieldnames=fields, extrasaction="ignore")
        writer.writeheader()
        writer.writerows(results)
    paragraphs = ["第1讲规则演示的实际运行记录\n不含大模型调用，不代表真实模型性能。\n"]
    for result in results:
        paragraphs.append(f"场景 {result['scenario']} | {LABELS[result['policy']]}")
        for step in result["trace"]:
            obs = json.dumps(step["observation"], ensure_ascii=False)
            paragraphs.append(f"  第{step['step']}步 {step['tool']}({step['room']}) -> {obs}")
        paragraphs.append(f"  调用数 {result['tool_calls']} | 任务成功 {result['task_success']} | {result['stop_reason']}\n")
    text = "\n".join(paragraphs)
    (output_dir / "trace_readable.txt").write_text(text, encoding="utf-8")
    return text


def main():
    """默认执行3个场景乘3种策略，共9次独立实验。"""
    parser = argparse.ArgumentParser(description=__doc__)
    parser.add_argument("--scenario", choices=("all", "normal", "conflict", "full"), default="all", help="场景；all表示全部")
    parser.add_argument("--policy", choices=("all",) + POLICIES, default="all", help="策略；all表示全部")
    parser.add_argument("--max-actions", type=int, default=6, help="每次独立实验最多允许的工具调用数")
    parser.add_argument("--output", type=Path, help="可选结果目录；默认自动创建带时间的文件夹")
    args = parser.parse_args()
    if args.max_actions < 1:
        parser.error("--max-actions 至少为1")
    scenarios = [s for s in load_scenarios() if args.scenario in ("all", s["id"])]
    policies = POLICIES if args.policy == "all" else (args.policy,)
    results = [run_case(s, p, args.max_actions) for s in scenarios for p in policies]
    # 微秒时间减少连续运行产生同名目录的机会；默认不覆盖之前的结果。
    stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
    output_dir = args.output or PACKAGE_ROOT / "outputs" / ("run_" + stamp)
    print(save_results(results, output_dir))
    print("结果目录：", output_dir.resolve())


if __name__ == "__main__":
    main()  # 直接运行本文件时启动；被别的文件导入时不自动执行实验。
