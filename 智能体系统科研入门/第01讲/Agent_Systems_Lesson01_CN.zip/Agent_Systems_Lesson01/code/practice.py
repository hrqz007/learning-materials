"""第1讲参数练习：先预测，再运行，再检查自己的解释。

只需修改下面3个参数；不要求现在理解参考程序的全部语法。
本文件使用同目录的 lesson01_demo.py，因此请保持两者位置不变。
"""

from datetime import datetime  # 给练习结果加时间标记，保留以前的记录。
from pathlib import Path  # 让路径在Windows和Linux上都能正确拼接。
from lesson01_demo import load_scenarios, run_case, save_results

# 练习A：先保持下方设置，预测B失败后是否会预约C。
# 场景可选 normal（正常）、conflict（冲突）、full（全满）。
SCENARIO = "conflict"

# 策略可选 fixed（只试B）、feedback（根据反馈换候选）、branch（预写分支）。
POLICY = "feedback"

# 练习B：把6改成4，预测“已经预约”与“已经验证”是否仍然同时成立。
MAX_ACTIONS = 6

# 从课程数据中找到指定场景；如果写错名字，立即报错，不静默改用别的场景。
matches = [item for item in load_scenarios() if item["id"] == SCENARIO]
if not matches:
    raise ValueError("SCENARIO拼写错误，请从normal、conflict、full中选择")
if MAX_ACTIONS < 1:
    raise ValueError("MAX_ACTIONS必须至少为1")

result = run_case(matches[0], POLICY, MAX_ACTIONS)
# 把新结果放在outputs中，不修改examples内已经提供的参考结果。
stamp = datetime.now().strftime("%Y%m%d_%H%M%S_%f")
output_dir = Path(__file__).resolve().parents[1] / "outputs" / ("practice_" + stamp)
print(save_results([result], output_dir))
print("练习结果目录：", output_dir.resolve())
