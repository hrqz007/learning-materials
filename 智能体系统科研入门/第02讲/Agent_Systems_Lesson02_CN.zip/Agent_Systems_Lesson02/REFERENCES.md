# 官方参考资料

查阅日期：2026-09-25。用于核对工具行为、环境命令和安装入口。
示例代码、关系图和实验练习为本课程编写。界面示意图不是软件实际截图。

1. [Microsoft：Python environments in VS Code](https://code.visualstudio.com/docs/python/environments)
   - 解释器选择、环境发现和运行环境。
2. [Python：venv](https://docs.python.org/3/library/venv.html)
   - 创建虚拟环境、激活与直接指定解释器、环境不适合直接复制迁移。
3. [conda：Getting started with conda](https://docs.conda.io/projects/conda/en/23.11.x/user-guide/getting-started.html)
   - 该官方文档版本用于核对环境创建、激活和查看命令，并非要求安装此版本的 conda。
4. [Microsoft：Getting Started with Python in VS Code](https://code.visualstudio.com/docs/python/python-tutorial)
   - Python 扩展与运行 Python 文件。
5. [Python 3.13：Using Python on Windows](https://docs.python.org/3.13/using/windows.html)
   - 路线 B 的 3.13 标准安装器选项与 Windows 运行方式。
6. [Python：Windows releases](https://www.python.org/downloads/windows/)
   - 获取官方 Windows 安装文件。补丁版本以页面上所选系列的最新维护版本为准。

课程创建新环境时举例使用 Python 3.13；已有 Python 3.10 至 3.14 可先沿用并完成本讲验收。
具体制作端运行版本、操作系统和未覆盖的测试范围见 VALIDATION.md。
