# 第 2 讲代码阅读顺序

1. `first_program.py`：必读。只有三条执行语句，每条都有说明。
2. 你自己创建的 `my_first_program.py`：必做，修改、保存并重跑。
3. `environment_probe.py`：必运行，先认识输出字段。暂不要求手写函数、字典或路径代码。
4. `save_result.py`：必运行，观察终端输出与磁盘结果的区别。
5. `practice_starter.py`：练习起点，复制为 `my_practice.py` 后修改。
6. `practice_answer.py`：对应第 11 题，做完后核对。

`environment_probe.py` 每次覆盖 `outputs/environment_report.json`。
`save_result.py` 每次覆盖 `outputs/learning_receipt.txt`。
两个程序都用脚本位置计算输出位置。想保留多次实验结果，请先把报告复制到 `worksheets` 并改名。

报告中的路径可能包含你的电脑用户名。提交实验时，只需记录有关环境和项目的部分，个人用户名可替换为“我的用户”。

本讲代码只完成环境观察和最小运行练习，并不是一个智能体，也不调用模型。
