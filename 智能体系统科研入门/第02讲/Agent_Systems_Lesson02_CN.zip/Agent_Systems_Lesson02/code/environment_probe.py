"""第 2 讲的环境观察工具。先观察输出，具体语法将在后续课程学习。

仅使用 Python 标准库。不联网、不安装软件、不修改系统设置。
报告只记录解释器和本课程的文件路径；每次运行覆盖自己的报告文件。
"""

# sys 提供当前 Python 进程的信息；Path 帮我们处理文件路径。
import json
import sys
from pathlib import Path


def powershell_quote(text):
    """把路径放进 PowerShell 单引号中，路径里的单引号要写成两个。"""
    return "'" + str(text).replace("'", "''") + "'"


def main():
    # __file__ 指向当前脚本，resolve 得到它的绝对路径。
    script_path = Path(__file__).resolve()
    # 当前脚本在 code 文件夹里；再向上一层就是本讲根目录。
    project_root = script_path.parent.parent
    # cwd 是工作目录，即这次启动程序时所在的目录。
    working_directory = Path.cwd()

    # 这里分别检查两种环境特征。Conda 不应仅靠 prefix 差异判断。
    if (Path(sys.prefix) / "conda-meta").is_dir():
        environment_kind = "conda"
    elif sys.prefix != sys.base_prefix:
        environment_kind = "venv"
    else:
        environment_kind = "other_or_system"

    # 这份小字典用于写报告。下一讲会详细介绍字典。
    report = {
        "python_executable": sys.executable,
        "python_version": sys.version.split()[0],
        "environment_kind_hint": environment_kind,
        "working_directory": str(working_directory),
        "script_path": str(script_path),
        "project_root": str(project_root),
    }

    print("=== 第 2 讲 环境观察 ===")
    for name, value in report.items():
        print(f"{name}: {value}")

    # 输出位置以脚本的位置为依据，改变 cwd 不会改变报告目录。
    output_dir = project_root / "outputs"
    output_dir.mkdir(exist_ok=True)
    report_path = output_dir / "environment_report.json"
    report_path.write_text(
        json.dumps(report, ensure_ascii=False, indent=2) + "\n",
        encoding="utf-8",
    )
    print(f"报告已保存: {report_path}")
    print("提示：这些信息帮助检查环境，不代表环境已通过全部验收。")

    # 仅在 Windows 上给出可直接复制到 PowerShell 的命令。
    # & 是 PowerShell 的调用符。这里打印命令，但不会自动执行命令。
    if sys.platform == "win32":
        print("\n以下命令供 PowerShell 使用，前提是这个解释器正是你选择的环境：")
        for name in ("first_program.py", "environment_probe.py", "save_result.py"):
            executable = powershell_quote(sys.executable)
            script = powershell_quote(script_path.parent / name)
            print(f"& {executable} {script}")


# 直接运行这个文件时，从 main 开始。函数语法将在第 4 讲学习。
if __name__ == "__main__":
    main()
