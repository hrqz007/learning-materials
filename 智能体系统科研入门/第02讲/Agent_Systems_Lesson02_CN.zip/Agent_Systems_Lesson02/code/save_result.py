"""把一次学习结果保存为文件，用来区分终端输出和磁盘文件。"""

from pathlib import Path


def main():
    # 本讲先把路径处理看成已有工具，第 5 讲再详细学习文件操作。
    project_root = Path(__file__).resolve().parent.parent
    output_dir = project_root / "outputs"
    output_dir.mkdir(exist_ok=True)

    # 只写入这个固定文件。再次运行会覆盖它，不会累加多份内容。
    output_file = output_dir / "learning_receipt.txt"
    content = (
        "第 2 讲学习记录\n"
        "我能够运行程序并找到程序保存的结果。\n"
        "这份文件由 save_result.py 写入。\n"
    )
    # 显式使用 UTF-8 编码，确保保存中文时编码一致。
    output_file.write_text(content, encoding="utf-8")
    print("学习记录已保存。")
    print(f"文件位置: {output_file}")


if __name__ == "__main__":
    main()
