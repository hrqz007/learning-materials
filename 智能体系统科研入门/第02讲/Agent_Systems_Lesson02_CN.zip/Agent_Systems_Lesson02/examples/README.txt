这些是教学包制作端实际运行留下的样例，不是你本人的实验结果。

实际验证系统：Linux
实际验证 Python：3.12.14，另建标准 venv，无第三方依赖
项目目录故意包含空格和中文，用来验证路径处理。

actual_root_run.json：从项目根目录启动时生成的真实报告。
actual_code_run.json：从 code 目录启动时生成的真实报告。
actual_learning_receipt.txt：save_result.py 实际写入的文件。
validation_log.txt：实际命令参数、输出和检查结果。

Windows 上的路径使用盘符和反斜杠，通常与这些 Linux 路径不同。
不要把样例里的 /workspace 路径复制到你的 Windows 命令中。
报告值之间的比较关系可以参考；你仍需亲自生成 root_run.json 和 code_run.json。

broken_syntax.py.txt 与 broken_name.py.txt 是故意写错的独立示例。
请把其中内容复制到你自己的 code/my_error.py 里，再按实验书的运行方式观察报错。
它们不属于正常示例；文档中的预期错误已经实际验证。
