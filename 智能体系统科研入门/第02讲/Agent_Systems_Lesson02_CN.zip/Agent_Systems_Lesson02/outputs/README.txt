这里存放你亲自运行程序后的结果。
environment_probe.py 生成 environment_report.json。
save_result.py 生成 learning_receipt.txt。
每次运行会覆盖各自同名文件，需要保留不同实验条件时请先复制并改名。
教学包附带的制作端实际运行记录在 examples 文件夹中，不能代替你的验收记录。
