# 第 4 讲参考资料

查阅日期：2026-09-25。以下为 Python 官方原始文档，用于核对语言规则。本讲的登记场景、示意图、实验、题目和源码为配套教学设计。

1. [More Control Flow Tools](https://docs.python.org/3.13/tutorial/controlflow.html)：if、for、range、循环控制和函数入门。
2. [Compound statements](https://docs.python.org/3.13/reference/compound_stmts.html)：if、while、for、函数定义与代码块。
3. [Simple statements](https://docs.python.org/3.13/reference/simple_stmts.html)：return、break、continue。

教程使用基础 Python 3 语法，测试使用 Python 3.12.14。链接固定为 Python 3.13 文档，不要求更换学习者现有的课程解释器。
