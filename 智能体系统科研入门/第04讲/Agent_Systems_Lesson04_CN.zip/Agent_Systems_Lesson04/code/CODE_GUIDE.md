# 第 4 讲源码说明

所有材料是虚构教学名称。程序只做本地登记模拟，不调用大模型、不读取真实论文、不产生网络请求。

## 文件与用途

| 文件 | 用途 | 先学什么 |
| --- | --- | --- |
| syntax_examples.py | 条件、for、while 与函数返回的短例子 | 讲义 1～6 节 |
| lesson04_demo.py | 完整主程序，提供 run_task 函数 | 讲义 7～9 节 |
| budget_experiment.py | 固定材料，只改变预算，再单独检查空材料 | 实验书第 5 节 |
| boundary_experiment.py | 正确检查、错误比较符号、错误检查顺序三组 | 实验书第 6 节 |
| practice_starter.py | 第 16 题模板，先复制为 my_practice.py | 独立练习 |
| practice_answer.py | 第 16 题完整参考答案 | 做完练习后查看 |

## 在哪里运行

保持这些文件都在 code 目录中。从本讲根目录执行：

```bat
python code\lesson04_demo.py
python code\budget_experiment.py
python code\boundary_experiment.py
python code\syntax_examples.py
```

这几行对应已经激活原 conda 环境的终端。

第二讲使用 .venv 的学习者，在本讲根目录的 PowerShell 中用：

```powershell
..\Agent_Systems_Lesson02\.venv\Scripts\python.exe code\lesson04_demo.py
```

其他脚本仅替换末尾文件名。该相对路径要求第二讲和第四讲的文件夹并排放置。
完整重开与解释器选择说明在根目录 01_REOPEN_CHECKLIST.txt。

## 主函数输入输出约定

run_task(papers, max_steps) 接受字符串列表和非负整数预算。它返回一张新的任务字典，含 papers、max_steps、used_steps、notes、completed、stop_reason。它拒绝负预算、浮点预算、字符串预算和布尔值预算；没有为任意外部材料类型构建完整校验。

一次登记对应一条 notes 记录和一次计数加 1。预算在登记之前检查，条件为 >=。当输入非空且全部登记完，completed 为 True；空材料返回 no_materials 且 completed 为 False；有未登记材料时返回 budget_exhausted。

papers.copy() 复制外层列表，列表中是不可变字符串，本例足够使用。函数每次新建 task 与 notes，实验结果彼此独立。函数不会修改调用者的原列表。

main 入口判断让导入函数时不重复执行演示。程序状态仅存在于本次进程，不自动写文件。需要保留的终端输出请自己复制并保存。

## 两个故意错误

boundary_experiment.py 里的 wrong_operator 和 wrong_order 是教学对照，不是推荐实现。三组函数都只遍历有限列表，可以正常运行并结束。

examples/error_while_static.py.txt 是只读分析材料，不能作为正常实验直接运行。其他两个错误例子可按实验书复制到自己的 .py 文件后逐个运行、修复。
