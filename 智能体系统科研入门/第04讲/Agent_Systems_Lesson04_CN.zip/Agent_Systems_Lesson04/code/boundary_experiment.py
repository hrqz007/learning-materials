"""三个有限循环的教学对照；两种故意错误都不会无限运行。

每个函数从空记录开始，一次 append 表示一次实际登记。
用 len(processed) 观察实际动作数量，避免只相信程序自己的完成标记。
"""


def correct_guard(papers, budget):
    processed = []
    for paper in papers:
        if len(processed) >= budget:
            break
        processed.append(paper)
    return processed


def wrong_operator(papers, budget):
    processed = []
    for paper in papers:
        if len(processed) > budget:  # 故意错误：相等时仍会放行。
            break
        processed.append(paper)
    return processed


def wrong_order(papers, budget):
    processed = []
    for paper in papers:
        processed.append(paper)  # 故意错误：已经行动，才检查上限。
        if len(processed) >= budget:
            break
    return processed


if __name__ == "__main__":
    papers = ["示例论文A", "示例论文B", "示例论文C"]
    for budget in [2, 0]:
        print(f"=== 固定预算 {budget} ===")
        correct = correct_guard(papers, budget)
        operator = wrong_operator(papers, budget)
        order = wrong_order(papers, budget)
        print("正确前置检查:", len(correct), correct)
        print("错误比较符号:", len(operator), operator)
        print("错误检查顺序:", len(order), order)
