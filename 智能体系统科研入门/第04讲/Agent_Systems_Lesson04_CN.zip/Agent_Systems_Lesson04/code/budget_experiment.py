"""固定三条材料，只改变预算；然后单独观察空材料边界。"""
from lesson04_demo import run_task

papers = ["示例论文A", "示例论文B", "示例论文C"]
for budget in [0, 1, 2, 3, 5]:
    # 每次调用都会初始化新任务，不延续上一组的计数和笔记。
    result = run_task(papers, budget)
    print(
        f"预算={budget} | 实际登记={len(result['notes'])} | "
        f"已用={result['used_steps']} | 完成={result['completed']} | "
        f"原因={result['stop_reason']}"
    )

empty = run_task([], 2)
print(
    f"空材料 | 预算=2 | 实际登记={len(empty['notes'])} | "
    f"完成={empty['completed']} | 原因={empty['stop_reason']}"
)
