"""第 16 题参考答案；仅接受题目约定的列表与非负整数预算。"""


def register_titles(titles, max_steps):
    registered = []
    for title in titles:
        if len(registered) >= max_steps:
            break
        registered.append(title)
    return registered


if __name__ == "__main__":
    titles = ["材料甲", "材料乙", "材料丙", "材料丁"]
    result = register_titles(titles, 2)
    print("登记结果:", result)
    print("实际登记数:", len(result))
