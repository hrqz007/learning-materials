"""第 16 题起始模板。先复制为 my_practice.py，再独立补全。"""


def register_titles(titles, max_steps):
    registered = []
    # TODO：逐条遍历；登记前检查预算；达到上限时 break。
    # TODO：没有达到上限时，将当前 title 追加到 registered。
    return registered


if __name__ == "__main__":
    titles = ["材料甲", "材料乙", "材料丙", "材料丁"]
    result = register_titles(titles, 2)
    print("登记结果:", result)
    print("实际登记数:", len(result))
