"""讲义中的独立小例子，顺序运行即可；本文件不会无限循环。"""

print("=== 条件与缩进 ===")
used_steps = 2
max_steps = 2
if used_steps >= max_steps:
    print("停止")
else:
    print("可以继续")
print("检查结束")

print("=== for 与 range ===")
for paper in ["示例论文A", "示例论文B"]:
    print(paper)
for i in range(3):
    print("编号:", i)

print("=== while 每轮重新判断 ===")
used_steps = 0
while used_steps < 2:
    used_steps += 1
    print("已执行:", used_steps)
print("循环之后:", used_steps)

print("=== return 将结果交给调用者 ===")


def remaining(max_steps, used_steps):
    return max_steps - used_steps


value = remaining(5, 2)
print("剩余:", value)
