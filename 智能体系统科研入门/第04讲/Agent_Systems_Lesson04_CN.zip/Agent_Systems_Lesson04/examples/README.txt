第 4 讲：实际运行输出与调试例子

actual_main_output.txt：主程序默认三条材料、两步预算的实际标准输出。
actual_budget_output.txt：预算为 0、1、2、3、5 与空材料检查的实际输出。
actual_boundary_output.txt：三种预算检查版本在预算 2 和 0 下的实际输出。
actual_syntax_output.txt：基础语法短例子的实际输出。
actual_practice_output.txt：练习参考程序默认输入的实际输出。
validation_log.txt：实际运行命令、退出码、输出和验证项目。

以上记录在 Linux、Python 3.12.14 环境中实际产生。
日志内 /workspace/... 是编写者的验证路径，不是你的 Windows 路径，请勿照抄。
对应 Windows 运行命令见实验设计书与重开清单。
输出文件由编写者在验证过程中保存；源码运行时只打印，不自动保存输出文件。

error_missing_return.py.txt：故意只打印、不返回计算值。
error_early_return.py.txt：故意把 return 缩进到循环内部。
这两个短例子按实验书复制为你自己的 .py 后运行、修复。

error_while_static.py.txt：状态不更新造成无限循环，仅供阅读分析，不直接运行。
验证过程中没有运行这个无限循环示例。自己编写程序遇到不停输出时，在运行终端按 Ctrl+C。

先预测并实际运行正常实验，再看这里的输出。不要用提供的样例替代你自己的实验记录。
