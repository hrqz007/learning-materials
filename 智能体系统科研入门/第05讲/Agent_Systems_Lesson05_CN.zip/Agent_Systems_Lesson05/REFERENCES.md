# 第 5 讲参考资料

查阅日期：2026-09-25。配套场景、实验和代码用于本课教学，格式规则核对以下原始文档。

1. [Python Input and Output](https://docs.python.org/3.13/tutorial/inputoutput.html)：文件读写、with、编码与基本 JSON 操作。
2. [Python json](https://docs.python.org/3.13/library/json.html)：dump、load、dumps、loads 和数据类型转换。
3. [Python pathlib](https://docs.python.org/3.13/library/pathlib.html)：路径拼接、parent、resolve、mkdir 与 open。
4. [JSON Lines](https://jsonlines.org/)：UTF-8、一行一个完整 JSON 值与换行约定。

链接固定为 Python 3.13 文档，本讲实际验证使用 Python 3.12.14，不要求更换已有课程解释器。
