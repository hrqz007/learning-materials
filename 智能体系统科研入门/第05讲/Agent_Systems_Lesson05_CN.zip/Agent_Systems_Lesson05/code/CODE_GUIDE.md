# 第 5 讲源码说明

所有示例均是本地材料登记，不调用模型、网络或真实阅读工具。只使用 Python 标准库。

| 文件 | 用途 |
| --- | --- |
| agent_core.py | 复用第四讲的 run_task，保持预算与停止规则 |
| lesson05_save.py | 读取和验证配置，登记后保存四个文件 |
| read_saved_run.py | 在新进程读取指定运行，不触发登记 |
| file_modes_experiment.py | 在新实验目录比较 w、a、x |
| practice_starter.py | 第 16 题起始模板，先复制再独立完成 |
| practice_answer.py | 第 16 题完整参考答案，做完后查看 |

## 最小运行方式

在本讲根目录、原 conda 环境中运行：

```bat
python code\lesson05_save.py
python code\read_saved_run.py
```

第二讲使用 .venv 的学习者，在 PowerShell 中用：

```powershell
..\Agent_Systems_Lesson02\.venv\Scripts\python.exe code\lesson05_save.py
..\Agent_Systems_Lesson02\.venv\Scripts\python.exe code\read_saved_run.py
```

这要求第二讲与第五讲文件夹并排。其他布局使用实际解释器路径。详细步骤见实验设计书或根目录重开清单。

## 配置约定

默认读取 data/task_config.json。顶层只允许 papers 与 max_steps 两个键。papers 为列表，每项是去掉两侧空白后仍有内容的字符串；验证不会改变原名称。max_steps 为非负普通整数，不接受布尔值、浮点数或字符串。

JSON 格式不合法由 json.load 报 JSONDecodeError；格式合法但字段不合约定由 validate_config 报 ValueError。输入不存在时抛 FileNotFoundError。程序不静默补默认值。

## 保存的含义

每次从零开始登记，再选 outputs 下第一个尚未存在的 run_001、run_002 等编号目录。若删除旧编号，该编号可能重新使用。此方案针对单进程顺序运行，不是并发编号分配机制。

每次目录包含 config_snapshot.json、result.json、events.jsonl 和 summary.txt。四个文件分别写入，正常完成后主程序才显示“已保存”。写入中途失败可能留下部分文件，with 不负责事务回滚。保存使用 x，拒绝覆盖已存在文件。

日志先在内存记录开始和结束，正常登记后统一写入，仅有两条事件。它没有每一步工具轨迹，不保证异常退出前的事件能够保留。不要把两条事件当成两次独立运行。

## 读取的含义

修改 read_saved_run.py 中 RUN_NAME，指定实际已有的目录名。它读回配置、结果和两条事件；不调用 run_task，不改写历史文件，也不继续上次未完成的登记。

再次运行保存脚本会读取当前配置并开始新任务。真正的断点续跑需要额外协议，本课没有实现。

## 调试样例

examples/bad_configs 里有四个故意错误配置。选学实验按实验书复制完整保存脚本，仅修改入口的配置路径，不修改正常 data/task_config.json。

file_modes_experiment.py 故意对自己新建的实验文件使用 w、a、x。它只捕获预期的 FileExistsError，保留其他错误，不用宽泛的异常捕获伪造成功。

practice_starter.py 尚未实现读写，运行会得到 None 与 False，并留下空练习目录；这是待完成模板，不是参考答案。
