"""第 5 讲复用第四讲的登记核心，执行规则保持不变。

输入约定：papers 是字符串列表；max_steps 是非负整数，不接受布尔值。
一步只代表登记一条材料。程序没有阅读论文、调用模型或执行外部工具。
"""


def run_task(papers, max_steps):
    """每次调用创建一张新任务卡，返回执行后的字典。"""
    # type 判断类型；or 表示任一条件成立就拒绝这个预算。
    if type(max_steps) != int or max_steps < 0:
        raise ValueError("max_steps 必须是非负整数，不能是布尔值")

    task = {
        "papers": papers.copy(),  # 本例列表中只有字符串，浅复制已足够。
        "max_steps": max_steps,
        "used_steps": 0,
        "notes": [],
        "completed": False,
        "stop_reason": "not_started",
    }

    # for 按原顺序逐条取材料；paper 每轮绑定到当前材料名称。
    for paper in task["papers"]:
        # 先检查再行动。相等时也必须停止，不能写成 >。
        if task["used_steps"] >= task["max_steps"]:
            break
        task["notes"].append(f"{paper}：已登记，内容待核对")
        task["used_steps"] += 1  # 本例等价于原值加 1 后重新赋值。

    # 这是循环结束后的结果分类，不属于上面的 for 循环体。
    if len(task["papers"]) == 0:
        task["stop_reason"] = "no_materials"
    elif task["used_steps"] == len(task["papers"]):
        task["completed"] = True
        task["stop_reason"] = "all_items_processed"
    else:
        task["stop_reason"] = "budget_exhausted"
    return task  # 结束本次函数调用，并把字典交给调用者。


