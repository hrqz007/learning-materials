"""只在自己新建的实验目录中比较 w、a、x，不修改既有实验结果。"""
from pathlib import Path
from lesson05_save import new_run_dir

ROOT = Path(__file__).resolve().parent.parent


def run_modes(output_root):
    directory = new_run_dir(output_root)
    overwrite = directory / "overwrite.txt"
    with overwrite.open("w", encoding="utf-8") as f:
        f.write("第一条\n")
    with overwrite.open("w", encoding="utf-8") as f:
        f.write("第二条\n")

    append = directory / "append.txt"
    with append.open("w", encoding="utf-8") as f:
        f.write("第一条\n")
    with append.open("a", encoding="utf-8") as f:
        f.write("第二条\n")

    exclusive = directory / "exclusive.txt"
    with exclusive.open("x", encoding="utf-8") as f:
        f.write("首次创建\n")
    # 这里只捕获预计出现的这一个异常，便于实验继续显示结果。
    try:
        with exclusive.open("x", encoding="utf-8") as f:
            f.write("不应写入\n")
    except FileExistsError:
        print("第二次 x 写入: FileExistsError，旧内容保持不变")
    print("w 两次后的内容:", repr(overwrite.read_text(encoding="utf-8")))
    print("w 后 a 的内容:", repr(append.read_text(encoding="utf-8")))
    print("x 文件的内容:", repr(exclusive.read_text(encoding="utf-8")))
    return directory


if __name__ == "__main__":
    print("实验目录:", run_modes(ROOT / "outputs" / "file_modes"))
