"""第 5 讲：读取配置，运行登记任务，保存四种文件。

从任意工作目录运行本 .py 文件，数据位置都以脚本所在项目为基准。
日志先放在内存，登记正常结束后统一写盘；不是实时持久化日志。
"""
import json
from pathlib import Path
from agent_core import run_task

ROOT = Path(__file__).resolve().parent.parent


def validate_config(config):
    """先检查数据含义。JSON 能解析，并不代表字段满足任务要求。"""
    if type(config) != dict:
        raise ValueError("配置顶层必须是 JSON 对象")
    for key in ["papers", "max_steps"]:
        if key not in config:
            raise ValueError(f"配置缺少字段: {key}")
    for key in config:
        if key not in ["papers", "max_steps"]:
            raise ValueError(f"本课不支持配置字段: {key}")
    if type(config["papers"]) != list:
        raise ValueError("papers 必须是列表")
    for title in config["papers"]:
        if type(title) != str or title.strip() == "":
            raise ValueError("每条材料名称必须是非空字符串")
    if type(config["max_steps"]) != int or config["max_steps"] < 0:
        raise ValueError("max_steps 必须是非负整数，不能是布尔值")


def new_run_dir(output_root):
    """单进程依次编号，保留已有运行；并发分配目录不在本课范围。"""
    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    number = 1
    run_dir = output_root / f"run_{number:03d}"
    while run_dir.exists():
        number += 1
        run_dir = output_root / f"run_{number:03d}"
    run_dir.mkdir()  # 如果同名目录此刻已被创建，会报错，不覆盖它。
    return run_dir


def run_and_save(config_path, output_root):
    # r 表示读取；with 结束时关闭文件；UTF-8 统一中文编码。
    with Path(config_path).open("r", encoding="utf-8") as f:
        config = json.load(f)
    validate_config(config)
    events = [{"seq": 1, "event": "run_started"}]
    result = run_task(config["papers"], config["max_steps"])
    events.append({
        "seq": 2, "event": "run_finished",
        "used_steps": result["used_steps"],
        "stop_reason": result["stop_reason"],
    })
    run_dir = new_run_dir(output_root)
    # x 表示只创建新文件；同名文件存在时拒绝覆盖。
    with (run_dir / "config_snapshot.json").open("x", encoding="utf-8") as f:
        json.dump(config, f, ensure_ascii=False, indent=2, allow_nan=False)
    with (run_dir / "result.json").open("x", encoding="utf-8") as f:
        json.dump(result, f, ensure_ascii=False, indent=2, allow_nan=False)
    with (run_dir / "events.jsonl").open("x", encoding="utf-8") as f:
        for event in events:
            f.write(json.dumps(event, ensure_ascii=False) + "\n")
    with (run_dir / "summary.txt").open("x", encoding="utf-8") as f:
        f.write(f"实际登记数: {len(result['notes'])}\n")
        f.write(f"登记全部完成: {result['completed']}\n")
        f.write(f"停止原因: {result['stop_reason']}\n")
    return run_dir


if __name__ == "__main__":
    saved_dir = run_and_save(ROOT / "data" / "task_config.json", ROOT / "outputs")
    print("本次目录:", saved_dir)
    print("已保存: config_snapshot.json, result.json, events.jsonl, summary.txt")
    print("请打开本次目录核对结果；读取历史文件不会自动继续执行任务。")
