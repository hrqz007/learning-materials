"""第 16 题参考答案；每次运行使用新目录，不覆盖旧文件。"""
import json
from pathlib import Path
from lesson05_save import new_run_dir

ROOT = Path(__file__).resolve().parent.parent


def save_and_load(task, path):
    with path.open("x", encoding="utf-8") as f:
        json.dump(task, f, ensure_ascii=False, indent=2)
    with path.open("r", encoding="utf-8") as f:
        restored = json.load(f)
    return restored


if __name__ == "__main__":
    task = {"goal": "核对实验记录", "completed": False, "notes": ["待人工复核"]}
    directory = new_run_dir(ROOT / "outputs" / "practice")
    restored = save_and_load(task, directory / "my_task.json")
    print("实验目录:", directory)
    print("读回结果:", restored)
    print("值相等:", restored == task)
