"""第 16 题模板。复制为 my_practice.py，独立完成后再看答案。"""
import json
from pathlib import Path
from lesson05_save import new_run_dir

ROOT = Path(__file__).resolve().parent.parent


def save_and_load(task, path):
    # TODO：用 x、UTF-8 和 json.dump 保存。
    # TODO：用 r、UTF-8 和 json.load 读回，再返回读回对象。
    return None


if __name__ == "__main__":
    task = {"goal": "核对实验记录", "completed": False, "notes": ["待人工复核"]}
    directory = new_run_dir(ROOT / "outputs" / "practice")
    restored = save_and_load(task, directory / "my_task.json")
    print("实验目录:", directory)
    print("读回结果:", restored)
    print("值相等:", restored == task)
