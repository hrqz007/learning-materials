"""在新的 Python 进程里读取一次历史运行，不执行登记任务。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUN_NAME = "run_001"  # 查看别次运行时，只改成实际存在的文件夹名称。


def read_run(run_dir):
    with (run_dir / "config_snapshot.json").open("r", encoding="utf-8") as f:
        config = json.load(f)
    with (run_dir / "result.json").open("r", encoding="utf-8") as f:
        result = json.load(f)
    events = []
    with (run_dir / "events.jsonl").open("r", encoding="utf-8") as f:
        for line in f:
            events.append(json.loads(line))
    return config, result, events


if __name__ == "__main__":
    run_dir = ROOT / "outputs" / RUN_NAME
    config, result, events = read_run(run_dir)
    print("读取目录:", run_dir)
    print("当次预算:", config["max_steps"])
    print("历史登记数:", len(result["notes"]))
    print("历史完成标记:", result["completed"])
    print("历史停止原因:", result["stop_reason"])
    print("读回类型:", type(result["completed"]).__name__)
    print("事件条数:", len(events))
    for event in events:
        print(event["seq"], event["event"])
