第 5 讲 实际运行样例

以下文件来自 Linux、Python 3.12.14 的真实执行。
验证在项目副本中进行，并从另一个工作目录启动完整脚本；资料包 outputs 保持未运行状态。

saved_run_budget2/：预算 2 的首次运行，包含四个真实生成文件。
saved_run_budget3/：只把配置预算改为 3 后的第二次运行，包含四个真实生成文件。
file_modes_run/：w、a、x 实验实际产生的三个文件。
config_original.json：原始正常配置的副本，需要时参考其内容恢复预算 2。

actual_save_budget2_output.txt 和 actual_save_budget3_output.txt：两次保存程序的终端输出。
actual_read_budget2_output.txt 和 actual_read_budget3_output.txt：新进程读取两组历史的实际输出。
actual_file_modes_output.txt：文件模式实验输出。
actual_practice_output.txt：练习参考答案输出。
actual_bad_config_diagnostics.txt：四个错误配置实际产生的异常类别和信息。
validation_log.txt：验证环境、实际运行命令、输出和验证项目。

bad_configs 中的四个 JSON 是故意错误的输入，不应当作正常配置。
trailing_comma.json：多余末尾逗号。
string_budget.json：预算是字符串。
wrong_papers.json：材料字段是字符串而不是列表。
missing_key.json：缺少预算字段。

日志中的 /workspace/... 是编写者的路径，不是你的 Windows 路径，不能照抄。
运行时请按实验设计书使用自己的解释器与项目路径。
编写者的样例只用于对照，不能替代自己的实验记录。
读取历史、从零重跑、真正续跑是三个不同动作，本课只实现前两个。
