# 第六讲参考资料

查阅日期：2026-09-25。正文用编号定位来源；本课没有调用模型 API，也不依赖这些网页运行代码。

1. Python 官方文档，Built-in Types。核对 str.count 的不重叠计数和空子串行为，以及 0、None 的真假值规则。
   https://docs.python.org/3.13/library/stdtypes.html
2. Python 官方教程，Errors and Exceptions。区分异常与普通返回值的语法基础。
   https://docs.python.org/3.13/tutorial/errors.html
3. Anthropic 官方文档，Tool use with Claude。说明客户端工具由应用执行，以及服务端工具执行位置不同。本课使用自定义教学协议，没有复制当前 API 的消息格式。
   https://platform.claude.com/docs/en/agents-and-tools/tool-use/overview
4. Yao 等，ReAct: Synergizing Reasoning and Acting in Language Models，arXiv:2210.03629，2022 提交，2023 修订。后续学习模型推理与行动交替的研究入口，本课不是该论文的复现。
   https://arxiv.org/abs/2210.03629

知识卡是本教程编写的短文本，人工统计参考答案来自卡片自身，不是外部科研数据集。运行环境与实际验证见 VALIDATION.md。
