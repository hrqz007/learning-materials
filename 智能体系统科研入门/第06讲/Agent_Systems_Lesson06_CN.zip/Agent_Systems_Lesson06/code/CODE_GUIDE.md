# 第六讲源码阅读说明

先运行，再定位最小的一段代码。全部源码带中文注释，只使用 Python 标准库。完整项目的 code、data、outputs 相对位置要保留。

## 七份源码的分工

| 文件 | 做什么 | 是否直接运行 |
| --- | --- | --- |
| toolbox.py | 两个工具、成功失败包装、动作分发与参数检查 | 通常由其他脚本导入 |
| agent_loop.py | 检查配置、选择动作、控制循环、生成最终结果 | 通常由入口导入 |
| lesson06_run.py | 读输入、调用循环、保存五个证据文件 | 完整实验入口 |
| read_trace.py | 读回历史结果并逐次显示 | 修改 RUN_NAME 后运行 |
| dispatch_demo.py | 单独展示七组合法或错误请求 | 初学先运行它 |
| practice_starter.py | 独立练习的起始文件 | 复制为 my_practice.py 后补全 |
| practice_answer.py | 练习的完整参考解答 | 独立完成后对照 |

## 建议阅读顺序

先看 toolbox.py 的 lookup_card 与 count_keyword。工具的具体能力只有两件事：按编号取出内存字典里的卡片；按精确子串计数。没有联网、全文检索或论文理解。

然后看 success 与 failure。它们只是构造统一观察字典，减少重复。成功时 data 有实际结果、error 为 None；失败时 data 为 None、error 保存类别和说明。tool_called 表示是否进入了工具函数，由本课实现记录，不是独立外部监测器。

接着看 dispatch。它先检查 action 的类型与键，再核对工具允许列表，再检查 arguments 的字段、类型与非空约束。最后两个函数调用才真正执行操作。直接调用工具函数会绕过这里的输入检查；本课其他组件都通过 dispatch 使用工具。

再看 agent_loop.py 的 choose_action。没有卡片就提出查询，已有卡片就用返回的真实正文提出统计。函数只生成数据。它依赖外层循环只在未结束时调用它，不独立处理完成后的调用。

最后跟踪 run_agent 的 while：检查预算 → 选择动作 → 尝试计数加一 → 分发 → 更新状态或记录错误 → 记录轨迹 → 判断停止。完成条件用 is not None，确保零次匹配也能成功。

## 关键字段

| 字段 | 含义 |
| --- | --- |
| goal.card_id | 本次希望查询的精确编号 |
| goal.keyword | 希望统计的非空字符串 |
| goal.max_attempts | 最多送入分发器的请求次数 |
| action.tool | 工具名字符串，不是可执行函数对象 |
| action.arguments | 此工具的参数字典 |
| observation.ok | 本次工具按本课约定成功还是失败 |
| observation.tool_called | 是否进入了工具函数 |
| state.card | 查到的卡片；起始为 None |
| state.count | 得到的计数；起始为 None，允许为 0 |
| used_attempts | 已提交请求数；分发前拒绝也算一次 |
| tool_calls | trace 中 tool_called=True 的数量 |
| completed | 本课控制器是否取得卡片和计数 |
| stop_reason | goal_completed、budget_exhausted 或具体错误 code |

表中点号用于说明字典的层级，并不是 Python 字典取值语法。实际代码写 goal["card_id"]、observation["data"]["text"] 等。

## 保存入口与运行记录

lesson06_run.py 的 ROOT 根据脚本位置确定项目目录，不根据终端当前目录猜测。run_and_save 读取任务和卡片，run_agent 正常返回后，才选新编号目录并写入五个文件。

run_agent 正常返回既可能 completed=True，也可能是有记录的预期失败。文件写入失败或意外程序异常会抛出异常，不打印“全部保存成功”。本课没有把五个文件合成事务，也没有逐步落盘。

new_run_dir 选择第一个不存在的编号；如果删掉旧目录，编号可能被重新使用。只用于单进程顺序实验，不保证并发分配，也不是时间戳。

read_trace.py 读取 result.json 和 trace.jsonl；目标与卡片快照在运行目录中另行打开核对。它不调用任何工具，也不自动挑选“最近的一次”。

## 两个具体跟踪例子

C02 与预算 2：起始 card=None、count=None → 查到卡片，count 仍为 None → 统计得到 3 → 完成并停止。

C01 与预算 2：同样查到卡片 → 统计得到 0 → 仍然完成。若把判断误改成 if state["count"]，就会丢掉这个合法零值。

C99：进入查询函数但找不到 → 观察 ok=False、tool_called=True → 记录 NOT_FOUND 并停止，不再发起统计。

## 独立练习

practice_starter.py 中的 TODO 是有意留给你的作业。直接运行会显示 None，不表示主程序损坏。把副本命名为 my_practice.py，放在 code 内，先补查询与失败分支，再补统计。

practice_answer.py 只演示两次依赖调用，不带 run_agent 的配置验证、尝试预算、运行目录或轨迹保存机制。不要把练习函数当成完整控制器。

新增第三工具需要同步修改约定、实现与分发分支。仅在 TOOL_ARGUMENTS 添一项并不会自动绑定新的函数。
