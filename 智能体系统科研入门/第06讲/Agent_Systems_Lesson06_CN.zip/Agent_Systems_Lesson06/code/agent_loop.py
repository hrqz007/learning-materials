"""使用固定规则选择动作的教学控制器；没有大模型、自学习或自动重试。"""
from toolbox import dispatch


def validate_inputs(goal, cards):
    """配置错误在执行前报错；不存在的卡片编号留给工具返回 NOT_FOUND。"""
    if type(goal) != dict or set(goal) != {"card_id", "keyword", "max_attempts"}:
        raise ValueError("任务必须且只能包含 card_id、keyword、max_attempts")
    for key in ["card_id", "keyword"]:
        if type(goal[key]) != str or goal[key].strip() == "":
            raise ValueError(f"{key} 必须是非空字符串")
    budget = goal["max_attempts"]
    if type(budget) != int or budget < 0:
        raise ValueError("max_attempts 必须是非负整数，不能是布尔值")
    if type(cards) != dict:
        raise ValueError("卡片库必须是字典")
    for card_id, card in cards.items():
        if type(card_id) != str or card_id.strip() == "":
            raise ValueError("卡片编号必须是非空字符串")
        if type(card) != dict or set(card) != {"title", "text"}:
            raise ValueError("每张卡片必须且只能包含 title 和 text")
        if type(card["title"]) != str or card["title"].strip() == "":
            raise ValueError("卡片标题必须是非空字符串")
        if type(card["text"]) != str:
            raise ValueError("卡片正文必须是字符串，可以为空")


def choose_action(goal, state):
    """只提出动作数据；此函数本身不执行 lookup_card 或 count_keyword。"""
    if state["card"] is None:
        return {"tool": "lookup_card", "arguments": {"card_id": goal["card_id"]}}
    return {
        "tool": "count_keyword",
        "arguments": {"text": state["card"]["text"], "keyword": goal["keyword"]},
    }


def run_agent(goal, cards):
    """执行到任务完成、一次预期失败或预算耗尽，返回结果和完整尝试记录。"""
    validate_inputs(goal, cards)
    state = {"card": None, "count": None}
    trace = []
    used_attempts = 0
    stop_reason = "budget_exhausted"
    while used_attempts < goal["max_attempts"]:
        action = choose_action(goal, state)
        # 一次送入分发器的请求就消耗一次尝试，即使请求被拒绝。
        used_attempts += 1
        observation = dispatch(action, cards)
        if observation["ok"]:
            if action["tool"] == "lookup_card":
                state["card"] = observation["data"]
            else:
                state["count"] = observation["data"]["count"]
        else:
            stop_reason = observation["error"]["code"]
        trace.append({
            "step": used_attempts,
            "action": action,
            "observation": observation,
            "state_after": {"card_loaded": state["card"] is not None,
                            "count": state["count"]},
        })
        if not observation["ok"]:
            break
        # 0 是一个已经算出的合法答案；None 才表示尚未算出。
        if state["card"] is not None and state["count"] is not None:
            stop_reason = "goal_completed"
            break
    completed = state["card"] is not None and state["count"] is not None
    answer = None
    if completed:
        answer = {
            "card_id": state["card"]["card_id"],
            "title": state["card"]["title"],
            "text": state["card"]["text"],
            "keyword": goal["keyword"],
            "count": state["count"],
        }
    tool_calls = 0
    for record in trace:
        if record["observation"]["tool_called"]:
            tool_calls += 1
    result = {
        "used_attempts": used_attempts,
        "tool_calls": tool_calls,
        "completed": completed,
        "stop_reason": stop_reason,
        "answer": answer,
    }
    return result, trace
