"""先单独观察分发器：成功、工具内部未找到、分发前拒绝。不会生成运行目录。"""
import json
from pathlib import Path
from toolbox import dispatch

ROOT = Path(__file__).resolve().parent.parent


if __name__ == "__main__":
    with (ROOT / "data" / "cards.json").open("r", encoding="utf-8") as f:
        cards = json.load(f)
    cases = [
        ("正常查询", {"tool": "lookup_card", "arguments": {"card_id": "C02"}}),
        ("卡片不存在", {"tool": "lookup_card", "arguments": {"card_id": "C99"}}),
        ("未知工具", {"tool": "send_email", "arguments": {}}),
        ("参数类型错误", {"tool": "count_keyword", "arguments": {"text": "工具", "keyword": 2}}),
        ("参数缺失", {"tool": "count_keyword", "arguments": {"text": "工具"}}),
        ("零次匹配", {"tool": "count_keyword", "arguments": {"text": "任务", "keyword": "工具"}}),
        ("空关键词", {"tool": "count_keyword", "arguments": {"text": "工具", "keyword": ""}}),
    ]
    for label, action in cases:
        print(label)
        print("  请求:", json.dumps(action, ensure_ascii=False))
        print("  观察:", json.dumps(dispatch(action, cards), ensure_ascii=False))
