"""完整入口：读取任务和卡片，执行工具循环，保存证据。仅使用标准库。"""
import json
from pathlib import Path
from agent_loop import run_agent

ROOT = Path(__file__).resolve().parent.parent


def new_run_dir(output_root):
    """与第五讲相同：选择第一个不存在的编号。只用于单进程顺序运行。"""
    output_root = Path(output_root)
    output_root.mkdir(parents=True, exist_ok=True)
    number = 1
    run_dir = output_root / f"run_{number:03d}"
    while run_dir.exists():
        number += 1
        run_dir = output_root / f"run_{number:03d}"
    run_dir.mkdir()
    return run_dir


def run_and_save(goal_path, cards_path, output_root):
    with Path(goal_path).open("r", encoding="utf-8") as f:
        goal = json.load(f)
    with Path(cards_path).open("r", encoding="utf-8") as f:
        cards = json.load(f)
    result, trace = run_agent(goal, cards)
    # 正常返回包括有记录的任务失败。completed 决定任务是否完成。
    run_dir = new_run_dir(output_root)
    snapshots = {
        "goal_snapshot.json": goal,
        "cards_snapshot.json": cards,
        "result.json": result,
    }
    for filename, data in snapshots.items():
        with (run_dir / filename).open("x", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)
    with (run_dir / "trace.jsonl").open("x", encoding="utf-8") as f:
        for record in trace:
            f.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
    with (run_dir / "summary.txt").open("x", encoding="utf-8") as f:
        f.write(f"任务完成: {result['completed']}\n")
        f.write(f"尝试数: {result['used_attempts']}\n")
        f.write(f"进入工具函数数: {result['tool_calls']}\n")
        f.write(f"停止原因: {result['stop_reason']}\n")
        if result["completed"]:
            f.write(f"关键词出现次数: {result['answer']['count']}\n")
    return run_dir, result


if __name__ == "__main__":
    saved_dir, result = run_and_save(
        ROOT / "data" / "task.json", ROOT / "data" / "cards.json", ROOT / "outputs"
    )
    print("本次目录:", saved_dir)
    print("已保存五个证据文件。任务是否完成，请看下面的 completed。")
    print("completed:", result["completed"])
    print("used_attempts:", result["used_attempts"])
    print("tool_calls:", result["tool_calls"])
    print("stop_reason:", result["stop_reason"])
    if result["completed"]:
        print("关键词出现次数:", result["answer"]["count"])
