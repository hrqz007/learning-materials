"""练习第16题参考答案。这个函数演示依赖调用，不带主控制器的预算机制。"""
import json
from pathlib import Path
from toolbox import dispatch

ROOT = Path(__file__).resolve().parent.parent


def solve_once(card_id, keyword, cards):
    first = dispatch({
        "tool": "lookup_card", "arguments": {"card_id": card_id}
    }, cards)
    if not first["ok"]:
        return first
    second = dispatch({
        "tool": "count_keyword",
        "arguments": {"text": first["data"]["text"], "keyword": keyword},
    }, cards)
    return second


if __name__ == "__main__":
    with (ROOT / "data" / "cards.json").open("r", encoding="utf-8") as f:
        cards = json.load(f)
    for card_id, keyword in [("C02", "工具"), ("C99", "工具"), ("C01", "工具")]:
        print(card_id, keyword, solve_once(card_id, keyword, cards))
