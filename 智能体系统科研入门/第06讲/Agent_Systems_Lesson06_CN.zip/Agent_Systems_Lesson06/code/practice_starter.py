"""练习第16题。复制为 my_practice.py，再补全函数；先预测后参考答案。"""
import json
from pathlib import Path
from toolbox import dispatch

ROOT = Path(__file__).resolve().parent.parent


def solve_once(card_id, keyword, cards):
    # TODO 1：构造 lookup_card 动作，实际交给 dispatch 执行。
    # TODO 2：查询失败时直接返回它，不发起统计。
    # TODO 3：查询成功后，用它返回的正文构造 count_keyword 动作。
    # TODO 4：实际执行统计，返回第二个观察。禁止硬编码答案或直接调用工具函数。
    return None


if __name__ == "__main__":
    with (ROOT / "data" / "cards.json").open("r", encoding="utf-8") as f:
        cards = json.load(f)
    for card_id, keyword in [("C02", "工具"), ("C99", "工具"), ("C01", "工具")]:
        print(card_id, keyword, solve_once(card_id, keyword, cards))
