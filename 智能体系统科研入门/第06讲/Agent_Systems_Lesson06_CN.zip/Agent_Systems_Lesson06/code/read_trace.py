"""在新进程查看历史，不重新执行工具。修改 RUN_NAME 指定实际运行目录。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUN_NAME = "run_001"


def read_run(run_dir):
    with (run_dir / "result.json").open("r", encoding="utf-8") as f:
        result = json.load(f)
    records = []
    with (run_dir / "trace.jsonl").open("r", encoding="utf-8") as f:
        for line in f:
            records.append(json.loads(line))
    return result, records


if __name__ == "__main__":
    run_dir = ROOT / "outputs" / RUN_NAME
    result, records = read_run(run_dir)
    print("历史目录:", run_dir)
    for record in records:
        obs = record["observation"]
        print(f"第 {record['step']} 次尝试: {record['action']['tool']}")
        print("  参数:", record["action"]["arguments"])
        print("  进入工具函数:", obs["tool_called"], "工具成功:", obs["ok"])
        print("  数据:", obs["data"])
        print("  错误:", obs["error"])
        print("  更新后的状态:", record["state_after"])
    print("记录条数:", len(records))
    print("completed:", result["completed"])
    print("stop_reason:", result["stop_reason"])
    print("答案:", result["answer"])
