"""第六讲的工具与分发器。通过 dispatch 调用，输入才经过本课约定的检查。"""

# 允许调用的工具名称，以及每个工具必须且只能携带的参数。
# 这里只是本课的 Python 约定，不是某家模型 API 的协议或 JSON Schema。
TOOL_ARGUMENTS = {
    "lookup_card": ["card_id"],
    "count_keyword": ["text", "keyword"],
}


def success(data):
    """工具函数正常返回本课约定的数据。成功不代表整个任务已完成。"""
    return {"ok": True, "tool_called": True, "data": data, "error": None}


def failure(code, message, tool_called):
    """保留错误原因；tool_called 说明是否真正进入了工具函数。"""
    return {
        "ok": False,
        "tool_called": tool_called,
        "data": None,
        "error": {"code": code, "message": message},
    }


def lookup_card(card_id, cards):
    """按精确编号查本地卡片字典，不联网、不读论文、不做语义检索。"""
    if card_id not in cards:
        return failure("NOT_FOUND", f"没有编号为 {card_id} 的卡片", True)
    card = cards[card_id]
    return success({
        "card_id": card_id,
        "title": card["title"],
        "text": card["text"],
    })


def count_keyword(text, keyword):
    """精确统计不重叠的子串，区分大小写；不会分词或理解语义。"""
    return success({"keyword": keyword, "count": text.count(keyword)})


def dispatch(action, cards):
    """先检查请求，再显式调用两个允许的函数之一。

    格式错误与工具未找到是预期结果，返回结构化失败。
    意外的编程异常不在这里吞掉；本课不实现自动重试。
    """
    if type(action) != dict:
        return failure("INVALID_ACTION", "动作必须是字典", False)
    if set(action) != {"tool", "arguments"}:
        return failure("INVALID_ACTION", "动作只允许 tool 和 arguments", False)
    name = action["tool"]
    if type(name) != str:
        return failure("INVALID_ACTION", "tool 必须是字符串", False)
    if name not in TOOL_ARGUMENTS:
        return failure("UNKNOWN_TOOL", f"不允许调用工具 {name}", False)
    args = action["arguments"]
    if type(args) != dict:
        return failure("INVALID_ARGUMENTS", "arguments 必须是字典", False)
    expected = TOOL_ARGUMENTS[name]
    if set(args) != set(expected):
        return failure("INVALID_ARGUMENTS", f"参数必须且只能是 {expected}", False)
    for key in expected:
        if type(args[key]) != str:
            return failure("INVALID_ARGUMENTS", f"{key} 必须是字符串", False)
        # text 可以为空；编号和关键词不能是空串或全空白。
        # strip 只用于检查，不会偷偷改写原始输入。
        if key != "text" and args[key].strip() == "":
            return failure("INVALID_ARGUMENTS", f"{key} 不能为空", False)
    if name == "lookup_card":
        return lookup_card(args["card_id"], cards)
    return count_keyword(args["text"], args["keyword"])
