第 6 讲 实际运行样例

以下六个目录由完整脚本在 Linux、Python 3.12.14 中实际运行产生。
每组都从空状态开始，只改变说明中的任务条件，使用同一份原始卡片库。

default_run：C02，关键词“工具”，预算 2 → 两次尝试，计数 3，完成。
budget1_run：C02，预算 1 → 一次查询，预算耗尽，未完成。
budget5_run：C02，预算 5 → 两次尝试后提前完成，计数 3。
budget0_run：C02，预算 0 → 零次尝试，未完成，trace.jsonl 为空。
missing_run：C99，预算 2 → 一次查询，NOT_FOUND，未完成。
zero_run：C01，预算 2 → 两次尝试，计数 0，完成。

六组均包含 goal_snapshot.json、cards_snapshot.json、trace.jsonl、result.json、summary.txt。
actual_*_output.txt 保存对应终端输出。
actual_read_run_001.txt：新进程读回默认成功。
actual_read_run_004.txt：新进程读回零预算空轨迹。
actual_read_run_005.txt：新进程读回查询失败。
actual_read_run_006.txt：新进程读回计数 0 的完成结果。
actual_dispatch_output.txt：七种请求的实际观察。
actual_practice_output.txt：独立练习参考答案的三组实际输出。
validation_log.txt：环境、运行命令、输出及检查记录。

task_original.json、cards_original.json 是原始正常输入副本。
验证在独立项目副本中进行，学习者的 outputs 保持初始状态。
日志中的 /workspace/... 是验证机器路径，不是 Windows 示例路径，不能照抄。
示例用于核对，不替代自己的实际运行和实验记录。
