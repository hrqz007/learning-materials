# 第七讲源码导读

先运行完整入口，再按下面的顺序读代码。源文件中的注释解释了关键边界，不必第一遍掌握全部辅助代码。

| 文件 | 作用 | 是否单独运行 |
| --- | --- | --- |
| prompt_builder.py | 把任务、剩余预算、实际观察组织成提示词 | 作为模块导入 |
| response_gate.py | 解析、工具合约、当前任务三层检查 | 作为模块导入 |
| toolbox.py | 工具合约、工具函数和分发器 | 作为模块导入 |
| replay_agent.py | 从空状态组织候选检查、执行、状态更新和停止 | 作为模块导入 |
| lesson07_run.py | 读取配置与候选，运行并保存新报告 | 主入口 |
| read_report.py | 只读取 RUN_NAME 指定的报告 | 可运行，先选目录名 |
| run_case_matrix.py | 依次运行 10 个人工样例并保存报告 | 可运行 |
| practice_starter.py | 第 16 题未完成的骨架，需自行补全 | 复制成 my_practice.py 后运行 |
| practice_answer.py | 第 16 题完整参考实现 | 可运行 |

`requirements.txt` 仅说明无第三方依赖；不需要执行 pip install。

## 主要输入

`data/task.json`：

```json
{"card_id":"C02","keyword":"工具","max_attempts":2}
```

`max_attempts` 是非负整数，不允许布尔值。一次尝试从接收到一份候选文本开始；解析失败也消耗一次。没有候选时等待，不消耗次数。

`data/run_config.json` 默认值：

```json
{"source":"fixture","case_id":"valid_chain","reported_model":""}
```

`fixture` 读取作者编写的样例；`manual` 读取 `data/manual/reply_1.txt` 等连续编号文件。手动模式下 `case_id` 不参与样例选择，可设空字符串；`reported_model` 由你自行填写模型名和日期，程序不验证真实性。

`fixtures.json` 的 `responses` 是一个字符串列表；列表中的每个字符串是完整候选原文。字符串内部出现反斜杠加双引号，是外层 JSON 保存字符串的转义，不是模型回复中要求出现反斜杠。

## 动作协议

只接受顶层含 `tool` 和 `arguments` 两个字段的字典。工具及参数：

- `lookup_card`：只接收非空字符串 `card_id`。
- `count_keyword`：只接收字符串 `text` 和非空字符串 `keyword`；text 可为空。

这只是本课自定义协议，不是模型服务 API 的请求格式。工具不联网；查询使用精确编号；统计用 Python `str.count`。

`inspect_response` 不执行工具。通过返回 `accepted=True`；失败返回阶段和错误原因。只有完整控制流程中的 accepted 分支才调用 `dispatch`。分发器检查工具合约，但不替代任务检查。

本课限制文本长度为 6000 个 Python 字符，拒绝重复键、NaN、Infinity 等输入。不会调用 eval，不自动删围栏，不从解释文字中抽取 JSON，不自动修复后伪装成原回复。

## 状态与停止

- `card=None`：还没有实际查到卡片。
- `count=None`：还没有实际取得计数；`count=0` 是有效结果。
- `awaiting_response`：缺少下一份候选，保存 next_prompt.txt。
- `goal_completed`：已查到卡片并得到计数。
- `budget_exhausted`：候选预算耗尽，尚未完成。
- 其他错误码：检查拒绝或工具失败，本课立即停止，不重试。

`used_attempts` 与 `tool_calls` 都只统计当前一次完整运行。多次运行需要另行汇总。默认手动流程的三次运行是 0、1、2 次工具调用，累计 3 次；第三次会重做第一步查询。

## 保存与重现

程序通过 `__file__` 定位课程根目录，因此从别的当前工作目录启动入口也能找到 data。各模块必须保持在完整的 code 目录中。

输出使用新的 run_001 等目录保存，单进程教学场景下不覆盖已有目录。它不是并发任务调度器，也没有恢复中断、自动修复半写文件或断点续跑的实现。

每次生成 6 个固定文件：input_snapshot.json、responses_snapshot.json、prompts.json、trace.jsonl、result.json、summary.txt。等待时再生成 next_prompt.txt。输入有多余候选时，会保存在回复快照中，并用 unprocessed_response_count 说明有多少未被处理。

prompts.json 是程序按运行状态构造的提示词。对于人工样例，它不能证明这些回复来自模型；对于手动输入，应自己另存实际提交的提示词及任何差异。

## 继续研究时的边界

本课保留固定两步顺序，用来学习模型输出与程序执行的接口。它不是通用语义评判器、开放式规划系统或安全沙箱。将来更换工具、修改数据或引入有副作用的动作，需要重新设计状态、约束和恢复机制。
