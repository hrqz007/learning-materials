# 第七讲从这里开始

本讲：大模型的动作提议与输出检查。沿用第六讲的查卡片和关键词统计工具，把重点放在“候选文本如何通过检查后执行”。

1. 阅读 `materials/01_Lecture.pdf`：16 页彩色讲义，包含 4 幅图。
2. 按 `materials/02_Lab_Guide.pdf` 操作：完整实验设计和运行步骤。
3. 做 `materials/03_Exercises.pdf`：18 题，100 分。
4. 对照 `materials/04_Answers.pdf`，填写 `materials/05_Worksheet.docx`。

五份材料均有 PDF 和可编辑 DOCX。记录表 DOCX 可直接输入，PDF 可打印手写。

必做实验使用作者手写的 10 组候选，不联网、不调用模型 API、不需要密钥或第三方 Python 包。选做实验可以读取你从真实模型界面复制的可见回复；程序不会认证其模型来源。

## 第一次运行

在第二讲已有 Python 环境中打开完整解压目录，运行：

```text
python code/lesson07_run.py
```

默认结果：`completed=True`，`stop_reason=goal_completed`，`used_attempts=2`，`tool_calls=2`，关键词计数 `3`。输出目录会显示在屏幕上。

Windows 的 Anaconda 与 `.venv` 两条具体路径见实验设计书第 2 节。继续使用你之前选定的环境即可。

## 文件位置

| 目录或文件 | 内容 |
| --- | --- |
| materials | 五份教学材料，每份 PDF 和 DOCX |
| code | 9 个 Python 源码文件与依赖说明 |
| data | 卡片、任务、10 组人工样例、运行配置与手动回复目录 |
| figures | 4 幅原始彩色图解 |
| examples | 3 组由程序实际运行生成的示例报告，候选均为人工样例 |
| outputs | 你自己的运行报告；交付时只有说明文件 |
| CODE_GUIDE.md | 源码导读与参数约定 |
| VALIDATION.md | 已执行的验证及适用范围 |

每次运行从空状态回放已有候选。读取历史报告与断点续跑不同；手动模式也不是断点续跑。这个设计只用于本课的只读工具。
