"""完整入口。source=fixture 使用人工样例，source=manual 读取粘贴文本。"""
import json
import re
from pathlib import Path
from replay_agent import run_replay

ROOT = Path(__file__).resolve().parent.parent


def read_json(path):
    with path.open("r", encoding="utf-8") as f:
        return json.load(f)


def new_run_dir(output_root):
    output_root.mkdir(parents=True, exist_ok=True)
    number = 1
    run_dir = output_root / f"run_{number:03d}"
    while run_dir.exists():
        number += 1
        run_dir = output_root / f"run_{number:03d}"
    run_dir.mkdir()
    return run_dir


def load_responses(root, config):
    if type(config) != dict or set(config) != {"source", "case_id", "reported_model"}:
        raise ValueError("运行配置必须且只能包含 source、case_id、reported_model")
    if any(type(config[key]) != str for key in config):
        raise ValueError("运行配置三个字段都必须是字符串")
    if config["source"] == "fixture":
        cases = read_json(root / "data" / "fixtures.json")
        if config["case_id"] not in cases:
            raise ValueError("case_id 不在人工样例列表中")
        raw_list = cases[config["case_id"]]["responses"]
        items = [{"name": f"{config['case_id']}:{i}", "text": raw}
                 for i, raw in enumerate(raw_list, 1)]
        source = {"kind": "author_fixture", "case_id": config["case_id"],
                  "reported_model": None, "model_verified": False}
        return items, source
    if config["source"] != "manual":
        raise ValueError("source 只能是 fixture 或 manual")
    numbered = {}
    for path in (root / "data" / "manual").glob("reply_*.txt"):
        match = re.fullmatch(r"reply_([1-9][0-9]*)\.txt", path.name)
        if match is None:
            raise ValueError(f"回复文件名称不符合约定: {path.name}")
        numbered[int(match.group(1))] = path
    if len(numbered) > 20 or sorted(numbered) != list(range(1, len(numbered) + 1)):
        raise ValueError("回复应从 reply_1.txt 连续编号，且不超过 20 份")
    # bytes 解码保留原文中的换行，不自动去除围栏或说明文字。
    items = [{"name": numbered[i].name, "text": numbered[i].read_bytes().decode("utf-8")}
             for i in sorted(numbered)]
    source = {"kind": "user_paste", "case_id": None,
              "reported_model": config["reported_model"], "model_verified": False}
    return items, source


def run_and_save(root, config):
    goal = read_json(root / "data" / "task.json")
    cards = read_json(root / "data" / "cards.json")
    items, source = load_responses(root, config)
    result, trace, prompts, next_prompt = run_replay(goal, cards, [item["text"] for item in items])
    result["source"] = source
    run_dir = new_run_dir(root / "outputs")
    documents = {
        "input_snapshot.json": {"goal": goal, "cards": cards, "run_config": config, "source": source},
        "responses_snapshot.json": items, "prompts.json": prompts, "result.json": result,
    }
    for filename, data in documents.items():
        with (run_dir / filename).open("x", encoding="utf-8") as f:
            json.dump(data, f, ensure_ascii=False, indent=2, allow_nan=False)
    with (run_dir / "trace.jsonl").open("x", encoding="utf-8") as f:
        for record in trace:
            f.write(json.dumps(record, ensure_ascii=False, allow_nan=False) + "\n")
    with (run_dir / "summary.txt").open("x", encoding="utf-8") as f:
        for key in ["completed", "stop_reason", "used_attempts", "tool_calls", "unprocessed_response_count"]:
            f.write(f"{key}: {result[key]}\n")
        f.write(f"source_kind: {source['kind']}\n")
        if result["completed"]:
            f.write(f"count: {result['answer']['count']}\n")
    if next_prompt is not None:
        with (run_dir / "next_prompt.txt").open("x", encoding="utf-8") as f:
            f.write(next_prompt)
    return run_dir, result


if __name__ == "__main__":
    config = read_json(ROOT / "data" / "run_config.json")
    run_dir, result = run_and_save(ROOT, config)
    print("本次目录:", run_dir)
    print("输入来源:", result["source"]["kind"], "程序没有调用模型 API。")
    print("completed:", result["completed"])
    print("stop_reason:", result["stop_reason"])
    print("used_attempts:", result["used_attempts"], "tool_calls:", result["tool_calls"])
    print("未处理回复数:", result["unprocessed_response_count"])
    if result["completed"]:
        print("关键词计数:", result["answer"]["count"])
    if result["stop_reason"] == "awaiting_response":
        print("提示词:", run_dir / "next_prompt.txt")
        print(f"下一份回复文件: data/manual/reply_{result['next_response_number']}.txt")
    print("每次运行从零回放已有回复，只在本课两个只读工具中这样使用。")
