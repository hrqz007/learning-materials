"""第16题参考答案，只演示第一条回复的检查与执行，不含循环和预算。"""
import json
from pathlib import Path
from response_gate import inspect_response
from toolbox import dispatch

ROOT = Path(__file__).resolve().parent.parent


def execute_first_reply(raw_text, goal, cards):
    state = {"card": None, "count": None}
    decision = inspect_response(raw_text, goal, state)
    if not decision["accepted"]:
        return {"decision": decision, "observation": None}
    observation = dispatch(decision["action"], cards)
    return {"decision": decision, "observation": observation}


if __name__ == "__main__":
    goal = json.loads((ROOT / "data/task.json").read_text(encoding="utf-8"))
    cards = json.loads((ROOT / "data/cards.json").read_text(encoding="utf-8"))
    cases = json.loads((ROOT / "data/fixtures.json").read_text(encoding="utf-8"))
    for name in ["valid_chain", "bad_json", "wrong_target"]:
        print(name, execute_first_reply(cases[name]["responses"][0], goal, cards))
