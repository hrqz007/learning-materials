"""第16题。复制为 my_practice.py 并补全，不要先看答案。"""
import json
from pathlib import Path
from response_gate import inspect_response
from toolbox import dispatch

ROOT = Path(__file__).resolve().parent.parent


def execute_first_reply(raw_text, goal, cards):
    # TODO：建立初始状态，先调用 inspect_response。
    # TODO：拒绝时返回 decision 和 observation=None，不能执行工具。
    # TODO：通过后才 dispatch，返回 decision 和实际 observation。
    return None


if __name__ == "__main__":
    goal = json.loads((ROOT / "data/task.json").read_text(encoding="utf-8"))
    cards = json.loads((ROOT / "data/cards.json").read_text(encoding="utf-8"))
    cases = json.loads((ROOT / "data/fixtures.json").read_text(encoding="utf-8"))
    for name in ["valid_chain", "bad_json", "wrong_target"]:
        print(name, execute_first_reply(cases[name]["responses"][0], goal, cards))
