"""只读取已保存的检查报告，不重跑工具。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUN_NAME = "run_001"


if __name__ == "__main__":
    run_dir = ROOT / "outputs" / RUN_NAME
    with (run_dir / "result.json").open("r", encoding="utf-8") as f:
        result = json.load(f)
    print("历史目录:", run_dir)
    print("输入来源:", result["source"])
    with (run_dir / "trace.jsonl").open("r", encoding="utf-8") as f:
        for line in f:
            record = json.loads(line)
            decision = record["decision"]
            print("尝试:", record["step"], "原文:", repr(record["raw_text"]))
            print("  accepted:", decision["accepted"], "stage:", decision["stage"])
            print("  检查错误:", decision["error"])
            print("  tool_called:", record["tool_called"], "工具观察:", record["observation"])
            print("  更新后状态:", record["state_after"])
    print("completed:", result["completed"], "stop_reason:", result["stop_reason"])
    print("答案:", result["answer"])
