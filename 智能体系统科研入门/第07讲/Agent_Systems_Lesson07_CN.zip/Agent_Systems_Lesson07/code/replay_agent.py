"""从空状态检查并回放候选回复；不连接模型，不从上次运行续跑。"""
from toolbox import dispatch
from response_gate import inspect_response
from prompt_builder import build_prompt


def validate_inputs(goal, cards):
    if type(goal) != dict or set(goal) != {"card_id", "keyword", "max_attempts"}:
        raise ValueError("任务必须且只能包含 card_id、keyword、max_attempts")
    for key in ["card_id", "keyword"]:
        if type(goal[key]) != str or goal[key].strip() == "":
            raise ValueError(f"{key} 必须是非空字符串")
    if type(goal["max_attempts"]) != int or goal["max_attempts"] < 0:
        raise ValueError("max_attempts 必须是非负整数，不能是布尔值")
    if type(cards) != dict:
        raise ValueError("卡片库必须是字典")
    for card_id, card in cards.items():
        if type(card_id) != str or card_id.strip() == "":
            raise ValueError("卡片编号必须是非空字符串")
        if type(card) != dict or set(card) != {"title", "text"}:
            raise ValueError("卡片必须且只能包含 title 和 text")
        if type(card["title"]) != str or card["title"].strip() == "":
            raise ValueError("卡片标题必须是非空字符串")
        if type(card["text"]) != str:
            raise ValueError("卡片正文必须是字符串")


def run_replay(goal, cards, responses):
    validate_inputs(goal, cards)
    if type(responses) != list or any(type(item) != str for item in responses):
        raise ValueError("候选回复必须是字符串列表")
    state = {"card": None, "count": None}
    trace, prompts = [], []
    used_attempts, tool_calls = 0, 0
    stop_reason = "budget_exhausted"
    next_prompt = None
    while used_attempts < goal["max_attempts"]:
        prompt = build_prompt(goal, state, used_attempts)
        has_reply = used_attempts < len(responses)
        prompts.append({"step": used_attempts + 1, "has_reply": has_reply, "text": prompt})
        if not has_reply:
            stop_reason = "awaiting_response"
            next_prompt = prompt
            break
        raw_text = responses[used_attempts]
        # 本讲尝试从“提交候选文本”开始，解析失败也消耗一次。
        used_attempts += 1
        decision = inspect_response(raw_text, goal, state)
        observation = None
        if decision["accepted"]:
            observation = dispatch(decision["action"], cards)
            if observation["tool_called"]:
                tool_calls += 1
            if observation["ok"]:
                if decision["action"]["tool"] == "lookup_card":
                    state["card"] = observation["data"]
                else:
                    state["count"] = observation["data"]["count"]
            else:
                stop_reason = observation["error"]["code"]
        else:
            stop_reason = decision["error"]["code"]
        trace.append({
            "step": used_attempts, "raw_text": raw_text, "decision": decision,
            "tool_called": observation is not None and observation["tool_called"],
            "observation": observation,
            "state_after": {"card_loaded": state["card"] is not None, "count": state["count"]},
        })
        if not decision["accepted"] or not observation["ok"]:
            break
        if state["card"] is not None and state["count"] is not None:
            stop_reason = "goal_completed"
            break
    completed = state["card"] is not None and state["count"] is not None
    answer = None
    if completed:
        answer = {"card_id": state["card"]["card_id"], "text": state["card"]["text"],
                  "keyword": goal["keyword"], "count": state["count"]}
    result = {
        "completed": completed, "stop_reason": stop_reason,
        "used_attempts": used_attempts, "tool_calls": tool_calls,
        "input_response_count": len(responses),
        "unprocessed_response_count": len(responses) - used_attempts,
        "next_response_number": used_attempts + 1 if next_prompt is not None else None,
        "answer": answer,
    }
    return result, trace, prompts, next_prompt
