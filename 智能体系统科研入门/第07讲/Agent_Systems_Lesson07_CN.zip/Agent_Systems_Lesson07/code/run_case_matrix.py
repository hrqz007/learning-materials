"""选做：按当前 task 和 cards 顺序回放全部人工样例，不修改输入配置。"""
from lesson07_run import ROOT, read_json, run_and_save


if __name__ == "__main__":
    cases = read_json(ROOT / "data" / "fixtures.json")
    print("全部是人工构造的检查用例，不是模型评测结果。")
    print("请使用原始任务 C02 / 工具 / 预算2，以便与教材预期核对。")
    for case_id in cases:
        config = {"source": "fixture", "case_id": case_id, "reported_model": ""}
        folder, result = run_and_save(ROOT, config)
        print(case_id, folder.name, result["stop_reason"],
              "尝试", result["used_attempts"], "工具", result["tool_calls"])
