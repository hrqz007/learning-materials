# 示例报告的来源

这三组报告由完整程序在隔离目录中实际运行生成，候选输入全部来自作者手写的 fixtures.json。没有真实模型参与，也没有模型 API 调用。

| 目录 | 结果 | 阅读重点 |
| --- | --- | --- |
| valid_chain | 完成，count=3，尝试 2 次，工具 2 次 | 两份候选如何变成两份真实工具观察 |
| fabricated_text | TEXT_MISMATCH，尝试 2 次，工具 1 次 | 第一份工具观察存在，第二份 observation 为 null |
| duplicate_key | PARSE_ERROR，尝试 1 次，工具 0 次 | 重复键在解析层被拒绝，保留原始文本 |

这些文件供对照阅读。你自己运行的输出保存在 outputs 中。不要把 examples 中的作者运行结果署名为自己的实验结果。
