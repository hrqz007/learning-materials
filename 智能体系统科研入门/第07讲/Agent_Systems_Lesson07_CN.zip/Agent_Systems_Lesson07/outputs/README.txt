自己的实验结果写入这里。初始没有 run_001。
每次运行独立选取第一个空缺编号，保留旧结果。
正常记录有六个固定文件；awaiting_response 时另外生成 next_prompt.txt。
编写者的实际测试结果在 examples；人工输入样例不代表真实模型输出。
