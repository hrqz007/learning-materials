# 源码与记录导读

这是固定两步任务的教学控制器：查卡片，再统计原文中的关键词，最后核对模型汇报。它没有实现开放式规划、并行工具调度、自动重试、断点恢复或通用事实核查。

## 从哪里开始读

| 文件 | 职责 |
| --- | --- |
| protocol.py | 组装消息与原生工具定义，解析服务响应，配对调用编号，验证最终 JSON |
| lesson08_run.py | 完整程序入口，控制循环、预算、状态与报告保存 |
| model_client.py | 离线人工回复和真实 HTTPS 请求共用的 complete 接口 |
| response_gate.py | 延续第 7 讲的参数解析、工具合约、任务检查 |
| toolbox.py | 本地查询与关键词统计的实际实现和分发器 |
| read_report.py | 只读取指定 run 目录，不执行工具或请求模型 |
| run_cases.py | 逐个运行全部人工样例，固定为离线模式 |
| practice_starter.py | 第 16 题骨架，未补全时只返回原列表 |
| practice_answer.py | 第 16 题参考答案；只练习消息组织 |

先读 `initial_messages`、`build_request`、`make_tool_message`，再跟踪入口的成功路径。`requirements.txt` 说明只用 Python 标准库，无需 pip 安装。

## 配置

修改 `data/config.json`，保存后重新启动入口。文件必须保留模板中的六个字段，使用合法 JSON 的英文双引号；布尔值不能代替整数。

| 字段 | 默认值 | 本教学程序允许范围或含义 |
| --- | --- | --- |
| case_id | success | 离线样例名；真实模式不使用人工回复 |
| model | deepseek-flash | 非空模型名，真实可用性以供应商文档为准 |
| max_model_requests | 3 | 整数 0–6，complete 逻辑尝试上限 |
| max_tool_calls | 2 | 整数 0–2，本地工具实际执行上限 |
| max_output_tokens | 512 | 整数 64–2048，映射为每次请求的 max_tokens |
| timeout_seconds | 30 | 整数 1–120，网络阻塞操作的等待参数 |

这些范围是本课主动设置的教学约束，不是供应商支持范围的完整声明。输出上限不是整个任务的总 token 或费用额度；timeout 不是严格的任务总墙钟时限。

真实客户端使用固定官方地址 `https://api.deepseek.com/chat/completions`、POST、非流式输出、`thinking.type=disabled`、`temperature=0`。前两步 `tool_choice=auto`，两种工具成功完成后改为 `none`。本课未开启 Beta 严格模式，本地检查仍然执行。

默认卡片任务在 `data/task.json`。改变目标后，固定人工样例不会自动变成适配新目标的模型：这正是人工回放的边界。数据、人工回复和程序机制不能在一个单变量实验里同时修改。

## 一次成功流程

1. 请求 1 带 system、user 两条消息；模型提出 lookup_card。
2. 本地检查、执行查询；保存 assistant 调用与实际 tool 结果。
3. 请求 2 带四条消息；模型提出 count_keyword。
4. 本地检查目标、关键词与原文来源，再执行统计并加入实际结果。
5. 请求 3 带六条消息；模型返回最终 JSON。
6. 本地比较 card_id、keyword、count，核对通过才 completed=true。最后保存七条消息。

`function.arguments` 是 JSON 字符串，需要内层解析；`tool.content` 也是由实际观察序列化而成的字符串。`tool_call_id` 必须与对应 assistant 的调用 `id` 相等，不能用工具名替代。

## 计数和完成状态

| 字段 | 含义 |
| --- | --- |
| model_requests | 本轮对 complete 的逻辑尝试数，离线也计数 |
| network_attempts | 客户端开始网络发送的尝试数，离线始终为 0 |
| received_responses | 客户端成功返回 UTF-8 正文的次数；正文仍可能不合协议 |
| tool_calls | 实际进入工具函数的次数，不能用模型提议数代替 |
| tools_completed | 查询与计数均已成功获得实际观察 |
| final_verified | 最终 JSON 的字段、类型、任务值和计数已通过核对 |
| completed | tools_completed 与 final_verified 同时为真 |

零是合法计数；未统计时用 None，不能把 None 当成 0。count 为 true 也不能代替整数 1。

一条响应提出多个工具调用时，整条拒绝，一个都不执行。缺失或重复调用编号、截断输出、参数错误、任务不匹配、工具失败和最终核验失败都会停止，不自动修复或重试。

## 报告文件

| 文件 | 证据意义 |
| --- | --- |
| input_snapshot.json | 时间、Python 版本、配置、任务、卡片、来源和源码 SHA-256 |
| requests/request_NNN.json | 当轮准备提交的请求体；不含认证头 |
| responses/response_NNN.txt | 客户端返回的原始 UTF-8 正文，包括可能不合约的内容 |
| events.jsonl | 每次逻辑请求对应的事件、拒绝原因或真实工具观察 |
| messages.json | 程序最终保存的本地历史，不等于全部已经发给远端 |
| result.json | 状态、计数、最终答案与已知用量 |
| summary.txt | 方便快速查看的摘要 |

网络异常时可能没有对应响应文件。请求文件能证明程序准备的内容，不能单独证明服务端收到或完成处理。HTTP 错误正文和认证头不会保存；错误码与类别写入事件。`read_report.py` 中的 `RUN_NAME` 需按实际目录调整。

`usage_summary.known_totals` 只汇总类型合法且加总一致的 prompt/completion/total 三个字段。完整原始响应仍保留缓存等细分信息。status 有 complete、partial、unavailable、not_applicable 四种；缺失用量不补零。离线为 not_applicable。`billing_amount` 保持 null，费用到官方平台核对。

## 运行约定

一个进程、一次新运行。不要同时开多个进程写同一个 outputs 目录；本课没有并发分配目录锁。主入口完整成功退出码为 0，未达到任务完成标准为 2，启动或配置失败为 1。

真实密钥仅在 `--live` 分支由 getpass 读取，放入 Authorization 请求头；不从配置或环境变量自动读取，不写入正常报告。无法关闭终端回显时停止。客户端不自动跟随 HTTP 重定向，也不自动重试。

网络等待时 Ctrl+C 可产生 INTERRUPTED 记录，但不能保证远端生成已取消或不会计费。再次启动会创建新的完整任务，不是继续旧请求。

## 官方协议参考

按 2026-09-26 核对。模型别名与服务可能更新，记录请求模型、响应 model 字段、时间与原始输出，不宣称同名即相同权重。

- [DeepSeek 初次调用与当前模型](https://api-docs.deepseek.com/)
- [Chat Completions 协议](https://api-docs.deepseek.com/api/create-chat-completion/)
- [当前计费规则](https://api-docs.deepseek.com/quick_start/pricing/)
- [错误代码](https://api-docs.deepseek.com/quick_start/error_codes/)
- [Python urllib.request](https://docs.python.org/3/library/urllib.request.html)
- [Python getpass](https://docs.python.org/3/library/getpass.html)
