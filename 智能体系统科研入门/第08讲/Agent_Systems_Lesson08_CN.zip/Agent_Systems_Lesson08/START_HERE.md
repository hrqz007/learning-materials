# 第 8 讲：接入真实 API 与工具调用闭环

本讲承接第 7 讲，把“复制模型回复、检查、执行”的过程连接成程序内自动完成的一轮闭环。保留 C02 卡片与“工具”计数任务，让你只专注于新增加的通信与消息历史。

**先做默认离线实验，再按条件选做真实 API。** 默认运行不访问模型服务、不读取密钥、不产生 API 用量。离线回复是作者手写的教学样例，不能作为真实模型能力或速度的数据。

## 学习顺序

1. 读 `materials/01_Lecture.pdf`，先理解 API、调用编号、两层 JSON 和消息历史。蓝色看原理，绿色看证据，橙色看容易混淆的边界。
2. 按 `materials/02_Lab_Guide.pdf` 跑通 success、wrong_final 与预算对照。
3. 填写 `materials/05_Worksheet.docx`，保留本次运行目录。
4. 完成 `materials/03_Exercises.pdf` 的 18 道题，再核对 `materials/04_Answers.pdf`。
5. 第 16 题先复制 `code/practice_starter.py` 为 `code/my_practice.py`，完成后再看参考答案。

## 包内内容

| 位置 | 内容 |
| --- | --- |
| materials/01_Lecture | 17 页彩色原理讲义，PDF 与可编辑 DOCX |
| materials/02_Lab_Guide | 8 页实验设计书，PDF 与 DOCX |
| materials/03_Exercises | 4 页练习，18 题、100 分，PDF 与 DOCX |
| materials/04_Answers | 5 页答案与评分依据，PDF 与 DOCX |
| materials/05_Worksheet | 2 页实验记录，DOCX 可填，PDF 可打印 |
| figures | 4 张精确示意图 |
| code | 9 个 Python 文件，含完整入口、练习骨架与答案 |
| data | 配置、任务、卡片库、10 组人工响应 |
| examples | 程序运行产生的 3 组离线报告，附来源说明 |
| outputs | 你运行后生成的新报告 |
| CODE_GUIDE.md | 文件职责、参数和日志字段说明 |
| VALIDATION.md / validation_results.json | 已验证内容及未验证范围 |

PDF 共 36 页。Word 与 PDF 内容相同，Word 的分页可能随你电脑的字体与软件略有变化；固定版式以 PDF 为准。实验记录的 PDF 是打印版，不是带交互表单字段的 PDF。

## 第一次运行

先完整解压，再打开其中的 `Agent_Systems_Lesson08` 文件夹。不要直接在压缩包内运行，也不要只取出一个 .py 文件。

沿用前几讲的 Python 环境，无需安装额外 Python 包。Windows Anaconda Prompt 示例：

```bat
conda activate agent-study
cd /d "C:\AgentStudy\Agent_Systems_Lesson08"
python --version
python code\lesson08_run.py
```

如果沿用第二讲的 `.venv`，且两个课程目录在同一个父目录中，在 PowerShell 中执行：

```powershell
cd "C:\AgentStudy\Agent_Systems_Lesson08"
..\Agent_Systems_Lesson02\.venv\Scripts\python.exe code\lesson08_run.py
```

后文的 `python` 均指你选定的解释器。使用 `.venv` 时，把它换成上面的完整解释器路径。Linux/macOS 在自己的环境中执行 `python code/lesson08_run.py`。

默认结果应为：`mode=offline`、`completed=True`、`model_requests=3`、`network_attempts=0`、`tool_calls=2`、`observed_count=3`。报告路径以终端实际显示为准。每次重跑新建目录，从空状态开始；旧报告不会被当作可恢复的进程。

## 选做真实 API

读完实验设计书第 6 节后，用你自己的有效 DeepSeek API Key：

```bat
python code\lesson08_run.py --live
```

密钥由本地终端隐藏输入，不要发给聊天助手或写进材料。每次新运行都需重新输入；不加 `--live` 始终回到离线模式。真实调用可能按实际用量收费，账单到官方平台核对。

本课采用核对当日官方文档中的 `deepseek-flash`，关闭思考与流式输出。真实模型可能提前结束、给出不合约动作或错误最终答复，程序会保留记录并停止。源码已经过离线和模拟传输验证，制作本材料时没有连接真实供应商账户；实际可用性需在你的网络与账户下验证。

学习完成标准：不用背代码，也能用保存的记录解释“三次模型请求、两次工具执行、最终七条消息”，并区分工具完成与整个任务完成。
