"""两个来源使用相同 complete 接口：人工离线响应与真实 HTTPS API。"""
import json
import socket
from urllib.error import HTTPError, URLError
from urllib.request import Request, HTTPRedirectHandler, build_opener

ENDPOINT = "https://api.deepseek.com/chat/completions"
MAX_RESPONSE_BYTES = 1_048_576


class ProviderError(Exception):
    def __init__(self, code, message):
        super().__init__(message)
        self.code, self.message = code, message


class NoRedirect(HTTPRedirectHandler):
    def redirect_request(self, req, fp, code, msg, headers, newurl):
        # 不把带认证头的请求自动转向另一个地址。
        return None


class LiveClient:
    """每次 complete 最多发起一次网络请求，不自动重试。"""
    def __init__(self, api_key, timeout_seconds):
        if type(api_key) != str or not api_key or not api_key.isascii() or any(c.isspace() for c in api_key):
            raise ValueError("密钥应为非空 ASCII 字符串，且不包含空白")
        self.api_key = api_key
        self.timeout_seconds = timeout_seconds
        self.network_attempts = 0
        self.opener = build_opener(NoRedirect())

    def complete(self, payload):
        body = json.dumps(payload, ensure_ascii=False, allow_nan=False).encode("utf-8")
        request = Request(ENDPOINT, data=body, method="POST", headers={
            "Content-Type": "application/json",
            "Authorization": "Bearer " + self.api_key,
        })
        self.network_attempts += 1
        try:
            with self.opener.open(request, timeout=self.timeout_seconds) as response:
                raw = response.read(MAX_RESPONSE_BYTES + 1)
        except HTTPError as exc:
            code = exc.code
            exc.close()
            # 不保存可能带敏感内容的服务端错误正文或认证头。
            raise ProviderError(f"HTTP_{code}", "服务端返回 HTTP 错误，请按实验指南定位") from None
        except (TimeoutError, socket.timeout):
            raise ProviderError("TIMEOUT", "网络等待超时，服务端是否已处理未知") from None
        except URLError as exc:
            code = "TIMEOUT" if isinstance(exc.reason, (TimeoutError, socket.timeout)) else "NETWORK_ERROR"
            raise ProviderError(code, "网络或 TLS 连接未完成；本课不自动重试") from None
        except OSError:
            raise ProviderError("NETWORK_ERROR", "连接中断；本课不自动重试") from None
        if len(raw) > MAX_RESPONSE_BYTES:
            raise ProviderError("RESPONSE_TOO_LARGE", "响应超过本课大小限制")
        try:
            return raw.decode("utf-8")
        except UnicodeDecodeError:
            raise ProviderError("INVALID_UTF8", "响应无法作为 UTF-8 文本读取") from None


class OfflineClient:
    """人工脚本响应，不是大模型，不会读取密钥或访问网络。"""
    def __init__(self, frames):
        if type(frames) != list:
            raise ValueError("离线 frames 必须是列表")
        self.frames = frames
        self.position = 0
        self.network_attempts = 0

    def complete(self, payload):
        # payload 由控制器另行保存。离线回复由作者预先编写。
        if self.position >= len(self.frames):
            raise ProviderError("FIXTURE_EXHAUSTED", "人工响应已经用完")
        frame = self.frames[self.position]
        self.position += 1
        if "error" in frame:
            raise ProviderError(frame["error"], "人工注入的故障，不是真实网络故障")
        return json.dumps(frame["response"], ensure_ascii=False, allow_nan=False)
