"""第 16 题参考答案。本文件不执行工具，只练习消息配对。"""
import json


def append_tool_exchange(messages, assistant, observation):
    """前提：assistant 中唯一调用已通过检查，工具已实际执行。"""
    messages.append(assistant)
    call_id = assistant["tool_calls"][0]["id"]
    tool_message = {
        "role": "tool", "tool_call_id": call_id,
        "content": json.dumps(observation, ensure_ascii=False),
    }
    messages.append(tool_message)
    return messages


if __name__ == "__main__":
    assistant = {"role": "assistant", "content": None, "tool_calls": [
        {"id": "practice_1", "type": "function", "function": {
            "name": "lookup_card", "arguments": '{"card_id":"C02"}'}}]}
    observation = {"ok": True, "tool_called": True,
                   "data": {"card_id": "C02", "text": "练习用正文"}, "error": None}
    result = append_tool_exchange([], assistant, observation)
    print(json.dumps(result, ensure_ascii=False, indent=2))
