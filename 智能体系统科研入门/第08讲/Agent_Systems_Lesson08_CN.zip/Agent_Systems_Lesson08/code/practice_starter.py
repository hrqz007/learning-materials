"""第 16 题：复制成 my_practice.py，补全后再看参考答案。"""
import json


def append_tool_exchange(messages, assistant, observation):
    """前提：assistant 中唯一调用已通过检查，工具已实际执行。"""
    # TODO：先把 assistant 消息追加到 messages。
    # TODO：取 tool_calls[0]["id"]，构造 role=tool 的消息。
    # TODO：content 必须是把 observation 转成 JSON 后的字符串。
    # TODO：把 tool 消息追加到 messages，并返回同一个列表。
    return messages


if __name__ == "__main__":
    assistant = {"role": "assistant", "content": None, "tool_calls": [
        {"id": "practice_1", "type": "function", "function": {
            "name": "lookup_card", "arguments": '{"card_id":"C02"}'}}]}
    observation = {"ok": True, "tool_called": True,
                   "data": {"card_id": "C02", "text": "练习用正文"}, "error": None}
    result = append_tool_exchange([], assistant, observation)
    print(json.dumps(result, ensure_ascii=False, indent=2))
