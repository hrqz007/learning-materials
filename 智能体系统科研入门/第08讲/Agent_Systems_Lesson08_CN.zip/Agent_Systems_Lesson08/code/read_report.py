"""仅查看已有事件与结果，不发送网络请求或执行工具。"""
import json
from pathlib import Path

ROOT = Path(__file__).resolve().parent.parent
RUN_NAME = "run_001"

if __name__ == "__main__":
    folder = ROOT / "outputs" / RUN_NAME
    with (folder / "events.jsonl").open(encoding="utf-8") as handle:
        for line in handle:
            event = json.loads(line)
            print("请求序号:", event["request_number"], "事件类型:", event["kind"])
            print("  工具实际执行:", event["tool_called"])
            print("  检查:", event.get("decision", event.get("error", event.get("reason"))))
    print((folder / "summary.txt").read_text(encoding="utf-8"))
