"""检查候选文本。本文件不执行工具；调用模型由客户端负责。"""
import json
from toolbox import validate_action

MAX_RESPONSE_CHARS = 6000


def unique_object(pairs):
    """本课拒绝 JSON 对象中的重复键，避免后一个值悄悄覆盖前一个。"""
    result = {}
    for key, value in pairs:
        if key in result:
            raise ValueError(f"出现重复键: {key}")
        result[key] = value
    return result


def reject_constant(value):
    """拒绝 Python JSON 解码器默认可能接受的 NaN 和 Infinity。"""
    raise ValueError(f"不接受特殊数值: {value}")


def reject(stage, code, message, action=None):
    return {"accepted": False, "stage": stage, "action": action,
            "error": {"code": code, "message": message}}


def check_task(action, goal, state):
    """工具约定已通过，再核对本课任务的顺序、目标和数据来源。"""
    if state["count"] is not None:
        return reject("task", "TASK_FINISHED", "已经得到计数，不再接收动作", action)
    name = action["tool"]
    args = action["arguments"]
    if state["card"] is None:
        if name != "lookup_card":
            return reject("task", "WRONG_ORDER", "必须先查询卡片", action)
        if args["card_id"] != goal["card_id"]:
            return reject("task", "WRONG_TARGET", "查询编号与任务不一致", action)
    else:
        if name != "count_keyword":
            return reject("task", "WRONG_ORDER", "已查到卡片，下一步应统计", action)
        if args["keyword"] != goal["keyword"]:
            return reject("task", "KEYWORD_MISMATCH", "关键词与任务不一致", action)
        if args["text"] != state["card"]["text"]:
            return reject("task", "TEXT_MISMATCH", "正文与实际查询结果不一致", action)
    return None


def inspect_response(raw_text, goal, state):
    """三层检查。通过只说明允许交给分发器，不代表已经执行。"""
    if type(raw_text) != str:
        return reject("parse", "NOT_TEXT", "候选回复必须是字符串")
    if len(raw_text) > MAX_RESPONSE_CHARS:
        return reject("parse", "TOO_LONG", "回复超过本课 6000 字符上限")
    try:
        action = json.loads(raw_text, object_pairs_hook=unique_object,
                            parse_constant=reject_constant)
        # 也拒绝溢出的浮点数和不能写入 UTF-8 的孤立代理字符。
        # 这样拒绝报告本身仍然可以正常保存。
        json.dumps(action, ensure_ascii=False, allow_nan=False).encode("utf-8")
    except (ValueError, RecursionError, UnicodeError) as exc:
        return reject("parse", "PARSE_ERROR", str(exc))
    contract_error = validate_action(action)
    if contract_error is not None:
        error = contract_error["error"]
        return reject("contract", error["code"], error["message"], action)
    task_error = check_task(action, goal, state)
    if task_error is not None:
        return task_error
    return {"accepted": True, "stage": "accepted", "action": action, "error": None}
