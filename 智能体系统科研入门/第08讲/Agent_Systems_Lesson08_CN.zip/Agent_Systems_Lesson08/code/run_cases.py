"""固定只运行人工离线样例；不会批量调用真实 API。"""
from lesson08_run import ROOT, read_json, run_and_save

if __name__ == "__main__":
    config = read_json(ROOT / "data/config.json")
    print("全部为人工离线响应；本表不是模型评测结果。")
    for name in read_json(ROOT / "data/offline_cases.json"):
        folder, result = run_and_save(ROOT, {**config, "case_id": name}, live=False)
        print(name, folder.name, result["stop_reason"],
              "请求", result["model_requests"], "工具", result["tool_calls"])
