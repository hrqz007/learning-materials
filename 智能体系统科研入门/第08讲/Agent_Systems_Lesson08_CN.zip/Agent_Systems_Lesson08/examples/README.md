# 三组可复查的离线报告

这些文件由配套控制器执行真实本地工具后产生；模型回复则来自作者编写的 offline_cases.json。它们不是供应商模型的真实输出，不用于估算模型能力、速度或费用。

| 目录 | 停止原因 | 逻辑请求 | 网络尝试 | 工具执行 | tools_completed | final_verified |
| --- | --- | --- | --- | --- | --- | --- |
| success | goal_completed | 3 | 0 | 2 | true | true |
| wrong_final | FINAL_MISMATCH | 3 | 0 | 2 | true | false |
| simulated_timeout | TIMEOUT | 1 | 0 | 0 | false | false |

在 success 中，比较第二次请求的最后一条 tool 消息与第一条工具事件；再比较第三次请求的最后一条消息与第二条工具事件。它们应包含对应实际观察。

在 wrong_final 中，工具计数为 3，最终人工回复却报 9，因此工具完成与任务完成不同。

simulated_timeout 是人工注入故障，网络尝试为 0；没有响应正文文件，不能据此判断真实服务是否可用。示例里的时间与耗时只属于本次本地运行。

完整原始来源、任务、配置和代码摘要见各目录 input_snapshot.json。自己的新运行写入 outputs，示例不会自动成为可续跑状态。
