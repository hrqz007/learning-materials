# 源码阅读与结果速查

本课的主体仍是第八讲的两工具闭环：查卡片、数关键词、汇报最终答案。第九讲增加“批次计划 → 多次独立运行 → 评分 → 汇总”。默认响应来自作者脚本，不运行真实大模型。

## 推荐阅读顺序

先读 `run_evaluation.py` 的 `build_plan` 与 `run_batch`，了解计划和运行如何对应；再读 `evaluation.py` 的 `grade_result`、`rate_summary`、`summarize`；最后读 `report_batch.py`，看数据如何成为报告。暂时不必一次读完底层 HTTP 实现。

| 源文件 | 职责 |
| --- | --- |
| `run_evaluation.py` | 入口、输入校验、冻结计划、创建独立 trial、保存评分 |
| `evaluation.py` | 对照冻结答案评分，核验记录，计算缺失、任务指标与配对结果 |
| `report_batch.py` | 读取已有记录，创建新的汇总 JSON 与 Markdown 报告 |
| `audit_demo.py` | 在副本里演示缺失；在内存里验证重复记录被拒绝 |
| `fixtures.py` | 为离线教学编写原生 tool call 响应与预设故障 |
| `agent_core.py` | 单次智能体控制循环与原始轨迹保存，沿用第八讲机制 |
| `model_client.py` | 离线响应读取与可选真实 API 传输 |
| `protocol.py` | 提示词、消息和工具定义 |
| `response_gate.py` | 模型响应与工具调用格式核验 |
| `toolbox.py` | 两个实际执行的本地工具 |
| `practice_starter.py` | 第 16 题待补函数 |
| `practice_answer.py` | 第 16 题完整参考实现 |

`agent_core.py` 调整了入口和代码快照位置，以支持每个 trial 的独立工作目录。`model_client.py`、`protocol.py`、`response_gate.py`、`toolbox.py` 与第八讲版本相同。

## 数据与默认规模

`data/tasks.json` 保存 task_id、card_id、keyword、category；`data/cards.json` 保存工具查询的三张卡片；`grader/answers.json` 保存人工核对的整数标签。答案 0 合法，布尔值不能冒充整数答案。

`data/eval_config.json` 的默认设置为：budget2 上限 2 次逻辑请求，budget3 上限 3 次；工具上限 2；单次输出上限 512 token；请求超时 30 秒；离线每项重复 2 次；真实任务 T01、T02 各重复 1 次；运行顺序种子 20260926。

默认离线计划为 6 × 2 × 2 = 24 个 trial，预算总和 60，实际执行 51 次逻辑请求、0 次网络尝试。真实预实验为 2 × 2 × 1 = 4 个 trial，最多 10 次 API 请求。真实和离线各自创建批次。

模板只允许固定预算 2/3，重复次数 1 或 2，任务集合 1 至 20 项，真实任务最多选择其中 2 项。修改任务时须同步答案，并人工核对标签；原始六任务的预设故障按 task_id 与 repeat 指定，新增任务不自动形成有代表性的测试集。

顺序种子只控制本地排列；它不固定远端大模型响应。运行顺序不会改变默认离线脚本。每个 trial 都从新的消息列表和客户端开始。

## 从计划追到原始证据

每批有 `plan.json`，包含模式、UTC 时间、Python 版本、代码 SHA-256、任务与卡片及答案快照、配置、最大逻辑请求总数，以及全部计划项。程序在任何模型尝试前写入它。

例如 `T01__budget3__r02` 表示任务 T01、上限 3、第二次完整尝试。它不表示第三次请求或第二轮工具。

每项输出位于 `trials/<trial_id>/`：

- `record.json`：计划标识、任务/配置/重复号、模式、原始运行路径、控制器结果和最终评分。
- `data/`：该次运行的任务与卡片；离线模式另含作者响应脚本。
- `outputs/run_001/`：请求、响应、消息、事件、结果与快照。先查 `record.json` 的 `raw_run`，再按其中相对路径进入。

`record.result` 中，`completed` 表示控制器认可流程完成，`tools_completed` 表示工具完成，`final_verified` 表示最终答案通过控制器核验。`record.grade.success` 再要求最终字典与冻结标签完全一致。控制器最终核验与标签评分承担不同职责，但它们仍可能共享错误；标签和评分代码都需要人工检查。

真实模式的最初 user 消息只有 card_id 和 keyword，不发送预先答案标签。后续工具返回的真实统计结果可以回传。**离线响应工厂会读取标签来编写脚本**，因此离线数字只验证机制，不能作为模型评测证据。

代码与计划哈希有助于发现意外错配，不是安全沙箱或完整的防篡改证明。汇总器不重新执行全部原始事件，也不能仅靠哈希证明标签正确。

## 指标的明确口径

设计划数 N、已评分数 G、成功数 S、缺失数 M=N−G。

| 指标 | 定义与边界 |
| --- | --- |
| `coverage` | G/N，记录覆盖率 |
| `success_rate` | S/G；G=0 时是 None，不填 0% 或 100% |
| `lower_bound`、`upper_bound` | S/N 与 (S+M)/N，表示把缺失分别视为失败或成功的范围；不是统计置信区间 |
| `per_task` | 每个任务自己的计划、已评分、成功、缺失与比例 |
| `macro_success_on_complete_tasks` | 对重复记录全部齐全的任务，取逐任务成功率的等权平均 |
| `fully_observed_tasks` | 上述宏平均及下面两项的任务分母 |
| `any_success_task_rate` | 完整任务中，至少有一次成功的任务占比 |
| `all_success_task_rate` | 完整任务中，每次都成功的任务占比 |
| `difference_on_paired` | 完整配对中，(仅 budget3 成功数 − 仅 budget2 成功数)/配对数 |

一对由相同 task_id 与 repeat 的两种配置组成。一边缺失，整对不进入差值计算，但报告仍列出缺失配对数。只有记录齐全时，默认 12 对的差值才覆盖完整计划。

默认 budget3 的成功数按任务为 2、2、1、1、1、1。合并运行成功率是 8/12；至少一次成功的任务占比是 6/6；每次成功的任务占比是 2/6。它们的分母不同。

缺失练习副本中，budget3 有 11 条已评分记录，成功 8 条；其已评分成功率为 8/11，覆盖率为 11/12，完整计划范围为 8/12 至 9/12。任务宏平均等指标此时只使用 5 个重复齐全的任务，不能隐去这个分母变化。

## 资源计数与未知信息

`model_requests_known_total` 是已评分 trial 的逻辑请求总数，包括失败请求；`network_attempts_known_total` 是实际发起网络传输的已知次数；`tool_calls_known_total` 是实际工具执行次数。缺失 trial 的资源不在这些已知合计内。

离线网络尝试为 0，token 为 None，usage_status 为 not_applicable。真实用量有 complete、partial、unavailable 状态；`known_tokens` 只合计已获得的用量，不把未知填零。费用字段始终为 None，需自行核对账单。512 是每次输出 token 上限，不能视为整个任务的费用上限。

## 失败、缺失与重新执行

有效 record 中 grade.success=false 是已评分失败；原计划有该项但缺少有效记录，则是缺失。格式损坏、计划错配、重复或来源混杂会被拒绝，需要核查，程序不会悄悄丢弃。

真实模式遇到 HTTP_401 或 HTTP_402，第一项保留失败评分并停止整批，其余计划项保持缺失。内部捕获的 INTERRUPTED 可以形成评分记录；更早中断而未形成 record 时保持缺失。框架异常写入 `batch_error.json`，只记录异常类型，不写异常正文。

`run_evaluation.py` 的退出码：0=计划全部得到评分；2=有缺失；1=启动未完成。失败 trial 可以存在于退出码 0 的批次中。

重新汇总只读取原 plan 与原 record，新建 `analysis_NNN`。重新运行则从空状态创建 `batch_NNN`，没有续跑、自动重试或自动合并。不要多个进程同时写同一 outputs。

`audit_demo.py` 只在新副本中移除一条评分记录，保留该条原始轨迹；原批次不变。重复演示在内存里完成，不写重复记录到原目录。

## 本讲的科研边界

六任务共享三张卡片，重复脚本也由作者指定；没有保留测试集，样本不覆盖广泛的智能体应用。增加一次预算验证的是本课固定机制，不是相同资源条件下的新方法比较。本课不进行显著性检验，也不从这些数字推断真实模型的总体成功率。
