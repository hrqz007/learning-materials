# 第9讲：智能体系统评测与对照实验

本讲承接第八讲的工具调用闭环，学习把一次成功变成一份可以复查的评测报告。先固定任务与计划，再运行、评分和汇总，最后回到原始轨迹解释结果。

## 从这里开始

1. 完整解压压缩包，在本地 VS Code 打开 `Agent_Systems_Lesson09` 文件夹。
2. 阅读 `materials/01_Lecture.pdf` 的第 1 至 7 节，理解 task、trial、模型请求和评分的区别。
3. 跟随 `materials/02_Lab_Guide.pdf` 运行默认离线实验，再完成缺失记录练习。
4. 填写 `materials/05_Worksheet.docx`，完成 `03_Exercises.pdf`，最后核对 `04_Answers.pdf`。
5. 想读源码时，从 `CODE_GUIDE.md` 开始。真实 API 预实验是选做内容，不影响必做实验的完成。

PDF 便于阅读；同名 DOCX 便于修改与做笔记。蓝色解释概念，绿色标出证据，橙色提示易混淆之处，标题保持黑色；颜色之外也有文字说明。

## 材料清单

| 文件或目录 | 内容 |
| --- | --- |
| `materials/01_Lecture.pdf` 与 `.docx` | 18 页彩色学习讲义，含 4 张教学图 |
| `materials/02_Lab_Guide.pdf` 与 `.docx` | 8 页实验设计书与操作步骤 |
| `materials/03_Exercises.pdf` 与 `.docx` | 4 页练习，18 题，共 100 分 |
| `materials/04_Answers.pdf` 与 `.docx` | 5 页参考答案、解析与评分要点 |
| `materials/05_Worksheet.pdf` 与 `.docx` | 2 页实验记录表；DOCX 可编辑，PDF 可打印 |
| `code/` | 12 个 Python 源文件，含练习起始代码和完整答案 |
| `data/` 与 `grader/` | 卡片、六个任务、配置和预先核对的答案 |
| `figures/` | 4 张独立 PNG 教学图 |
| `examples/offline_baseline/` | 实际执行产生的默认离线计划、24 条评分记录与原始轨迹 |
| `outputs/` | 你运行后产生的新批次与练习副本 |
| `VALIDATION.md` 与 `validation_results.json` | 材料核验范围与程序检查结果 |

五份文档合计 37 页，PDF 与 DOCX 为同一套内容的两种格式。

## 第一次运行

沿用已有的本地 Python 环境，无需新装依赖、GPU 或 Hadoop 服务。源码仅使用 Python 标准库；`code/requirements.txt` 是说明文件。

如果使用已有 Anaconda 环境，在 Anaconda Prompt 执行：

```bat
conda activate agent-study
cd /d "C:\AgentStudy\Agent_Systems_Lesson09"
python --version
python code\run_evaluation.py
```

将路径改为实际解压位置。若沿用第二讲的 `.venv`，且两个课程文件夹同在 `C:\AgentStudy` 下，在 PowerShell 执行：

```powershell
cd "C:\AgentStudy\Agent_Systems_Lesson09"
..\Agent_Systems_Lesson02\.venv\Scripts\python.exe code\run_evaluation.py
```

Linux 或 macOS 在已有环境、本课根目录执行 `python code/run_evaluation.py`。后续命令里的 `python` 均指你选定的解释器。

**默认是离线模式，不需要密钥，不产生 API 调用费用。** 模型响应是作者编写的固定脚本，本地工具会实际运行。这些数据用于理解评测机制，不能当作真实模型成绩。

运行完成后，以终端打印的目录为准，打开类似 `outputs/batch_001/analysis_001/report.md` 的文件。在 VS Code 中可打开 Markdown 预览。再次运行会创建新批次，不覆盖或续跑旧批次。

| 默认核对项 | budget2 | budget3 |
| --- | --- | --- |
| 计划与已评分次数 | 12 / 12 | 12 / 12 |
| 成功次数 | 0 | 8 |
| 完整批次成功率 | 0% | 66.67% |
| 逻辑请求总数 | 21 | 30 |
| 实际工具执行总数 | 18 | 18 |
| 真实网络尝试总数 | 0 | 0 |

命令正常退出并不意味着智能体每次都成功：本讲退出码 0 表示全部计划项都已得到评分。

## 接着完成两个动作

```bat
python code\report_batch.py outputs\batch_001
python code\audit_demo.py outputs\batch_001
```

第一条只重新汇总，生成 `analysis_002` 等新目录。第二条创建练习副本并移除副本中的一条失败评分记录，观察已评分成功率从 66.67% 变为 72.73%，同时记录覆盖率下降。原批次保留。请将命令中的批次名换为自己的实际目录名。

编程练习：复制 `code/practice_starter.py` 为 `code/my_practice.py`，完成第 16 题，再核对 `practice_answer.py`。

## 选做真实预实验

先完成离线实验，再阅读实验设计书第 6 节。`python code\run_evaluation.py --live` 默认创建独立批次，运行 T01、T02 各两种预算，共 4 次完整尝试、最多 10 次 API 请求。使用自己的有效账户，在本地终端隐藏输入密钥。

本材料制作时没有调用真实供应商账户。真实结果、网络、模型可用性和费用需以你的实际记录与账单为准；不照抄离线分数。程序没有自动重试、断点续跑或并发调度。

完成标志：你能解释 8/12、6/6、2/6 分别回答什么问题，能区分失败与缺失，并用一条原始轨迹支撑自己的实验结论。
