"""沿用第八讲的单次闭环核心，由第九讲批量入口调用。"""
import getpass
import hashlib
import json
import sys
import time
import warnings
from datetime import datetime, timezone
from pathlib import Path

from model_client import LiveClient, OfflineClient, ProviderError, ENDPOINT
from protocol import (ProtocolError, strict_json, initial_messages, build_request,
                      select_message, inspect_call, make_tool_message, verify_final)
from toolbox import dispatch



def read_json(path):
    return strict_json(path.read_text(encoding="utf-8"))


def write_json(path, data):
    with path.open("x", encoding="utf-8") as handle:
        json.dump(data, handle, ensure_ascii=False, indent=2, allow_nan=False)


def validate_inputs(config, goal, cards):
    expected = {"case_id", "model", "max_model_requests", "max_tool_calls",
                "max_output_tokens", "timeout_seconds"}
    if type(config) != dict or set(config) != expected:
        raise ValueError("config.json 的字段与教材模板不一致")
    for key in ("case_id", "model"):
        if type(config[key]) != str or not config[key].strip():
            raise ValueError(f"{key} 必须为非空字符串")
    ranges = {"max_model_requests": (0, 6), "max_tool_calls": (0, 2),
              "max_output_tokens": (64, 2048), "timeout_seconds": (1, 120)}
    for key, (low, high) in ranges.items():
        if type(config[key]) != int or not low <= config[key] <= high:
            raise ValueError(f"{key} 必须是 {low} 到 {high} 之间的整数")
    if type(goal) != dict or set(goal) != {"card_id", "keyword"}:
        raise ValueError("任务必须且只能含 card_id 和 keyword")
    if any(type(value) != str or not value.strip() for value in goal.values()):
        raise ValueError("任务中的两个值都必须是非空字符串")
    if type(cards) != dict:
        raise ValueError("卡片库应是字典")
    for name, card in cards.items():
        if type(name) != str or not name.strip() or type(card) != dict:
            raise ValueError("卡片编号或记录类型不正确")
        if set(card) != {"title", "text"} or any(type(v) != str for v in card.values()):
            raise ValueError("卡片必须含字符串 title 和 text")


def next_run(root):
    output = root / "outputs"
    output.mkdir(exist_ok=True)
    number = 1
    while (output / f"run_{number:03d}").exists():
        number += 1
    folder = output / f"run_{number:03d}"
    folder.mkdir()
    (folder / "requests").mkdir()
    (folder / "responses").mkdir()
    (folder / "events.jsonl").touch()
    return folder


def append_event(folder, event):
    with (folder / "events.jsonl").open("a", encoding="utf-8") as handle:
        handle.write(json.dumps(event, ensure_ascii=False, allow_nan=False) + "\n")


def usage_record(response):
    """用量缺失或不合约时返回 None，绝不把未知用量填成零。"""
    usage = response.get("usage") if type(response) == dict else None
    if type(usage) != dict:
        return None
    fields = ("prompt_tokens", "completion_tokens", "total_tokens")
    if any(type(usage.get(k)) != int or usage[k] < 0 for k in fields):
        return None
    if usage["prompt_tokens"] + usage["completion_tokens"] != usage["total_tokens"]:
        return None
    return {key: usage[key] for key in fields}


def summarize_usage(records, attempts, mode):
    if mode == "offline":
        return {"status": "not_applicable", "covered_responses": 0,
                "all_attempts_covered": False, "known_totals": None}
    good = [record for record in records if record is not None]
    totals = None
    if good:
        totals = {key: sum(row[key] for row in good) for key in good[0]}
    complete = attempts > 0 and len(good) == attempts
    status = "complete" if complete else ("partial" if good else "unavailable")
    return {"status": status, "covered_responses": len(good),
            "all_attempts_covered": complete, "known_totals": totals}


def run_and_save(root, config, *, live=False, client_override=None):
    """一轮进程内自动闭环；重开程序从零运行，不是恢复断点。"""
    goal = read_json(root / "data/task.json")
    cards = read_json(root / "data/cards.json")
    validate_inputs(config, goal, cards)
    mode = "live" if live else "offline"
    frames = None
    if live:
        if client_override is None:
            print("即将连接官方 API，可能按实际用量收费。密钥只在本次进程内使用。")
            # 回显不可关闭时直接停止，避免 getpass 降级成明文输入。
            with warnings.catch_warnings():
                warnings.simplefilter("error", getpass.GetPassWarning)
                key = getpass.getpass("输入 DeepSeek API Key（不会显示）：")
            client = LiveClient(key, config["timeout_seconds"])
        else:
            client = client_override  # 只供隔离验证替换传输层。
    else:
        cases = read_json(root / "data/offline_cases.json")
        if config["case_id"] not in cases:
            raise ValueError("case_id 不在离线样例列表中")
        frames = cases[config["case_id"]]["frames"]
        client = client_override or OfflineClient(frames)
    folder = next_run(root)
    started = datetime.now(timezone.utc).isoformat()
    hashes = {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
              for p in sorted(Path(__file__).resolve().parent.glob("*.py"))}
    source = "live_api" if live else "author_fixture"
    write_json(folder / "input_snapshot.json", {
        "started_at_utc": started, "mode": mode, "source": source,
        "endpoint": ENDPOINT if live else None, "config": config,
        "goal": goal, "cards": cards, "offline_frames": frames,
        "python_version": sys.version, "code_sha256": hashes,
    })
    messages = initial_messages(goal)
    state = {"card": None, "count": None}
    seen_ids, usages, returned_models = set(), [], []
    model_requests, tool_calls, received_responses = 0, 0, 0
    final_verified, final_answer = False, None
    stop_reason = "MODEL_BUDGET"

    while model_requests < config["max_model_requests"]:
        tools_completed = state["card"] is not None and state["count"] is not None
        # 工具预算不足且还需要工具时，提前停，不再请求模型。
        if not tools_completed and tool_calls >= config["max_tool_calls"]:
            stop_reason = "TOOL_BUDGET"
            break
        payload = build_request(messages, config, tools_completed)
        model_requests += 1
        number = model_requests
        write_json(folder / "requests" / f"request_{number:03d}.json", payload)
        event = {"request_number": number, "tool_called": False, "observation": None}
        before = time.perf_counter()
        try:
            raw_text = client.complete(payload)
            event["elapsed_ms"] = round((time.perf_counter() - before) * 1000, 3)
            received_responses += 1
            # 保存服务端返回的 UTF-8 文本，不保存认证头。
            (folder / "responses" / f"response_{number:03d}.txt").write_text(raw_text, encoding="utf-8")
            try:
                response = strict_json(raw_text)
            except (ValueError, RecursionError, UnicodeError):
                raise ProtocolError("RESPONSE_JSON_ERROR", "响应正文不是本课允许的 JSON") from None
            usages.append(usage_record(response))
            if type(response) == dict and type(response.get("model")) == str:
                returned_models.append(response["model"])
            assistant, call = select_message(response, seen_ids)
            event["finish_reason"] = response["choices"][0]["finish_reason"]
            # 先保留模型提出调用的 assistant 消息，再加入对应 tool 结果。
            messages.append(assistant)
            if call is None:
                final_verified, stop_reason, final_answer = verify_final(assistant["content"], goal, state)
                event.update({"kind": "final", "verified": final_verified, "reason": stop_reason})
            else:
                decision = inspect_call(call, goal, state)
                event.update({"kind": "tool", "call_id": call["id"], "decision": decision})
                if not decision["accepted"]:
                    stop_reason = decision["error"]["code"]
                else:
                    seen_ids.add(call["id"])
                    observation = dispatch(decision["action"], cards)
                    event["tool_called"] = observation["tool_called"]
                    event["observation"] = observation
                    if observation["tool_called"]:
                        tool_calls += 1
                    messages.append(make_tool_message(call["id"], observation))
                    if not observation["ok"]:
                        stop_reason = observation["error"]["code"]
                    elif decision["action"]["tool"] == "lookup_card":
                        state["card"] = observation["data"]
                    else:
                        state["count"] = observation["data"]["count"]
                event["state_after"] = {"card_loaded": state["card"] is not None, "count": state["count"]}
            append_event(folder, event)
            if call is None:
                break
            if not decision["accepted"] or not event["observation"]["ok"]:
                break
        except (ProviderError, ProtocolError) as exc:
            stop_reason = exc.code
            event.update({"kind": "error", "stage": "provider" if isinstance(exc, ProviderError) else "protocol",
                          "error": {"code": exc.code, "message": exc.message},
                          "elapsed_ms": round((time.perf_counter() - before) * 1000, 3)})
            append_event(folder, event)
            break
        except KeyboardInterrupt:
            stop_reason = "INTERRUPTED"
            event.update({"kind": "error", "stage": "client", "error": {"code": stop_reason,
                          "message": "用户中止等待，服务端是否处理未知"}})
            append_event(folder, event)
            break

    tools_completed = state["card"] is not None and state["count"] is not None
    result = {
        "mode": mode, "source": source, "stop_reason": stop_reason,
        "tools_completed": tools_completed, "final_verified": final_verified,
        "completed": tools_completed and final_verified,
        "model_requests": model_requests, "network_attempts": client.network_attempts,
        "received_responses": received_responses, "tool_calls": tool_calls,
        "observed_count": state["count"], "final_answer": final_answer,
        "returned_models": returned_models,
        "usage_summary": summarize_usage(usages, model_requests, mode),
        "billing_amount": None,
    }
    write_json(folder / "messages.json", messages)
    write_json(folder / "result.json", result)
    with (folder / "summary.txt").open("x", encoding="utf-8") as handle:
        for key in ["mode", "source", "stop_reason", "tools_completed", "final_verified", "completed",
                    "model_requests", "network_attempts", "tool_calls", "observed_count"]:
            handle.write(f"{key}: {result[key]}\n")
        handle.write("费用以服务商账单为准；程序不把未知用量或未知费用记为零。\n")
    return folder, result

