"""在新副本里演示缺失与重复记录，不修改原批次。"""
import argparse
import shutil
from pathlib import Path
from agent_core import read_json
from evaluation import summarize
from report_batch import save_report

ROOT = Path(__file__).resolve().parent.parent


def make_demo(root, source):
    plan = read_json(source / "plan.json")
    if plan["mode"] != "offline":
        raise ValueError("本练习只使用人工离线批次")
    selected = source / "trials/T03__budget3__r02/record.json"
    if not selected.exists() or read_json(selected)["grade"]["success"] is not False:
        raise ValueError("请使用默认 24 次离线批次，确保指定失败记录存在")
    index = 1
    while (root / "outputs" / f"audit_demo_{index:03d}").exists():
        index += 1
    destination = root / "outputs" / f"audit_demo_{index:03d}"
    destination.mkdir()
    shutil.copy2(source / "plan.json", destination / "plan.json")
    shutil.copytree(source / "trials", destination / "trials")
    # 只移除刚创建副本中的一条汇总记录；原始轨迹保留，源批次保持不变。
    (destination / "trials/T03__budget3__r02/record.json").unlink()
    report, summary = save_report(destination)
    records = [read_json(p) for p in sorted((destination / "trials").glob("*/record.json"))]
    try:
        summarize(plan, records + [records[0]])
    except ValueError:
        duplicate_message = "重复记录被拒绝，没有被算作一次新运行。"
    else:
        raise AssertionError("重复记录检查未生效")
    (destination / "README.txt").write_text(
        "本目录是缺失记录练习副本。原批次没有修改。\n"
        "人为移除 T03__budget3__r02 的 record.json，原始轨迹仍在。\n"
        "缺失可评分汇总记录不等于没有运行，也不等于失败；应回到轨迹调查。\n" + duplicate_message + "\n", encoding="utf-8")
    print("缺失记录练习报告：", report)
    print(duplicate_message)
    return destination, summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("batch", nargs="?", default="examples/offline_baseline")
    args = parser.parse_args()
    source = Path(args.batch)
    if not source.is_absolute():
        source = ROOT / source
    make_demo(ROOT, source)
