"""独立答案核对、计划核验和汇总。这里不请求模型、不执行工具。"""
import hashlib
import json
from collections import Counter


def digest(value):
    encoded = json.dumps(value, ensure_ascii=False, sort_keys=True,
                         separators=(",", ":"), allow_nan=False).encode("utf-8")
    return hashlib.sha256(encoded).hexdigest()


def grade_result(result, task, expected_count):
    """成功同时要求流程完成和预先核对的答案一致。"""
    answer = result.get("final_answer")
    expected = {"card_id": task["card_id"], "keyword": task["keyword"],
                "count": expected_count}
    answer_ok = (type(answer) == dict and type(answer.get("count")) == int
                 and answer == expected)
    success = result.get("completed") is True and answer_ok
    reason = ("PASS" if success else
              ("GOLD_MISMATCH" if result.get("completed") is True
               else result["stop_reason"]))
    return {"success": success, "reason": reason, "answer_matches_gold": answer_ok}


def rate_summary(successes, graded, planned):
    """缺失不是零分。下上界只描述缺失记录，不是统计置信区间。"""
    if any(type(n) != int for n in (successes, graded, planned)):
        raise ValueError("计数必须是整数")
    if not 0 <= successes <= graded <= planned or planned == 0:
        raise ValueError("要求 0 <= 成功数 <= 已评分数 <= 计划数，计划数大于零")
    unknown = planned - graded
    return {"planned": planned, "graded": graded, "missing": unknown,
            "successes": successes, "coverage": graded / planned,
            "success_rate": successes / graded if graded else None,
            "lower_bound": successes / planned,
            "upper_bound": (successes + unknown) / planned}


def check_plan(plan):
    rows = plan["trials"]
    if not rows or len({r["trial_id"] for r in rows}) != len(rows):
        raise ValueError("计划为空或 trial_id 重复")
    if len({(r["task_id"], r["policy"], r["repeat"]) for r in rows}) != len(rows):
        raise ValueError("同一个任务、配置、重复编号出现多次")
    for row in rows:
        canonical = f'{row["task_id"]}__{row["policy"]}__r{row["repeat"]:02d}'
        if row["trial_id"] != canonical or row["policy"] not in ("budget2", "budget3"):
            raise ValueError("计划编号或配置不合法")
        if row["task_id"] not in plan["snapshot"]["answers"]:
            raise ValueError("计划缺少答案标签")


def validate_record(record, row, plan, task):
    """防止错配、来源混合或评分字段被无意改坏；不是防篡改沙箱。"""
    for field in ("trial_id", "task_id", "policy", "repeat"):
        if record.get(field) != row[field]:
            raise ValueError(f"记录与计划的 {field} 不一致")
    if record.get("plan_sha256") != digest(plan) or record.get("mode") != plan["mode"]:
        raise ValueError("记录来自另一计划或另一模式")
    result = record["result"]
    source = "author_fixture" if plan["mode"] == "offline" else "live_api"
    if result.get("source") != source or result.get("mode") != plan["mode"]:
        raise ValueError("记录的响应来源不一致")
    for key in ("completed", "tools_completed", "final_verified"):
        if type(result.get(key)) != bool:
            raise ValueError("完成标志必须为布尔值")
    for key in ("model_requests", "network_attempts", "tool_calls"):
        if type(result.get(key)) != int or result[key] < 0:
            raise ValueError("调用计数应为非负整数")
    budget = plan["snapshot"]["config"]["policies"][row["policy"]]
    if result["model_requests"] > budget or result["tool_calls"] > 2:
        raise ValueError("记录超过计划预算")
    if result["network_attempts"] > result["model_requests"]:
        raise ValueError("网络计数与逻辑请求不一致")
    if plan["mode"] == "offline" and result["network_attempts"] != 0:
        raise ValueError("离线记录出现网络请求")
    expected_grade = grade_result(result, task, plan["snapshot"]["answers"][task["task_id"]])
    if record.get("grade") != expected_grade:
        raise ValueError("评分与冻结答案不一致")


def summarize(plan, records):
    """只按计划汇总，拒绝额外记录和重复记录；缺记录单独呈现。"""
    check_plan(plan)
    by_id = {r["trial_id"]: r for r in records}
    planned_ids = {r["trial_id"] for r in plan["trials"]}
    if len(by_id) != len(records) or not set(by_id) <= planned_ids:
        raise ValueError("出现重复记录或计划外记录")
    tasks = {t["task_id"]: t for t in plan["snapshot"]["tasks"]}
    for row in plan["trials"]:
        if row["trial_id"] in by_id:
            validate_record(by_id[row["trial_id"]], row, plan, tasks[row["task_id"]])
    summary = {"mode": plan["mode"], "source": "author_fixture" if plan["mode"] == "offline" else "live_api",
               "groups": {}, "paired": {}, "scope": "teaching_demo_not_model_benchmark"}
    for policy in ("budget2", "budget3"):
        rows = [r for r in plan["trials"] if r["policy"] == policy]
        found = [by_id[r["trial_id"]] for r in rows if r["trial_id"] in by_id]
        good = sum(r["grade"]["success"] for r in found)
        group = rate_summary(good, len(found), len(rows))
        group["failure_reasons"] = dict(Counter(r["grade"]["reason"] for r in found if not r["grade"]["success"]))
        for key in ("model_requests", "network_attempts", "tool_calls"):
            group[key + "_known_total"] = sum(r["result"][key] for r in found)
        group["mean_model_requests_on_graded"] = (group["model_requests_known_total"] / len(found) if found else None)
        # 缺失任一次重复时，该任务不进入“至少一次/每次成功”的已完整任务分母。
        task_rows = {}
        for task_id in sorted({r["task_id"] for r in rows}):
            matching = [r for r in rows if r["task_id"] == task_id]
            observed = [by_id[r["trial_id"]] for r in matching if r["trial_id"] in by_id]
            wins = sum(r["grade"]["success"] for r in observed)
            task_rows[task_id] = rate_summary(wins, len(observed), len(matching))
        complete_tasks = [g for g in task_rows.values() if g["missing"] == 0]
        group["per_task"] = task_rows
        group["fully_observed_tasks"] = len(complete_tasks)
        group["macro_success_on_complete_tasks"] = (sum(g["success_rate"] for g in complete_tasks) / len(complete_tasks) if complete_tasks else None)
        group["any_success_task_rate"] = (sum(g["successes"] > 0 for g in complete_tasks) / len(complete_tasks) if complete_tasks else None)
        group["all_success_task_rate"] = (sum(g["successes"] == g["planned"] for g in complete_tasks) / len(complete_tasks) if complete_tasks else None)
        usage = [r["result"]["usage_summary"] for r in found]
        known = [u["known_totals"] for u in usage if u["known_totals"] is not None]
        group["known_tokens"] = ({k: sum(u[k] for u in known) for k in ("prompt_tokens", "completion_tokens", "total_tokens")} if known else None)
        group["usage_status"] = ("not_applicable" if plan["mode"] == "offline" else
            ("complete" if found and len(found) == len(rows) and all(u["status"] == "complete" for u in usage) else ("partial" if known else "unavailable")))
        group["billing_amount"] = None
        summary["groups"][policy] = group
    pairs = {}
    for row in plan["trials"]:
        pairs.setdefault((row["task_id"], row["repeat"]), {})[row["policy"]] = by_id.get(row["trial_id"])
    outcomes = Counter({"both_pass": 0, "budget2_only": 0, "budget3_only": 0, "neither_pass": 0})
    paired_count = 0
    for pair in pairs.values():
        if not pair.get("budget2") or not pair.get("budget3"):
            continue
        paired_count += 1
        a, b = (pair[p]["grade"]["success"] for p in ("budget2", "budget3"))
        outcomes["both_pass" if a and b else "budget2_only" if a else "budget3_only" if b else "neither_pass"] += 1
    summary["paired"] = {"planned_pairs": len(pairs), "graded_pairs": paired_count,
                         "missing_pairs": len(pairs) - paired_count, **outcomes,
                         "difference_on_paired": ((outcomes["budget3_only"] - outcomes["budget2_only"]) / paired_count if paired_count else None)}
    return summary
