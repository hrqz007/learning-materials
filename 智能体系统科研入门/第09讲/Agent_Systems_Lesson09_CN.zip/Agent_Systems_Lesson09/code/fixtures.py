"""人工响应工厂：只用于离线机制实验，不是一个语言模型。"""
import json


def scenario_for(task_id, repeat):
    # 故障位置预先固定；两种预算使用同一份响应脚本。
    return {("T03", 2): "wrong_final", ("T04", 2): "early_final",
            ("T05", 1): "timeout", ("T06", 1): "multiple_calls"}.get(
                (task_id, repeat), "success")


def make_frames(task, cards, expected_count, scenario):
    """作者利用答案构造教学脚本；真实模式绝不调用本函数。"""
    goal = {k: task[k] for k in ("card_id", "keyword")}
    text = cards[task["card_id"]]["text"]
    def call(number, name, arguments):
        return {"id": f"call_{number}", "type": "function", "function": {
            "name": name, "arguments": json.dumps(arguments, ensure_ascii=False)}}
    def frame(content=None, calls=None):
        message = {"role": "assistant", "content": content}
        if calls is not None:
            message["tool_calls"] = calls
        return {"response": {"model": "author-fixture-not-a-model", "usage": None,
                "choices": [{"index": 0, "message": message,
                             "finish_reason": "tool_calls" if calls else "stop"}]}}
    first = call(1, "lookup_card", {"card_id": task["card_id"]})
    second = call(2, "count_keyword", {"text": text, "keyword": task["keyword"]})
    final = {**goal, "count": expected_count + (1 if scenario == "wrong_final" else 0)}
    if scenario == "timeout":
        return [{"error": "TIMEOUT"}]
    if scenario == "multiple_calls":
        return [frame(calls=[first, second])]
    if scenario == "early_final":
        return [frame(content=json.dumps(final, ensure_ascii=False))]
    return [frame(calls=[first]), frame(calls=[second]),
            frame(content=json.dumps(final, ensure_ascii=False))]
