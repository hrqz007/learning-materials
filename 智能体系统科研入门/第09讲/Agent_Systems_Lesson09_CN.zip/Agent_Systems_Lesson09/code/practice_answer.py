"""第 16 题参考答案；这一函数不负责补齐计划或处理缺失。"""


def observed_success_rate(records):
    """records 是已评分记录；每条 success 必须是 bool，空列表返回 None。"""
    for record in records:
        if type(record.get("success")) != bool:
            raise ValueError("success 必须为布尔值")
    if not records:
        return None
    successes = sum(record["success"] for record in records)
    return successes / len(records)


if __name__ == "__main__":
    print(observed_success_rate([{"success": True}, {"success": False}, {"success": True}]))
    print(observed_success_rate([]))
