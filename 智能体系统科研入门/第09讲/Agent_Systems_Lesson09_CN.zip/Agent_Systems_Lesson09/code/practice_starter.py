"""第 16 题：先补全再看答案。本文件不联网。"""


def observed_success_rate(records):
    """records 是已评分记录；每条 success 必须是 bool，空列表返回 None。"""
    # TODO：验证每条记录的 success 类型；计算成功数 / 已评分数。
    return None


if __name__ == "__main__":
    print(observed_success_rate([{"success": True}, {"success": False}, {"success": True}]))
    print(observed_success_rate([]))
