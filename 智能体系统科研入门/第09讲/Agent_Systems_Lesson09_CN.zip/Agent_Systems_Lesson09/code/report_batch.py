"""重新汇总已有批次，不重新运行智能体。生成可读的 Markdown 报告。"""
import argparse
from pathlib import Path
from agent_core import read_json, write_json
from evaluation import summarize

ROOT = Path(__file__).resolve().parent.parent


def percent(value):
    return "未知" if value is None else f"{value * 100:.2f}%"


def load_and_summarize(batch):
    plan = read_json(batch / "plan.json")
    expected = {r["trial_id"] for r in plan["trials"]}
    paths = sorted((batch / "trials").glob("*/record.json"))
    if any(p.parent.name not in expected for p in paths):
        raise ValueError("存在计划外运行目录，请核查；程序不会悄悄丢弃")
    records = []
    for path in paths:
        record = read_json(path)
        if record.get("trial_id") != path.parent.name:
            raise ValueError("目录名与记录编号不一致")
        records.append(record)
    return summarize(plan, records)


def report_text(summary):
    lines = ["# 第九讲评测结果", "", f"模式：{summary['mode']}；来源：{summary['source']}。",
             "离线数据只验证程序与指标，不代表真实模型表现。缺失范围不是置信区间。", "",
             "| 配置 | 已评分/计划 | 成功数 | 已评分成功率 | 缺失情况下的范围 | 已知逻辑请求总数 |",
             "| --- | --- | --- | --- | --- | --- |"]
    for name, g in summary["groups"].items():
        lines.append(f"| {name} | {g['graded']}/{g['planned']} | {g['successes']} | {percent(g['success_rate'])} | {percent(g['lower_bound'])} 至 {percent(g['upper_bound'])} | {g['model_requests_known_total']} |")
    lines += ["", "只有覆盖全部计划时，已评分成功率才是本批完整成功率。网络尝试与逻辑请求是不同计数。", ""]
    for name, g in summary["groups"].items():
        lines += [f"## {name}", "", f"记录覆盖率：{percent(g['coverage'])}；缺失：{g['missing']}。",
                  f"每次已评分运行平均逻辑请求：{g['mean_model_requests_on_graded']}。",
                  f"已知网络尝试总数：{g['network_attempts_known_total']}；工具总数：{g['tool_calls_known_total']}。",
                  f"重复记录齐全的任务数：{g['fully_observed_tasks']}。",
                  f"至少一次成功的任务占比：{percent(g['any_success_task_rate'])}；每次都成功的任务占比：{percent(g['all_success_task_rate'])}。",
                  f"任务等权平均：{percent(g['macro_success_on_complete_tasks'])}。",
                  f"用量状态：{g['usage_status']}；已知 token：{g['known_tokens']}；费用未知，请核对账单。",
                  f"已评分失败原因：{g['failure_reasons']}", "",
                  "| 任务 | 已评分/计划 | 成功数 | 已评分成功率 |", "| --- | --- | --- | --- |"]
        for task_id, t in g["per_task"].items():
            lines.append(f"| {task_id} | {t['graded']}/{t['planned']} | {t['successes']} | {percent(t['success_rate'])} |")
    p = summary["paired"]
    lines += ["", "## 配对比较", "", f"已评分配对：{p['graded_pairs']}/{p['planned_pairs']}；缺失配对：{p['missing_pairs']}。",
              f"两者成功 {p['both_pass']}；仅 budget2 成功 {p['budget2_only']}；仅 budget3 成功 {p['budget3_only']}；两者失败 {p['neither_pass']}。",
              "budget3 减 budget2 的配对成功率差：" + ("未知" if p['difference_on_paired'] is None else f"{p['difference_on_paired'] * 100:.2f} 个百分点") + "。",
              "这是当前任务和控制策略下的观察，不能外推为所有智能体的提升。", ""]
    return "\n".join(lines)


def save_report(batch):
    summary = load_and_summarize(batch)
    # 重算也使用新目录，避免覆盖首次汇总。
    index = 1
    while (batch / f"analysis_{index:03d}").exists():
        index += 1
    destination = batch / f"analysis_{index:03d}"
    destination.mkdir()
    write_json(destination / "summary.json", summary)
    (destination / "report.md").write_text(report_text(summary), encoding="utf-8")
    return destination, summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser()
    parser.add_argument("batch", help="outputs/batch_001 等批次目录")
    args = parser.parse_args()
    target = Path(args.batch)
    if not target.is_absolute():
        target = ROOT / target
    destination, _ = save_report(target)
    print("新汇总目录：", destination)
