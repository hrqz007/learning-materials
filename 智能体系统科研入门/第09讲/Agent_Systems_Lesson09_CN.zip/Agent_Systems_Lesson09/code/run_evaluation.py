"""第九讲入口：冻结计划，隔离单次运行，逐条评分，最后汇总。"""
import argparse
import getpass
import hashlib
import random
import re
import sys
import warnings
from datetime import datetime, timezone
from pathlib import Path

from agent_core import read_json, write_json, run_and_save, validate_inputs
from model_client import LiveClient
from fixtures import make_frames, scenario_for
from evaluation import digest, grade_result
from report_batch import save_report

ROOT = Path(__file__).resolve().parent.parent


def build_plan(root, live=False):
    config = read_json(root / "data/eval_config.json")
    tasks = read_json(root / "data/tasks.json")
    cards = read_json(root / "data/cards.json")
    answers = read_json(root / "grader/answers.json")
    fields = {"model", "max_tool_calls", "max_output_tokens", "timeout_seconds", "policies",
              "offline_repeats", "live_task_ids", "live_repeats", "order_seed"}
    if type(config) != dict or set(config) != fields or config["policies"] != {"budget2": 2, "budget3": 3}:
        raise ValueError("配置须保留模板字段及预算 2/3 对照")
    for name in ("offline_repeats", "live_repeats"):
        if type(config[name]) != int or not 1 <= config[name] <= 2:
            raise ValueError("本课重复次数只允许 1 或 2")
    if type(config["order_seed"]) != int:
        raise ValueError("order_seed 应为整数")
    if type(tasks) != list or not 1 <= len(tasks) <= 20:
        raise ValueError("任务集需为 1 到 20 个任务的列表")
    ids = []
    for task in tasks:
        if type(task) != dict or set(task) != {"task_id", "card_id", "keyword", "category"}:
            raise ValueError("任务字段不符合模板")
        if type(task["task_id"]) != str or not re.fullmatch(r"T[0-9]{2}", task["task_id"]):
            raise ValueError("task_id 格式应类似 T01")
        ids.append(task["task_id"])
        goal = {k: task[k] for k in ("card_id", "keyword")}
        validate_inputs({"case_id": "selected", "model": config["model"], "max_model_requests": 3,
                         **{k: config[k] for k in ("max_tool_calls", "max_output_tokens", "timeout_seconds")}}, goal, cards)
        if task["card_id"] not in cards or type(task["category"]) != str:
            raise ValueError("任务应引用存在的卡片，并给出类别")
    if len(set(ids)) != len(ids) or type(answers) != dict or set(answers) != set(ids):
        raise ValueError("任务编号重复或答案与任务不一一对应")
    if any(type(v) != int or v < 0 for v in answers.values()):
        raise ValueError("人工核对答案应为非负整数")
    live_ids = config["live_task_ids"]
    if type(live_ids) != list or not 1 <= len(live_ids) <= 2 or len(set(live_ids)) != len(live_ids) or not set(live_ids) <= set(ids):
        raise ValueError("真实预实验只允许选择 1 到 2 个不重复的已有任务")
    selected = [t for t in tasks if not live or t["task_id"] in live_ids]
    repeats = config["live_repeats"] if live else config["offline_repeats"]
    trials = []
    for task in selected:
        for repeat in range(1, repeats + 1):
            for policy in ("budget2", "budget3"):
                trials.append({"trial_id": f'{task["task_id"]}__{policy}__r{repeat:02d}',
                               "task_id": task["task_id"], "policy": policy, "repeat": repeat,
                               "scenario": None if live else scenario_for(task["task_id"], repeat)})
    random.Random(config["order_seed"]).shuffle(trials)
    return {"lesson": 9, "mode": "live" if live else "offline",
            "created_at_utc": datetime.now(timezone.utc).isoformat(),
            "python_version": sys.version, "trials": trials,
            "max_logical_requests": sum(config["policies"][t["policy"]] for t in trials),
            "snapshot": {"config": config, "tasks": selected, "cards": cards,
                         "answers": {t["task_id"]: answers[t["task_id"]] for t in selected}},
            "code_sha256": {p.name: hashlib.sha256(p.read_bytes()).hexdigest()
                            for p in sorted((root / "code").glob("*.py"))}}


def run_batch(root, *, live=False, key=None, client_factory=None):
    """client_factory 只供本地模拟传输验证，不是用户输入的代码。"""
    plan = build_plan(root, live)
    if live and key is None and client_factory is None:
        print(f"将运行 {len(plan['trials'])} 次完整任务，最多 {plan['max_logical_requests']} 次 API 请求，可能收费。")
        with warnings.catch_warnings():
            warnings.simplefilter("error", getpass.GetPassWarning)
            key = getpass.getpass("输入自己的 DeepSeek API Key（隐藏输入）：")
    output = root / "outputs"
    output.mkdir(exist_ok=True)
    index = 1
    while (output / f"batch_{index:03d}").exists():
        index += 1
    batch = output / f"batch_{index:03d}"
    batch.mkdir()
    (batch / "trials").mkdir()
    write_json(batch / "plan.json", plan)  # 在任何模型尝试之前冻结分母。
    config = plan["snapshot"]["config"]
    tasks = {t["task_id"]: t for t in plan["snapshot"]["tasks"]}
    interrupted = False
    try:
        for row in plan["trials"]:
            task = tasks[row["task_id"]]
            trial = batch / "trials" / row["trial_id"]
            trial.mkdir()
            (trial / "data").mkdir()
            goal = {k: task[k] for k in ("card_id", "keyword")}
            write_json(trial / "data/task.json", goal)
            write_json(trial / "data/cards.json", plan["snapshot"]["cards"])
            if not live:
                frames = make_frames(task, plan["snapshot"]["cards"],
                                     plan["snapshot"]["answers"][row["task_id"]], row["scenario"])
                write_json(trial / "data/offline_cases.json", {"selected": {"frames": frames}})
            run_config = {"case_id": "selected", "model": config["model"],
                          "max_model_requests": config["policies"][row["policy"]],
                          **{k: config[k] for k in ("max_tool_calls", "max_output_tokens", "timeout_seconds")}}
            # 每次运行使用新客户端；网络计数不会从前一个 trial 继承。
            client = client_factory(row, plan) if client_factory else (LiveClient(key, config["timeout_seconds"]) if live else None)
            folder, result = run_and_save(trial, run_config, live=live, client_override=client)
            grade = grade_result(result, task, plan["snapshot"]["answers"][row["task_id"]])
            record = {**row, "mode": plan["mode"], "plan_sha256": digest(plan),
                      "raw_run": str(folder.relative_to(trial)), "result": result, "grade": grade}
            write_json(trial / "record.json", record)
            print(row["trial_id"], grade["reason"])
            if result["stop_reason"] == "INTERRUPTED":
                interrupted = True
                break
            # 认证/额度错误时整批停下，未运行的计划项保持缺失。
            if live and result["stop_reason"] in ("HTTP_401", "HTTP_402"):
                break
    except KeyboardInterrupt:
        interrupted = True  # 当前若尚未写 record，就保留为缺失。
    except Exception as exc:
        # 不把异常正文写入报告，避免不受控异常内容混入敏感信息。
        write_json(batch / "batch_error.json", {"type": type(exc).__name__,
                   "message": "评测框架未完成；保留当前目录，核查输入或源码。"})
        print("评测框架停止，未完成项保持缺失。错误类型：", type(exc).__name__)
    destination, summary = save_report(batch)
    print("汇总目录：", destination)
    if interrupted:
        print("已中止批次；远端是否仍处理请求未知。再次启动会创建新批次。")
    return batch, summary


if __name__ == "__main__":
    parser = argparse.ArgumentParser(description="默认进行人工离线评测")
    parser.add_argument("--live", action="store_true", help="只运行配置中的小规模真实预实验，可能收费")
    args = parser.parse_args()
    try:
        _, summary = run_batch(ROOT, live=args.live)
    except (ValueError, OSError, getpass.GetPassWarning, EOFError) as exc:
        print("未完成评测，请检查配置和本地终端。错误类型：", type(exc).__name__)
        raise SystemExit(1)
    except KeyboardInterrupt:
        print("已取消输入。")
        raise SystemExit(1)
    # 0 表示计划全部得到评分，不表示智能体每次都成功。
    raise SystemExit(0 if all(g["missing"] == 0 for g in summary["groups"].values()) else 2)
