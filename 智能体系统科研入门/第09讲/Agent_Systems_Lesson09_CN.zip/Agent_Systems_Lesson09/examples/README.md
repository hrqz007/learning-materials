# 示例数据来源

`offline_baseline` 是 2026-09-26 在本材料的默认配置下实际执行产生的完整离线批次：6 个任务、2 个请求预算、每组重复 2 次，共 24 条 trial 记录。目录中的时间戳、代码哈希和轨迹来自该次执行，未把人工填写的汇总表冒充程序结果。

响应内容由 `fixtures.py` 人工编写，本地卡片查询和关键词统计工具实际执行；未请求真实大模型。响应 model 为 `author-fixture-not-a-model`，结果 source 为 `author_fixture`。离线成功率不能用作真实模型成绩。

可直接打开 `offline_baseline/analysis_001/report.md` 和 `summary.json`，再按 trial_id 回查原始轨迹。budget2 为 0/12 成功、21 次逻辑请求；budget3 为 8/12 成功、30 次逻辑请求；两组各执行 18 次工具、0 次网络尝试。

本示例保留首次分析 `analysis_001`。你可以用 `report_batch.py examples/offline_baseline` 生成新的汇总目录；该动作不调用模型。无参数运行 `audit_demo.py` 会以此为来源，在 outputs 创建独立练习副本。

运行时间与耗时来自制作环境，不是模型速度测量。重新执行时，时间戳和目录编号可以不同；默认的任务结果、评分和计数应一致。
