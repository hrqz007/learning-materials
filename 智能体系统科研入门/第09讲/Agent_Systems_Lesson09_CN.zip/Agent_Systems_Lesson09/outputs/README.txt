运行 run_evaluation.py 后在此生成 batch_001 等新目录。每次从头执行，不覆盖或续跑旧批次。
